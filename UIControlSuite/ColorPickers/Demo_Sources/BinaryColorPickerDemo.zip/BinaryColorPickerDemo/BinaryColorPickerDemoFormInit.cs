﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite;
using Binarymission.WinForms.Controls.ColorPickers;
using Binarymission.WinForms.Controls.ExtendedColorPickers;

namespace BinaryColorPickerDemo
{
    public partial class BinaryColorPickerDemoForm
    {
        private SmartButton _buttonColorPicker;
        private BinaryColorPickerComboBox _binaryColorPickerComboBox1;
        private Label _label1;
        private Label _label2;
        private Label _label3;
        private Label _label4;
        private Label _label5;
        private Label _label6;
        private ComboBox _borderStyleCombobox;
        private BinaryOfficeColorPickerComboBox _binaryOfficeColorPickerComboBox1;
        private GroupBox _groupBox2;
        private BinaryColorPickerDropDown _binaryColorPickerDropDown2;
        private readonly Container _components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _components?.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BinaryColorPickerDemoForm));
            this._buttonColorPicker = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._label1 = new System.Windows.Forms.Label();
            this._label2 = new System.Windows.Forms.Label();
            this._label3 = new System.Windows.Forms.Label();
            this._borderStyleCombobox = new System.Windows.Forms.ComboBox();
            this._label4 = new System.Windows.Forms.Label();
            this._label6 = new System.Windows.Forms.Label();
            this._groupBox2 = new System.Windows.Forms.GroupBox();
            this._binaryOfficeColorPickerComboBox1 = new Binarymission.WinForms.Controls.ColorPickers.BinaryOfficeColorPickerComboBox();
            this._binaryColorPickerComboBox1 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this._binaryColorPickerDropDown2 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerDropDown();
            this._label5 = new System.Windows.Forms.Label();
            this._groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // _buttonColorPicker
            // 
            this._buttonColorPicker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._buttonColorPicker.BorderColor = System.Drawing.Color.Black;
            this._buttonColorPicker.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._buttonColorPicker.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._buttonColorPicker.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._buttonColorPicker.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._buttonColorPicker.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._buttonColorPicker.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._buttonColorPicker.ContextMenuProperties.UseGradientPainting = true;
            this._buttonColorPicker.DefaultTheme = true;
            this._buttonColorPicker.DialogResult = System.Windows.Forms.DialogResult.None;
            this._buttonColorPicker.DrawMenuButtonSeparator = true;
            this._buttonColorPicker.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._buttonColorPicker.DropDownMenuItems = null;
            this._buttonColorPicker.EndColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._buttonColorPicker.IsRenderingTheme = false;
            this._buttonColorPicker.LinearGradientRenderingAngle = 90F;
            this._buttonColorPicker.Location = new System.Drawing.Point(512, 53);
            this._buttonColorPicker.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._buttonColorPicker.MenuButtonSeparatorLineHeight = -1;
            this._buttonColorPicker.Name = "_buttonColorPicker";
            this._buttonColorPicker.PushedEndColor = System.Drawing.Color.White;
            this._buttonColorPicker.PushedStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._buttonColorPicker.Size = new System.Drawing.Size(124, 27);
            this._buttonColorPicker.StartColor = System.Drawing.Color.White;
            this._buttonColorPicker.TabIndex = 1;
            this._buttonColorPicker.Text = "Color.Empty";
            this._buttonColorPicker.TextStringFormat = null;
            this._buttonColorPicker.TransparentColor = System.Drawing.Color.Empty;
            this._buttonColorPicker.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._buttonColorPicker.UseCustomTextStringFormat = false;
            this._buttonColorPicker.UseUserDefinedColorForArrowMark = true;
            this._buttonColorPicker.UseUserDefinedColorForMenuButtonSeparator = true;
            this._buttonColorPicker.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._buttonColorPicker.Click += new System.EventHandler(this.buttonColorPicker_Click);
            // 
            // _label1
            // 
            this._label1.Location = new System.Drawing.Point(257, 21);
            this._label1.Name = "_label1";
            this._label1.Size = new System.Drawing.Size(243, 16);
            this._label1.TabIndex = 3;
            this._label1.Text = "2)   Extended Color Picker ComboBox control";
            // 
            // _label2
            // 
            this._label2.Location = new System.Drawing.Point(509, 21);
            this._label2.Name = "_label2";
            this._label2.Size = new System.Drawing.Size(192, 18);
            this._label2.TabIndex = 5;
            this._label2.Text = "3)   Color Picker Drop-down control";
            // 
            // _label3
            // 
            this._label3.Location = new System.Drawing.Point(16, 31);
            this._label3.Name = "_label3";
            this._label3.Size = new System.Drawing.Size(334, 16);
            this._label3.TabIndex = 6;
            this._label3.Text = "Set Border style for custom color boxes in Custom colors  tab page:";
            // 
            // _borderStyleCombobox
            // 
            this._borderStyleCombobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._borderStyleCombobox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._borderStyleCombobox.Items.AddRange(new object[] {
            "Sunken",
            "SunkenInner",
            "SunkenOuter",
            "Raised",
            "RaisedInner",
            "RaisedOuter",
            "Flat",
            "Etched",
            "Bump",
            "Adjust"});
            this._borderStyleCombobox.Location = new System.Drawing.Point(19, 56);
            this._borderStyleCombobox.Name = "_borderStyleCombobox";
            this._borderStyleCombobox.Size = new System.Drawing.Size(192, 24);
            this._borderStyleCombobox.TabIndex = 7;
            this._borderStyleCombobox.SelectedIndexChanged += new System.EventHandler(this.BorderStyleComboboxSelectedIndexChanged);
            // 
            // label1
            // 
            this._label4.Location = new System.Drawing.Point(16, 21);
            this._label4.Name = "_label4";
            this._label4.Size = new System.Drawing.Size(207, 16);
            this._label4.TabIndex = 12;
            this._label4.Text = "1)   Office style Color picker:";
            // 
            // label2
            // 
            this._label6.Location = new System.Drawing.Point(508, 137);
            this._label6.Name = "_label6";
            this._label6.Size = new System.Drawing.Size(334, 39);
            this._label6.TabIndex = 14;
            this._label6.Text = "However, you could use the drop-down control on any .NET control.";
            // 
            // _groupBox2
            // 
            this._groupBox2.Controls.Add(this._label3);
            this._groupBox2.Controls.Add(this._borderStyleCombobox);
            this._groupBox2.Location = new System.Drawing.Point(10, 316);
            this._groupBox2.Name = "_groupBox2";
            this._groupBox2.Size = new System.Drawing.Size(612, 96);
            this._groupBox2.TabIndex = 16;
            this._groupBox2.TabStop = false;
            this._groupBox2.Text = "Specific options applicable to color pickers (2 && 3)";
            // 
            // _binaryOfficeColorPickerComboBox1
            // 
            this._binaryOfficeColorPickerComboBox1.AlphaBlendFactorForControlPainting = 100;
            this._binaryOfficeColorPickerComboBox1.AlphaBlendFactorForDropDownPressedColor = 70;
            this._binaryOfficeColorPickerComboBox1.AlphaBlendFactorForItemSelectionColor = 70;
            this._binaryOfficeColorPickerComboBox1.AlphaValue = 255;
            this._binaryOfficeColorPickerComboBox1.BackColor = System.Drawing.SystemColors.Window;
            this._binaryOfficeColorPickerComboBox1.BlendTargetColor = System.Drawing.Color.Empty;
            this._binaryOfficeColorPickerComboBox1.BorderColor = System.Drawing.SystemColors.WindowText;
            this._binaryOfficeColorPickerComboBox1.CustomColorForRectangleBorder = System.Drawing.Color.Yellow;
            this._binaryOfficeColorPickerComboBox1.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this._binaryOfficeColorPickerComboBox1.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this._binaryOfficeColorPickerComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this._binaryOfficeColorPickerComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._binaryOfficeColorPickerComboBox1.EnableSettingAlphaValue = false;
            this._binaryOfficeColorPickerComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._binaryOfficeColorPickerComboBox1.HeadingBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(219)))), ((int)(((byte)(230)))));
            this._binaryOfficeColorPickerComboBox1.HeadingForeColor = System.Drawing.SystemColors.WindowText;
            this._binaryOfficeColorPickerComboBox1.Items.AddRange(new object[] {
            "Empty"});
            this._binaryOfficeColorPickerComboBox1.Location = new System.Drawing.Point(16, 51);
            this._binaryOfficeColorPickerComboBox1.Name = "_binaryOfficeColorPickerComboBox1";
            this._binaryOfficeColorPickerComboBox1.SelectedColor = System.Drawing.Color.Empty;
            this._binaryOfficeColorPickerComboBox1.SelectedColorRectangleBorder = System.Drawing.SystemColors.WindowText;
            this._binaryOfficeColorPickerComboBox1.ShowBorderAlways = true;
            this._binaryOfficeColorPickerComboBox1.ShowColorNameIfKnownColor = false;
            this._binaryOfficeColorPickerComboBox1.ShowHSBInToolTip = true;
            this._binaryOfficeColorPickerComboBox1.ShowToolTip = true;
            this._binaryOfficeColorPickerComboBox1.Size = new System.Drawing.Size(173, 24);
            this._binaryOfficeColorPickerComboBox1.TabIndex = 13;
            // 
            // _binaryColorPickerComboBox1
            // 
            this._binaryColorPickerComboBox1.AlphaBlendFactorForControlPainting = 100;
            this._binaryColorPickerComboBox1.AlphaBlendFactorForDropDownPressedColor = 70;
            this._binaryColorPickerComboBox1.AlphaBlendFactorForItemSelectionColor = 70;
            this._binaryColorPickerComboBox1.BackColor = System.Drawing.SystemColors.Window;
            this._binaryColorPickerComboBox1.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this._binaryColorPickerComboBox1.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this._binaryColorPickerComboBox1.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this._binaryColorPickerComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this._binaryColorPickerComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._binaryColorPickerComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._binaryColorPickerComboBox1.Items.AddRange(new object[] {
            "0, 0, 0"});
            this._binaryColorPickerComboBox1.Location = new System.Drawing.Point(257, 52);
            this._binaryColorPickerComboBox1.Name = "_binaryColorPickerComboBox1";
            this._binaryColorPickerComboBox1.SelectedColor = System.Drawing.Color.Empty;
            this._binaryColorPickerComboBox1.ShowBorderAlways = true;
            this._binaryColorPickerComboBox1.ShowColorNameIfKnownColor = true;
            this._binaryColorPickerComboBox1.Size = new System.Drawing.Size(156, 24);
            this._binaryColorPickerComboBox1.TabIndex = 2;
            // 
            // _binaryColorPickerDropDown2
            // 
            this._binaryColorPickerDropDown2.ClientSize = new System.Drawing.Size(194, 194);
            this._binaryColorPickerDropDown2.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this._binaryColorPickerDropDown2.ForeColor = System.Drawing.SystemColors.Control;
            this._binaryColorPickerDropDown2.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this._binaryColorPickerDropDown2.Name = "BinaryColorPickerDropDown";
            this._binaryColorPickerDropDown2.SelectedColor = System.Drawing.Color.White;
            this._binaryColorPickerDropDown2.ShowInTaskbar = false;
            this._binaryColorPickerDropDown2.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this._binaryColorPickerDropDown2.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this._binaryColorPickerDropDown2.Visible = false;
            this._binaryColorPickerDropDown2.BinaryColorPickerSelectedColorChanged += new System.EventHandler(this.BinaryColorPickerSelectedColorChanged);
            // 
            // _label5
            // 
            this._label5.Location = new System.Drawing.Point(509, 98);
            this._label5.Name = "_label5";
            this._label5.Size = new System.Drawing.Size(334, 32);
            this._label5.TabIndex = 15;
            this._label5.Text = "This instance of Color-picker Drop-down control is being used with our SmartButto" +
    "n .NET control.";
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(7, 16);
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BorderColorDisabledCloseCommandButton = System.Drawing.Color.Transparent;
            this.BorderColorDisabledMaximiseRestoreCommandButton = System.Drawing.Color.Transparent;
            this.BorderColorDisabledMinimizeCommandButton = System.Drawing.Color.Transparent;
            this.BorderColorNormalCloseCommandButton = System.Drawing.Color.CornflowerBlue;
            this.BorderColorNormalMaximiseRestoreCommandButton = System.Drawing.Color.CornflowerBlue;
            this.BorderColorNormalMinimizeCommandButton = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(862, 469);
            this.Controls.Add(this._groupBox2);
            this.Controls.Add(this._label5);
            this.Controls.Add(this._label6);
            this.Controls.Add(this._binaryOfficeColorPickerComboBox1);
            this.Controls.Add(this._label4);
            this.Controls.Add(this._label2);
            this.Controls.Add(this._label1);
            this.Controls.Add(this._binaryColorPickerComboBox1);
            this.Controls.Add(this._buttonColorPicker);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForegroundInternalVisualForNormalCloseCommandButton = System.Drawing.Color.Black;
            this.ForegroundInternalVisualForNormalMaximizeRestoreCommandButton = System.Drawing.Color.Black;
            this.ForegroundInternalVisualForNormalMinimizeCommandButton = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.TitlebarText = "Binarymission ExtendedColorPickers .NET Controls Demo";
            this.WindowChromeBorderColor = System.Drawing.Color.CornflowerBlue;
            this.WindowChromeEndColor = System.Drawing.Color.LightBlue;
            this.WindowChromeStartColor = System.Drawing.Color.CornflowerBlue;
            this.WindowChromeTheme = Binarymission.WinForms.Controls.ContainerControls.Windows.Enums.WindowChromeTheme.OfficeBlue;
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextFont = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold);
            this.Load += new System.EventHandler(this.FormLoaded);
            this._groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion

        [STAThread]
        private static void Main()
        {
            Application.Run(new BinaryColorPickerDemoForm());
        }
    }
}
