using System;
using System.Drawing;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryColorPickerDemo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public partial class BinaryColorPickerDemoForm : ModernChromeWindow
	{
		public BinaryColorPickerDemoForm()
		{
            Application.EnableVisualStyles();
			InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlue;
		}
        
        private void buttonColorPicker_Click(object sender, EventArgs e)
		{
			_binaryColorPickerDropDown2.Show(PointToScreen(new Point(_buttonColorPicker.Left, _buttonColorPicker.Bottom)));
        }

		private void BorderStyleComboboxSelectedIndexChanged(object sender, EventArgs e)
		{
		    var listCOntrolInstance = sender as ComboBox;
		    if (listCOntrolInstance == null) return;
		    switch(listCOntrolInstance.SelectedItem.ToString())
		    {
		        case "Sunken" : _binaryColorPickerComboBox1.CustomColorRectangleBorderStyle = Border3DStyle.Sunken;
		            _binaryColorPickerDropDown2.CustomColorRectangleBorderStyle = Border3DStyle.Sunken;
		            break;
		        case "SunkenInner" : _binaryColorPickerComboBox1.CustomColorRectangleBorderStyle = Border3DStyle.SunkenInner;
		            _binaryColorPickerDropDown2.CustomColorRectangleBorderStyle = Border3DStyle.SunkenInner;
		            break;
		        case "SunkenOuter" : _binaryColorPickerComboBox1.CustomColorRectangleBorderStyle = Border3DStyle.SunkenOuter;
		            _binaryColorPickerDropDown2.CustomColorRectangleBorderStyle = Border3DStyle.SunkenOuter;
		            break;
		        case "Raised" : _binaryColorPickerComboBox1.CustomColorRectangleBorderStyle = Border3DStyle.Raised;
		            _binaryColorPickerDropDown2.CustomColorRectangleBorderStyle = Border3DStyle.Raised;
		            break;
		        case "RaisedInner" : _binaryColorPickerComboBox1.CustomColorRectangleBorderStyle = Border3DStyle.RaisedInner;
		            _binaryColorPickerDropDown2.CustomColorRectangleBorderStyle = Border3DStyle.RaisedInner;
		            break;
		        case "RaisedOuter" : _binaryColorPickerComboBox1.CustomColorRectangleBorderStyle = Border3DStyle.RaisedOuter;
		            _binaryColorPickerDropDown2.CustomColorRectangleBorderStyle = Border3DStyle.RaisedOuter;
		            break;
		        case "Flat" : _binaryColorPickerComboBox1.CustomColorRectangleBorderStyle = Border3DStyle.Flat;
		            _binaryColorPickerDropDown2.CustomColorRectangleBorderStyle = Border3DStyle.Flat;
		            break;
		        case "Etched" : _binaryColorPickerComboBox1.CustomColorRectangleBorderStyle = Border3DStyle.Etched;
		            _binaryColorPickerDropDown2.CustomColorRectangleBorderStyle = Border3DStyle.Etched;
		            break;
		        case "Bump" : _binaryColorPickerComboBox1.CustomColorRectangleBorderStyle = Border3DStyle.Bump;
		            _binaryColorPickerDropDown2.CustomColorRectangleBorderStyle = Border3DStyle.Bump;
		            break;
		        case "Adjust" : _binaryColorPickerComboBox1.CustomColorRectangleBorderStyle = Border3DStyle.Adjust;
		            _binaryColorPickerDropDown2.CustomColorRectangleBorderStyle = Border3DStyle.Adjust;
		            break;
		    }
		}

	    private void FormLoaded(object sender, EventArgs e)
		{
			_borderStyleCombobox.SelectedIndex = 0;
            _binaryColorPickerComboBox1.ShowColorNameIfKnownColor = true;
		}

        private void BinaryColorPickerSelectedColorChanged(object sender, EventArgs e)
        {
            var selectedColor = _binaryColorPickerDropDown2.SelectedColor;
            _buttonColorPicker.Text = (selectedColor.IsKnownColor) ? selectedColor.ToKnownColor().ToString() : ("Color: " + (selectedColor.R + "," + selectedColor.G + "," + selectedColor.B));
        }
	}
}
    