﻿using System.Drawing;
using Binarymission.WinForms.Controls.TabControls;

namespace CheckedImageListBoxDemo
{
    partial class CheckedImageListBoxDemoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Drawing.StringFormat stringFormat1 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat2 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat3 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat4 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat5 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat6 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat7 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat8 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat9 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat10 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat11 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat12 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat13 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat14 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat15 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat16 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat17 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat18 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat19 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat20 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat21 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat22 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat23 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat24 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat25 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat26 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat27 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat28 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat29 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat30 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat31 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat32 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat33 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat34 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat35 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat36 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat37 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat38 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat39 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat40 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat41 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat42 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat43 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat44 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat45 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat46 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat47 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat48 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat49 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat50 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat51 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat52 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat53 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat54 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat55 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat56 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat57 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat58 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat59 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat60 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat61 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat62 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat63 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat64 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat65 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat66 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat67 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat68 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat69 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat70 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat71 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat72 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat73 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat74 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat75 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat76 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat77 = new System.Drawing.StringFormat();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CheckedImageListBoxDemoForm));
            this.label1 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.checkedImageListBox1 = new Binarymission.WinForms.Controls.AdvancedListControls.CheckedImageListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.advancedGroupBox1 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.chkItemImageClicked = new System.Windows.Forms.CheckBox();
            this.chkItemAnnotationImageClicked = new System.Windows.Forms.CheckBox();
            this.extendedLabel67 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel66 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel65 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.chkEnableItemImageAnimation = new System.Windows.Forms.CheckBox();
            this.chkEventOnItemCheckStateChanged = new System.Windows.Forms.CheckBox();
            this.extItemCheckStateChangedInfo = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel46 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.chkItemCheckUnCheckAllowedStatus = new System.Windows.Forms.CheckBox();
            this.extendedLabel6 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.btnUndefinedStateCheckAll = new System.Windows.Forms.Button();
            this.nmItemIndexProvider = new System.Windows.Forms.NumericUpDown();
            this.extendedLabel14 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel13 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.chkCheckOperationOption = new System.Windows.Forms.CheckBox();
            this.btnUncheckAll = new System.Windows.Forms.Button();
            this.btnCheckAll = new System.Windows.Forms.Button();
            this.extendedLabel15 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.chkIsEnabled = new System.Windows.Forms.CheckBox();
            this.extendedLabel12 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.cmbSelectionMode = new System.Windows.Forms.ComboBox();
            this.extendedLabel10 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.btnUnselectAll = new System.Windows.Forms.Button();
            this.extendedLabel11 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.btnSelectAll = new System.Windows.Forms.Button();
            this.extendedLabel9 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel7 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.binaryPowerTabStrip1 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip();
            this.binaryPowerTabPage3 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.btnUncheckedStateImageBrowser = new System.Windows.Forms.Button();
            this.btnCheckedStateImageBrowser = new System.Windows.Forms.Button();
            this.extendedLabel26 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel25 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.chkCheckOnClick = new System.Windows.Forms.CheckBox();
            this.chkShouldUseImageForCheckState = new System.Windows.Forms.CheckBox();
            this.extendedLabel19 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel18 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel17 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.nmCheckBoxSizeHeightProvider = new System.Windows.Forms.NumericUpDown();
            this.nmCheckBoxSizeWidthProvider = new System.Windows.Forms.NumericUpDown();
            this.chkShouldDrawCheckBoxInVisualStyle = new System.Windows.Forms.CheckBox();
            this.binaryPowerTabPage6 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.btnSidebarSelectedStateEndColor = new System.Windows.Forms.Button();
            this.btnSidebarSelectedStateStartColor = new System.Windows.Forms.Button();
            this.extendedLabel69 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel70 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.cmbSidebarGradientMode = new System.Windows.Forms.ComboBox();
            this.extendedLabel64 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.nmSidebarBorderThicknessProvider = new System.Windows.Forms.NumericUpDown();
            this.extendedLabel63 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.chkDrawSidebarBorder = new System.Windows.Forms.CheckBox();
            this.chkDrawSidebar = new System.Windows.Forms.CheckBox();
            this.nmSidebarWidthProvider = new System.Windows.Forms.NumericUpDown();
            this.btnSiderbarEndColor = new System.Windows.Forms.Button();
            this.btnSidebarBorderColor = new System.Windows.Forms.Button();
            this.btnSiderbarStartColor = new System.Windows.Forms.Button();
            this.extendedLabel45 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel49 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel50 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel62 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.binaryPowerTabPage7 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.chkItemsAnnotation = new System.Windows.Forms.CheckBox();
            this.btnItemAnnotationImagePicker = new System.Windows.Forms.Button();
            this.extendedLabel68 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.binaryPowerTabPage5 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.nmItemUnselectedBorderThicknessProvider = new System.Windows.Forms.NumericUpDown();
            this.nmItemSelectedBorderThicknessProvider = new System.Windows.Forms.NumericUpDown();
            this.chkShouldDrawItemBorder = new System.Windows.Forms.CheckBox();
            this.nmItemMouseHoverBorderThicknessProvider = new System.Windows.Forms.NumericUpDown();
            this.nmMinimumItemTopAndBottomMargin = new System.Windows.Forms.NumericUpDown();
            this.chkShouldDrawTopItemSpacingForFirstItem = new System.Windows.Forms.CheckBox();
            this.nmSpacingBetweenItemsProvider = new System.Windows.Forms.NumericUpDown();
            this.nmPaddingBetweenItemsComponentsProvider = new System.Windows.Forms.NumericUpDown();
            this.extendedLabel20 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel16 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel24 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel23 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel22 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel21 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.binaryPowerTabPage1 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.btnReadOnlyContentTextColorProvider = new System.Windows.Forms.Button();
            this.btnReadOnlyTitleTextColorProvider = new System.Windows.Forms.Button();
            this.btnItemDisabledTitleTextColorProvider = new System.Windows.Forms.Button();
            this.btnItemDisabledContentTextColorProvider = new System.Windows.Forms.Button();
            this.btnHoverTitleTextColorProvider = new System.Windows.Forms.Button();
            this.btnHoverContentTextColorProvider = new System.Windows.Forms.Button();
            this.chkEnableAlternatingColors = new System.Windows.Forms.CheckBox();
            this.nmAlternateGradientFactorProvider = new System.Windows.Forms.NumericUpDown();
            this.btnAltEndColor = new System.Windows.Forms.Button();
            this.btnItemUnselectedTitleTextColorProvider = new System.Windows.Forms.Button();
            this.btnItemUnselectedContentTextColorProvider = new System.Windows.Forms.Button();
            this.btnTitleTextColorProvider = new System.Windows.Forms.Button();
            this.btnContentTextColorProvider = new System.Windows.Forms.Button();
            this.btnAltStartColor = new System.Windows.Forms.Button();
            this.extendedLabel42 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel43 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel40 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel41 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel58 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel59 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel53 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel38 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel32 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel29 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel30 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel27 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel28 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.binaryPowerTabPage4 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.btnDisabledItemEndColor = new System.Windows.Forms.Button();
            this.btnDisabledItemStartColor = new System.Windows.Forms.Button();
            this.btnItemReadOnlyBorderColorProvider = new System.Windows.Forms.Button();
            this.btnItemReadOnlyEndColorProvider = new System.Windows.Forms.Button();
            this.btnItemReadOnlyStartColorProvider = new System.Windows.Forms.Button();
            this.btnItemSelectedEndColorProvider = new System.Windows.Forms.Button();
            this.btnItemSelectedStartColorProvider = new System.Windows.Forms.Button();
            this.nmItemMouseHoverGradientFactorProvider = new System.Windows.Forms.NumericUpDown();
            this.nmItemUnselectedColorGradientProvider = new System.Windows.Forms.NumericUpDown();
            this.nmItemSelectedColorGradientProvider = new System.Windows.Forms.NumericUpDown();
            this.btnItemUnselectedBorderColorProvider = new System.Windows.Forms.Button();
            this.btnItemSelectedBorderColorProvider = new System.Windows.Forms.Button();
            this.btnItemUnselectedEndColorProvider = new System.Windows.Forms.Button();
            this.btnItemUnselectedStartColorProvider = new System.Windows.Forms.Button();
            this.btnItemTitleFontProvider = new System.Windows.Forms.Button();
            this.btnItemContentFontProvider = new System.Windows.Forms.Button();
            this.extendedLabel33 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel31 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel51 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel37 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel39 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel35 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel36 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel34 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel48 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel47 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel52 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel44 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel56 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel57 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel54 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel55 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.binaryPowerTabPage2 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.btnTooltipTitleFontProvider = new System.Windows.Forms.Button();
            this.btnTooltipContentFontProvider = new System.Windows.Forms.Button();
            this.chkIsImageDrawnWhenUsingDefaultItemTooltip = new System.Windows.Forms.CheckBox();
            this.chkShouldShowDefaultTooltipOnItemHover = new System.Windows.Forms.CheckBox();
            this.extendedLabel60 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel61 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.chkAreItemsInFullItemView = new System.Windows.Forms.CheckBox();
            this.extVerticalScrollInfo = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel8 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extLblHoverItemInfo = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel5 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel4 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.chkVerticalScrollDetected = new System.Windows.Forms.CheckBox();
            this.chkTooltipAboutToBeDisplayed = new System.Windows.Forms.CheckBox();
            this.chkOnItemHoverChanged = new System.Windows.Forms.CheckBox();
            this.chkTooltipAboutToPopup = new System.Windows.Forms.CheckBox();
            this.extendedLabel3 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extLblCurrentSelectedIndex = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel2 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.extendedLabel1 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this.chkControlIsReadOnly = new System.Windows.Forms.CheckBox();
            this.chkSelectUponScrollIntoView = new System.Windows.Forms.CheckBox();
            this.nmDeterministicScroller = new System.Windows.Forms.NumericUpDown();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.advancedGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemIndexProvider)).BeginInit();
            this.binaryPowerTabStrip1.SuspendLayout();
            this.binaryPowerTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmCheckBoxSizeHeightProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmCheckBoxSizeWidthProvider)).BeginInit();
            this.binaryPowerTabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmSidebarBorderThicknessProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmSidebarWidthProvider)).BeginInit();
            this.binaryPowerTabPage7.SuspendLayout();
            this.binaryPowerTabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemUnselectedBorderThicknessProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemSelectedBorderThicknessProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemMouseHoverBorderThicknessProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmMinimumItemTopAndBottomMargin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmSpacingBetweenItemsProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmPaddingBetweenItemsComponentsProvider)).BeginInit();
            this.binaryPowerTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmAlternateGradientFactorProvider)).BeginInit();
            this.binaryPowerTabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemMouseHoverGradientFactorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemUnselectedColorGradientProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemSelectedColorGradientProvider)).BeginInit();
            this.binaryPowerTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmDeterministicScroller)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "CheckedImageListBox control instance:";
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.Gray;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.checkedImageListBox1);
            this.splitContainer1.Panel1MinSize = 24;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panel1);
            this.splitContainer1.Size = new System.Drawing.Size(1524, 910);
            this.splitContainer1.SplitterDistance = 490;
            this.splitContainer1.SplitterWidth = 8;
            this.splitContainer1.TabIndex = 7;
            // 
            // checkedImageListBox1
            // 
            this.checkedImageListBox1.AnnotationImageOnMouseHover = null;
            this.checkedImageListBox1.BackColor = System.Drawing.SystemColors.Window;
            this.checkedImageListBox1.CheckBoxSize = new System.Drawing.Size(16, 16);
            this.checkedImageListBox1.CheckedStateImage = null;
            this.checkedImageListBox1.CheckOnClick = false;
            stringFormat1.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat1.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat1.LineAlignment = System.Drawing.StringAlignment.Near;
            stringFormat1.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
            this.checkedImageListBox1.ContentStringFormat = stringFormat1;
            this.checkedImageListBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkedImageListBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.checkedImageListBox1.EnableItemFullView = true;
            this.checkedImageListBox1.FormattingEnabled = true;
            this.checkedImageListBox1.IsAnnotationEnabled = true;
            this.checkedImageListBox1.IsImageDrawnWhenUsingDefaultItemTooltip = false;
            this.checkedImageListBox1.IsItemCheckUncheckAllowed = true;
            this.checkedImageListBox1.IsItemSidebarBorderDrawingEnabled = true;
            this.checkedImageListBox1.IsItemSidebarDrawingEnabled = true;
            this.checkedImageListBox1.IsReadOnly = false;
            this.checkedImageListBox1.ItemAlternateEndColor = System.Drawing.Color.White;
            this.checkedImageListBox1.ItemAlternateGradientFactor = 90F;
            this.checkedImageListBox1.ItemAlternateStartColor = System.Drawing.Color.Wheat;
            this.checkedImageListBox1.ItemContentFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedImageListBox1.ItemContentTextColor = System.Drawing.Color.Black;
            this.checkedImageListBox1.ItemDisabledContentTextColor = System.Drawing.SystemColors.GrayText;
            this.checkedImageListBox1.ItemDisabledEndColor = System.Drawing.SystemColors.Window;
            this.checkedImageListBox1.ItemDisabledStartColor = System.Drawing.SystemColors.ControlLight;
            this.checkedImageListBox1.ItemDisabledTitleTextColor = System.Drawing.SystemColors.GrayText;
            this.checkedImageListBox1.ItemHeight = 16;
            this.checkedImageListBox1.ItemMouseHoverBorderColor = System.Drawing.Color.DarkBlue;
            this.checkedImageListBox1.ItemMouseHoverBorderThickness = 1;
            this.checkedImageListBox1.ItemMouseHoverContentTextForeColor = System.Drawing.Color.Blue;
            this.checkedImageListBox1.ItemMouseHoverEndColor = System.Drawing.Color.White;
            this.checkedImageListBox1.ItemMouseHoverGradientFactor = 90F;
            this.checkedImageListBox1.ItemMouseHoverStartColor = System.Drawing.Color.SkyBlue;
            this.checkedImageListBox1.ItemMouseHoverTitleForeColor = System.Drawing.Color.BlueViolet;
            this.checkedImageListBox1.ItemReadOnlyBorderColor = System.Drawing.Color.Black;
            this.checkedImageListBox1.ItemReadOnlyContentTextColor = System.Drawing.SystemColors.WindowText;
            this.checkedImageListBox1.ItemReadOnlyEndColor = System.Drawing.Color.White;
            this.checkedImageListBox1.ItemReadOnlyStartColor = System.Drawing.Color.GhostWhite;
            this.checkedImageListBox1.ItemReadOnlyTitleTextColor = System.Drawing.SystemColors.WindowText;
            this.checkedImageListBox1.ItemSelectedBorderColor = System.Drawing.Color.Red;
            this.checkedImageListBox1.ItemSelectedBorderThickness = 1;
            this.checkedImageListBox1.ItemSelectedEndColor = System.Drawing.Color.White;
            this.checkedImageListBox1.ItemSelectedGradientFactor = 90F;
            this.checkedImageListBox1.ItemSelectedStartColor = System.Drawing.Color.LightSalmon;
            this.checkedImageListBox1.ItemSpacing = 6;
            this.checkedImageListBox1.ItemTitleFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.checkedImageListBox1.ItemTitleTextColor = System.Drawing.Color.Brown;
            this.checkedImageListBox1.ItemTooltipContentFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedImageListBox1.ItemTooltipTitleFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.checkedImageListBox1.ItemUnselectedBorderColor = System.Drawing.Color.BurlyWood;
            this.checkedImageListBox1.ItemUnselectedBorderThickness = 1;
            this.checkedImageListBox1.ItemUnselectedContentTextColor = System.Drawing.Color.Brown;
            this.checkedImageListBox1.ItemUnselectedEndColor = System.Drawing.Color.White;
            this.checkedImageListBox1.ItemUnselectedGradientFactor = 270F;
            this.checkedImageListBox1.ItemUnselectedStartColor = System.Drawing.Color.NavajoWhite;
            this.checkedImageListBox1.ItemUnselectedTitleTextColor = System.Drawing.Color.Black;
            this.checkedImageListBox1.Location = new System.Drawing.Point(0, 0);
            this.checkedImageListBox1.Margin = new System.Windows.Forms.Padding(8);
            this.checkedImageListBox1.MinimumItemTopAndBottomMargin = 10;
            this.checkedImageListBox1.Name = "checkedImageListBox1";
            this.checkedImageListBox1.PaddingBetweenItemComponents = 8;
            this.checkedImageListBox1.ShouldAnimateItemImage = false;
            this.checkedImageListBox1.ShouldDrawCheckBoxInVisualStyle = true;
            this.checkedImageListBox1.ShouldDrawItemBorder = true;
            this.checkedImageListBox1.ShouldDrawTopItemSpacingForFirstItem = false;
            this.checkedImageListBox1.ShouldEnableAlternatingColors = false;
            this.checkedImageListBox1.ShouldExpandItemFullViewUponClick = false;
            this.checkedImageListBox1.ShouldRefreshBasedOnMessage = true;
            this.checkedImageListBox1.ShouldShowDefaultTooltipOnItemHover = false;
            this.checkedImageListBox1.ShouldUseImageForCheckState = false;
            this.checkedImageListBox1.SidebarBorderThickness = 1;
            this.checkedImageListBox1.SidebarGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.checkedImageListBox1.SidebarItemHoveredStateBorderColor = System.Drawing.Color.Black;
            this.checkedImageListBox1.SidebarItemHoveredStateEndColor = System.Drawing.Color.CornflowerBlue;
            this.checkedImageListBox1.SidebarItemHoveredStateStartColor = System.Drawing.Color.RoyalBlue;
            this.checkedImageListBox1.SidebarItemSelectedStateBorderColor = System.Drawing.Color.Black;
            this.checkedImageListBox1.SidebarItemSelectedStateEndColor = System.Drawing.Color.BurlyWood;
            this.checkedImageListBox1.SidebarItemSelectedStateStartColor = System.Drawing.Color.Brown;
            this.checkedImageListBox1.SidebarWidth = 12;
            this.checkedImageListBox1.Size = new System.Drawing.Size(490, 910);
            this.checkedImageListBox1.TabIndex = 4;
            stringFormat2.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat2.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat2.LineAlignment = System.Drawing.StringAlignment.Near;
            stringFormat2.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
            this.checkedImageListBox1.TitleStringFormat = stringFormat2;
            this.checkedImageListBox1.UncheckedStateImage = null;
            this.checkedImageListBox1.SelectedIndexChanged += new System.EventHandler(this.CheckedImageListBoxSelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.advancedGroupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1026, 910);
            this.panel1.TabIndex = 7;
            // 
            // advancedGroupBox1
            // 
            this.advancedGroupBox1.BackgroundBrushColor1 = System.Drawing.Color.White;
            this.advancedGroupBox1.BackgroundBrushColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.advancedGroupBox1.BorderColor = System.Drawing.Color.DarkGray;
            this.advancedGroupBox1.BorderThickness = 1F;
            this.advancedGroupBox1.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal;
            this.advancedGroupBox1.Controls.Add(this.chkItemImageClicked);
            this.advancedGroupBox1.Controls.Add(this.chkItemAnnotationImageClicked);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel67);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel66);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel65);
            this.advancedGroupBox1.Controls.Add(this.chkEnableItemImageAnimation);
            this.advancedGroupBox1.Controls.Add(this.chkEventOnItemCheckStateChanged);
            this.advancedGroupBox1.Controls.Add(this.extItemCheckStateChangedInfo);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel46);
            this.advancedGroupBox1.Controls.Add(this.chkItemCheckUnCheckAllowedStatus);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel6);
            this.advancedGroupBox1.Controls.Add(this.btnUndefinedStateCheckAll);
            this.advancedGroupBox1.Controls.Add(this.nmItemIndexProvider);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel14);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel13);
            this.advancedGroupBox1.Controls.Add(this.chkCheckOperationOption);
            this.advancedGroupBox1.Controls.Add(this.btnUncheckAll);
            this.advancedGroupBox1.Controls.Add(this.btnCheckAll);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel15);
            this.advancedGroupBox1.Controls.Add(this.chkIsEnabled);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel12);
            this.advancedGroupBox1.Controls.Add(this.cmbSelectionMode);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel10);
            this.advancedGroupBox1.Controls.Add(this.btnUnselectAll);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel11);
            this.advancedGroupBox1.Controls.Add(this.btnSelectAll);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel9);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel7);
            this.advancedGroupBox1.Controls.Add(this.binaryPowerTabStrip1);
            this.advancedGroupBox1.Controls.Add(this.chkAreItemsInFullItemView);
            this.advancedGroupBox1.Controls.Add(this.extVerticalScrollInfo);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel8);
            this.advancedGroupBox1.Controls.Add(this.extLblHoverItemInfo);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel5);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel4);
            this.advancedGroupBox1.Controls.Add(this.chkVerticalScrollDetected);
            this.advancedGroupBox1.Controls.Add(this.chkTooltipAboutToBeDisplayed);
            this.advancedGroupBox1.Controls.Add(this.chkOnItemHoverChanged);
            this.advancedGroupBox1.Controls.Add(this.chkTooltipAboutToPopup);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel3);
            this.advancedGroupBox1.Controls.Add(this.extLblCurrentSelectedIndex);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel2);
            this.advancedGroupBox1.Controls.Add(this.extendedLabel1);
            this.advancedGroupBox1.Controls.Add(this.chkControlIsReadOnly);
            this.advancedGroupBox1.Controls.Add(this.chkSelectUponScrollIntoView);
            this.advancedGroupBox1.Controls.Add(this.nmDeterministicScroller);
            this.advancedGroupBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.advancedGroupBox1.DottedBorderDepth = 4;
            this.advancedGroupBox1.DottedBorderGap = 2;
            this.advancedGroupBox1.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopCenter;
            this.advancedGroupBox1.HeaderBackgroundColor1 = System.Drawing.Color.White;
            this.advancedGroupBox1.HeaderBackgroundColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.advancedGroupBox1.HeaderBackgroundLeftMargin = 3;
            this.advancedGroupBox1.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox1.HeaderBackgroundRightMargin = 4;
            this.advancedGroupBox1.HeaderBorderColor = System.Drawing.Color.Black;
            this.advancedGroupBox1.HeaderBorderThickness = 1;
            this.advancedGroupBox1.HeaderExtraHeightFactor = 8;
            this.advancedGroupBox1.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advancedGroupBox1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.advancedGroupBox1.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.advancedGroupBox1.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.advancedGroupBox1.IsHeaderBackgroundDrawingEnabled = true;
            this.advancedGroupBox1.IsHeaderBackgroundGradient = true;
            this.advancedGroupBox1.IsHeaderBorderDrawingEnabled = true;
            this.advancedGroupBox1.LinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.advancedGroupBox1.Name = "advancedGroupBox1";
            this.advancedGroupBox1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.advancedGroupBox1.RoundedCornersAngle = 60F;
            this.advancedGroupBox1.RoundedCornerTargets = ((Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets)((((Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.TopLeft | Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.TopRight) 
            | Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.BottomLeft) 
            | Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.BottomRight)));
            this.advancedGroupBox1.ShouldDrawRoundedCorners = false;
            this.advancedGroupBox1.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.advancedGroupBox1.Size = new System.Drawing.Size(1014, 910);
            this.advancedGroupBox1.TabIndex = 6;
            this.advancedGroupBox1.TabStop = false;
            this.advancedGroupBox1.Text = "Customization options ";
            this.advancedGroupBox1.TextLeftMargin = 2;
            this.advancedGroupBox1.TextRightMargin = 4;
            // 
            // chkItemImageClicked
            // 
            this.chkItemImageClicked.AutoSize = true;
            this.chkItemImageClicked.BackColor = System.Drawing.Color.Transparent;
            this.chkItemImageClicked.Location = new System.Drawing.Point(585, 512);
            this.chkItemImageClicked.Name = "chkItemImageClicked";
            this.chkItemImageClicked.Size = new System.Drawing.Size(110, 17);
            this.chkItemImageClicked.TabIndex = 62;
            this.chkItemImageClicked.Text = "ItemImageClicked";
            this.chkItemImageClicked.UseVisualStyleBackColor = false;
            this.chkItemImageClicked.CheckedChanged += new System.EventHandler(this.ItemImageClickCheckedChanged);
            // 
            // chkItemAnnotationImageClicked
            // 
            this.chkItemAnnotationImageClicked.AutoSize = true;
            this.chkItemAnnotationImageClicked.BackColor = System.Drawing.Color.Transparent;
            this.chkItemAnnotationImageClicked.Location = new System.Drawing.Point(794, 491);
            this.chkItemAnnotationImageClicked.Name = "chkItemAnnotationImageClicked";
            this.chkItemAnnotationImageClicked.Size = new System.Drawing.Size(161, 17);
            this.chkItemAnnotationImageClicked.TabIndex = 61;
            this.chkItemAnnotationImageClicked.Text = "ItemAnnotationImageClicked";
            this.chkItemAnnotationImageClicked.UseVisualStyleBackColor = false;
            this.chkItemAnnotationImageClicked.CheckedChanged += new System.EventHandler(this.ItemAnnotationImageClickedCheckedChanged);
            // 
            // extendedLabel67
            // 
            this.extendedLabel67.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel67.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel67.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel67.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel67.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel67.DropShadowMargin = 6;
            this.extendedLabel67.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel67.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel67.ForeColor = System.Drawing.Color.Black;
            this.extendedLabel67.IsBackgroundTransparent = true;
            this.extendedLabel67.Location = new System.Drawing.Point(239, 452);
            this.extendedLabel67.Name = "extendedLabel67";
            this.extendedLabel67.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel67.ShouldDrawBorder = false;
            this.extendedLabel67.ShouldDrawDropShadow = false;
            this.extendedLabel67.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel67.Size = new System.Drawing.Size(186, 19);
            this.extendedLabel67.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel67.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat3.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat3.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat3.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat3.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel67.StringFormat = stringFormat3;
            this.extendedLabel67.TabIndex = 60;
            this.extendedLabel67.TabStop = false;
            this.extendedLabel67.Text = "Check-state Setup APIs:";
            this.extendedLabel67.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel67.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel66
            // 
            this.extendedLabel66.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel66.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel66.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel66.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel66.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel66.DropShadowMargin = 6;
            this.extendedLabel66.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel66.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel66.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel66.ForeColor = System.Drawing.Color.Black;
            this.extendedLabel66.IsBackgroundTransparent = true;
            this.extendedLabel66.Location = new System.Drawing.Point(18, 449);
            this.extendedLabel66.Name = "extendedLabel66";
            this.extendedLabel66.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel66.ShouldDrawBorder = false;
            this.extendedLabel66.ShouldDrawDropShadow = false;
            this.extendedLabel66.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel66.Size = new System.Drawing.Size(126, 19);
            this.extendedLabel66.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel66.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat4.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat4.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat4.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat4.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel66.StringFormat = stringFormat4;
            this.extendedLabel66.TabIndex = 59;
            this.extendedLabel66.TabStop = false;
            this.extendedLabel66.Text = "Scrolling APIs:";
            this.extendedLabel66.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel66.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel65
            // 
            this.extendedLabel65.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel65.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel65.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel65.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel65.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel65.DropShadowMargin = 6;
            this.extendedLabel65.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel65.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel65.ForeColor = System.Drawing.Color.Black;
            this.extendedLabel65.IsBackgroundTransparent = true;
            this.extendedLabel65.Location = new System.Drawing.Point(22, 688);
            this.extendedLabel65.Name = "extendedLabel65";
            this.extendedLabel65.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel65.ShouldDrawBorder = false;
            this.extendedLabel65.ShouldDrawDropShadow = false;
            this.extendedLabel65.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel65.Size = new System.Drawing.Size(135, 19);
            this.extendedLabel65.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel65.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat5.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat5.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat5.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat5.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel65.StringFormat = stringFormat5;
            this.extendedLabel65.TabIndex = 58;
            this.extendedLabel65.TabStop = false;
            this.extendedLabel65.Text = "Selection APIs:";
            this.extendedLabel65.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel65.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // chkEnableItemImageAnimation
            // 
            this.chkEnableItemImageAnimation.BackColor = System.Drawing.Color.Transparent;
            this.chkEnableItemImageAnimation.Location = new System.Drawing.Point(23, 256);
            this.chkEnableItemImageAnimation.Name = "chkEnableItemImageAnimation";
            this.chkEnableItemImageAnimation.Size = new System.Drawing.Size(171, 24);
            this.chkEnableItemImageAnimation.TabIndex = 57;
            this.chkEnableItemImageAnimation.Text = "Enable animating Item image?";
            this.chkEnableItemImageAnimation.UseVisualStyleBackColor = false;
            this.chkEnableItemImageAnimation.CheckedChanged += new System.EventHandler(this.EnableItemImageAnimationCheckedChanged);
            // 
            // chkEventOnItemCheckStateChanged
            // 
            this.chkEventOnItemCheckStateChanged.AutoSize = true;
            this.chkEventOnItemCheckStateChanged.BackColor = System.Drawing.Color.Transparent;
            this.chkEventOnItemCheckStateChanged.Location = new System.Drawing.Point(794, 466);
            this.chkEventOnItemCheckStateChanged.Name = "chkEventOnItemCheckStateChanged";
            this.chkEventOnItemCheckStateChanged.Size = new System.Drawing.Size(145, 17);
            this.chkEventOnItemCheckStateChanged.TabIndex = 56;
            this.chkEventOnItemCheckStateChanged.Text = "ItemCheckStateChanged";
            this.chkEventOnItemCheckStateChanged.UseVisualStyleBackColor = false;
            this.chkEventOnItemCheckStateChanged.CheckedChanged += new System.EventHandler(this.ChkEventOnItemCheckStateChangedCheckedChanged);
            // 
            // extItemCheckStateChangedInfo
            // 
            this.extItemCheckStateChangedInfo.BackgroundGradientFloatAngle = 0F;
            this.extItemCheckStateChangedInfo.BorderColor = System.Drawing.Color.Black;
            this.extItemCheckStateChangedInfo.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extItemCheckStateChangedInfo.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extItemCheckStateChangedInfo.DropShadowGradientFloatAngle = 45F;
            this.extItemCheckStateChangedInfo.DropShadowMargin = 6;
            this.extItemCheckStateChangedInfo.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extItemCheckStateChangedInfo.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extItemCheckStateChangedInfo.IsBackgroundTransparent = true;
            this.extItemCheckStateChangedInfo.Location = new System.Drawing.Point(581, 773);
            this.extItemCheckStateChangedInfo.Name = "extItemCheckStateChangedInfo";
            this.extItemCheckStateChangedInfo.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extItemCheckStateChangedInfo.ShouldDrawBorder = false;
            this.extItemCheckStateChangedInfo.ShouldDrawDropShadow = false;
            this.extItemCheckStateChangedInfo.ShouldRefreshUponParentMoveResize = false;
            this.extItemCheckStateChangedInfo.Size = new System.Drawing.Size(384, 67);
            this.extItemCheckStateChangedInfo.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extItemCheckStateChangedInfo.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat6.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat6.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat6.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat6.Trimming = System.Drawing.StringTrimming.Character;
            this.extItemCheckStateChangedInfo.StringFormat = stringFormat6;
            this.extItemCheckStateChangedInfo.TabIndex = 55;
            this.extItemCheckStateChangedInfo.TabStop = false;
            this.extItemCheckStateChangedInfo.Text = "None as yet.";
            this.extItemCheckStateChangedInfo.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extItemCheckStateChangedInfo.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel46
            // 
            this.extendedLabel46.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel46.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel46.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel46.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel46.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel46.DropShadowMargin = 6;
            this.extendedLabel46.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel46.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel46.ForeColor = System.Drawing.Color.Maroon;
            this.extendedLabel46.IsBackgroundTransparent = true;
            this.extendedLabel46.Location = new System.Drawing.Point(581, 749);
            this.extendedLabel46.Name = "extendedLabel46";
            this.extendedLabel46.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel46.ShouldDrawBorder = false;
            this.extendedLabel46.ShouldDrawDropShadow = false;
            this.extendedLabel46.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel46.Size = new System.Drawing.Size(382, 20);
            this.extendedLabel46.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel46.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat7.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat7.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat7.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat7.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel46.StringFormat = stringFormat7;
            this.extendedLabel46.TabIndex = 54;
            this.extendedLabel46.TabStop = false;
            this.extendedLabel46.Text = "Event information obtained from OnItemCheckStateChanged event:";
            this.extendedLabel46.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel46.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // chkItemCheckUnCheckAllowedStatus
            // 
            this.chkItemCheckUnCheckAllowedStatus.BackColor = System.Drawing.Color.Transparent;
            this.chkItemCheckUnCheckAllowedStatus.Checked = true;
            this.chkItemCheckUnCheckAllowedStatus.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkItemCheckUnCheckAllowedStatus.Location = new System.Drawing.Point(22, 220);
            this.chkItemCheckUnCheckAllowedStatus.Name = "chkItemCheckUnCheckAllowedStatus";
            this.chkItemCheckUnCheckAllowedStatus.Size = new System.Drawing.Size(171, 31);
            this.chkItemCheckUnCheckAllowedStatus.TabIndex = 53;
            this.chkItemCheckUnCheckAllowedStatus.Text = "Allow items to be checked / unchecked?";
            this.chkItemCheckUnCheckAllowedStatus.UseVisualStyleBackColor = false;
            this.chkItemCheckUnCheckAllowedStatus.CheckedChanged += new System.EventHandler(this.ItemCheckUnCheckAllowedStatusCheckedChanged);
            // 
            // extendedLabel6
            // 
            this.extendedLabel6.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel6.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel6.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel6.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel6.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel6.DropShadowMargin = 6;
            this.extendedLabel6.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel6.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel6.ForeColor = System.Drawing.Color.Maroon;
            this.extendedLabel6.IsBackgroundTransparent = true;
            this.extendedLabel6.Location = new System.Drawing.Point(13, 70);
            this.extendedLabel6.Name = "extendedLabel6";
            this.extendedLabel6.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel6.ShouldDrawBorder = false;
            this.extendedLabel6.ShouldDrawDropShadow = false;
            this.extendedLabel6.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel6.Size = new System.Drawing.Size(200, 21);
            this.extendedLabel6.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel6.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat8.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat8.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat8.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat8.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel6.StringFormat = stringFormat8;
            this.extendedLabel6.TabIndex = 52;
            this.extendedLabel6.TabStop = false;
            this.extendedLabel6.Text = "Customize Properties";
            this.extendedLabel6.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel6.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // btnUndefinedStateCheckAll
            // 
            this.btnUndefinedStateCheckAll.Location = new System.Drawing.Point(239, 626);
            this.btnUndefinedStateCheckAll.Name = "btnUndefinedStateCheckAll";
            this.btnUndefinedStateCheckAll.Size = new System.Drawing.Size(186, 31);
            this.btnUndefinedStateCheckAll.TabIndex = 51;
            this.btnUndefinedStateCheckAll.Text = "Set CheckState to undefined";
            this.btnUndefinedStateCheckAll.UseVisualStyleBackColor = true;
            this.btnUndefinedStateCheckAll.Click += new System.EventHandler(this.UndefinedStateCheckAllItemsInCheckedImageListBoxClick);
            // 
            // nmItemIndexProvider
            // 
            this.nmItemIndexProvider.Location = new System.Drawing.Point(314, 508);
            this.nmItemIndexProvider.Maximum = new decimal(new int[] {
            49,
            0,
            0,
            0});
            this.nmItemIndexProvider.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nmItemIndexProvider.Name = "nmItemIndexProvider";
            this.nmItemIndexProvider.Size = new System.Drawing.Size(80, 20);
            this.nmItemIndexProvider.TabIndex = 50;
            this.nmItemIndexProvider.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nmItemIndexProvider.ValueChanged += new System.EventHandler(this.ItemIndexProviderValueChanged);
            // 
            // extendedLabel14
            // 
            this.extendedLabel14.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel14.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel14.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel14.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel14.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel14.DropShadowMargin = 6;
            this.extendedLabel14.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel14.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel14.ForeColor = System.Drawing.Color.Maroon;
            this.extendedLabel14.IsBackgroundTransparent = true;
            this.extendedLabel14.Location = new System.Drawing.Point(239, 565);
            this.extendedLabel14.Name = "extendedLabel14";
            this.extendedLabel14.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel14.ShouldDrawBorder = false;
            this.extendedLabel14.ShouldDrawDropShadow = false;
            this.extendedLabel14.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel14.Size = new System.Drawing.Size(186, 19);
            this.extendedLabel14.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel14.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat9.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat9.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat9.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat9.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel14.StringFormat = stringFormat9;
            this.extendedLabel14.TabIndex = 49;
            this.extendedLabel14.TabStop = false;
            this.extendedLabel14.Text = "Perform bulk CheckState:";
            this.extendedLabel14.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel14.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel13
            // 
            this.extendedLabel13.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel13.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel13.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel13.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel13.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel13.DropShadowMargin = 6;
            this.extendedLabel13.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel13.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel13.IsBackgroundTransparent = true;
            this.extendedLabel13.Location = new System.Drawing.Point(239, 509);
            this.extendedLabel13.Name = "extendedLabel13";
            this.extendedLabel13.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel13.ShouldDrawBorder = false;
            this.extendedLabel13.ShouldDrawDropShadow = false;
            this.extendedLabel13.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel13.Size = new System.Drawing.Size(69, 19);
            this.extendedLabel13.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel13.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat10.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat10.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat10.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat10.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel13.StringFormat = stringFormat10;
            this.extendedLabel13.TabIndex = 48;
            this.extendedLabel13.TabStop = false;
            this.extendedLabel13.Text = "Item index:";
            this.extendedLabel13.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel13.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // chkCheckOperationOption
            // 
            this.chkCheckOperationOption.AutoSize = true;
            this.chkCheckOperationOption.BackColor = System.Drawing.Color.Transparent;
            this.chkCheckOperationOption.Checked = true;
            this.chkCheckOperationOption.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.chkCheckOperationOption.Location = new System.Drawing.Point(244, 534);
            this.chkCheckOperationOption.Name = "chkCheckOperationOption";
            this.chkCheckOperationOption.Size = new System.Drawing.Size(152, 17);
            this.chkCheckOperationOption.TabIndex = 47;
            this.chkCheckOperationOption.Text = "Check, Uncheck or none?";
            this.chkCheckOperationOption.ThreeState = true;
            this.chkCheckOperationOption.UseVisualStyleBackColor = false;
            this.chkCheckOperationOption.CheckStateChanged += new System.EventHandler(this.CheckOperationOptionCheckStateChanged);
            // 
            // btnUncheckAll
            // 
            this.btnUncheckAll.Location = new System.Drawing.Point(335, 590);
            this.btnUncheckAll.Name = "btnUncheckAll";
            this.btnUncheckAll.Size = new System.Drawing.Size(90, 31);
            this.btnUncheckAll.TabIndex = 45;
            this.btnUncheckAll.Text = "Uncheck All";
            this.btnUncheckAll.UseVisualStyleBackColor = true;
            this.btnUncheckAll.Click += new System.EventHandler(this.UncheckAllItemsInCheckedImageListBoxClick);
            // 
            // btnCheckAll
            // 
            this.btnCheckAll.Location = new System.Drawing.Point(239, 590);
            this.btnCheckAll.Name = "btnCheckAll";
            this.btnCheckAll.Size = new System.Drawing.Size(90, 31);
            this.btnCheckAll.TabIndex = 43;
            this.btnCheckAll.Text = "Check All";
            this.btnCheckAll.UseVisualStyleBackColor = true;
            this.btnCheckAll.Click += new System.EventHandler(this.CheckAllItemsInCheckedImageListBoxClick);
            // 
            // extendedLabel15
            // 
            this.extendedLabel15.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel15.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel15.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel15.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel15.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel15.DropShadowMargin = 6;
            this.extendedLabel15.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel15.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel15.ForeColor = System.Drawing.Color.Maroon;
            this.extendedLabel15.IsBackgroundTransparent = true;
            this.extendedLabel15.Location = new System.Drawing.Point(239, 484);
            this.extendedLabel15.Name = "extendedLabel15";
            this.extendedLabel15.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel15.ShouldDrawBorder = false;
            this.extendedLabel15.ShouldDrawDropShadow = false;
            this.extendedLabel15.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel15.Size = new System.Drawing.Size(160, 19);
            this.extendedLabel15.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel15.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat11.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat11.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat11.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat11.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel15.StringFormat = stringFormat11;
            this.extendedLabel15.TabIndex = 41;
            this.extendedLabel15.TabStop = false;
            this.extendedLabel15.Text = "Set CheckState for Item(s):";
            this.extendedLabel15.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel15.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // chkIsEnabled
            // 
            this.chkIsEnabled.AutoSize = true;
            this.chkIsEnabled.BackColor = System.Drawing.Color.Transparent;
            this.chkIsEnabled.Checked = true;
            this.chkIsEnabled.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIsEnabled.Location = new System.Drawing.Point(21, 160);
            this.chkIsEnabled.Name = "chkIsEnabled";
            this.chkIsEnabled.Size = new System.Drawing.Size(116, 17);
            this.chkIsEnabled.TabIndex = 40;
            this.chkIsEnabled.Text = "Control is enabled?";
            this.chkIsEnabled.UseVisualStyleBackColor = false;
            this.chkIsEnabled.CheckedChanged += new System.EventHandler(this.CheckedImageListBoxIsEnabledCheckedChanged);
            // 
            // extendedLabel12
            // 
            this.extendedLabel12.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel12.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel12.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel12.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel12.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel12.DropShadowMargin = 6;
            this.extendedLabel12.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel12.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel12.ForeColor = System.Drawing.Color.Maroon;
            this.extendedLabel12.IsBackgroundTransparent = true;
            this.extendedLabel12.Location = new System.Drawing.Point(19, 383);
            this.extendedLabel12.Name = "extendedLabel12";
            this.extendedLabel12.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel12.ShouldDrawBorder = false;
            this.extendedLabel12.ShouldDrawDropShadow = false;
            this.extendedLabel12.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel12.Size = new System.Drawing.Size(180, 19);
            this.extendedLabel12.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel12.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat12.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat12.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat12.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat12.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel12.StringFormat = stringFormat12;
            this.extendedLabel12.TabIndex = 39;
            this.extendedLabel12.TabStop = false;
            this.extendedLabel12.Text = "Methods & Events:";
            this.extendedLabel12.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel12.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // cmbSelectionMode
            // 
            this.cmbSelectionMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectionMode.FormattingEnabled = true;
            this.cmbSelectionMode.Location = new System.Drawing.Point(23, 320);
            this.cmbSelectionMode.Name = "cmbSelectionMode";
            this.cmbSelectionMode.Size = new System.Drawing.Size(156, 21);
            this.cmbSelectionMode.TabIndex = 38;
            this.cmbSelectionMode.SelectedIndexChanged += new System.EventHandler(this.CheckedImageListBoxSelectionModeSelectedIndexChanged);
            // 
            // extendedLabel10
            // 
            this.extendedLabel10.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel10.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel10.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel10.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel10.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel10.DropShadowMargin = 6;
            this.extendedLabel10.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel10.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel10.IsBackgroundTransparent = true;
            this.extendedLabel10.Location = new System.Drawing.Point(18, 294);
            this.extendedLabel10.Name = "extendedLabel10";
            this.extendedLabel10.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel10.ShouldDrawBorder = false;
            this.extendedLabel10.ShouldDrawDropShadow = false;
            this.extendedLabel10.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel10.Size = new System.Drawing.Size(115, 20);
            this.extendedLabel10.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel10.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat13.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat13.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat13.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat13.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel10.StringFormat = stringFormat13;
            this.extendedLabel10.TabIndex = 37;
            this.extendedLabel10.TabStop = false;
            this.extendedLabel10.Text = "Set SelectionMode:";
            this.extendedLabel10.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel10.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // btnUnselectAll
            // 
            this.btnUnselectAll.Location = new System.Drawing.Point(204, 760);
            this.btnUnselectAll.Name = "btnUnselectAll";
            this.btnUnselectAll.Size = new System.Drawing.Size(90, 31);
            this.btnUnselectAll.TabIndex = 36;
            this.btnUnselectAll.Text = "Unselect All";
            this.btnUnselectAll.UseVisualStyleBackColor = true;
            this.btnUnselectAll.Click += new System.EventHandler(this.UnselectAllItemsInCheckedImageListBoxClick);
            // 
            // extendedLabel11
            // 
            this.extendedLabel11.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel11.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel11.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel11.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel11.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel11.DropShadowMargin = 6;
            this.extendedLabel11.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel11.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel11.ForeColor = System.Drawing.Color.Maroon;
            this.extendedLabel11.IsBackgroundTransparent = true;
            this.extendedLabel11.Location = new System.Drawing.Point(201, 713);
            this.extendedLabel11.Name = "extendedLabel11";
            this.extendedLabel11.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel11.ShouldDrawBorder = false;
            this.extendedLabel11.ShouldDrawDropShadow = false;
            this.extendedLabel11.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel11.Size = new System.Drawing.Size(93, 19);
            this.extendedLabel11.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel11.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat14.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat14.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat14.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat14.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel11.StringFormat = stringFormat14;
            this.extendedLabel11.TabIndex = 34;
            this.extendedLabel11.TabStop = false;
            this.extendedLabel11.Text = "Unselect All";
            this.extendedLabel11.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel11.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // btnSelectAll
            // 
            this.btnSelectAll.Location = new System.Drawing.Point(26, 760);
            this.btnSelectAll.Name = "btnSelectAll";
            this.btnSelectAll.Size = new System.Drawing.Size(90, 31);
            this.btnSelectAll.TabIndex = 33;
            this.btnSelectAll.Text = "Select All";
            this.btnSelectAll.UseVisualStyleBackColor = true;
            this.btnSelectAll.Click += new System.EventHandler(this.SelectAllItemsInCheckedImageListBoxClick);
            // 
            // extendedLabel9
            // 
            this.extendedLabel9.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel9.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel9.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel9.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel9.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel9.DropShadowMargin = 6;
            this.extendedLabel9.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel9.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel9.IsBackgroundTransparent = true;
            this.extendedLabel9.Location = new System.Drawing.Point(21, 731);
            this.extendedLabel9.Name = "extendedLabel9";
            this.extendedLabel9.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel9.ShouldDrawBorder = false;
            this.extendedLabel9.ShouldDrawDropShadow = false;
            this.extendedLabel9.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel9.Size = new System.Drawing.Size(265, 24);
            this.extendedLabel9.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel9.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat15.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat15.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat15.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat15.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel9.StringFormat = stringFormat15;
            this.extendedLabel9.TabIndex = 32;
            this.extendedLabel9.TabStop = false;
            this.extendedLabel9.Text = "(Applicable only if the Selection mode is Multiple)";
            this.extendedLabel9.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel9.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel7
            // 
            this.extendedLabel7.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel7.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel7.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel7.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel7.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel7.DropShadowMargin = 6;
            this.extendedLabel7.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel7.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel7.ForeColor = System.Drawing.Color.Maroon;
            this.extendedLabel7.IsBackgroundTransparent = true;
            this.extendedLabel7.Location = new System.Drawing.Point(22, 713);
            this.extendedLabel7.Name = "extendedLabel7";
            this.extendedLabel7.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel7.ShouldDrawBorder = false;
            this.extendedLabel7.ShouldDrawDropShadow = false;
            this.extendedLabel7.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel7.Size = new System.Drawing.Size(95, 19);
            this.extendedLabel7.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel7.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat16.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat16.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat16.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat16.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel7.StringFormat = stringFormat16;
            this.extendedLabel7.TabIndex = 31;
            this.extendedLabel7.TabStop = false;
            this.extendedLabel7.Text = "Select All";
            this.extendedLabel7.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel7.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // binaryPowerTabStrip1
            // 
            this.binaryPowerTabStrip1.Cursor = System.Windows.Forms.Cursors.Default;
            this.binaryPowerTabStrip1.CustomEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip1.CustomStartColor = System.Drawing.Color.Green;
            this.binaryPowerTabStrip1.DrawBorderAroundTabStrip = false;
            this.binaryPowerTabStrip1.DrawTabPageOnTopOfEachOther = true;
            this.binaryPowerTabStrip1.EmptySpaceLengthBeforeTheFirstTabPage = 4;
            this.binaryPowerTabStrip1.EnableAutomaticUpdateOfTabPagesHeaderSize = true;
            this.binaryPowerTabStrip1.EnableControlledLayoutRendering = false;
            this.binaryPowerTabStrip1.EnableDragAndDropOfTabPages = false;
            this.binaryPowerTabStrip1.EnableTabPageLevelCloseButtonRendering = true;
            this.binaryPowerTabStrip1.ExtendedWindowsXPRenderingFirstColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.binaryPowerTabStrip1.ExtendedWindowsXPRenderingSecondColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.binaryPowerTabStrip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabStrip1.GapBetweenTabPages = 1;
            this.binaryPowerTabStrip1.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabStrip1.HeaderTextCloseButtonExtraGap = 8;
            this.binaryPowerTabStrip1.IsBackgroundTransparent = true;
            this.binaryPowerTabStrip1.KeepShowingTooltipEvenWhenMousePointerIsMoving = false;
            this.binaryPowerTabStrip1.Location = new System.Drawing.Point(202, 95);
            this.binaryPowerTabStrip1.Name = "binaryPowerTabStrip1";
            this.binaryPowerTabStrip1.NewlyAddedPagesAreLocatedAtLeftCorner = false;
            this.binaryPowerTabStrip1.PreventInvalidation = false;
            this.binaryPowerTabStrip1.RenderFullTextForTabPageHeader = true;
            this.binaryPowerTabStrip1.SelectedPageHeaderTextIsRenderedBold = false;
            this.binaryPowerTabStrip1.ShouldAutoSizeTabs = false;
            this.binaryPowerTabStrip1.ShouldDrawTabPageHeaderInMultiLines = false;
            this.binaryPowerTabStrip1.ShouldUpdateUponParentMove = false;
            this.binaryPowerTabStrip1.ShouldUpdateUponParentResize = false;
            this.binaryPowerTabStrip1.ShowToolTip = true;
            this.binaryPowerTabStrip1.Size = new System.Drawing.Size(801, 250);
            this.binaryPowerTabStrip1.TabBottomOrientationCloseButtonPosition = Binarymission.WinForms.Controls.TabControls.CloseButtonPosition.Bottom;
            stringFormat17.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat17.FormatFlags = System.Drawing.StringFormatFlags.NoWrap;
            stringFormat17.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat17.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat17.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
            this.binaryPowerTabStrip1.TabHeaderStringFormat = stringFormat17;
            this.binaryPowerTabStrip1.TabIndex = 30;
            this.binaryPowerTabStrip1.TabPageBorderColor = System.Drawing.Color.Gray;
            this.binaryPowerTabStrip1.TabPageCloseButtonMouseEnterColor = System.Drawing.Color.Red;
            this.binaryPowerTabStrip1.TabPageCloseButtonRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPageCloseButtonRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPageCurrentSelectionIndicatorEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip1.TabPageCurrentSelectionIndicatorStartColor = System.Drawing.Color.Orange;
            this.binaryPowerTabStrip1.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.binaryPowerTabStrip1.TabPageHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPageHeaderHeight = 24;
            this.binaryPowerTabStrip1.TabPageHeaderShowsSideBar = false;
            this.binaryPowerTabStrip1.TabPageHeaderTextFontOverridesControlDefault = false;
            this.binaryPowerTabStrip1.TabPageHeaderWidth = 200;
            this.binaryPowerTabStrip1.TabPages.AddRange(new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage[] {
            this.binaryPowerTabPage3,
            this.binaryPowerTabPage6,
            this.binaryPowerTabPage7,
            this.binaryPowerTabPage5,
            this.binaryPowerTabPage1,
            this.binaryPowerTabPage4,
            this.binaryPowerTabPage2});
            this.binaryPowerTabStrip1.TabPagesCloseButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryPowerTabStrip1.TabPagesHaveGapBetweenThem = true;
            this.binaryPowerTabStrip1.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabStrip1.TabPagesOverflowCalculationStrategy = Binarymission.WinForms.Controls.TabControls.TabPagesOverflowCalculationStrategy.Pessimistic;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuDropDownColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuGlyphActiveRectangleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.binaryPowerTabStrip1.TabPagesRenderingLocation = Binarymission.WinForms.Controls.TabControls.TabPagesRenderingLocation.Top;
            this.binaryPowerTabStrip1.TabRenderingStyle = Binarymission.WinForms.Controls.TabControls.RenderingStyle.ExtendedWindowsXP;
            this.binaryPowerTabStrip1.TabsOverflowMode = Binarymission.WinForms.Controls.TabControls.OverflowMode.Menu;
            this.binaryPowerTabStrip1.Text = "Images";
            this.binaryPowerTabStrip1.ThemeBorderColorCanBeOverridden = true;
            this.binaryPowerTabStrip1.ToolTipConfiguration.AutomaticDelay = 500;
            this.binaryPowerTabStrip1.ToolTipConfiguration.AutoPopDelay = 5000;
            this.binaryPowerTabStrip1.ToolTipConfiguration.BackColor = System.Drawing.SystemColors.Info;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.ToolTipConfiguration.InitialDelay = 500;
            this.binaryPowerTabStrip1.ToolTipConfiguration.IsBalloon = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ReshowDelay = 100;
            this.binaryPowerTabStrip1.ToolTipConfiguration.StripAmpersands = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ToolTipIcon = System.Windows.Forms.ToolTipIcon.None;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ToolTipTitle = "";
            this.binaryPowerTabStrip1.ToolTipConfiguration.UseAnimation = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.UseFading = false;
            this.binaryPowerTabStrip1.UseTabCurrentSelectionIndicatorColor = true;
            this.binaryPowerTabStrip1.TabPageClosing += new Binarymission.WinForms.Controls.TabControls.TabPageClosingHandler(this.BinaryPowerTabStripTabPageClosing);
            // 
            // binaryPowerTabPage3
            // 
            this.binaryPowerTabPage3.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryPowerTabPage3.BorderSize = 1;
            this.binaryPowerTabPage3.Controls.Add(this.btnUncheckedStateImageBrowser);
            this.binaryPowerTabPage3.Controls.Add(this.btnCheckedStateImageBrowser);
            this.binaryPowerTabPage3.Controls.Add(this.extendedLabel26);
            this.binaryPowerTabPage3.Controls.Add(this.extendedLabel25);
            this.binaryPowerTabPage3.Controls.Add(this.chkCheckOnClick);
            this.binaryPowerTabPage3.Controls.Add(this.chkShouldUseImageForCheckState);
            this.binaryPowerTabPage3.Controls.Add(this.extendedLabel19);
            this.binaryPowerTabPage3.Controls.Add(this.extendedLabel18);
            this.binaryPowerTabPage3.Controls.Add(this.extendedLabel17);
            this.binaryPowerTabPage3.Controls.Add(this.nmCheckBoxSizeHeightProvider);
            this.binaryPowerTabPage3.Controls.Add(this.nmCheckBoxSizeWidthProvider);
            this.binaryPowerTabPage3.Controls.Add(this.chkShouldDrawCheckBoxInVisualStyle);
            this.binaryPowerTabPage3.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage3.IsBackgroundTransparent = false;
            this.binaryPowerTabPage3.IsHeaderEnabled = true;
            this.binaryPowerTabPage3.Name = "binaryPowerTabPage3";
            this.binaryPowerTabPage3.Size = new System.Drawing.Size(799, 224);
            this.binaryPowerTabPage3.TabIndex = 2;
            this.binaryPowerTabPage3.TabPageContentIsDirty = false;
            this.binaryPowerTabPage3.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.Text = "CheckState";
            this.binaryPowerTabPage3.ToolTipText = "";
            // 
            // btnUncheckedStateImageBrowser
            // 
            this.btnUncheckedStateImageBrowser.Enabled = false;
            this.btnUncheckedStateImageBrowser.Location = new System.Drawing.Point(190, 162);
            this.btnUncheckedStateImageBrowser.Name = "btnUncheckedStateImageBrowser";
            this.btnUncheckedStateImageBrowser.Size = new System.Drawing.Size(111, 23);
            this.btnUncheckedStateImageBrowser.TabIndex = 57;
            this.btnUncheckedStateImageBrowser.Text = "Browse...";
            this.btnUncheckedStateImageBrowser.UseVisualStyleBackColor = true;
            this.btnUncheckedStateImageBrowser.Click += new System.EventHandler(this.UncheckedStateImageBrowserClick);
            // 
            // btnCheckedStateImageBrowser
            // 
            this.btnCheckedStateImageBrowser.Enabled = false;
            this.btnCheckedStateImageBrowser.Location = new System.Drawing.Point(190, 134);
            this.btnCheckedStateImageBrowser.Name = "btnCheckedStateImageBrowser";
            this.btnCheckedStateImageBrowser.Size = new System.Drawing.Size(111, 23);
            this.btnCheckedStateImageBrowser.TabIndex = 56;
            this.btnCheckedStateImageBrowser.Text = "Browse...";
            this.btnCheckedStateImageBrowser.UseVisualStyleBackColor = true;
            this.btnCheckedStateImageBrowser.Click += new System.EventHandler(this.CheckedStateImageBrowserClick);
            // 
            // extendedLabel26
            // 
            this.extendedLabel26.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel26.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel26.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel26.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel26.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel26.DropShadowMargin = 6;
            this.extendedLabel26.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel26.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel26.IsBackgroundTransparent = true;
            this.extendedLabel26.Location = new System.Drawing.Point(34, 161);
            this.extendedLabel26.Name = "extendedLabel26";
            this.extendedLabel26.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel26.ShouldDrawBorder = false;
            this.extendedLabel26.ShouldDrawDropShadow = false;
            this.extendedLabel26.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel26.Size = new System.Drawing.Size(133, 21);
            this.extendedLabel26.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel26.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat18.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat18.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat18.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat18.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel26.StringFormat = stringFormat18;
            this.extendedLabel26.TabIndex = 55;
            this.extendedLabel26.TabStop = false;
            this.extendedLabel26.Text = "Unchecked state image:";
            this.extendedLabel26.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel26.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel25
            // 
            this.extendedLabel25.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel25.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel25.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel25.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel25.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel25.DropShadowMargin = 6;
            this.extendedLabel25.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel25.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel25.IsBackgroundTransparent = true;
            this.extendedLabel25.Location = new System.Drawing.Point(34, 133);
            this.extendedLabel25.Name = "extendedLabel25";
            this.extendedLabel25.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel25.ShouldDrawBorder = false;
            this.extendedLabel25.ShouldDrawDropShadow = false;
            this.extendedLabel25.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel25.Size = new System.Drawing.Size(133, 21);
            this.extendedLabel25.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel25.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat19.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat19.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat19.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat19.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel25.StringFormat = stringFormat19;
            this.extendedLabel25.TabIndex = 54;
            this.extendedLabel25.TabStop = false;
            this.extendedLabel25.Text = "Checked state image:";
            this.extendedLabel25.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel25.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // chkCheckOnClick
            // 
            this.chkCheckOnClick.AutoSize = true;
            this.chkCheckOnClick.BackColor = System.Drawing.Color.Transparent;
            this.chkCheckOnClick.Location = new System.Drawing.Point(19, 78);
            this.chkCheckOnClick.Name = "chkCheckOnClick";
            this.chkCheckOnClick.Size = new System.Drawing.Size(173, 17);
            this.chkCheckOnClick.TabIndex = 53;
            this.chkCheckOnClick.Text = "Are Items checked upon click?";
            this.chkCheckOnClick.UseVisualStyleBackColor = false;
            this.chkCheckOnClick.CheckedChanged += new System.EventHandler(this.CheckOnClickCheckedChanged);
            // 
            // chkShouldUseImageForCheckState
            // 
            this.chkShouldUseImageForCheckState.AutoSize = true;
            this.chkShouldUseImageForCheckState.BackColor = System.Drawing.Color.Transparent;
            this.chkShouldUseImageForCheckState.Location = new System.Drawing.Point(19, 107);
            this.chkShouldUseImageForCheckState.Name = "chkShouldUseImageForCheckState";
            this.chkShouldUseImageForCheckState.Size = new System.Drawing.Size(227, 17);
            this.chkShouldUseImageForCheckState.TabIndex = 45;
            this.chkShouldUseImageForCheckState.Text = "Shoudl use custom image for check state?";
            this.chkShouldUseImageForCheckState.UseVisualStyleBackColor = false;
            this.chkShouldUseImageForCheckState.CheckedChanged += new System.EventHandler(this.ShouldUseImageForCheckStateCheckedChanged);
            // 
            // extendedLabel19
            // 
            this.extendedLabel19.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel19.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel19.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel19.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel19.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel19.DropShadowMargin = 6;
            this.extendedLabel19.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel19.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel19.IsBackgroundTransparent = true;
            this.extendedLabel19.Location = new System.Drawing.Point(197, 14);
            this.extendedLabel19.Name = "extendedLabel19";
            this.extendedLabel19.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel19.ShouldDrawBorder = false;
            this.extendedLabel19.ShouldDrawDropShadow = false;
            this.extendedLabel19.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel19.Size = new System.Drawing.Size(50, 19);
            this.extendedLabel19.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel19.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat20.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat20.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat20.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat20.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel19.StringFormat = stringFormat20;
            this.extendedLabel19.TabIndex = 44;
            this.extendedLabel19.TabStop = false;
            this.extendedLabel19.Text = "Height:";
            this.extendedLabel19.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel19.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel18
            // 
            this.extendedLabel18.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel18.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel18.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel18.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel18.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel18.DropShadowMargin = 6;
            this.extendedLabel18.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel18.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel18.IsBackgroundTransparent = true;
            this.extendedLabel18.Location = new System.Drawing.Point(102, 13);
            this.extendedLabel18.Name = "extendedLabel18";
            this.extendedLabel18.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel18.ShouldDrawBorder = false;
            this.extendedLabel18.ShouldDrawDropShadow = false;
            this.extendedLabel18.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel18.Size = new System.Drawing.Size(44, 19);
            this.extendedLabel18.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel18.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat21.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat21.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat21.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat21.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel18.StringFormat = stringFormat21;
            this.extendedLabel18.TabIndex = 43;
            this.extendedLabel18.TabStop = false;
            this.extendedLabel18.Text = "Width:";
            this.extendedLabel18.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel18.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel17
            // 
            this.extendedLabel17.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel17.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel17.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel17.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel17.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel17.DropShadowMargin = 6;
            this.extendedLabel17.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel17.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel17.IsBackgroundTransparent = true;
            this.extendedLabel17.Location = new System.Drawing.Point(9, 13);
            this.extendedLabel17.Name = "extendedLabel17";
            this.extendedLabel17.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel17.ShouldDrawBorder = false;
            this.extendedLabel17.ShouldDrawDropShadow = false;
            this.extendedLabel17.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel17.Size = new System.Drawing.Size(93, 19);
            this.extendedLabel17.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel17.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat22.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat22.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat22.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat22.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel17.StringFormat = stringFormat22;
            this.extendedLabel17.TabIndex = 42;
            this.extendedLabel17.TabStop = false;
            this.extendedLabel17.Text = "Checkbox size:";
            this.extendedLabel17.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel17.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // nmCheckBoxSizeHeightProvider
            // 
            this.nmCheckBoxSizeHeightProvider.Location = new System.Drawing.Point(254, 16);
            this.nmCheckBoxSizeHeightProvider.Maximum = new decimal(new int[] {
            36,
            0,
            0,
            0});
            this.nmCheckBoxSizeHeightProvider.Minimum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.nmCheckBoxSizeHeightProvider.Name = "nmCheckBoxSizeHeightProvider";
            this.nmCheckBoxSizeHeightProvider.Size = new System.Drawing.Size(40, 20);
            this.nmCheckBoxSizeHeightProvider.TabIndex = 41;
            this.nmCheckBoxSizeHeightProvider.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.nmCheckBoxSizeHeightProvider.ValueChanged += new System.EventHandler(this.CheckBoxSizeHeightProviderValueChanged);
            // 
            // nmCheckBoxSizeWidthProvider
            // 
            this.nmCheckBoxSizeWidthProvider.Location = new System.Drawing.Point(153, 15);
            this.nmCheckBoxSizeWidthProvider.Maximum = new decimal(new int[] {
            36,
            0,
            0,
            0});
            this.nmCheckBoxSizeWidthProvider.Minimum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.nmCheckBoxSizeWidthProvider.Name = "nmCheckBoxSizeWidthProvider";
            this.nmCheckBoxSizeWidthProvider.Size = new System.Drawing.Size(39, 20);
            this.nmCheckBoxSizeWidthProvider.TabIndex = 40;
            this.nmCheckBoxSizeWidthProvider.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.nmCheckBoxSizeWidthProvider.ValueChanged += new System.EventHandler(this.CheckBoxSizeWidthProviderValueChanged);
            // 
            // chkShouldDrawCheckBoxInVisualStyle
            // 
            this.chkShouldDrawCheckBoxInVisualStyle.AutoSize = true;
            this.chkShouldDrawCheckBoxInVisualStyle.BackColor = System.Drawing.Color.Transparent;
            this.chkShouldDrawCheckBoxInVisualStyle.Checked = true;
            this.chkShouldDrawCheckBoxInVisualStyle.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShouldDrawCheckBoxInVisualStyle.Location = new System.Drawing.Point(20, 49);
            this.chkShouldDrawCheckBoxInVisualStyle.Name = "chkShouldDrawCheckBoxInVisualStyle";
            this.chkShouldDrawCheckBoxInVisualStyle.Size = new System.Drawing.Size(266, 17);
            this.chkShouldDrawCheckBoxInVisualStyle.TabIndex = 39;
            this.chkShouldDrawCheckBoxInVisualStyle.Text = "Should draw checkbox in Windows \"VisualStyle\" ?";
            this.chkShouldDrawCheckBoxInVisualStyle.UseVisualStyleBackColor = false;
            this.chkShouldDrawCheckBoxInVisualStyle.CheckedChanged += new System.EventHandler(this.ShouldDrawCheckBoxInVisualStyleCheckedChanged);
            // 
            // binaryPowerTabPage6
            // 
            this.binaryPowerTabPage6.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage6.BorderColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabPage6.BorderSize = 1;
            this.binaryPowerTabPage6.Controls.Add(this.btnSidebarSelectedStateEndColor);
            this.binaryPowerTabPage6.Controls.Add(this.btnSidebarSelectedStateStartColor);
            this.binaryPowerTabPage6.Controls.Add(this.extendedLabel69);
            this.binaryPowerTabPage6.Controls.Add(this.extendedLabel70);
            this.binaryPowerTabPage6.Controls.Add(this.cmbSidebarGradientMode);
            this.binaryPowerTabPage6.Controls.Add(this.extendedLabel64);
            this.binaryPowerTabPage6.Controls.Add(this.nmSidebarBorderThicknessProvider);
            this.binaryPowerTabPage6.Controls.Add(this.extendedLabel63);
            this.binaryPowerTabPage6.Controls.Add(this.chkDrawSidebarBorder);
            this.binaryPowerTabPage6.Controls.Add(this.chkDrawSidebar);
            this.binaryPowerTabPage6.Controls.Add(this.nmSidebarWidthProvider);
            this.binaryPowerTabPage6.Controls.Add(this.btnSiderbarEndColor);
            this.binaryPowerTabPage6.Controls.Add(this.btnSidebarBorderColor);
            this.binaryPowerTabPage6.Controls.Add(this.btnSiderbarStartColor);
            this.binaryPowerTabPage6.Controls.Add(this.extendedLabel45);
            this.binaryPowerTabPage6.Controls.Add(this.extendedLabel49);
            this.binaryPowerTabPage6.Controls.Add(this.extendedLabel50);
            this.binaryPowerTabPage6.Controls.Add(this.extendedLabel62);
            this.binaryPowerTabPage6.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage6.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage6.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage6.IsBackgroundTransparent = false;
            this.binaryPowerTabPage6.IsHeaderEnabled = true;
            this.binaryPowerTabPage6.Name = "binaryPowerTabPage6";
            this.binaryPowerTabPage6.Size = new System.Drawing.Size(799, 224);
            this.binaryPowerTabPage6.TabIndex = 5;
            this.binaryPowerTabPage6.TabPageContentIsDirty = false;
            this.binaryPowerTabPage6.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage6.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage6.Text = "Sidebar";
            this.binaryPowerTabPage6.ToolTipText = "";
            // 
            // btnSidebarSelectedStateEndColor
            // 
            this.btnSidebarSelectedStateEndColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSidebarSelectedStateEndColor.Location = new System.Drawing.Point(719, 54);
            this.btnSidebarSelectedStateEndColor.Name = "btnSidebarSelectedStateEndColor";
            this.btnSidebarSelectedStateEndColor.Size = new System.Drawing.Size(39, 23);
            this.btnSidebarSelectedStateEndColor.TabIndex = 134;
            this.btnSidebarSelectedStateEndColor.Text = "...";
            this.btnSidebarSelectedStateEndColor.UseVisualStyleBackColor = true;
            this.btnSidebarSelectedStateEndColor.Click += new System.EventHandler(this.SidebarSelectedStateEndColorClick);
            // 
            // btnSidebarSelectedStateStartColor
            // 
            this.btnSidebarSelectedStateStartColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSidebarSelectedStateStartColor.Location = new System.Drawing.Point(459, 54);
            this.btnSidebarSelectedStateStartColor.Name = "btnSidebarSelectedStateStartColor";
            this.btnSidebarSelectedStateStartColor.Size = new System.Drawing.Size(39, 23);
            this.btnSidebarSelectedStateStartColor.TabIndex = 132;
            this.btnSidebarSelectedStateStartColor.Text = "...";
            this.btnSidebarSelectedStateStartColor.UseVisualStyleBackColor = true;
            this.btnSidebarSelectedStateStartColor.Click += new System.EventHandler(this.SidebarSelectedStateStartColorClick);
            // 
            // extendedLabel69
            // 
            this.extendedLabel69.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel69.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel69.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel69.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel69.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel69.DropShadowMargin = 6;
            this.extendedLabel69.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel69.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel69.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel69.IsBackgroundTransparent = true;
            this.extendedLabel69.Location = new System.Drawing.Point(525, 56);
            this.extendedLabel69.Name = "extendedLabel69";
            this.extendedLabel69.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel69.ShouldDrawBorder = false;
            this.extendedLabel69.ShouldDrawDropShadow = false;
            this.extendedLabel69.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel69.Size = new System.Drawing.Size(187, 19);
            this.extendedLabel69.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel69.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat23.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat23.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat23.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat23.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel69.StringFormat = stringFormat23;
            this.extendedLabel69.TabIndex = 133;
            this.extendedLabel69.TabStop = false;
            this.extendedLabel69.Text = "Sidebar Item Selected End color:";
            this.extendedLabel69.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel69.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel70
            // 
            this.extendedLabel70.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel70.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel70.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel70.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel70.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel70.DropShadowMargin = 6;
            this.extendedLabel70.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel70.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel70.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel70.IsBackgroundTransparent = true;
            this.extendedLabel70.Location = new System.Drawing.Point(263, 55);
            this.extendedLabel70.Name = "extendedLabel70";
            this.extendedLabel70.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel70.ShouldDrawBorder = false;
            this.extendedLabel70.ShouldDrawDropShadow = false;
            this.extendedLabel70.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel70.Size = new System.Drawing.Size(183, 19);
            this.extendedLabel70.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel70.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat24.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat24.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat24.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat24.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel70.StringFormat = stringFormat24;
            this.extendedLabel70.TabIndex = 131;
            this.extendedLabel70.TabStop = false;
            this.extendedLabel70.Text = "Sidebar Item Selected Start color:";
            this.extendedLabel70.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel70.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // cmbSidebarGradientMode
            // 
            this.cmbSidebarGradientMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSidebarGradientMode.FormattingEnabled = true;
            this.cmbSidebarGradientMode.Location = new System.Drawing.Point(460, 119);
            this.cmbSidebarGradientMode.Name = "cmbSidebarGradientMode";
            this.cmbSidebarGradientMode.Size = new System.Drawing.Size(165, 21);
            this.cmbSidebarGradientMode.TabIndex = 130;
            this.cmbSidebarGradientMode.SelectedIndexChanged += new System.EventHandler(this.SidebarGradientModeSelectedIndexChanged);
            // 
            // extendedLabel64
            // 
            this.extendedLabel64.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel64.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel64.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel64.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel64.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel64.DropShadowMargin = 6;
            this.extendedLabel64.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel64.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel64.IsBackgroundTransparent = true;
            this.extendedLabel64.Location = new System.Drawing.Point(264, 114);
            this.extendedLabel64.Name = "extendedLabel64";
            this.extendedLabel64.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel64.ShouldDrawBorder = false;
            this.extendedLabel64.ShouldDrawDropShadow = false;
            this.extendedLabel64.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel64.Size = new System.Drawing.Size(168, 32);
            this.extendedLabel64.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel64.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat25.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat25.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat25.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat25.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel64.StringFormat = stringFormat25;
            this.extendedLabel64.TabIndex = 129;
            this.extendedLabel64.TabStop = false;
            this.extendedLabel64.Text = "Sidebar background Gradient mode:";
            this.extendedLabel64.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel64.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // nmSidebarBorderThicknessProvider
            // 
            this.nmSidebarBorderThicknessProvider.Location = new System.Drawing.Point(570, 176);
            this.nmSidebarBorderThicknessProvider.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nmSidebarBorderThicknessProvider.Name = "nmSidebarBorderThicknessProvider";
            this.nmSidebarBorderThicknessProvider.Size = new System.Drawing.Size(39, 20);
            this.nmSidebarBorderThicknessProvider.TabIndex = 128;
            this.nmSidebarBorderThicknessProvider.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmSidebarBorderThicknessProvider.ValueChanged += new System.EventHandler(this.SidebarBorderThicknessProviderValueChanged);
            // 
            // extendedLabel63
            // 
            this.extendedLabel63.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel63.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel63.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel63.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel63.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel63.DropShadowMargin = 6;
            this.extendedLabel63.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel63.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel63.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel63.IsBackgroundTransparent = true;
            this.extendedLabel63.Location = new System.Drawing.Point(443, 174);
            this.extendedLabel63.Name = "extendedLabel63";
            this.extendedLabel63.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel63.ShouldDrawBorder = false;
            this.extendedLabel63.ShouldDrawDropShadow = false;
            this.extendedLabel63.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel63.Size = new System.Drawing.Size(109, 19);
            this.extendedLabel63.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel63.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat26.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat26.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat26.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat26.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel63.StringFormat = stringFormat26;
            this.extendedLabel63.TabIndex = 127;
            this.extendedLabel63.TabStop = false;
            this.extendedLabel63.Text = "Border thickness:";
            this.extendedLabel63.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel63.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // chkDrawSidebarBorder
            // 
            this.chkDrawSidebarBorder.AutoSize = true;
            this.chkDrawSidebarBorder.BackColor = System.Drawing.Color.Transparent;
            this.chkDrawSidebarBorder.Location = new System.Drawing.Point(22, 181);
            this.chkDrawSidebarBorder.Name = "chkDrawSidebarBorder";
            this.chkDrawSidebarBorder.Size = new System.Drawing.Size(215, 17);
            this.chkDrawSidebarBorder.TabIndex = 126;
            this.chkDrawSidebarBorder.Text = "Should draw border around the sidebar?";
            this.chkDrawSidebarBorder.UseVisualStyleBackColor = false;
            this.chkDrawSidebarBorder.CheckedChanged += new System.EventHandler(this.DrawSidebarBorderCheckedChanged);
            this.chkDrawSidebarBorder.EnabledChanged += new System.EventHandler(this.DrawSidebarBorderEnabledChanged);
            // 
            // chkDrawSidebar
            // 
            this.chkDrawSidebar.AutoSize = true;
            this.chkDrawSidebar.BackColor = System.Drawing.Color.Transparent;
            this.chkDrawSidebar.Location = new System.Drawing.Point(22, 26);
            this.chkDrawSidebar.Name = "chkDrawSidebar";
            this.chkDrawSidebar.Size = new System.Drawing.Size(229, 17);
            this.chkDrawSidebar.TabIndex = 125;
            this.chkDrawSidebar.Text = "Should draw sidebar on item mouse hover?";
            this.chkDrawSidebar.UseVisualStyleBackColor = false;
            this.chkDrawSidebar.CheckedChanged += new System.EventHandler(this.DrawSidebarCheckedChanged);
            // 
            // nmSidebarWidthProvider
            // 
            this.nmSidebarWidthProvider.Location = new System.Drawing.Point(461, 89);
            this.nmSidebarWidthProvider.Name = "nmSidebarWidthProvider";
            this.nmSidebarWidthProvider.Size = new System.Drawing.Size(39, 20);
            this.nmSidebarWidthProvider.TabIndex = 124;
            this.nmSidebarWidthProvider.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nmSidebarWidthProvider.ValueChanged += new System.EventHandler(this.SidebarWidthProviderValueChanged);
            // 
            // btnSiderbarEndColor
            // 
            this.btnSiderbarEndColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSiderbarEndColor.Location = new System.Drawing.Point(719, 26);
            this.btnSiderbarEndColor.Name = "btnSiderbarEndColor";
            this.btnSiderbarEndColor.Size = new System.Drawing.Size(39, 23);
            this.btnSiderbarEndColor.TabIndex = 122;
            this.btnSiderbarEndColor.Text = "...";
            this.btnSiderbarEndColor.UseVisualStyleBackColor = true;
            this.btnSiderbarEndColor.Click += new System.EventHandler(this.SiderbarEndColorClick);
            // 
            // btnSidebarBorderColor
            // 
            this.btnSidebarBorderColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSidebarBorderColor.Location = new System.Drawing.Point(364, 175);
            this.btnSidebarBorderColor.Name = "btnSidebarBorderColor";
            this.btnSidebarBorderColor.Size = new System.Drawing.Size(39, 23);
            this.btnSidebarBorderColor.TabIndex = 120;
            this.btnSidebarBorderColor.Text = "...";
            this.btnSidebarBorderColor.UseVisualStyleBackColor = true;
            this.btnSidebarBorderColor.Click += new System.EventHandler(this.BorderColorClick);
            // 
            // btnSiderbarStartColor
            // 
            this.btnSiderbarStartColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSiderbarStartColor.Location = new System.Drawing.Point(458, 23);
            this.btnSiderbarStartColor.Name = "btnSiderbarStartColor";
            this.btnSiderbarStartColor.Size = new System.Drawing.Size(39, 23);
            this.btnSiderbarStartColor.TabIndex = 119;
            this.btnSiderbarStartColor.Text = "...";
            this.btnSiderbarStartColor.UseVisualStyleBackColor = true;
            this.btnSiderbarStartColor.Click += new System.EventHandler(this.SiderbarStartColorClick);
            // 
            // extendedLabel45
            // 
            this.extendedLabel45.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel45.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel45.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel45.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel45.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel45.DropShadowMargin = 6;
            this.extendedLabel45.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel45.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel45.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel45.IsBackgroundTransparent = true;
            this.extendedLabel45.Location = new System.Drawing.Point(262, 84);
            this.extendedLabel45.Name = "extendedLabel45";
            this.extendedLabel45.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel45.ShouldDrawBorder = false;
            this.extendedLabel45.ShouldDrawDropShadow = false;
            this.extendedLabel45.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel45.Size = new System.Drawing.Size(125, 19);
            this.extendedLabel45.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel45.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat27.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat27.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat27.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat27.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel45.StringFormat = stringFormat27;
            this.extendedLabel45.TabIndex = 123;
            this.extendedLabel45.TabStop = false;
            this.extendedLabel45.Text = "Sidebar width:";
            this.extendedLabel45.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel45.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel49
            // 
            this.extendedLabel49.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel49.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel49.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel49.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel49.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel49.DropShadowMargin = 6;
            this.extendedLabel49.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel49.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel49.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel49.IsBackgroundTransparent = true;
            this.extendedLabel49.Location = new System.Drawing.Point(524, 25);
            this.extendedLabel49.Name = "extendedLabel49";
            this.extendedLabel49.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel49.ShouldDrawBorder = false;
            this.extendedLabel49.ShouldDrawDropShadow = false;
            this.extendedLabel49.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel49.Size = new System.Drawing.Size(170, 19);
            this.extendedLabel49.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel49.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat28.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat28.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat28.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat28.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel49.StringFormat = stringFormat28;
            this.extendedLabel49.TabIndex = 121;
            this.extendedLabel49.TabStop = false;
            this.extendedLabel49.Text = "Sidebar Item Hover End color:";
            this.extendedLabel49.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel49.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel50
            // 
            this.extendedLabel50.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel50.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel50.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel50.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel50.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel50.DropShadowMargin = 6;
            this.extendedLabel50.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel50.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel50.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel50.IsBackgroundTransparent = true;
            this.extendedLabel50.Location = new System.Drawing.Point(263, 177);
            this.extendedLabel50.Name = "extendedLabel50";
            this.extendedLabel50.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel50.ShouldDrawBorder = false;
            this.extendedLabel50.ShouldDrawDropShadow = false;
            this.extendedLabel50.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel50.Size = new System.Drawing.Size(111, 19);
            this.extendedLabel50.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel50.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat29.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat29.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat29.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat29.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel50.StringFormat = stringFormat29;
            this.extendedLabel50.TabIndex = 118;
            this.extendedLabel50.TabStop = false;
            this.extendedLabel50.Text = "Border color:";
            this.extendedLabel50.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel50.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel62
            // 
            this.extendedLabel62.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel62.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel62.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel62.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel62.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel62.DropShadowMargin = 6;
            this.extendedLabel62.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel62.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel62.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel62.IsBackgroundTransparent = true;
            this.extendedLabel62.Location = new System.Drawing.Point(262, 24);
            this.extendedLabel62.Name = "extendedLabel62";
            this.extendedLabel62.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel62.ShouldDrawBorder = false;
            this.extendedLabel62.ShouldDrawDropShadow = false;
            this.extendedLabel62.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel62.Size = new System.Drawing.Size(170, 19);
            this.extendedLabel62.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel62.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat30.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat30.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat30.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat30.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel62.StringFormat = stringFormat30;
            this.extendedLabel62.TabIndex = 117;
            this.extendedLabel62.TabStop = false;
            this.extendedLabel62.Text = "Sidebar Item Hover Start color:";
            this.extendedLabel62.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel62.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // binaryPowerTabPage7
            // 
            this.binaryPowerTabPage7.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage7.BorderColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabPage7.BorderSize = 1;
            this.binaryPowerTabPage7.Controls.Add(this.chkItemsAnnotation);
            this.binaryPowerTabPage7.Controls.Add(this.btnItemAnnotationImagePicker);
            this.binaryPowerTabPage7.Controls.Add(this.extendedLabel68);
            this.binaryPowerTabPage7.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage7.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage7.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage7.IsBackgroundTransparent = false;
            this.binaryPowerTabPage7.IsHeaderEnabled = true;
            this.binaryPowerTabPage7.Name = "binaryPowerTabPage7";
            this.binaryPowerTabPage7.Size = new System.Drawing.Size(799, 224);
            this.binaryPowerTabPage7.TabIndex = 6;
            this.binaryPowerTabPage7.TabPageContentIsDirty = false;
            this.binaryPowerTabPage7.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage7.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage7.Text = "Annotation";
            this.binaryPowerTabPage7.ToolTipText = "";
            // 
            // chkItemsAnnotation
            // 
            this.chkItemsAnnotation.AutoSize = true;
            this.chkItemsAnnotation.BackColor = System.Drawing.Color.Transparent;
            this.chkItemsAnnotation.Checked = true;
            this.chkItemsAnnotation.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkItemsAnnotation.Location = new System.Drawing.Point(16, 21);
            this.chkItemsAnnotation.Name = "chkItemsAnnotation";
            this.chkItemsAnnotation.Size = new System.Drawing.Size(195, 17);
            this.chkItemsAnnotation.TabIndex = 128;
            this.chkItemsAnnotation.Text = "Should enable annotation on items?";
            this.chkItemsAnnotation.UseVisualStyleBackColor = false;
            this.chkItemsAnnotation.CheckedChanged += new System.EventHandler(this.ItemsAnnotationCheckedChanged);
            // 
            // btnItemAnnotationImagePicker
            // 
            this.btnItemAnnotationImagePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemAnnotationImagePicker.Location = new System.Drawing.Point(430, 17);
            this.btnItemAnnotationImagePicker.Name = "btnItemAnnotationImagePicker";
            this.btnItemAnnotationImagePicker.Size = new System.Drawing.Size(39, 23);
            this.btnItemAnnotationImagePicker.TabIndex = 127;
            this.btnItemAnnotationImagePicker.Text = "...";
            this.btnItemAnnotationImagePicker.UseVisualStyleBackColor = true;
            this.btnItemAnnotationImagePicker.Click += new System.EventHandler(this.ItemAnnotationImagePickerClick);
            // 
            // extendedLabel68
            // 
            this.extendedLabel68.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel68.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel68.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel68.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel68.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel68.DropShadowMargin = 6;
            this.extendedLabel68.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel68.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel68.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel68.IsBackgroundTransparent = true;
            this.extendedLabel68.Location = new System.Drawing.Point(264, 18);
            this.extendedLabel68.Name = "extendedLabel68";
            this.extendedLabel68.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel68.ShouldDrawBorder = false;
            this.extendedLabel68.ShouldDrawDropShadow = false;
            this.extendedLabel68.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel68.Size = new System.Drawing.Size(154, 19);
            this.extendedLabel68.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel68.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat31.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat31.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat31.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat31.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel68.StringFormat = stringFormat31;
            this.extendedLabel68.TabIndex = 126;
            this.extendedLabel68.TabStop = false;
            this.extendedLabel68.Text = "Annotation custom image: ";
            this.extendedLabel68.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel68.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // binaryPowerTabPage5
            // 
            this.binaryPowerTabPage5.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryPowerTabPage5.BorderSize = 1;
            this.binaryPowerTabPage5.Controls.Add(this.nmItemUnselectedBorderThicknessProvider);
            this.binaryPowerTabPage5.Controls.Add(this.nmItemSelectedBorderThicknessProvider);
            this.binaryPowerTabPage5.Controls.Add(this.chkShouldDrawItemBorder);
            this.binaryPowerTabPage5.Controls.Add(this.nmItemMouseHoverBorderThicknessProvider);
            this.binaryPowerTabPage5.Controls.Add(this.nmMinimumItemTopAndBottomMargin);
            this.binaryPowerTabPage5.Controls.Add(this.chkShouldDrawTopItemSpacingForFirstItem);
            this.binaryPowerTabPage5.Controls.Add(this.nmSpacingBetweenItemsProvider);
            this.binaryPowerTabPage5.Controls.Add(this.nmPaddingBetweenItemsComponentsProvider);
            this.binaryPowerTabPage5.Controls.Add(this.extendedLabel20);
            this.binaryPowerTabPage5.Controls.Add(this.extendedLabel16);
            this.binaryPowerTabPage5.Controls.Add(this.extendedLabel24);
            this.binaryPowerTabPage5.Controls.Add(this.extendedLabel23);
            this.binaryPowerTabPage5.Controls.Add(this.extendedLabel22);
            this.binaryPowerTabPage5.Controls.Add(this.extendedLabel21);
            this.binaryPowerTabPage5.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage5.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage5.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage5.IsBackgroundTransparent = false;
            this.binaryPowerTabPage5.IsHeaderEnabled = true;
            this.binaryPowerTabPage5.Name = "binaryPowerTabPage5";
            this.binaryPowerTabPage5.Size = new System.Drawing.Size(799, 224);
            this.binaryPowerTabPage5.TabIndex = 4;
            this.binaryPowerTabPage5.TabPageContentIsDirty = false;
            this.binaryPowerTabPage5.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage5.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage5.Text = "Sizing";
            this.binaryPowerTabPage5.ToolTipText = "";
            // 
            // nmItemUnselectedBorderThicknessProvider
            // 
            this.nmItemUnselectedBorderThicknessProvider.Location = new System.Drawing.Point(215, 168);
            this.nmItemUnselectedBorderThicknessProvider.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nmItemUnselectedBorderThicknessProvider.Name = "nmItemUnselectedBorderThicknessProvider";
            this.nmItemUnselectedBorderThicknessProvider.Size = new System.Drawing.Size(80, 20);
            this.nmItemUnselectedBorderThicknessProvider.TabIndex = 72;
            this.nmItemUnselectedBorderThicknessProvider.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmItemUnselectedBorderThicknessProvider.ValueChanged += new System.EventHandler(this.ItemUnselectedBorderThicknessProviderValueChanged);
            // 
            // nmItemSelectedBorderThicknessProvider
            // 
            this.nmItemSelectedBorderThicknessProvider.Location = new System.Drawing.Point(215, 144);
            this.nmItemSelectedBorderThicknessProvider.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nmItemSelectedBorderThicknessProvider.Name = "nmItemSelectedBorderThicknessProvider";
            this.nmItemSelectedBorderThicknessProvider.Size = new System.Drawing.Size(80, 20);
            this.nmItemSelectedBorderThicknessProvider.TabIndex = 70;
            this.nmItemSelectedBorderThicknessProvider.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmItemSelectedBorderThicknessProvider.ValueChanged += new System.EventHandler(this.ItemSelectedBorderThicknessProviderValueChanged);
            // 
            // chkShouldDrawItemBorder
            // 
            this.chkShouldDrawItemBorder.AutoSize = true;
            this.chkShouldDrawItemBorder.BackColor = System.Drawing.Color.Transparent;
            this.chkShouldDrawItemBorder.Checked = true;
            this.chkShouldDrawItemBorder.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShouldDrawItemBorder.Location = new System.Drawing.Point(325, 66);
            this.chkShouldDrawItemBorder.Name = "chkShouldDrawItemBorder";
            this.chkShouldDrawItemBorder.Size = new System.Drawing.Size(147, 17);
            this.chkShouldDrawItemBorder.TabIndex = 68;
            this.chkShouldDrawItemBorder.Text = "Should draw Item border?";
            this.chkShouldDrawItemBorder.UseVisualStyleBackColor = false;
            this.chkShouldDrawItemBorder.CheckedChanged += new System.EventHandler(this.ShouldDrawItemBorderCheckedChanged);
            // 
            // nmItemMouseHoverBorderThicknessProvider
            // 
            this.nmItemMouseHoverBorderThicknessProvider.Location = new System.Drawing.Point(214, 116);
            this.nmItemMouseHoverBorderThicknessProvider.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.nmItemMouseHoverBorderThicknessProvider.Name = "nmItemMouseHoverBorderThicknessProvider";
            this.nmItemMouseHoverBorderThicknessProvider.Size = new System.Drawing.Size(80, 20);
            this.nmItemMouseHoverBorderThicknessProvider.TabIndex = 67;
            this.nmItemMouseHoverBorderThicknessProvider.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmItemMouseHoverBorderThicknessProvider.ValueChanged += new System.EventHandler(this.ItemMouseHoverBorderThicknessProviderValueChanged);
            // 
            // nmMinimumItemTopAndBottomMargin
            // 
            this.nmMinimumItemTopAndBottomMargin.Location = new System.Drawing.Point(214, 89);
            this.nmMinimumItemTopAndBottomMargin.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.nmMinimumItemTopAndBottomMargin.Name = "nmMinimumItemTopAndBottomMargin";
            this.nmMinimumItemTopAndBottomMargin.Size = new System.Drawing.Size(80, 20);
            this.nmMinimumItemTopAndBottomMargin.TabIndex = 65;
            this.nmMinimumItemTopAndBottomMargin.ValueChanged += new System.EventHandler(this.MinimumItemTopAndBottomMarginValueChanged);
            // 
            // chkShouldDrawTopItemSpacingForFirstItem
            // 
            this.chkShouldDrawTopItemSpacingForFirstItem.AutoSize = true;
            this.chkShouldDrawTopItemSpacingForFirstItem.BackColor = System.Drawing.Color.Transparent;
            this.chkShouldDrawTopItemSpacingForFirstItem.Checked = true;
            this.chkShouldDrawTopItemSpacingForFirstItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShouldDrawTopItemSpacingForFirstItem.Location = new System.Drawing.Point(325, 41);
            this.chkShouldDrawTopItemSpacingForFirstItem.Name = "chkShouldDrawTopItemSpacingForFirstItem";
            this.chkShouldDrawTopItemSpacingForFirstItem.Size = new System.Drawing.Size(233, 17);
            this.chkShouldDrawTopItemSpacingForFirstItem.TabIndex = 63;
            this.chkShouldDrawTopItemSpacingForFirstItem.Text = "Should draw spacing for Top (0-index) item?";
            this.chkShouldDrawTopItemSpacingForFirstItem.UseVisualStyleBackColor = false;
            this.chkShouldDrawTopItemSpacingForFirstItem.CheckedChanged += new System.EventHandler(this.ShouldDrawTopItemSpacingForFirstItemCheckedChanged);
            // 
            // nmSpacingBetweenItemsProvider
            // 
            this.nmSpacingBetweenItemsProvider.Location = new System.Drawing.Point(214, 63);
            this.nmSpacingBetweenItemsProvider.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.nmSpacingBetweenItemsProvider.Name = "nmSpacingBetweenItemsProvider";
            this.nmSpacingBetweenItemsProvider.Size = new System.Drawing.Size(80, 20);
            this.nmSpacingBetweenItemsProvider.TabIndex = 62;
            this.nmSpacingBetweenItemsProvider.ValueChanged += new System.EventHandler(this.SpacingBetweenItemsProviderValueChanged);
            // 
            // nmPaddingBetweenItemsComponentsProvider
            // 
            this.nmPaddingBetweenItemsComponentsProvider.Location = new System.Drawing.Point(214, 38);
            this.nmPaddingBetweenItemsComponentsProvider.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nmPaddingBetweenItemsComponentsProvider.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nmPaddingBetweenItemsComponentsProvider.Name = "nmPaddingBetweenItemsComponentsProvider";
            this.nmPaddingBetweenItemsComponentsProvider.Size = new System.Drawing.Size(80, 20);
            this.nmPaddingBetweenItemsComponentsProvider.TabIndex = 60;
            this.nmPaddingBetweenItemsComponentsProvider.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nmPaddingBetweenItemsComponentsProvider.ValueChanged += new System.EventHandler(this.PaddingBetweenItemsComponentsProviderValueChanged);
            // 
            // extendedLabel20
            // 
            this.extendedLabel20.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel20.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel20.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel20.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel20.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel20.DropShadowMargin = 6;
            this.extendedLabel20.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel20.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel20.IsBackgroundTransparent = true;
            this.extendedLabel20.Location = new System.Drawing.Point(15, 165);
            this.extendedLabel20.Name = "extendedLabel20";
            this.extendedLabel20.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel20.ShouldDrawBorder = false;
            this.extendedLabel20.ShouldDrawDropShadow = false;
            this.extendedLabel20.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel20.Size = new System.Drawing.Size(194, 19);
            this.extendedLabel20.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel20.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat32.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat32.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat32.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat32.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel20.StringFormat = stringFormat32;
            this.extendedLabel20.TabIndex = 71;
            this.extendedLabel20.TabStop = false;
            this.extendedLabel20.Text = "Item Un-selected Border Thickness:";
            this.extendedLabel20.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel20.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel16
            // 
            this.extendedLabel16.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel16.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel16.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel16.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel16.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel16.DropShadowMargin = 6;
            this.extendedLabel16.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel16.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel16.IsBackgroundTransparent = true;
            this.extendedLabel16.Location = new System.Drawing.Point(15, 141);
            this.extendedLabel16.Name = "extendedLabel16";
            this.extendedLabel16.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel16.ShouldDrawBorder = false;
            this.extendedLabel16.ShouldDrawDropShadow = false;
            this.extendedLabel16.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel16.Size = new System.Drawing.Size(175, 19);
            this.extendedLabel16.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel16.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat33.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat33.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat33.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat33.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel16.StringFormat = stringFormat33;
            this.extendedLabel16.TabIndex = 69;
            this.extendedLabel16.TabStop = false;
            this.extendedLabel16.Text = "Item Selected Border Thickness:";
            this.extendedLabel16.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel16.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel24
            // 
            this.extendedLabel24.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel24.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel24.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel24.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel24.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel24.DropShadowMargin = 6;
            this.extendedLabel24.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel24.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel24.IsBackgroundTransparent = true;
            this.extendedLabel24.Location = new System.Drawing.Point(14, 113);
            this.extendedLabel24.Name = "extendedLabel24";
            this.extendedLabel24.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel24.ShouldDrawBorder = false;
            this.extendedLabel24.ShouldDrawDropShadow = false;
            this.extendedLabel24.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel24.Size = new System.Drawing.Size(194, 19);
            this.extendedLabel24.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel24.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat34.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat34.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat34.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat34.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel24.StringFormat = stringFormat34;
            this.extendedLabel24.TabIndex = 66;
            this.extendedLabel24.TabStop = false;
            this.extendedLabel24.Text = "Item mouse-hover border thickness:";
            this.extendedLabel24.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel24.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel23
            // 
            this.extendedLabel23.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel23.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel23.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel23.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel23.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel23.DropShadowMargin = 6;
            this.extendedLabel23.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel23.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel23.IsBackgroundTransparent = true;
            this.extendedLabel23.Location = new System.Drawing.Point(14, 86);
            this.extendedLabel23.Name = "extendedLabel23";
            this.extendedLabel23.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel23.ShouldDrawBorder = false;
            this.extendedLabel23.ShouldDrawDropShadow = false;
            this.extendedLabel23.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel23.Size = new System.Drawing.Size(194, 19);
            this.extendedLabel23.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel23.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat35.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat35.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat35.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat35.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel23.StringFormat = stringFormat35;
            this.extendedLabel23.TabIndex = 64;
            this.extendedLabel23.TabStop = false;
            this.extendedLabel23.Text = "Top / Bottom item spacing:";
            this.extendedLabel23.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel23.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel22
            // 
            this.extendedLabel22.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel22.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel22.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel22.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel22.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel22.DropShadowMargin = 6;
            this.extendedLabel22.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel22.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel22.IsBackgroundTransparent = true;
            this.extendedLabel22.Location = new System.Drawing.Point(14, 60);
            this.extendedLabel22.Name = "extendedLabel22";
            this.extendedLabel22.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel22.ShouldDrawBorder = false;
            this.extendedLabel22.ShouldDrawDropShadow = false;
            this.extendedLabel22.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel22.Size = new System.Drawing.Size(194, 19);
            this.extendedLabel22.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel22.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat36.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat36.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat36.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat36.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel22.StringFormat = stringFormat36;
            this.extendedLabel22.TabIndex = 61;
            this.extendedLabel22.TabStop = false;
            this.extendedLabel22.Text = "Spacing between Items:";
            this.extendedLabel22.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel22.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel21
            // 
            this.extendedLabel21.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel21.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel21.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel21.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel21.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel21.DropShadowMargin = 6;
            this.extendedLabel21.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel21.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel21.IsBackgroundTransparent = true;
            this.extendedLabel21.Location = new System.Drawing.Point(14, 35);
            this.extendedLabel21.Name = "extendedLabel21";
            this.extendedLabel21.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel21.ShouldDrawBorder = false;
            this.extendedLabel21.ShouldDrawDropShadow = false;
            this.extendedLabel21.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel21.Size = new System.Drawing.Size(194, 19);
            this.extendedLabel21.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel21.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat37.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat37.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat37.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat37.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel21.StringFormat = stringFormat37;
            this.extendedLabel21.TabIndex = 59;
            this.extendedLabel21.TabStop = false;
            this.extendedLabel21.Text = "Padding between item\'s components:";
            this.extendedLabel21.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel21.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // binaryPowerTabPage1
            // 
            this.binaryPowerTabPage1.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryPowerTabPage1.BorderSize = 1;
            this.binaryPowerTabPage1.Controls.Add(this.btnReadOnlyContentTextColorProvider);
            this.binaryPowerTabPage1.Controls.Add(this.btnReadOnlyTitleTextColorProvider);
            this.binaryPowerTabPage1.Controls.Add(this.btnItemDisabledTitleTextColorProvider);
            this.binaryPowerTabPage1.Controls.Add(this.btnItemDisabledContentTextColorProvider);
            this.binaryPowerTabPage1.Controls.Add(this.btnHoverTitleTextColorProvider);
            this.binaryPowerTabPage1.Controls.Add(this.btnHoverContentTextColorProvider);
            this.binaryPowerTabPage1.Controls.Add(this.chkEnableAlternatingColors);
            this.binaryPowerTabPage1.Controls.Add(this.nmAlternateGradientFactorProvider);
            this.binaryPowerTabPage1.Controls.Add(this.btnAltEndColor);
            this.binaryPowerTabPage1.Controls.Add(this.btnItemUnselectedTitleTextColorProvider);
            this.binaryPowerTabPage1.Controls.Add(this.btnItemUnselectedContentTextColorProvider);
            this.binaryPowerTabPage1.Controls.Add(this.btnTitleTextColorProvider);
            this.binaryPowerTabPage1.Controls.Add(this.btnContentTextColorProvider);
            this.binaryPowerTabPage1.Controls.Add(this.btnAltStartColor);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel42);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel43);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel40);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel41);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel58);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel59);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel53);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel38);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel32);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel29);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel30);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel27);
            this.binaryPowerTabPage1.Controls.Add(this.extendedLabel28);
            this.binaryPowerTabPage1.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage1.IsBackgroundTransparent = false;
            this.binaryPowerTabPage1.IsHeaderEnabled = true;
            this.binaryPowerTabPage1.Name = "binaryPowerTabPage1";
            this.binaryPowerTabPage1.Size = new System.Drawing.Size(799, 224);
            this.binaryPowerTabPage1.TabIndex = 0;
            this.binaryPowerTabPage1.TabPageContentIsDirty = false;
            this.binaryPowerTabPage1.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.Text = "Colors";
            this.binaryPowerTabPage1.ToolTipText = "";
            // 
            // btnReadOnlyContentTextColorProvider
            // 
            this.btnReadOnlyContentTextColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReadOnlyContentTextColorProvider.Location = new System.Drawing.Point(550, 186);
            this.btnReadOnlyContentTextColorProvider.Name = "btnReadOnlyContentTextColorProvider";
            this.btnReadOnlyContentTextColorProvider.Size = new System.Drawing.Size(39, 23);
            this.btnReadOnlyContentTextColorProvider.TabIndex = 128;
            this.btnReadOnlyContentTextColorProvider.Text = "...";
            this.btnReadOnlyContentTextColorProvider.UseVisualStyleBackColor = true;
            this.btnReadOnlyContentTextColorProvider.Click += new System.EventHandler(this.ReadOnlyContentTextColorProviderClick);
            // 
            // btnReadOnlyTitleTextColorProvider
            // 
            this.btnReadOnlyTitleTextColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReadOnlyTitleTextColorProvider.Location = new System.Drawing.Point(221, 184);
            this.btnReadOnlyTitleTextColorProvider.Name = "btnReadOnlyTitleTextColorProvider";
            this.btnReadOnlyTitleTextColorProvider.Size = new System.Drawing.Size(39, 23);
            this.btnReadOnlyTitleTextColorProvider.TabIndex = 126;
            this.btnReadOnlyTitleTextColorProvider.Text = "...";
            this.btnReadOnlyTitleTextColorProvider.UseVisualStyleBackColor = true;
            this.btnReadOnlyTitleTextColorProvider.Click += new System.EventHandler(this.ReadOnlyTitleTextColorProviderClick);
            // 
            // btnItemDisabledTitleTextColorProvider
            // 
            this.btnItemDisabledTitleTextColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemDisabledTitleTextColorProvider.Location = new System.Drawing.Point(550, 157);
            this.btnItemDisabledTitleTextColorProvider.Name = "btnItemDisabledTitleTextColorProvider";
            this.btnItemDisabledTitleTextColorProvider.Size = new System.Drawing.Size(39, 23);
            this.btnItemDisabledTitleTextColorProvider.TabIndex = 124;
            this.btnItemDisabledTitleTextColorProvider.Text = "...";
            this.btnItemDisabledTitleTextColorProvider.UseVisualStyleBackColor = true;
            this.btnItemDisabledTitleTextColorProvider.Click += new System.EventHandler(this.ItemDisabledTitleTextColorProviderClick);
            // 
            // btnItemDisabledContentTextColorProvider
            // 
            this.btnItemDisabledContentTextColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemDisabledContentTextColorProvider.Location = new System.Drawing.Point(550, 131);
            this.btnItemDisabledContentTextColorProvider.Name = "btnItemDisabledContentTextColorProvider";
            this.btnItemDisabledContentTextColorProvider.Size = new System.Drawing.Size(39, 23);
            this.btnItemDisabledContentTextColorProvider.TabIndex = 122;
            this.btnItemDisabledContentTextColorProvider.Text = "...";
            this.btnItemDisabledContentTextColorProvider.UseVisualStyleBackColor = true;
            this.btnItemDisabledContentTextColorProvider.Click += new System.EventHandler(this.ItemDisabledContentTextColorProviderClick);
            // 
            // btnHoverTitleTextColorProvider
            // 
            this.btnHoverTitleTextColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHoverTitleTextColorProvider.Location = new System.Drawing.Point(550, 104);
            this.btnHoverTitleTextColorProvider.Name = "btnHoverTitleTextColorProvider";
            this.btnHoverTitleTextColorProvider.Size = new System.Drawing.Size(39, 23);
            this.btnHoverTitleTextColorProvider.TabIndex = 120;
            this.btnHoverTitleTextColorProvider.Text = "...";
            this.btnHoverTitleTextColorProvider.UseVisualStyleBackColor = true;
            this.btnHoverTitleTextColorProvider.Click += new System.EventHandler(this.HoverTitleTextColorProviderClick);
            // 
            // btnHoverContentTextColorProvider
            // 
            this.btnHoverContentTextColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHoverContentTextColorProvider.Location = new System.Drawing.Point(550, 78);
            this.btnHoverContentTextColorProvider.Name = "btnHoverContentTextColorProvider";
            this.btnHoverContentTextColorProvider.Size = new System.Drawing.Size(39, 23);
            this.btnHoverContentTextColorProvider.TabIndex = 118;
            this.btnHoverContentTextColorProvider.Text = "...";
            this.btnHoverContentTextColorProvider.UseVisualStyleBackColor = true;
            this.btnHoverContentTextColorProvider.Click += new System.EventHandler(this.HoverContentTextColorProviderClick);
            // 
            // chkEnableAlternatingColors
            // 
            this.chkEnableAlternatingColors.AutoSize = true;
            this.chkEnableAlternatingColors.BackColor = System.Drawing.Color.Transparent;
            this.chkEnableAlternatingColors.Location = new System.Drawing.Point(25, 21);
            this.chkEnableAlternatingColors.Name = "chkEnableAlternatingColors";
            this.chkEnableAlternatingColors.Size = new System.Drawing.Size(272, 17);
            this.chkEnableAlternatingColors.TabIndex = 116;
            this.chkEnableAlternatingColors.Text = "Should enable rendering alternating colors for items?";
            this.chkEnableAlternatingColors.UseVisualStyleBackColor = false;
            this.chkEnableAlternatingColors.CheckedChanged += new System.EventHandler(this.EnableAlternatingColorsCheckedChanged);
            // 
            // nmAlternateGradientFactorProvider
            // 
            this.nmAlternateGradientFactorProvider.Location = new System.Drawing.Point(467, 48);
            this.nmAlternateGradientFactorProvider.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nmAlternateGradientFactorProvider.Name = "nmAlternateGradientFactorProvider";
            this.nmAlternateGradientFactorProvider.Size = new System.Drawing.Size(39, 20);
            this.nmAlternateGradientFactorProvider.TabIndex = 112;
            this.nmAlternateGradientFactorProvider.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nmAlternateGradientFactorProvider.ValueChanged += new System.EventHandler(this.AlternateGradientFactorProviderValueChanged);
            // 
            // btnAltEndColor
            // 
            this.btnAltEndColor.Enabled = false;
            this.btnAltEndColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAltEndColor.Location = new System.Drawing.Point(551, 18);
            this.btnAltEndColor.Name = "btnAltEndColor";
            this.btnAltEndColor.Size = new System.Drawing.Size(39, 23);
            this.btnAltEndColor.TabIndex = 72;
            this.btnAltEndColor.Text = "...";
            this.btnAltEndColor.UseVisualStyleBackColor = true;
            this.btnAltEndColor.Click += new System.EventHandler(this.AlternateEndColorClick);
            // 
            // btnItemUnselectedTitleTextColorProvider
            // 
            this.btnItemUnselectedTitleTextColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemUnselectedTitleTextColorProvider.Location = new System.Drawing.Point(221, 155);
            this.btnItemUnselectedTitleTextColorProvider.Name = "btnItemUnselectedTitleTextColorProvider";
            this.btnItemUnselectedTitleTextColorProvider.Size = new System.Drawing.Size(39, 23);
            this.btnItemUnselectedTitleTextColorProvider.TabIndex = 68;
            this.btnItemUnselectedTitleTextColorProvider.Text = "...";
            this.btnItemUnselectedTitleTextColorProvider.UseVisualStyleBackColor = true;
            this.btnItemUnselectedTitleTextColorProvider.Click += new System.EventHandler(this.ItemUnselectedTitleTextColorProviderClick);
            // 
            // btnItemUnselectedContentTextColorProvider
            // 
            this.btnItemUnselectedContentTextColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemUnselectedContentTextColorProvider.Location = new System.Drawing.Point(221, 129);
            this.btnItemUnselectedContentTextColorProvider.Name = "btnItemUnselectedContentTextColorProvider";
            this.btnItemUnselectedContentTextColorProvider.Size = new System.Drawing.Size(39, 23);
            this.btnItemUnselectedContentTextColorProvider.TabIndex = 65;
            this.btnItemUnselectedContentTextColorProvider.Text = "...";
            this.btnItemUnselectedContentTextColorProvider.UseVisualStyleBackColor = true;
            this.btnItemUnselectedContentTextColorProvider.Click += new System.EventHandler(this.ItemUnselectedContentTextColorProviderClick);
            // 
            // btnTitleTextColorProvider
            // 
            this.btnTitleTextColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTitleTextColorProvider.Location = new System.Drawing.Point(221, 103);
            this.btnTitleTextColorProvider.Name = "btnTitleTextColorProvider";
            this.btnTitleTextColorProvider.Size = new System.Drawing.Size(39, 23);
            this.btnTitleTextColorProvider.TabIndex = 64;
            this.btnTitleTextColorProvider.Text = "...";
            this.btnTitleTextColorProvider.UseVisualStyleBackColor = true;
            this.btnTitleTextColorProvider.Click += new System.EventHandler(this.TitleTextColorProviderClick);
            // 
            // btnContentTextColorProvider
            // 
            this.btnContentTextColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContentTextColorProvider.Location = new System.Drawing.Point(221, 76);
            this.btnContentTextColorProvider.Name = "btnContentTextColorProvider";
            this.btnContentTextColorProvider.Size = new System.Drawing.Size(39, 23);
            this.btnContentTextColorProvider.TabIndex = 61;
            this.btnContentTextColorProvider.Text = "...";
            this.btnContentTextColorProvider.UseVisualStyleBackColor = true;
            this.btnContentTextColorProvider.Click += new System.EventHandler(this.ContentTextColorProviderClick);
            // 
            // btnAltStartColor
            // 
            this.btnAltStartColor.Enabled = false;
            this.btnAltStartColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAltStartColor.Location = new System.Drawing.Point(403, 17);
            this.btnAltStartColor.Name = "btnAltStartColor";
            this.btnAltStartColor.Size = new System.Drawing.Size(39, 23);
            this.btnAltStartColor.TabIndex = 60;
            this.btnAltStartColor.Text = "...";
            this.btnAltStartColor.UseVisualStyleBackColor = true;
            this.btnAltStartColor.Click += new System.EventHandler(this.AlternateStartColorClick);
            // 
            // extendedLabel42
            // 
            this.extendedLabel42.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel42.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel42.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel42.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel42.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel42.DropShadowMargin = 6;
            this.extendedLabel42.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel42.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel42.IsBackgroundTransparent = true;
            this.extendedLabel42.Location = new System.Drawing.Point(305, 187);
            this.extendedLabel42.Name = "extendedLabel42";
            this.extendedLabel42.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel42.ShouldDrawBorder = false;
            this.extendedLabel42.ShouldDrawDropShadow = false;
            this.extendedLabel42.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel42.Size = new System.Drawing.Size(197, 19);
            this.extendedLabel42.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel42.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat38.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat38.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat38.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat38.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel42.StringFormat = stringFormat38;
            this.extendedLabel42.TabIndex = 127;
            this.extendedLabel42.TabStop = false;
            this.extendedLabel42.Text = "Item read-only content text color:";
            this.extendedLabel42.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel42.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel43
            // 
            this.extendedLabel43.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel43.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel43.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel43.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel43.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel43.DropShadowMargin = 6;
            this.extendedLabel43.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel43.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel43.IsBackgroundTransparent = true;
            this.extendedLabel43.Location = new System.Drawing.Point(13, 185);
            this.extendedLabel43.Name = "extendedLabel43";
            this.extendedLabel43.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel43.ShouldDrawBorder = false;
            this.extendedLabel43.ShouldDrawDropShadow = false;
            this.extendedLabel43.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel43.Size = new System.Drawing.Size(182, 19);
            this.extendedLabel43.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel43.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat39.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat39.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat39.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat39.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel43.StringFormat = stringFormat39;
            this.extendedLabel43.TabIndex = 125;
            this.extendedLabel43.TabStop = false;
            this.extendedLabel43.Text = "Item read-only title text color:";
            this.extendedLabel43.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel43.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel40
            // 
            this.extendedLabel40.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel40.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel40.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel40.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel40.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel40.DropShadowMargin = 6;
            this.extendedLabel40.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel40.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel40.IsBackgroundTransparent = true;
            this.extendedLabel40.Location = new System.Drawing.Point(305, 158);
            this.extendedLabel40.Name = "extendedLabel40";
            this.extendedLabel40.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel40.ShouldDrawBorder = false;
            this.extendedLabel40.ShouldDrawDropShadow = false;
            this.extendedLabel40.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel40.Size = new System.Drawing.Size(197, 19);
            this.extendedLabel40.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel40.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat40.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat40.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat40.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat40.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel40.StringFormat = stringFormat40;
            this.extendedLabel40.TabIndex = 123;
            this.extendedLabel40.TabStop = false;
            this.extendedLabel40.Text = "Item disabled title text color:";
            this.extendedLabel40.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel40.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel41
            // 
            this.extendedLabel41.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel41.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel41.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel41.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel41.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel41.DropShadowMargin = 6;
            this.extendedLabel41.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel41.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel41.IsBackgroundTransparent = true;
            this.extendedLabel41.Location = new System.Drawing.Point(305, 131);
            this.extendedLabel41.Name = "extendedLabel41";
            this.extendedLabel41.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel41.ShouldDrawBorder = false;
            this.extendedLabel41.ShouldDrawDropShadow = false;
            this.extendedLabel41.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel41.Size = new System.Drawing.Size(182, 19);
            this.extendedLabel41.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel41.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat41.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat41.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat41.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat41.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel41.StringFormat = stringFormat41;
            this.extendedLabel41.TabIndex = 121;
            this.extendedLabel41.TabStop = false;
            this.extendedLabel41.Text = "Item disabled content text color:";
            this.extendedLabel41.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel41.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel58
            // 
            this.extendedLabel58.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel58.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel58.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel58.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel58.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel58.DropShadowMargin = 6;
            this.extendedLabel58.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel58.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel58.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel58.IsBackgroundTransparent = true;
            this.extendedLabel58.Location = new System.Drawing.Point(306, 105);
            this.extendedLabel58.Name = "extendedLabel58";
            this.extendedLabel58.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel58.ShouldDrawBorder = false;
            this.extendedLabel58.ShouldDrawDropShadow = false;
            this.extendedLabel58.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel58.Size = new System.Drawing.Size(197, 19);
            this.extendedLabel58.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel58.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat42.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat42.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat42.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat42.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel58.StringFormat = stringFormat42;
            this.extendedLabel58.TabIndex = 119;
            this.extendedLabel58.TabStop = false;
            this.extendedLabel58.Text = "Item hover title text color:";
            this.extendedLabel58.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel58.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel59
            // 
            this.extendedLabel59.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel59.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel59.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel59.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel59.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel59.DropShadowMargin = 6;
            this.extendedLabel59.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel59.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel59.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel59.IsBackgroundTransparent = true;
            this.extendedLabel59.Location = new System.Drawing.Point(305, 79);
            this.extendedLabel59.Name = "extendedLabel59";
            this.extendedLabel59.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel59.ShouldDrawBorder = false;
            this.extendedLabel59.ShouldDrawDropShadow = false;
            this.extendedLabel59.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel59.Size = new System.Drawing.Size(182, 19);
            this.extendedLabel59.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel59.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat43.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat43.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat43.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat43.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel59.StringFormat = stringFormat43;
            this.extendedLabel59.TabIndex = 117;
            this.extendedLabel59.TabStop = false;
            this.extendedLabel59.Text = "Item hover content text color:";
            this.extendedLabel59.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel59.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel53
            // 
            this.extendedLabel53.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel53.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel53.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel53.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel53.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel53.DropShadowMargin = 6;
            this.extendedLabel53.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel53.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel53.IsBackgroundTransparent = true;
            this.extendedLabel53.Location = new System.Drawing.Point(307, 46);
            this.extendedLabel53.Name = "extendedLabel53";
            this.extendedLabel53.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel53.ShouldDrawBorder = false;
            this.extendedLabel53.ShouldDrawDropShadow = false;
            this.extendedLabel53.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel53.Size = new System.Drawing.Size(149, 19);
            this.extendedLabel53.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel53.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat44.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat44.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat44.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat44.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel53.StringFormat = stringFormat44;
            this.extendedLabel53.TabIndex = 105;
            this.extendedLabel53.TabStop = false;
            this.extendedLabel53.Text = "Alternate Gradient factor:";
            this.extendedLabel53.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel53.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel38
            // 
            this.extendedLabel38.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel38.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel38.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel38.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel38.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel38.DropShadowMargin = 6;
            this.extendedLabel38.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel38.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel38.IsBackgroundTransparent = true;
            this.extendedLabel38.Location = new System.Drawing.Point(455, 19);
            this.extendedLabel38.Name = "extendedLabel38";
            this.extendedLabel38.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel38.ShouldDrawBorder = false;
            this.extendedLabel38.ShouldDrawDropShadow = false;
            this.extendedLabel38.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel38.Size = new System.Drawing.Size(89, 19);
            this.extendedLabel38.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel38.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat45.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat45.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat45.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat45.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel38.StringFormat = stringFormat45;
            this.extendedLabel38.TabIndex = 70;
            this.extendedLabel38.TabStop = false;
            this.extendedLabel38.Text = "Alternate End:";
            this.extendedLabel38.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel38.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel32
            // 
            this.extendedLabel32.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel32.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel32.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel32.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel32.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel32.DropShadowMargin = 6;
            this.extendedLabel32.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel32.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel32.IsBackgroundTransparent = true;
            this.extendedLabel32.Location = new System.Drawing.Point(13, 156);
            this.extendedLabel32.Name = "extendedLabel32";
            this.extendedLabel32.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel32.ShouldDrawBorder = false;
            this.extendedLabel32.ShouldDrawDropShadow = false;
            this.extendedLabel32.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel32.Size = new System.Drawing.Size(197, 19);
            this.extendedLabel32.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel32.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat46.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat46.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat46.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat46.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel32.StringFormat = stringFormat46;
            this.extendedLabel32.TabIndex = 66;
            this.extendedLabel32.TabStop = false;
            this.extendedLabel32.Text = "Item unselected title text color:";
            this.extendedLabel32.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel32.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel29
            // 
            this.extendedLabel29.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel29.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel29.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel29.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel29.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel29.DropShadowMargin = 6;
            this.extendedLabel29.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel29.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel29.IsBackgroundTransparent = true;
            this.extendedLabel29.Location = new System.Drawing.Point(13, 129);
            this.extendedLabel29.Name = "extendedLabel29";
            this.extendedLabel29.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel29.ShouldDrawBorder = false;
            this.extendedLabel29.ShouldDrawDropShadow = false;
            this.extendedLabel29.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel29.Size = new System.Drawing.Size(182, 19);
            this.extendedLabel29.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel29.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat47.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat47.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat47.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat47.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel29.StringFormat = stringFormat47;
            this.extendedLabel29.TabIndex = 63;
            this.extendedLabel29.TabStop = false;
            this.extendedLabel29.Text = "Item unselected content text color:";
            this.extendedLabel29.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel29.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel30
            // 
            this.extendedLabel30.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel30.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel30.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel30.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel30.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel30.DropShadowMargin = 6;
            this.extendedLabel30.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel30.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel30.IsBackgroundTransparent = true;
            this.extendedLabel30.Location = new System.Drawing.Point(13, 102);
            this.extendedLabel30.Name = "extendedLabel30";
            this.extendedLabel30.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel30.ShouldDrawBorder = false;
            this.extendedLabel30.ShouldDrawDropShadow = false;
            this.extendedLabel30.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel30.Size = new System.Drawing.Size(130, 19);
            this.extendedLabel30.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel30.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat48.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat48.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat48.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat48.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel30.StringFormat = stringFormat48;
            this.extendedLabel30.TabIndex = 62;
            this.extendedLabel30.TabStop = false;
            this.extendedLabel30.Text = "Item standard Title Text Color:";
            this.extendedLabel30.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel30.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel27
            // 
            this.extendedLabel27.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel27.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel27.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel27.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel27.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel27.DropShadowMargin = 6;
            this.extendedLabel27.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel27.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel27.IsBackgroundTransparent = true;
            this.extendedLabel27.Location = new System.Drawing.Point(13, 76);
            this.extendedLabel27.Name = "extendedLabel27";
            this.extendedLabel27.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel27.ShouldDrawBorder = false;
            this.extendedLabel27.ShouldDrawDropShadow = false;
            this.extendedLabel27.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel27.Size = new System.Drawing.Size(150, 19);
            this.extendedLabel27.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel27.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat49.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat49.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat49.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat49.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel27.StringFormat = stringFormat49;
            this.extendedLabel27.TabIndex = 59;
            this.extendedLabel27.TabStop = false;
            this.extendedLabel27.Text = "Item standard Content Text Color:";
            this.extendedLabel27.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel27.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel28
            // 
            this.extendedLabel28.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel28.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel28.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel28.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel28.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel28.DropShadowMargin = 6;
            this.extendedLabel28.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel28.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel28.IsBackgroundTransparent = true;
            this.extendedLabel28.Location = new System.Drawing.Point(307, 18);
            this.extendedLabel28.Name = "extendedLabel28";
            this.extendedLabel28.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel28.ShouldDrawBorder = false;
            this.extendedLabel28.ShouldDrawDropShadow = false;
            this.extendedLabel28.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel28.Size = new System.Drawing.Size(89, 19);
            this.extendedLabel28.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel28.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat50.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat50.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat50.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat50.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel28.StringFormat = stringFormat50;
            this.extendedLabel28.TabIndex = 58;
            this.extendedLabel28.TabStop = false;
            this.extendedLabel28.Text = "Alternate Start:";
            this.extendedLabel28.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel28.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // binaryPowerTabPage4
            // 
            this.binaryPowerTabPage4.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryPowerTabPage4.BorderSize = 1;
            this.binaryPowerTabPage4.Controls.Add(this.btnDisabledItemEndColor);
            this.binaryPowerTabPage4.Controls.Add(this.btnDisabledItemStartColor);
            this.binaryPowerTabPage4.Controls.Add(this.btnItemReadOnlyBorderColorProvider);
            this.binaryPowerTabPage4.Controls.Add(this.btnItemReadOnlyEndColorProvider);
            this.binaryPowerTabPage4.Controls.Add(this.btnItemReadOnlyStartColorProvider);
            this.binaryPowerTabPage4.Controls.Add(this.btnItemSelectedEndColorProvider);
            this.binaryPowerTabPage4.Controls.Add(this.btnItemSelectedStartColorProvider);
            this.binaryPowerTabPage4.Controls.Add(this.nmItemMouseHoverGradientFactorProvider);
            this.binaryPowerTabPage4.Controls.Add(this.nmItemUnselectedColorGradientProvider);
            this.binaryPowerTabPage4.Controls.Add(this.nmItemSelectedColorGradientProvider);
            this.binaryPowerTabPage4.Controls.Add(this.btnItemUnselectedBorderColorProvider);
            this.binaryPowerTabPage4.Controls.Add(this.btnItemSelectedBorderColorProvider);
            this.binaryPowerTabPage4.Controls.Add(this.btnItemUnselectedEndColorProvider);
            this.binaryPowerTabPage4.Controls.Add(this.btnItemUnselectedStartColorProvider);
            this.binaryPowerTabPage4.Controls.Add(this.btnItemTitleFontProvider);
            this.binaryPowerTabPage4.Controls.Add(this.btnItemContentFontProvider);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel33);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel31);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel51);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel37);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel39);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel35);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel36);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel34);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel48);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel47);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel52);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel44);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel56);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel57);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel54);
            this.binaryPowerTabPage4.Controls.Add(this.extendedLabel55);
            this.binaryPowerTabPage4.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage4.IsBackgroundTransparent = false;
            this.binaryPowerTabPage4.IsHeaderEnabled = true;
            this.binaryPowerTabPage4.Name = "binaryPowerTabPage4";
            this.binaryPowerTabPage4.Size = new System.Drawing.Size(799, 224);
            this.binaryPowerTabPage4.TabIndex = 3;
            this.binaryPowerTabPage4.TabPageContentIsDirty = false;
            this.binaryPowerTabPage4.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.Text = "Colors, Gradients & Fonts";
            this.binaryPowerTabPage4.ToolTipText = "";
            // 
            // btnDisabledItemEndColor
            // 
            this.btnDisabledItemEndColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisabledItemEndColor.Location = new System.Drawing.Point(371, 183);
            this.btnDisabledItemEndColor.Name = "btnDisabledItemEndColor";
            this.btnDisabledItemEndColor.Size = new System.Drawing.Size(41, 23);
            this.btnDisabledItemEndColor.TabIndex = 142;
            this.btnDisabledItemEndColor.Text = "...";
            this.btnDisabledItemEndColor.UseVisualStyleBackColor = true;
            this.btnDisabledItemEndColor.Click += new System.EventHandler(this.DisabledItemEndColorClick);
            // 
            // btnDisabledItemStartColor
            // 
            this.btnDisabledItemStartColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisabledItemStartColor.Location = new System.Drawing.Point(159, 180);
            this.btnDisabledItemStartColor.Name = "btnDisabledItemStartColor";
            this.btnDisabledItemStartColor.Size = new System.Drawing.Size(42, 23);
            this.btnDisabledItemStartColor.TabIndex = 140;
            this.btnDisabledItemStartColor.Text = "...";
            this.btnDisabledItemStartColor.UseVisualStyleBackColor = true;
            this.btnDisabledItemStartColor.Click += new System.EventHandler(this.DisabledItemStartColorClick);
            // 
            // btnItemReadOnlyBorderColorProvider
            // 
            this.btnItemReadOnlyBorderColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemReadOnlyBorderColorProvider.Location = new System.Drawing.Point(577, 33);
            this.btnItemReadOnlyBorderColorProvider.Name = "btnItemReadOnlyBorderColorProvider";
            this.btnItemReadOnlyBorderColorProvider.Size = new System.Drawing.Size(41, 23);
            this.btnItemReadOnlyBorderColorProvider.TabIndex = 138;
            this.btnItemReadOnlyBorderColorProvider.Text = "...";
            this.btnItemReadOnlyBorderColorProvider.UseVisualStyleBackColor = true;
            this.btnItemReadOnlyBorderColorProvider.Click += new System.EventHandler(this.ItemReadOnlyBorderColorProviderClick);
            // 
            // btnItemReadOnlyEndColorProvider
            // 
            this.btnItemReadOnlyEndColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemReadOnlyEndColorProvider.Location = new System.Drawing.Point(370, 146);
            this.btnItemReadOnlyEndColorProvider.Name = "btnItemReadOnlyEndColorProvider";
            this.btnItemReadOnlyEndColorProvider.Size = new System.Drawing.Size(41, 23);
            this.btnItemReadOnlyEndColorProvider.TabIndex = 136;
            this.btnItemReadOnlyEndColorProvider.Text = "...";
            this.btnItemReadOnlyEndColorProvider.UseVisualStyleBackColor = true;
            this.btnItemReadOnlyEndColorProvider.Click += new System.EventHandler(this.ItemReadOnlyEndColorProviderClick);
            // 
            // btnItemReadOnlyStartColorProvider
            // 
            this.btnItemReadOnlyStartColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemReadOnlyStartColorProvider.Location = new System.Drawing.Point(159, 146);
            this.btnItemReadOnlyStartColorProvider.Name = "btnItemReadOnlyStartColorProvider";
            this.btnItemReadOnlyStartColorProvider.Size = new System.Drawing.Size(41, 23);
            this.btnItemReadOnlyStartColorProvider.TabIndex = 134;
            this.btnItemReadOnlyStartColorProvider.Text = "...";
            this.btnItemReadOnlyStartColorProvider.UseVisualStyleBackColor = true;
            this.btnItemReadOnlyStartColorProvider.Click += new System.EventHandler(this.ItemReadOnlyStartColorProviderClick);
            // 
            // btnItemSelectedEndColorProvider
            // 
            this.btnItemSelectedEndColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemSelectedEndColorProvider.Location = new System.Drawing.Point(370, 117);
            this.btnItemSelectedEndColorProvider.Name = "btnItemSelectedEndColorProvider";
            this.btnItemSelectedEndColorProvider.Size = new System.Drawing.Size(41, 23);
            this.btnItemSelectedEndColorProvider.TabIndex = 132;
            this.btnItemSelectedEndColorProvider.Text = "...";
            this.btnItemSelectedEndColorProvider.UseVisualStyleBackColor = true;
            this.btnItemSelectedEndColorProvider.Click += new System.EventHandler(this.ItemSelectedEndColorProviderClick);
            // 
            // btnItemSelectedStartColorProvider
            // 
            this.btnItemSelectedStartColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemSelectedStartColorProvider.Location = new System.Drawing.Point(370, 89);
            this.btnItemSelectedStartColorProvider.Name = "btnItemSelectedStartColorProvider";
            this.btnItemSelectedStartColorProvider.Size = new System.Drawing.Size(41, 23);
            this.btnItemSelectedStartColorProvider.TabIndex = 131;
            this.btnItemSelectedStartColorProvider.Text = "...";
            this.btnItemSelectedStartColorProvider.UseVisualStyleBackColor = true;
            this.btnItemSelectedStartColorProvider.Click += new System.EventHandler(this.ItemSelectedStartColorProviderClick);
            // 
            // nmItemMouseHoverGradientFactorProvider
            // 
            this.nmItemMouseHoverGradientFactorProvider.Location = new System.Drawing.Point(578, 73);
            this.nmItemMouseHoverGradientFactorProvider.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nmItemMouseHoverGradientFactorProvider.Name = "nmItemMouseHoverGradientFactorProvider";
            this.nmItemMouseHoverGradientFactorProvider.Size = new System.Drawing.Size(41, 20);
            this.nmItemMouseHoverGradientFactorProvider.TabIndex = 128;
            this.nmItemMouseHoverGradientFactorProvider.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nmItemMouseHoverGradientFactorProvider.ValueChanged += new System.EventHandler(this.ItemMouseHoverGradientFactorProviderValueChanged);
            // 
            // nmItemUnselectedColorGradientProvider
            // 
            this.nmItemUnselectedColorGradientProvider.Location = new System.Drawing.Point(578, 150);
            this.nmItemUnselectedColorGradientProvider.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nmItemUnselectedColorGradientProvider.Name = "nmItemUnselectedColorGradientProvider";
            this.nmItemUnselectedColorGradientProvider.Size = new System.Drawing.Size(41, 20);
            this.nmItemUnselectedColorGradientProvider.TabIndex = 115;
            this.nmItemUnselectedColorGradientProvider.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nmItemUnselectedColorGradientProvider.ValueChanged += new System.EventHandler(this.ItemUnselectedColorGradientProviderValueChanged);
            // 
            // nmItemSelectedColorGradientProvider
            // 
            this.nmItemSelectedColorGradientProvider.Location = new System.Drawing.Point(578, 114);
            this.nmItemSelectedColorGradientProvider.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nmItemSelectedColorGradientProvider.Name = "nmItemSelectedColorGradientProvider";
            this.nmItemSelectedColorGradientProvider.Size = new System.Drawing.Size(41, 20);
            this.nmItemSelectedColorGradientProvider.TabIndex = 113;
            this.nmItemSelectedColorGradientProvider.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nmItemSelectedColorGradientProvider.ValueChanged += new System.EventHandler(this.ItemSelectedColorGradientProviderValueChanged);
            // 
            // btnItemUnselectedBorderColorProvider
            // 
            this.btnItemUnselectedBorderColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemUnselectedBorderColorProvider.Location = new System.Drawing.Point(370, 60);
            this.btnItemUnselectedBorderColorProvider.Name = "btnItemUnselectedBorderColorProvider";
            this.btnItemUnselectedBorderColorProvider.Size = new System.Drawing.Size(39, 23);
            this.btnItemUnselectedBorderColorProvider.TabIndex = 118;
            this.btnItemUnselectedBorderColorProvider.Text = "...";
            this.btnItemUnselectedBorderColorProvider.UseVisualStyleBackColor = true;
            this.btnItemUnselectedBorderColorProvider.Click += new System.EventHandler(this.ItemUnselectedBorderColorProviderClick);
            // 
            // btnItemSelectedBorderColorProvider
            // 
            this.btnItemSelectedBorderColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemSelectedBorderColorProvider.Location = new System.Drawing.Point(370, 31);
            this.btnItemSelectedBorderColorProvider.Name = "btnItemSelectedBorderColorProvider";
            this.btnItemSelectedBorderColorProvider.Size = new System.Drawing.Size(39, 23);
            this.btnItemSelectedBorderColorProvider.TabIndex = 107;
            this.btnItemSelectedBorderColorProvider.Text = "...";
            this.btnItemSelectedBorderColorProvider.UseVisualStyleBackColor = true;
            this.btnItemSelectedBorderColorProvider.Click += new System.EventHandler(this.ItemSelectedBorderColorProviderClick);
            // 
            // btnItemUnselectedEndColorProvider
            // 
            this.btnItemUnselectedEndColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemUnselectedEndColorProvider.Location = new System.Drawing.Point(159, 117);
            this.btnItemUnselectedEndColorProvider.Name = "btnItemUnselectedEndColorProvider";
            this.btnItemUnselectedEndColorProvider.Size = new System.Drawing.Size(41, 23);
            this.btnItemUnselectedEndColorProvider.TabIndex = 65;
            this.btnItemUnselectedEndColorProvider.Text = "...";
            this.btnItemUnselectedEndColorProvider.UseVisualStyleBackColor = true;
            this.btnItemUnselectedEndColorProvider.Click += new System.EventHandler(this.ItemUnselectedEndColorProviderClick);
            // 
            // btnItemUnselectedStartColorProvider
            // 
            this.btnItemUnselectedStartColorProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemUnselectedStartColorProvider.Location = new System.Drawing.Point(159, 89);
            this.btnItemUnselectedStartColorProvider.Name = "btnItemUnselectedStartColorProvider";
            this.btnItemUnselectedStartColorProvider.Size = new System.Drawing.Size(41, 23);
            this.btnItemUnselectedStartColorProvider.TabIndex = 64;
            this.btnItemUnselectedStartColorProvider.Text = "...";
            this.btnItemUnselectedStartColorProvider.UseVisualStyleBackColor = true;
            this.btnItemUnselectedStartColorProvider.Click += new System.EventHandler(this.ItemUnselectedStartColorProviderClick);
            // 
            // btnItemTitleFontProvider
            // 
            this.btnItemTitleFontProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemTitleFontProvider.Location = new System.Drawing.Point(159, 60);
            this.btnItemTitleFontProvider.Name = "btnItemTitleFontProvider";
            this.btnItemTitleFontProvider.Size = new System.Drawing.Size(41, 23);
            this.btnItemTitleFontProvider.TabIndex = 61;
            this.btnItemTitleFontProvider.Text = "...";
            this.btnItemTitleFontProvider.UseVisualStyleBackColor = true;
            this.btnItemTitleFontProvider.Click += new System.EventHandler(this.ItemTitleFontProviderClick);
            // 
            // btnItemContentFontProvider
            // 
            this.btnItemContentFontProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemContentFontProvider.Location = new System.Drawing.Point(159, 32);
            this.btnItemContentFontProvider.Name = "btnItemContentFontProvider";
            this.btnItemContentFontProvider.Size = new System.Drawing.Size(41, 23);
            this.btnItemContentFontProvider.TabIndex = 60;
            this.btnItemContentFontProvider.Text = "...";
            this.btnItemContentFontProvider.UseVisualStyleBackColor = true;
            this.btnItemContentFontProvider.Click += new System.EventHandler(this.ItemContentFontProviderClick);
            // 
            // extendedLabel33
            // 
            this.extendedLabel33.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel33.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel33.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel33.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel33.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel33.DropShadowMargin = 6;
            this.extendedLabel33.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel33.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel33.IsBackgroundTransparent = true;
            this.extendedLabel33.Location = new System.Drawing.Point(212, 175);
            this.extendedLabel33.Name = "extendedLabel33";
            this.extendedLabel33.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel33.ShouldDrawBorder = false;
            this.extendedLabel33.ShouldDrawDropShadow = false;
            this.extendedLabel33.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel33.Size = new System.Drawing.Size(151, 30);
            this.extendedLabel33.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel33.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat51.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat51.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat51.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat51.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel33.StringFormat = stringFormat51;
            this.extendedLabel33.TabIndex = 141;
            this.extendedLabel33.TabStop = false;
            this.extendedLabel33.Text = "Item disabled-mode end color:";
            this.extendedLabel33.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel33.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel31
            // 
            this.extendedLabel31.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel31.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel31.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel31.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel31.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel31.DropShadowMargin = 6;
            this.extendedLabel31.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel31.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel31.IsBackgroundTransparent = true;
            this.extendedLabel31.Location = new System.Drawing.Point(7, 174);
            this.extendedLabel31.Name = "extendedLabel31";
            this.extendedLabel31.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel31.ShouldDrawBorder = false;
            this.extendedLabel31.ShouldDrawDropShadow = false;
            this.extendedLabel31.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel31.Size = new System.Drawing.Size(152, 30);
            this.extendedLabel31.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel31.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat52.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat52.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat52.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat52.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel31.StringFormat = stringFormat52;
            this.extendedLabel31.TabIndex = 139;
            this.extendedLabel31.TabStop = false;
            this.extendedLabel31.Text = "Item disabled-mode start color:";
            this.extendedLabel31.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel31.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel51
            // 
            this.extendedLabel51.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel51.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel51.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel51.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel51.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel51.DropShadowMargin = 6;
            this.extendedLabel51.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel51.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel51.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel51.IsBackgroundTransparent = true;
            this.extendedLabel51.Location = new System.Drawing.Point(423, 34);
            this.extendedLabel51.Name = "extendedLabel51";
            this.extendedLabel51.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel51.ShouldDrawBorder = false;
            this.extendedLabel51.ShouldDrawDropShadow = false;
            this.extendedLabel51.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel51.Size = new System.Drawing.Size(152, 19);
            this.extendedLabel51.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel51.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat53.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat53.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat53.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat53.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel51.StringFormat = stringFormat53;
            this.extendedLabel51.TabIndex = 137;
            this.extendedLabel51.TabStop = false;
            this.extendedLabel51.Text = "Item read-only border color:";
            this.extendedLabel51.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel51.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel37
            // 
            this.extendedLabel37.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel37.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel37.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel37.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel37.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel37.DropShadowMargin = 6;
            this.extendedLabel37.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel37.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel37.IsBackgroundTransparent = true;
            this.extendedLabel37.Location = new System.Drawing.Point(211, 147);
            this.extendedLabel37.Name = "extendedLabel37";
            this.extendedLabel37.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel37.ShouldDrawBorder = false;
            this.extendedLabel37.ShouldDrawDropShadow = false;
            this.extendedLabel37.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel37.Size = new System.Drawing.Size(152, 19);
            this.extendedLabel37.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel37.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat54.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat54.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat54.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat54.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel37.StringFormat = stringFormat54;
            this.extendedLabel37.TabIndex = 135;
            this.extendedLabel37.TabStop = false;
            this.extendedLabel37.Text = "Item read-only end color:";
            this.extendedLabel37.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel37.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel39
            // 
            this.extendedLabel39.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel39.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel39.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel39.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel39.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel39.DropShadowMargin = 6;
            this.extendedLabel39.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel39.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel39.IsBackgroundTransparent = true;
            this.extendedLabel39.Location = new System.Drawing.Point(7, 147);
            this.extendedLabel39.Name = "extendedLabel39";
            this.extendedLabel39.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel39.ShouldDrawBorder = false;
            this.extendedLabel39.ShouldDrawDropShadow = false;
            this.extendedLabel39.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel39.Size = new System.Drawing.Size(152, 19);
            this.extendedLabel39.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel39.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat55.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat55.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat55.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat55.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel39.StringFormat = stringFormat55;
            this.extendedLabel39.TabIndex = 133;
            this.extendedLabel39.TabStop = false;
            this.extendedLabel39.Text = "Item read-only start color:";
            this.extendedLabel39.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel39.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel35
            // 
            this.extendedLabel35.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel35.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel35.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel35.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel35.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel35.DropShadowMargin = 6;
            this.extendedLabel35.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel35.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel35.IsBackgroundTransparent = true;
            this.extendedLabel35.Location = new System.Drawing.Point(211, 118);
            this.extendedLabel35.Name = "extendedLabel35";
            this.extendedLabel35.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel35.ShouldDrawBorder = false;
            this.extendedLabel35.ShouldDrawDropShadow = false;
            this.extendedLabel35.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel35.Size = new System.Drawing.Size(152, 19);
            this.extendedLabel35.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel35.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat56.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat56.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat56.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat56.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel35.StringFormat = stringFormat56;
            this.extendedLabel35.TabIndex = 130;
            this.extendedLabel35.TabStop = false;
            this.extendedLabel35.Text = "Item selected end color:";
            this.extendedLabel35.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel35.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel36
            // 
            this.extendedLabel36.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel36.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel36.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel36.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel36.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel36.DropShadowMargin = 6;
            this.extendedLabel36.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel36.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel36.IsBackgroundTransparent = true;
            this.extendedLabel36.Location = new System.Drawing.Point(211, 90);
            this.extendedLabel36.Name = "extendedLabel36";
            this.extendedLabel36.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel36.ShouldDrawBorder = false;
            this.extendedLabel36.ShouldDrawDropShadow = false;
            this.extendedLabel36.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel36.Size = new System.Drawing.Size(152, 19);
            this.extendedLabel36.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel36.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat57.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat57.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat57.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat57.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel36.StringFormat = stringFormat57;
            this.extendedLabel36.TabIndex = 129;
            this.extendedLabel36.TabStop = false;
            this.extendedLabel36.Text = "Item selected start color:";
            this.extendedLabel36.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel36.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel34
            // 
            this.extendedLabel34.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel34.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel34.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel34.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel34.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel34.DropShadowMargin = 6;
            this.extendedLabel34.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel34.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel34.IsBackgroundTransparent = true;
            this.extendedLabel34.Location = new System.Drawing.Point(423, 61);
            this.extendedLabel34.Name = "extendedLabel34";
            this.extendedLabel34.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel34.ShouldDrawBorder = false;
            this.extendedLabel34.ShouldDrawDropShadow = false;
            this.extendedLabel34.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel34.Size = new System.Drawing.Size(136, 31);
            this.extendedLabel34.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel34.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat58.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat58.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat58.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat58.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel34.StringFormat = stringFormat58;
            this.extendedLabel34.TabIndex = 127;
            this.extendedLabel34.TabStop = false;
            this.extendedLabel34.Text = "Item mouse-hover gradient factor:";
            this.extendedLabel34.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel34.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel48
            // 
            this.extendedLabel48.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel48.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel48.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel48.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel48.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel48.DropShadowMargin = 6;
            this.extendedLabel48.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel48.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel48.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel48.IsBackgroundTransparent = true;
            this.extendedLabel48.Location = new System.Drawing.Point(423, 142);
            this.extendedLabel48.Name = "extendedLabel48";
            this.extendedLabel48.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel48.ShouldDrawBorder = false;
            this.extendedLabel48.ShouldDrawDropShadow = false;
            this.extendedLabel48.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel48.Size = new System.Drawing.Size(130, 37);
            this.extendedLabel48.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel48.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat59.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat59.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat59.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat59.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel48.StringFormat = stringFormat59;
            this.extendedLabel48.TabIndex = 111;
            this.extendedLabel48.TabStop = false;
            this.extendedLabel48.Text = "Item Unselected color gradient factor:";
            this.extendedLabel48.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel48.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel47
            // 
            this.extendedLabel47.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel47.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel47.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel47.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel47.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel47.DropShadowMargin = 6;
            this.extendedLabel47.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel47.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel47.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel47.IsBackgroundTransparent = true;
            this.extendedLabel47.Location = new System.Drawing.Point(211, 62);
            this.extendedLabel47.Name = "extendedLabel47";
            this.extendedLabel47.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel47.ShouldDrawBorder = false;
            this.extendedLabel47.ShouldDrawDropShadow = false;
            this.extendedLabel47.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel47.Size = new System.Drawing.Size(162, 19);
            this.extendedLabel47.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel47.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat60.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat60.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat60.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat60.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel47.StringFormat = stringFormat60;
            this.extendedLabel47.TabIndex = 117;
            this.extendedLabel47.TabStop = false;
            this.extendedLabel47.Text = "Item unselected border color:";
            this.extendedLabel47.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel47.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel52
            // 
            this.extendedLabel52.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel52.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel52.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel52.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel52.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel52.DropShadowMargin = 6;
            this.extendedLabel52.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel52.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel52.IsBackgroundTransparent = true;
            this.extendedLabel52.Location = new System.Drawing.Point(423, 103);
            this.extendedLabel52.Name = "extendedLabel52";
            this.extendedLabel52.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel52.ShouldDrawBorder = false;
            this.extendedLabel52.ShouldDrawDropShadow = false;
            this.extendedLabel52.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel52.Size = new System.Drawing.Size(130, 30);
            this.extendedLabel52.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel52.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat61.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat61.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat61.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat61.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel52.StringFormat = stringFormat61;
            this.extendedLabel52.TabIndex = 107;
            this.extendedLabel52.TabStop = false;
            this.extendedLabel52.Text = "Item Selected color gradient factor:";
            this.extendedLabel52.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel52.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel44
            // 
            this.extendedLabel44.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel44.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel44.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel44.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel44.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel44.DropShadowMargin = 6;
            this.extendedLabel44.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel44.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel44.IsBackgroundTransparent = true;
            this.extendedLabel44.Location = new System.Drawing.Point(211, 34);
            this.extendedLabel44.Name = "extendedLabel44";
            this.extendedLabel44.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel44.ShouldDrawBorder = false;
            this.extendedLabel44.ShouldDrawDropShadow = false;
            this.extendedLabel44.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel44.Size = new System.Drawing.Size(149, 19);
            this.extendedLabel44.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel44.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat62.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat62.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat62.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat62.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel44.StringFormat = stringFormat62;
            this.extendedLabel44.TabIndex = 105;
            this.extendedLabel44.TabStop = false;
            this.extendedLabel44.Text = "Item selected border color:";
            this.extendedLabel44.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel44.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel56
            // 
            this.extendedLabel56.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel56.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel56.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel56.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel56.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel56.DropShadowMargin = 6;
            this.extendedLabel56.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel56.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel56.IsBackgroundTransparent = true;
            this.extendedLabel56.Location = new System.Drawing.Point(7, 118);
            this.extendedLabel56.Name = "extendedLabel56";
            this.extendedLabel56.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel56.ShouldDrawBorder = false;
            this.extendedLabel56.ShouldDrawDropShadow = false;
            this.extendedLabel56.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel56.Size = new System.Drawing.Size(152, 19);
            this.extendedLabel56.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel56.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat63.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat63.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat63.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat63.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel56.StringFormat = stringFormat63;
            this.extendedLabel56.TabIndex = 63;
            this.extendedLabel56.TabStop = false;
            this.extendedLabel56.Text = "Item Unselected end color:";
            this.extendedLabel56.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel56.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel57
            // 
            this.extendedLabel57.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel57.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel57.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel57.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel57.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel57.DropShadowMargin = 6;
            this.extendedLabel57.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel57.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel57.IsBackgroundTransparent = true;
            this.extendedLabel57.Location = new System.Drawing.Point(7, 90);
            this.extendedLabel57.Name = "extendedLabel57";
            this.extendedLabel57.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel57.ShouldDrawBorder = false;
            this.extendedLabel57.ShouldDrawDropShadow = false;
            this.extendedLabel57.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel57.Size = new System.Drawing.Size(152, 19);
            this.extendedLabel57.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel57.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat64.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat64.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat64.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat64.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel57.StringFormat = stringFormat64;
            this.extendedLabel57.TabIndex = 62;
            this.extendedLabel57.TabStop = false;
            this.extendedLabel57.Text = "Item Unselected start color:";
            this.extendedLabel57.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel57.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel54
            // 
            this.extendedLabel54.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel54.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel54.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel54.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel54.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel54.DropShadowMargin = 6;
            this.extendedLabel54.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel54.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel54.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel54.IsBackgroundTransparent = true;
            this.extendedLabel54.Location = new System.Drawing.Point(9, 61);
            this.extendedLabel54.Name = "extendedLabel54";
            this.extendedLabel54.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel54.ShouldDrawBorder = false;
            this.extendedLabel54.ShouldDrawDropShadow = false;
            this.extendedLabel54.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel54.Size = new System.Drawing.Size(136, 19);
            this.extendedLabel54.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel54.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat65.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat65.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat65.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat65.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel54.StringFormat = stringFormat65;
            this.extendedLabel54.TabIndex = 59;
            this.extendedLabel54.TabStop = false;
            this.extendedLabel54.Text = "Item Title font:";
            this.extendedLabel54.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel54.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel55
            // 
            this.extendedLabel55.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel55.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel55.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel55.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel55.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel55.DropShadowMargin = 6;
            this.extendedLabel55.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel55.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel55.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel55.IsBackgroundTransparent = true;
            this.extendedLabel55.Location = new System.Drawing.Point(9, 33);
            this.extendedLabel55.Name = "extendedLabel55";
            this.extendedLabel55.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel55.ShouldDrawBorder = false;
            this.extendedLabel55.ShouldDrawDropShadow = false;
            this.extendedLabel55.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel55.Size = new System.Drawing.Size(136, 19);
            this.extendedLabel55.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel55.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat66.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat66.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat66.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat66.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel55.StringFormat = stringFormat66;
            this.extendedLabel55.TabIndex = 58;
            this.extendedLabel55.TabStop = false;
            this.extendedLabel55.Text = "Item content font:";
            this.extendedLabel55.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel55.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // binaryPowerTabPage2
            // 
            this.binaryPowerTabPage2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryPowerTabPage2.BorderSize = 1;
            this.binaryPowerTabPage2.Controls.Add(this.btnTooltipTitleFontProvider);
            this.binaryPowerTabPage2.Controls.Add(this.btnTooltipContentFontProvider);
            this.binaryPowerTabPage2.Controls.Add(this.chkIsImageDrawnWhenUsingDefaultItemTooltip);
            this.binaryPowerTabPage2.Controls.Add(this.chkShouldShowDefaultTooltipOnItemHover);
            this.binaryPowerTabPage2.Controls.Add(this.extendedLabel60);
            this.binaryPowerTabPage2.Controls.Add(this.extendedLabel61);
            this.binaryPowerTabPage2.CurrentlySelected = true;
            this.binaryPowerTabPage2.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage2.IsBackgroundTransparent = false;
            this.binaryPowerTabPage2.IsHeaderEnabled = true;
            this.binaryPowerTabPage2.Name = "binaryPowerTabPage2";
            this.binaryPowerTabPage2.Size = new System.Drawing.Size(799, 224);
            this.binaryPowerTabPage2.TabIndex = 1;
            this.binaryPowerTabPage2.TabPageContentIsDirty = false;
            this.binaryPowerTabPage2.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.Text = "Tooltip";
            this.binaryPowerTabPage2.ToolTipText = "";
            // 
            // btnTooltipTitleFontProvider
            // 
            this.btnTooltipTitleFontProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTooltipTitleFontProvider.Location = new System.Drawing.Point(167, 95);
            this.btnTooltipTitleFontProvider.Name = "btnTooltipTitleFontProvider";
            this.btnTooltipTitleFontProvider.Size = new System.Drawing.Size(41, 23);
            this.btnTooltipTitleFontProvider.TabIndex = 65;
            this.btnTooltipTitleFontProvider.Text = "...";
            this.btnTooltipTitleFontProvider.UseVisualStyleBackColor = true;
            this.btnTooltipTitleFontProvider.Click += new System.EventHandler(this.TooltipTitleFontProviderClick);
            // 
            // btnTooltipContentFontProvider
            // 
            this.btnTooltipContentFontProvider.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTooltipContentFontProvider.Location = new System.Drawing.Point(167, 67);
            this.btnTooltipContentFontProvider.Name = "btnTooltipContentFontProvider";
            this.btnTooltipContentFontProvider.Size = new System.Drawing.Size(41, 23);
            this.btnTooltipContentFontProvider.TabIndex = 64;
            this.btnTooltipContentFontProvider.Text = "...";
            this.btnTooltipContentFontProvider.UseVisualStyleBackColor = true;
            this.btnTooltipContentFontProvider.Click += new System.EventHandler(this.TooltipContentFontProviderClick);
            // 
            // chkIsImageDrawnWhenUsingDefaultItemTooltip
            // 
            this.chkIsImageDrawnWhenUsingDefaultItemTooltip.AutoSize = true;
            this.chkIsImageDrawnWhenUsingDefaultItemTooltip.BackColor = System.Drawing.Color.Transparent;
            this.chkIsImageDrawnWhenUsingDefaultItemTooltip.Location = new System.Drawing.Point(21, 40);
            this.chkIsImageDrawnWhenUsingDefaultItemTooltip.Name = "chkIsImageDrawnWhenUsingDefaultItemTooltip";
            this.chkIsImageDrawnWhenUsingDefaultItemTooltip.Size = new System.Drawing.Size(251, 17);
            this.chkIsImageDrawnWhenUsingDefaultItemTooltip.TabIndex = 26;
            this.chkIsImageDrawnWhenUsingDefaultItemTooltip.Text = "Is image drawn when using default item tooltip ?";
            this.chkIsImageDrawnWhenUsingDefaultItemTooltip.UseVisualStyleBackColor = false;
            this.chkIsImageDrawnWhenUsingDefaultItemTooltip.CheckedChanged += new System.EventHandler(this.IsImageDrawnWhenUsingDefaultItemTooltipCheckedChanged);
            // 
            // chkShouldShowDefaultTooltipOnItemHover
            // 
            this.chkShouldShowDefaultTooltipOnItemHover.AutoSize = true;
            this.chkShouldShowDefaultTooltipOnItemHover.BackColor = System.Drawing.Color.Transparent;
            this.chkShouldShowDefaultTooltipOnItemHover.Location = new System.Drawing.Point(21, 17);
            this.chkShouldShowDefaultTooltipOnItemHover.Name = "chkShouldShowDefaultTooltipOnItemHover";
            this.chkShouldShowDefaultTooltipOnItemHover.Size = new System.Drawing.Size(232, 17);
            this.chkShouldShowDefaultTooltipOnItemHover.TabIndex = 25;
            this.chkShouldShowDefaultTooltipOnItemHover.Text = "Should show default tooltip upon item hover";
            this.chkShouldShowDefaultTooltipOnItemHover.UseVisualStyleBackColor = false;
            this.chkShouldShowDefaultTooltipOnItemHover.CheckedChanged += new System.EventHandler(this.ShouldShowDefaultTooltipOnItemHoverCheckedChanged);
            // 
            // extendedLabel60
            // 
            this.extendedLabel60.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel60.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel60.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel60.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel60.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel60.DropShadowMargin = 6;
            this.extendedLabel60.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel60.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel60.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel60.IsBackgroundTransparent = true;
            this.extendedLabel60.Location = new System.Drawing.Point(16, 94);
            this.extendedLabel60.Name = "extendedLabel60";
            this.extendedLabel60.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel60.ShouldDrawBorder = false;
            this.extendedLabel60.ShouldDrawDropShadow = false;
            this.extendedLabel60.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel60.Size = new System.Drawing.Size(129, 19);
            this.extendedLabel60.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel60.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat67.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat67.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat67.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat67.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel60.StringFormat = stringFormat67;
            this.extendedLabel60.TabIndex = 63;
            this.extendedLabel60.TabStop = false;
            this.extendedLabel60.Text = "Tooltip title font:";
            this.extendedLabel60.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel60.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel61
            // 
            this.extendedLabel61.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel61.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel61.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel61.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel61.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel61.DropShadowMargin = 6;
            this.extendedLabel61.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel61.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel61.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel61.IsBackgroundTransparent = true;
            this.extendedLabel61.Location = new System.Drawing.Point(16, 66);
            this.extendedLabel61.Name = "extendedLabel61";
            this.extendedLabel61.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel61.ShouldDrawBorder = false;
            this.extendedLabel61.ShouldDrawDropShadow = false;
            this.extendedLabel61.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel61.Size = new System.Drawing.Size(129, 19);
            this.extendedLabel61.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel61.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat68.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat68.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat68.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat68.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel61.StringFormat = stringFormat68;
            this.extendedLabel61.TabIndex = 62;
            this.extendedLabel61.TabStop = false;
            this.extendedLabel61.Text = "Tooltip content font:";
            this.extendedLabel61.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel61.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // chkAreItemsInFullItemView
            // 
            this.chkAreItemsInFullItemView.BackColor = System.Drawing.Color.Transparent;
            this.chkAreItemsInFullItemView.Checked = true;
            this.chkAreItemsInFullItemView.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkAreItemsInFullItemView.Location = new System.Drawing.Point(22, 185);
            this.chkAreItemsInFullItemView.Name = "chkAreItemsInFullItemView";
            this.chkAreItemsInFullItemView.Size = new System.Drawing.Size(171, 31);
            this.chkAreItemsInFullItemView.TabIndex = 28;
            this.chkAreItemsInFullItemView.Text = "Are items displayed in full item view?";
            this.chkAreItemsInFullItemView.UseVisualStyleBackColor = false;
            this.chkAreItemsInFullItemView.CheckedChanged += new System.EventHandler(this.AreItemsInFullItemViewCheckedChanged);
            // 
            // extVerticalScrollInfo
            // 
            this.extVerticalScrollInfo.BackgroundGradientFloatAngle = 0F;
            this.extVerticalScrollInfo.BorderColor = System.Drawing.Color.Black;
            this.extVerticalScrollInfo.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extVerticalScrollInfo.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extVerticalScrollInfo.DropShadowGradientFloatAngle = 45F;
            this.extVerticalScrollInfo.DropShadowMargin = 6;
            this.extVerticalScrollInfo.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extVerticalScrollInfo.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extVerticalScrollInfo.IsBackgroundTransparent = true;
            this.extVerticalScrollInfo.Location = new System.Drawing.Point(581, 663);
            this.extVerticalScrollInfo.Name = "extVerticalScrollInfo";
            this.extVerticalScrollInfo.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extVerticalScrollInfo.ShouldDrawBorder = false;
            this.extVerticalScrollInfo.ShouldDrawDropShadow = false;
            this.extVerticalScrollInfo.ShouldRefreshUponParentMoveResize = false;
            this.extVerticalScrollInfo.Size = new System.Drawing.Size(384, 71);
            this.extVerticalScrollInfo.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extVerticalScrollInfo.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat69.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat69.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat69.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat69.Trimming = System.Drawing.StringTrimming.Character;
            this.extVerticalScrollInfo.StringFormat = stringFormat69;
            this.extVerticalScrollInfo.TabIndex = 27;
            this.extVerticalScrollInfo.TabStop = false;
            this.extVerticalScrollInfo.Text = "None as yet.";
            this.extVerticalScrollInfo.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extVerticalScrollInfo.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel8
            // 
            this.extendedLabel8.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel8.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel8.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel8.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel8.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel8.DropShadowMargin = 6;
            this.extendedLabel8.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel8.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel8.ForeColor = System.Drawing.Color.Maroon;
            this.extendedLabel8.IsBackgroundTransparent = true;
            this.extendedLabel8.Location = new System.Drawing.Point(581, 639);
            this.extendedLabel8.Name = "extendedLabel8";
            this.extendedLabel8.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel8.ShouldDrawBorder = false;
            this.extendedLabel8.ShouldDrawDropShadow = false;
            this.extendedLabel8.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel8.Size = new System.Drawing.Size(382, 20);
            this.extendedLabel8.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel8.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat70.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat70.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat70.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat70.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel8.StringFormat = stringFormat70;
            this.extendedLabel8.TabIndex = 26;
            this.extendedLabel8.TabStop = false;
            this.extendedLabel8.Text = "Event information obtained from VerticalScroll event:";
            this.extendedLabel8.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel8.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extLblHoverItemInfo
            // 
            this.extLblHoverItemInfo.BackgroundGradientFloatAngle = 0F;
            this.extLblHoverItemInfo.BorderColor = System.Drawing.Color.Black;
            this.extLblHoverItemInfo.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extLblHoverItemInfo.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extLblHoverItemInfo.DropShadowGradientFloatAngle = 45F;
            this.extLblHoverItemInfo.DropShadowMargin = 6;
            this.extLblHoverItemInfo.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extLblHoverItemInfo.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extLblHoverItemInfo.IsBackgroundTransparent = true;
            this.extLblHoverItemInfo.Location = new System.Drawing.Point(580, 578);
            this.extLblHoverItemInfo.Name = "extLblHoverItemInfo";
            this.extLblHoverItemInfo.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extLblHoverItemInfo.ShouldDrawBorder = false;
            this.extLblHoverItemInfo.ShouldDrawDropShadow = false;
            this.extLblHoverItemInfo.ShouldRefreshUponParentMoveResize = false;
            this.extLblHoverItemInfo.Size = new System.Drawing.Size(384, 49);
            this.extLblHoverItemInfo.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extLblHoverItemInfo.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat71.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat71.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat71.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat71.Trimming = System.Drawing.StringTrimming.Character;
            this.extLblHoverItemInfo.StringFormat = stringFormat71;
            this.extLblHoverItemInfo.TabIndex = 23;
            this.extLblHoverItemInfo.TabStop = false;
            this.extLblHoverItemInfo.Text = "None as yet.";
            this.extLblHoverItemInfo.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extLblHoverItemInfo.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel5
            // 
            this.extendedLabel5.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel5.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel5.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel5.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel5.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel5.DropShadowMargin = 6;
            this.extendedLabel5.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel5.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel5.ForeColor = System.Drawing.Color.Maroon;
            this.extendedLabel5.IsBackgroundTransparent = true;
            this.extendedLabel5.Location = new System.Drawing.Point(580, 554);
            this.extendedLabel5.Name = "extendedLabel5";
            this.extendedLabel5.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel5.ShouldDrawBorder = false;
            this.extendedLabel5.ShouldDrawDropShadow = false;
            this.extendedLabel5.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel5.Size = new System.Drawing.Size(383, 20);
            this.extendedLabel5.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel5.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat72.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat72.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat72.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat72.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel5.StringFormat = stringFormat72;
            this.extendedLabel5.TabIndex = 22;
            this.extendedLabel5.TabStop = false;
            this.extendedLabel5.Text = "Event information obtained from OnItemHoverChanged event:";
            this.extendedLabel5.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel5.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel4
            // 
            this.extendedLabel4.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel4.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel4.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel4.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel4.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel4.DropShadowMargin = 6;
            this.extendedLabel4.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel4.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel4.ForeColor = System.Drawing.Color.Maroon;
            this.extendedLabel4.IsBackgroundTransparent = true;
            this.extendedLabel4.Location = new System.Drawing.Point(17, 411);
            this.extendedLabel4.Name = "extendedLabel4";
            this.extendedLabel4.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel4.ShouldDrawBorder = false;
            this.extendedLabel4.ShouldDrawDropShadow = false;
            this.extendedLabel4.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel4.Size = new System.Drawing.Size(250, 19);
            this.extendedLabel4.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel4.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat73.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat73.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat73.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat73.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel4.StringFormat = stringFormat73;
            this.extendedLabel4.TabIndex = 21;
            this.extendedLabel4.TabStop = false;
            this.extendedLabel4.Text = "Call special API methods:";
            this.extendedLabel4.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel4.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // chkVerticalScrollDetected
            // 
            this.chkVerticalScrollDetected.AutoSize = true;
            this.chkVerticalScrollDetected.BackColor = System.Drawing.Color.Transparent;
            this.chkVerticalScrollDetected.Location = new System.Drawing.Point(585, 489);
            this.chkVerticalScrollDetected.Name = "chkVerticalScrollDetected";
            this.chkVerticalScrollDetected.Size = new System.Drawing.Size(87, 17);
            this.chkVerticalScrollDetected.TabIndex = 20;
            this.chkVerticalScrollDetected.Text = "VerticalScroll";
            this.chkVerticalScrollDetected.UseVisualStyleBackColor = false;
            this.chkVerticalScrollDetected.CheckedChanged += new System.EventHandler(this.VerticalScrollDetectedCheckedChanged);
            // 
            // chkTooltipAboutToBeDisplayed
            // 
            this.chkTooltipAboutToBeDisplayed.AutoSize = true;
            this.chkTooltipAboutToBeDisplayed.BackColor = System.Drawing.Color.Transparent;
            this.chkTooltipAboutToBeDisplayed.Enabled = false;
            this.chkTooltipAboutToBeDisplayed.Location = new System.Drawing.Point(585, 466);
            this.chkTooltipAboutToBeDisplayed.Name = "chkTooltipAboutToBeDisplayed";
            this.chkTooltipAboutToBeDisplayed.Size = new System.Drawing.Size(144, 17);
            this.chkTooltipAboutToBeDisplayed.TabIndex = 19;
            this.chkTooltipAboutToBeDisplayed.Text = "ItemTooltipAboutToDraw";
            this.chkTooltipAboutToBeDisplayed.UseVisualStyleBackColor = false;
            this.chkTooltipAboutToBeDisplayed.CheckedChanged += new System.EventHandler(this.TooltipAboutToBeDisplayedCheckedChanged);
            // 
            // chkOnItemHoverChanged
            // 
            this.chkOnItemHoverChanged.AutoSize = true;
            this.chkOnItemHoverChanged.BackColor = System.Drawing.Color.Transparent;
            this.chkOnItemHoverChanged.Location = new System.Drawing.Point(794, 443);
            this.chkOnItemHoverChanged.Name = "chkOnItemHoverChanged";
            this.chkOnItemHoverChanged.Size = new System.Drawing.Size(118, 17);
            this.chkOnItemHoverChanged.TabIndex = 18;
            this.chkOnItemHoverChanged.Text = "ItemHoverChanged";
            this.chkOnItemHoverChanged.UseVisualStyleBackColor = false;
            this.chkOnItemHoverChanged.CheckedChanged += new System.EventHandler(this.OnItemHoverChangedCheckedChanged);
            // 
            // chkTooltipAboutToPopup
            // 
            this.chkTooltipAboutToPopup.AutoSize = true;
            this.chkTooltipAboutToPopup.BackColor = System.Drawing.Color.Transparent;
            this.chkTooltipAboutToPopup.Location = new System.Drawing.Point(585, 443);
            this.chkTooltipAboutToPopup.Name = "chkTooltipAboutToPopup";
            this.chkTooltipAboutToPopup.Size = new System.Drawing.Size(150, 17);
            this.chkTooltipAboutToPopup.TabIndex = 17;
            this.chkTooltipAboutToPopup.Text = "ItemTooltipAboutToPopup";
            this.chkTooltipAboutToPopup.UseVisualStyleBackColor = false;
            this.chkTooltipAboutToPopup.CheckedChanged += new System.EventHandler(this.TooltipAboutToPopupCheckedChanged);
            // 
            // extendedLabel3
            // 
            this.extendedLabel3.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel3.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel3.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel3.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel3.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel3.DropShadowMargin = 6;
            this.extendedLabel3.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel3.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel3.ForeColor = System.Drawing.Color.Maroon;
            this.extendedLabel3.IsBackgroundTransparent = true;
            this.extendedLabel3.Location = new System.Drawing.Point(579, 411);
            this.extendedLabel3.Name = "extendedLabel3";
            this.extendedLabel3.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel3.ShouldDrawBorder = false;
            this.extendedLabel3.ShouldDrawDropShadow = false;
            this.extendedLabel3.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel3.Size = new System.Drawing.Size(250, 19);
            this.extendedLabel3.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel3.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat74.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat74.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat74.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat74.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel3.StringFormat = stringFormat74;
            this.extendedLabel3.TabIndex = 16;
            this.extendedLabel3.TabStop = false;
            this.extendedLabel3.Text = "Subscribe to Control\'s special events:";
            this.extendedLabel3.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel3.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extLblCurrentSelectedIndex
            // 
            this.extLblCurrentSelectedIndex.BackgroundGradientFloatAngle = 0F;
            this.extLblCurrentSelectedIndex.BorderColor = System.Drawing.Color.Black;
            this.extLblCurrentSelectedIndex.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extLblCurrentSelectedIndex.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extLblCurrentSelectedIndex.DropShadowGradientFloatAngle = 45F;
            this.extLblCurrentSelectedIndex.DropShadowMargin = 6;
            this.extLblCurrentSelectedIndex.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extLblCurrentSelectedIndex.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extLblCurrentSelectedIndex.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extLblCurrentSelectedIndex.ForeColor = System.Drawing.Color.Black;
            this.extLblCurrentSelectedIndex.IsBackgroundTransparent = true;
            this.extLblCurrentSelectedIndex.Location = new System.Drawing.Point(286, 30);
            this.extLblCurrentSelectedIndex.Name = "extLblCurrentSelectedIndex";
            this.extLblCurrentSelectedIndex.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extLblCurrentSelectedIndex.ShouldDrawBorder = false;
            this.extLblCurrentSelectedIndex.ShouldDrawDropShadow = false;
            this.extLblCurrentSelectedIndex.ShouldRefreshUponParentMoveResize = false;
            this.extLblCurrentSelectedIndex.Size = new System.Drawing.Size(51, 20);
            this.extLblCurrentSelectedIndex.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extLblCurrentSelectedIndex.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat75.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat75.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat75.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat75.Trimming = System.Drawing.StringTrimming.Character;
            this.extLblCurrentSelectedIndex.StringFormat = stringFormat75;
            this.extLblCurrentSelectedIndex.TabIndex = 15;
            this.extLblCurrentSelectedIndex.TabStop = false;
            this.extLblCurrentSelectedIndex.Text = "-1";
            this.extLblCurrentSelectedIndex.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extLblCurrentSelectedIndex.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel2
            // 
            this.extendedLabel2.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel2.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel2.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel2.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel2.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel2.DropShadowMargin = 6;
            this.extendedLabel2.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel2.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel2.IsBackgroundTransparent = true;
            this.extendedLabel2.Location = new System.Drawing.Point(18, 479);
            this.extendedLabel2.Name = "extendedLabel2";
            this.extendedLabel2.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel2.ShouldDrawBorder = false;
            this.extendedLabel2.ShouldDrawDropShadow = false;
            this.extendedLabel2.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel2.Size = new System.Drawing.Size(126, 19);
            this.extendedLabel2.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel2.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat76.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat76.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat76.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat76.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel2.StringFormat = stringFormat76;
            this.extendedLabel2.TabIndex = 14;
            this.extendedLabel2.TabStop = false;
            this.extendedLabel2.Text = "Scroll index to view";
            this.extendedLabel2.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel2.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // extendedLabel1
            // 
            this.extendedLabel1.BackgroundGradientFloatAngle = 0F;
            this.extendedLabel1.BorderColor = System.Drawing.Color.Black;
            this.extendedLabel1.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel1.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel1.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel1.DropShadowMargin = 6;
            this.extendedLabel1.EndLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel1.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extendedLabel1.IsBackgroundTransparent = true;
            this.extendedLabel1.Location = new System.Drawing.Point(13, 30);
            this.extendedLabel1.Name = "extendedLabel1";
            this.extendedLabel1.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel1.ShouldDrawBorder = false;
            this.extendedLabel1.ShouldDrawDropShadow = false;
            this.extendedLabel1.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel1.Size = new System.Drawing.Size(144, 20);
            this.extendedLabel1.StartLinearGradientBackgroundColor = System.Drawing.SystemColors.Control;
            this.extendedLabel1.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat77.Alignment = System.Drawing.StringAlignment.Near;
            stringFormat77.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat77.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat77.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel1.StringFormat = stringFormat77;
            this.extendedLabel1.TabIndex = 13;
            this.extendedLabel1.TabStop = false;
            this.extendedLabel1.Text = "Current Selected Index:";
            this.extendedLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.extendedLabel1.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // chkControlIsReadOnly
            // 
            this.chkControlIsReadOnly.AutoSize = true;
            this.chkControlIsReadOnly.BackColor = System.Drawing.Color.Transparent;
            this.chkControlIsReadOnly.Location = new System.Drawing.Point(21, 133);
            this.chkControlIsReadOnly.Name = "chkControlIsReadOnly";
            this.chkControlIsReadOnly.Size = new System.Drawing.Size(121, 17);
            this.chkControlIsReadOnly.TabIndex = 12;
            this.chkControlIsReadOnly.Text = "Control is read-only?";
            this.chkControlIsReadOnly.UseVisualStyleBackColor = false;
            this.chkControlIsReadOnly.CheckedChanged += new System.EventHandler(this.CheckedImageListBoxControlIsReadOnlyCheckedChanged);
            // 
            // chkSelectUponScrollIntoView
            // 
            this.chkSelectUponScrollIntoView.AutoSize = true;
            this.chkSelectUponScrollIntoView.BackColor = System.Drawing.Color.Transparent;
            this.chkSelectUponScrollIntoView.Checked = true;
            this.chkSelectUponScrollIntoView.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSelectUponScrollIntoView.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSelectUponScrollIntoView.Location = new System.Drawing.Point(25, 530);
            this.chkSelectUponScrollIntoView.Name = "chkSelectUponScrollIntoView";
            this.chkSelectUponScrollIntoView.Size = new System.Drawing.Size(130, 17);
            this.chkSelectUponScrollIntoView.TabIndex = 11;
            this.chkSelectUponScrollIntoView.Text = "Auto-select after scroll";
            this.chkSelectUponScrollIntoView.UseVisualStyleBackColor = false;
            this.chkSelectUponScrollIntoView.CheckedChanged += new System.EventHandler(this.AutoSelectUponScrollIntoViewCheckedChanged);
            // 
            // nmDeterministicScroller
            // 
            this.nmDeterministicScroller.Location = new System.Drawing.Point(23, 504);
            this.nmDeterministicScroller.Maximum = new decimal(new int[] {
            49,
            0,
            0,
            0});
            this.nmDeterministicScroller.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nmDeterministicScroller.Name = "nmDeterministicScroller";
            this.nmDeterministicScroller.Size = new System.Drawing.Size(80, 20);
            this.nmDeterministicScroller.TabIndex = 10;
            this.nmDeterministicScroller.ValueChanged += new System.EventHandler(this.DeterministicItemScrollerValueChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.Location = new System.Drawing.Point(22, 26);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(229, 17);
            this.checkBox1.TabIndex = 125;
            this.checkBox1.Text = "Should draw sidebar on item mouse hover?";
            this.checkBox1.UseVisualStyleBackColor = false;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.BackColor = System.Drawing.Color.Transparent;
            this.checkBox2.Location = new System.Drawing.Point(22, 160);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(215, 17);
            this.checkBox2.TabIndex = 126;
            this.checkBox2.Text = "Should draw border around the sidebar?";
            this.checkBox2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.Enabled = false;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(436, 20);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(39, 23);
            this.button3.TabIndex = 119;
            this.button3.Text = "...";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ChromeTitlebarHeight = 48;
            this.ClientSize = new System.Drawing.Size(1524, 910);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.label1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsLocationAutoResettingAnchoredControlsEnabled = false;
            this.Name = "Form1";
            this.ShouldRenderAppIconUsingStandardSize = false;
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.advancedGroupBox1.ResumeLayout(false);
            this.advancedGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemIndexProvider)).EndInit();
            this.binaryPowerTabStrip1.ResumeLayout(false);
            this.binaryPowerTabPage3.ResumeLayout(false);
            this.binaryPowerTabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmCheckBoxSizeHeightProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmCheckBoxSizeWidthProvider)).EndInit();
            this.binaryPowerTabPage6.ResumeLayout(false);
            this.binaryPowerTabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmSidebarBorderThicknessProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmSidebarWidthProvider)).EndInit();
            this.binaryPowerTabPage7.ResumeLayout(false);
            this.binaryPowerTabPage7.PerformLayout();
            this.binaryPowerTabPage5.ResumeLayout(false);
            this.binaryPowerTabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemUnselectedBorderThicknessProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemSelectedBorderThicknessProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemMouseHoverBorderThicknessProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmMinimumItemTopAndBottomMargin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmSpacingBetweenItemsProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmPaddingBetweenItemsComponentsProvider)).EndInit();
            this.binaryPowerTabPage1.ResumeLayout(false);
            this.binaryPowerTabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmAlternateGradientFactorProvider)).EndInit();
            this.binaryPowerTabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nmItemMouseHoverGradientFactorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemUnselectedColorGradientProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmItemSelectedColorGradientProvider)).EndInit();
            this.binaryPowerTabPage2.ResumeLayout(false);
            this.binaryPowerTabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmDeterministicScroller)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private Binarymission.WinForms.Controls.AdvancedListControls.CheckedImageListBox checkedImageListBox1;
        private Binarymission.Winforms.Controls.AdvancedGroupBox advancedGroupBox1;
        private System.Windows.Forms.NumericUpDown nmDeterministicScroller;
        private System.Windows.Forms.CheckBox chkSelectUponScrollIntoView;
        private System.Windows.Forms.CheckBox chkControlIsReadOnly;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel1;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel2;
        private Binarymission.WinForms.Controls.ExtendedLabel extLblCurrentSelectedIndex;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel3;
        private System.Windows.Forms.CheckBox chkTooltipAboutToPopup;
        private System.Windows.Forms.CheckBox chkTooltipAboutToBeDisplayed;
        private System.Windows.Forms.CheckBox chkOnItemHoverChanged;
        private System.Windows.Forms.CheckBox chkVerticalScrollDetected;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel4;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel5;
        private Binarymission.WinForms.Controls.ExtendedLabel extLblHoverItemInfo;
        private System.Windows.Forms.CheckBox chkShouldShowDefaultTooltipOnItemHover;
        private Binarymission.WinForms.Controls.ExtendedLabel extVerticalScrollInfo;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel8;
        private System.Windows.Forms.CheckBox chkAreItemsInFullItemView;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip binaryPowerTabStrip1;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage1;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage2;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage3;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel9;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel7;
        private System.Windows.Forms.Button btnUnselectAll;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel11;
        private System.Windows.Forms.Button btnSelectAll;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel10;
        private System.Windows.Forms.ComboBox cmbSelectionMode;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel12;
        private System.Windows.Forms.CheckBox chkIsEnabled;
        private System.Windows.Forms.Button btnUncheckAll;
        private System.Windows.Forms.Button btnCheckAll;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel15;
        private System.Windows.Forms.CheckBox chkCheckOperationOption;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel13;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel14;
        private System.Windows.Forms.NumericUpDown nmItemIndexProvider;
        private System.Windows.Forms.Button btnUndefinedStateCheckAll;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel6;
        private System.Windows.Forms.CheckBox chkShouldDrawCheckBoxInVisualStyle;
        private System.Windows.Forms.NumericUpDown nmCheckBoxSizeHeightProvider;
        private System.Windows.Forms.NumericUpDown nmCheckBoxSizeWidthProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel19;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel18;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel17;
        private System.Windows.Forms.CheckBox chkShouldUseImageForCheckState;
        private System.Windows.Forms.CheckBox chkCheckOnClick;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage4;
        private System.Windows.Forms.CheckBox chkIsImageDrawnWhenUsingDefaultItemTooltip;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage5;
        private System.Windows.Forms.NumericUpDown nmSpacingBetweenItemsProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel22;
        private System.Windows.Forms.NumericUpDown nmPaddingBetweenItemsComponentsProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel21;
        private System.Windows.Forms.CheckBox chkShouldDrawTopItemSpacingForFirstItem;
        private System.Windows.Forms.NumericUpDown nmMinimumItemTopAndBottomMargin;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel23;
        private System.Windows.Forms.NumericUpDown nmItemMouseHoverBorderThicknessProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel24;
        private System.Windows.Forms.NumericUpDown nmItemUnselectedBorderThicknessProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel20;
        private System.Windows.Forms.NumericUpDown nmItemSelectedBorderThicknessProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel16;
        private System.Windows.Forms.CheckBox chkShouldDrawItemBorder;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel26;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel25;
        private System.Windows.Forms.Button btnCheckedStateImageBrowser;
        private System.Windows.Forms.Button btnUncheckedStateImageBrowser;
        private System.Windows.Forms.Button btnContentTextColorProvider;
        private System.Windows.Forms.Button btnAltStartColor;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel27;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel28;
        private System.Windows.Forms.Button btnAltEndColor;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel38;
        private System.Windows.Forms.Button btnItemUnselectedTitleTextColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel32;
        private System.Windows.Forms.Button btnItemUnselectedContentTextColorProvider;
        private System.Windows.Forms.Button btnTitleTextColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel29;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel30;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel48;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel52;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel53;
        private System.Windows.Forms.NumericUpDown nmItemUnselectedColorGradientProvider;
        private System.Windows.Forms.NumericUpDown nmItemSelectedColorGradientProvider;
        private System.Windows.Forms.NumericUpDown nmAlternateGradientFactorProvider;
        private System.Windows.Forms.Button btnItemUnselectedEndColorProvider;
        private System.Windows.Forms.Button btnItemUnselectedStartColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel56;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel57;
        private System.Windows.Forms.Button btnItemTitleFontProvider;
        private System.Windows.Forms.Button btnItemContentFontProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel54;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel55;
        private System.Windows.Forms.Button btnItemUnselectedBorderColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel47;
        private System.Windows.Forms.Button btnItemSelectedBorderColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel44;
        private System.Windows.Forms.CheckBox chkEnableAlternatingColors;
        private System.Windows.Forms.Button btnHoverTitleTextColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel58;
        private System.Windows.Forms.Button btnHoverContentTextColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel59;
        private System.Windows.Forms.Button btnTooltipTitleFontProvider;
        private System.Windows.Forms.Button btnTooltipContentFontProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel60;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel61;
        private System.Windows.Forms.NumericUpDown nmItemMouseHoverGradientFactorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel34;
        private System.Windows.Forms.Button btnItemSelectedEndColorProvider;
        private System.Windows.Forms.Button btnItemSelectedStartColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel35;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel36;
        private System.Windows.Forms.Button btnItemReadOnlyEndColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel37;
        private System.Windows.Forms.Button btnItemReadOnlyStartColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel39;
        private System.Windows.Forms.Button btnItemReadOnlyBorderColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel51;
        private System.Windows.Forms.Button btnDisabledItemEndColor;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel33;
        private System.Windows.Forms.Button btnDisabledItemStartColor;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel31;
        private System.Windows.Forms.Button btnItemDisabledTitleTextColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel40;
        private System.Windows.Forms.Button btnItemDisabledContentTextColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel41;
        private System.Windows.Forms.Button btnReadOnlyContentTextColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel42;
        private System.Windows.Forms.Button btnReadOnlyTitleTextColorProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel43;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox chkItemCheckUnCheckAllowedStatus;
        private System.Windows.Forms.CheckBox chkEventOnItemCheckStateChanged;
        private Binarymission.WinForms.Controls.ExtendedLabel extItemCheckStateChangedInfo;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel46;
        private System.Windows.Forms.CheckBox chkEnableItemImageAnimation;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage6;
        private System.Windows.Forms.CheckBox chkDrawSidebar;
        private System.Windows.Forms.NumericUpDown nmSidebarWidthProvider;
        private System.Windows.Forms.Button btnSiderbarEndColor;
        private System.Windows.Forms.Button btnSidebarBorderColor;
        private System.Windows.Forms.Button btnSiderbarStartColor;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel45;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel49;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel50;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel62;
        private System.Windows.Forms.CheckBox chkDrawSidebarBorder;
        private System.Windows.Forms.NumericUpDown nmSidebarBorderThicknessProvider;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel63;
        private System.Windows.Forms.ComboBox cmbSidebarGradientMode;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel64;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Button button3;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage7;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel67;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel66;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel65;
        private System.Windows.Forms.CheckBox chkItemsAnnotation;
        private System.Windows.Forms.Button btnItemAnnotationImagePicker;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel68;
        private System.Windows.Forms.CheckBox chkItemAnnotationImageClicked;
        private System.Windows.Forms.CheckBox chkItemImageClicked;
        private System.Windows.Forms.Button btnSidebarSelectedStateEndColor;
        private System.Windows.Forms.Button btnSidebarSelectedStateStartColor;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel69;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel70;
    }
}

