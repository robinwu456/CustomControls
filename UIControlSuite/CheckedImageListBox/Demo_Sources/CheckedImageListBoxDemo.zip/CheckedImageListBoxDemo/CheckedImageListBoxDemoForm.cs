﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.AdvancedListControls.CheckedImageListBoxControl.Events;
using Binarymission.WinForms.Controls.AdvancedListControls.DataEntities;
using Binarymission.WinForms.Controls.AdvancedListControls.Events;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using CheckedImageListBoxDemo.Properties;

namespace CheckedImageListBoxDemo
{
    public partial class CheckedImageListBoxDemoForm : ModernChromeWindow
    {
        private bool _shouldAutoSelectScrolledItemIntoView;
        private Dictionary<int, Image> _resourcesToSelectFrom;
        private Random _random;
        private OpenFileDialog _openFileDialog;
        private ColorDialog _colorDialog;
        private FontDialog _fontDialog;
        
        public CheckedImageListBoxDemoForm()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            SetupState();
            SetupWindowProperties();
            LoadSelectionModes();
            LoadListBoxWithData();
        }

        private void SetupWindowProperties()
        {
            TitleTextDrawingFormat = new StringFormat
            {
                Trimming = StringTrimming.EllipsisCharacter,
                LineAlignment = StringAlignment.Center,
                Alignment = StringAlignment.Near,
                FormatFlags = StringFormatFlags.NoWrap
            };

            TitlebarText = @"Binarymission CheckedImageListBox .NET Control Demo";
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void SetupState()
        {
            _openFileDialog = new OpenFileDialog
            {
                CheckFileExists = true
            };

            _colorDialog = new ColorDialog();

            _fontDialog = new FontDialog();

            _resourcesToSelectFrom = new Dictionary<int, Image>
            {
                {1, Resources.Alarm},
                {2, Resources.Clip},
                {3, Resources.History},
                {4, Resources.Item_Image},
                {5, Resources.NoteOpen},
                {6, Resources.Piece},
                {7, Resources.Screen},
                {8, Resources.History}
            };

            _random = new Random();

            _shouldAutoSelectScrolledItemIntoView = true;

            nmCheckBoxSizeWidthProvider.Enabled = nmCheckBoxSizeHeightProvider.Enabled = !chkShouldDrawCheckBoxInVisualStyle.Checked;
            chkShouldDrawCheckBoxInVisualStyle.Enabled = !chkShouldUseImageForCheckState.Checked;
            checkedImageListBox1.ItemSelectedBorderThickness = (int)nmItemSelectedBorderThicknessProvider.Value;
            checkedImageListBox1.ItemUnselectedBorderThickness = (int)nmItemUnselectedBorderThicknessProvider.Value;

            foreach (var item in Enum.GetValues(typeof (LinearGradientMode)))
            {
                cmbSidebarGradientMode.Items.Add(item);
            }

            cmbSidebarGradientMode.SelectedIndex = 0;
            chkDrawSidebar.Checked = true;
            chkDrawSidebarBorder.Checked = true;

            checkedImageListBox1.AnnotationImageOnMouseHover = Properties.Resources.Print;
        }

        private void LoadSelectionModes()
        {
            cmbSelectionMode.Items.AddRange(Enum.GetNames(typeof(SelectionMode)));
            cmbSelectionMode.SelectedIndex = 3;
        }

        private void LoadListBoxWithData()
        {
            checkedImageListBox1.Items.Clear();
            
            for (var i = 0; i < 25; i++)
            {
                var item = new CheckedImageListBoxItem
                {
                    Title = $"Title {i}",
                    Image = SelectImageAtRandom(),
                    ContentText = string.Format(
                    "{1}Sample item content text for index: {0}{1}More long and multi-line content text follows." +
                    "{1}{1}You can have many more (multi-line) content text, totalling upto a certain maximum size for height (in pixels) that each listbox item object can support rendering." +
                    "{1}{1}The control also supports built-in (also customisable) text formatting, such as automatic wrapping text content, alignment, etc.",
                    i,
                    Environment.NewLine),
                    IsChecked = null,
                    IsEnabled = true
                };
                
                item.TooltipContent = item.ContentText;
                item.TooltipTitle = item.Title;
                
                checkedImageListBox1.Items.Add(item);
            }

            nmDeterministicScroller.Maximum = checkedImageListBox1.Items.Count - 1;
            nmItemIndexProvider.Maximum = checkedImageListBox1.Items.Count - 1;
        }

        private Image SelectImageAtRandom()
        {
            return _resourcesToSelectFrom[_random.Next(1, 9)];
        }

        private void CheckedImageListBoxOnItemHoverChanged(object sender, ItemHoverChangedEventArgs e)
        {
            var hoverItemInfo = string.Empty;

            if (chkOnItemHoverChanged.Checked)
            {
                const string msgNotRelevant = "Not relevant";
                const string message = "1) Hovered item Index is: {0};{3}2) Mouse cursor position is: {1};{3}3) IsItemInFullView is: {2}{3}";
                
                hoverItemInfo = string.Format(message,
                    e.IsItemInFullView == null ? msgNotRelevant : e.HoveredItemIndex.ToString(),
                    e.IsItemInFullView == null ? msgNotRelevant : e.CursorPosition.ToString(),
                    e.IsItemInFullView == null ? msgNotRelevant : e.IsItemInFullView.Value.ToString(),
                    Environment.NewLine);
            }

            extLblHoverItemInfo.Text = hoverItemInfo;

            if (e.HoveredItemIndex == checkedImageListBox1.SelectedIndex)
            {
                checkedImageListBox1.AnnotationImageOnMouseHover = Resources.Print;
            }
            else
            {
                checkedImageListBox1.AnnotationImageOnMouseHover = Resources.BookmarkAndAdd;
            }
        }

        private void TooltipPopupHandler(object sender, ItemTooltipPopupEventArgs e)
        {
            if (!chkTooltipAboutToBeDisplayed.Checked)
            {
                e.TooltipPopupEventArgs.ToolTipSize = Size.Empty;
                e.TooltipPopupEventArgs.Cancel = true;
                return;
            }

            using (var tempGraphics = e.TooltipPopupEventArgs.AssociatedControl.CreateGraphics())
            {
                var titleSize = string.IsNullOrEmpty(e.CurrentlyHoveredListBoxItem.TooltipTitle) ? Size.Empty : tempGraphics.MeasureString(e.CurrentlyHoveredListBoxItem.TooltipTitle, checkedImageListBox1.ItemTitleFont);
                var contentSize = string.IsNullOrEmpty(e.CurrentlyHoveredListBoxItem.TooltipContent) ? Size.Empty : tempGraphics.MeasureString(e.CurrentlyHoveredListBoxItem.TooltipContent, checkedImageListBox1.ItemTooltipContentFont);

                if (contentSize == Size.Empty)
                {
                    e.TooltipPopupEventArgs.ToolTipSize = new Size(0, 0);
                    e.TooltipPopupEventArgs.Cancel = true;
                }
                else
                {
                    e.TooltipPopupEventArgs.ToolTipSize =
                        new Size(Math.Max((int) (titleSize.Width), (int) contentSize.Width) + 24,
                            10 + Math.Max((int) titleSize.Height, 24) + 10 + (int) contentSize.Height + 10);
                }
            }
        }

        private void TooltipCustomDrawingHandler(object sender, TooltipDrawEventArgs e)
        {
            if (!chkTooltipAboutToBeDisplayed.Checked)
            {
                return;
            }

            var graphics = e.DrawTooltipEventArgs.Graphics;

            using (var pen = new Pen(Color.Black, 1))
            {
                using (var brush = new SolidBrush(Color.White))
                {
                    var boundsRectangle = new Rectangle(0, 0, e.DrawTooltipEventArgs.Bounds.Width - 1, e.DrawTooltipEventArgs.Bounds.Height - 1);
                    var boundsContentRectangle = new Rectangle(1, 1, e.DrawTooltipEventArgs.Bounds.Width - 2, e.DrawTooltipEventArgs.Bounds.Height - 2);
                    graphics.DrawRectangle(pen, boundsRectangle);
                    graphics.FillRectangle(brush, boundsContentRectangle);

                    if (checkedImageListBox1.IsImageDrawnWhenUsingDefaultItemTooltip)
                    {
                        graphics.DrawImage(Resources.NetworkPrinter, new Point(10, 10));
                    }

                    using (var brushInfoText = new SolidBrush(Color.Black))
                    {
                        graphics.DrawString(
                            e.CurrentlyHoveredListBoxItem.TooltipTitle,
                            checkedImageListBox1.ItemTitleFont,
                            brushInfoText, 
                            42 - (checkedImageListBox1.IsImageDrawnWhenUsingDefaultItemTooltip ? 0 : 34),
                            10);
          
                        graphics.DrawString(
                            e.CurrentlyHoveredListBoxItem.TooltipContent,
                            checkedImageListBox1.ItemContentFont,
                            brushInfoText, 
                            10,
                            10 + Math.Max(graphics.MeasureString(e.CurrentlyHoveredListBoxItem.TooltipTitle,
                            checkedImageListBox1.ItemTitleFont).Height,
                            (checkedImageListBox1.IsImageDrawnWhenUsingDefaultItemTooltip ? 24 : 0)) + 10);
                    }
                }
            }
        }

        private void CheckedImageListBoxSelectedIndexChanged(object sender, EventArgs e)
        {
            extLblCurrentSelectedIndex.Text = checkedImageListBox1.SelectedIndex.ToString();
        }

        private void DeterministicItemScrollerValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ScrollIntoView((int)nmDeterministicScroller.Value, _shouldAutoSelectScrolledItemIntoView);
        }

        private void AutoSelectUponScrollIntoViewCheckedChanged(object sender, EventArgs e)
        {
            _shouldAutoSelectScrolledItemIntoView = chkSelectUponScrollIntoView.Checked;
            checkedImageListBox1.SelectedIndex = (int) nmDeterministicScroller.Value;
        }

        private void CheckedImageListBoxControlIsReadOnlyCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.IsReadOnly = chkControlIsReadOnly.Checked;
            _shouldAutoSelectScrolledItemIntoView = !checkedImageListBox1.IsReadOnly;
            chkSelectUponScrollIntoView.Enabled = !checkedImageListBox1.IsReadOnly;
            nmDeterministicScroller.Value = -1;
        }

        private void ExitApplication(object sender, EventArgs e)
        {
            Close();
        }

        private void ShouldShowDefaultTooltipOnItemHoverCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ShouldShowDefaultTooltipOnItemHover = chkShouldShowDefaultTooltipOnItemHover.Checked;
        }

        private void TooltipAboutToPopupCheckedChanged(object sender, EventArgs e)
        {
            if (chkTooltipAboutToPopup.Checked)
            {
                checkedImageListBox1.ItemTooltipAboutToPopup += TooltipPopupHandler;
            }
            else
            {
                checkedImageListBox1.ItemTooltipAboutToPopup -= TooltipPopupHandler;
                checkedImageListBox1.ItemTooltipAboutToDraw -= TooltipCustomDrawingHandler;
            }

            chkTooltipAboutToBeDisplayed.Enabled = chkTooltipAboutToPopup.Checked;
            chkShouldShowDefaultTooltipOnItemHover.Enabled = !chkTooltipAboutToBeDisplayed.Checked;
        }

        private void TooltipAboutToBeDisplayedCheckedChanged(object sender, EventArgs e)
        {
            if (chkTooltipAboutToBeDisplayed.Checked)
            {
                checkedImageListBox1.ItemTooltipAboutToDraw += TooltipCustomDrawingHandler;
            }
            else
            {
                checkedImageListBox1.ItemTooltipAboutToDraw -= TooltipCustomDrawingHandler;
            }

            chkShouldShowDefaultTooltipOnItemHover.Enabled = !chkTooltipAboutToBeDisplayed.Checked;
        }

        private void OnItemHoverChangedCheckedChanged(object sender, EventArgs e)
        {
            if (chkOnItemHoverChanged.Checked)
            {
                checkedImageListBox1.ItemHoverChanged += CheckedImageListBoxOnItemHoverChanged;
            }
            else
            {
                checkedImageListBox1.ItemHoverChanged -= CheckedImageListBoxOnItemHoverChanged;
            }
        }

        private void VerticalScrollDetectedCheckedChanged(object sender, EventArgs e)
        {
            if (chkVerticalScrollDetected.Checked)
            {
                checkedImageListBox1.VerticalScroll += CheckedImageListBoxVerticalScroll;
            }
            else
            {
                checkedImageListBox1.VerticalScroll -= CheckedImageListBoxVerticalScroll;
            }
        }

        private void CheckedImageListBoxVerticalScroll(object sender, EventArgs e)
        {
            var args = e as VerticalScrollEventArgs;

            if (args == null)
            {
                return;
            }

            extVerticalScrollInfo.Text =
                string.Format("Scroll event type: {0}{5}Old Scroll Position: {1}{5}New Scroll position: {2}{5}Source Windows message: {3}{5}Addition Keys data: {4}{5}",
                    args.ScrollEventArgs.Type, args.ScrollEventArgs.OldValue, args.ScrollEventArgs.NewValue, args.SourceWindowsMessage,args.Keys.ToString(), Environment.NewLine);
        }

        private void AreItemsInFullItemViewCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.EnableItemFullView = chkAreItemsInFullItemView.Checked;
        }

        private void CheckedImageListBoxSelectionModeSelectedIndexChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.SelectionMode = (SelectionMode)Enum.Parse(typeof(SelectionMode), cmbSelectionMode.SelectedItem.ToString());

            if (checkedImageListBox1.SelectionMode == SelectionMode.None)
            {
                btnSelectAll.Enabled = false;
                btnUnselectAll.Enabled = false;
            }
            else
            {
                btnSelectAll.Enabled = true;
                btnUnselectAll.Enabled = true;
            }
        }

        private void CheckedImageListBoxIsEnabledCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.Enabled = chkIsEnabled.Checked;
        }

        private void CheckAllItemsInCheckedImageListBoxClick(object sender, EventArgs e)
        {
            checkedImageListBox1.SetCheckState(-1, true);
        }

        private void UncheckAllItemsInCheckedImageListBoxClick(object sender, EventArgs e)
        {
            checkedImageListBox1.SetCheckState(-1, false);
        }

        private void UndefinedStateCheckAllItemsInCheckedImageListBoxClick(object sender, EventArgs e)
        {
            checkedImageListBox1.SetCheckState(-1, null);
        }

        private void SelectAllItemsInCheckedImageListBoxClick(object sender, EventArgs e)
        {
            checkedImageListBox1.SelectAll();
        }

        private void UnselectAllItemsInCheckedImageListBoxClick(object sender, EventArgs e)
        {
            checkedImageListBox1.UnselectAll();
        }

        private void ItemIndexProviderValueChanged(object sender, EventArgs e)
        {
            SetDeterministicItemCheckState();
        }

        private void CheckOperationOptionCheckStateChanged(object sender, EventArgs e)
        {
            SetDeterministicItemCheckState();
        }

        private void SetDeterministicItemCheckState()
        {
            var status = DetermineCheckOptionCheckStatus();
            checkedImageListBox1.SetCheckState((int)nmItemIndexProvider.Value, status);
        }

        private bool? DetermineCheckOptionCheckStatus()
        {
            bool? status = null;

            switch (chkCheckOperationOption.CheckState)
            {
                case CheckState.Checked:
                    status = true;
                    break;
                case CheckState.Unchecked:
                    status = false;
                    break;
                case CheckState.Indeterminate:
                    break;
            }
            return status;
        }

        private void BinaryPowerTabStripTabPageClosing(Binarymission.WinForms.Controls.TabControls.TabPageClosingEventArgs e)
        {
            var message = $"Are you sure, you want to close the tab page \"{e.TabPage.Text}\"?";

            var result = MessageBox.Show(message, @"Close tab page", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            e.Cancel = (result == DialogResult.No);
        }

        private void ShouldDrawCheckBoxInVisualStyleCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ShouldDrawCheckBoxInVisualStyle = chkShouldDrawCheckBoxInVisualStyle.Checked;

            nmCheckBoxSizeWidthProvider.ValueChanged -= CheckBoxSizeWidthProviderValueChanged;
            nmCheckBoxSizeHeightProvider.ValueChanged -= CheckBoxSizeHeightProviderValueChanged;

            nmCheckBoxSizeWidthProvider.Value = checkedImageListBox1.CheckBoxSize.Width;
            nmCheckBoxSizeHeightProvider.Value = checkedImageListBox1.CheckBoxSize.Height;

            nmCheckBoxSizeWidthProvider.ValueChanged += CheckBoxSizeWidthProviderValueChanged;
            nmCheckBoxSizeHeightProvider.ValueChanged += CheckBoxSizeHeightProviderValueChanged;

            nmCheckBoxSizeWidthProvider.Enabled = nmCheckBoxSizeHeightProvider.Enabled = !chkShouldDrawCheckBoxInVisualStyle.Checked;
        }

        private void CheckBoxSizeWidthProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.CheckBoxSize = new Size((int)nmCheckBoxSizeWidthProvider.Value, (int)nmCheckBoxSizeHeightProvider.Value);
        }

        private void CheckBoxSizeHeightProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.CheckBoxSize = new Size((int)nmCheckBoxSizeWidthProvider.Value, (int)nmCheckBoxSizeHeightProvider.Value);
        }

        private void ShouldUseImageForCheckStateCheckedChanged(object sender, EventArgs e)
        {
            chkShouldDrawCheckBoxInVisualStyle.Checked = !chkShouldUseImageForCheckState.Checked;
            chkShouldDrawCheckBoxInVisualStyle.Enabled = !chkShouldUseImageForCheckState.Checked;
            checkedImageListBox1.ShouldUseImageForCheckState = chkShouldUseImageForCheckState.Checked;
            btnCheckedStateImageBrowser.Enabled = chkShouldUseImageForCheckState.Checked;
            btnUncheckedStateImageBrowser.Enabled = chkShouldUseImageForCheckState.Checked;
        }

        private void CheckOnClickCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.CheckOnClick = chkCheckOnClick.Checked;
        }

        private void IsImageDrawnWhenUsingDefaultItemTooltipCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.IsImageDrawnWhenUsingDefaultItemTooltip =
                chkIsImageDrawnWhenUsingDefaultItemTooltip.Checked;
        }
        
        private void ShouldDrawItemBorderCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ShouldDrawItemBorder = chkShouldDrawItemBorder.Checked;
        }

        private void ItemSelectedBorderThicknessProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ItemSelectedBorderThickness = (int)nmItemSelectedBorderThicknessProvider.Value;
        }

        private void ItemUnselectedBorderThicknessProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ItemUnselectedBorderThickness = (int)nmItemUnselectedBorderThicknessProvider.Value;
        }

        private void PaddingBetweenItemsComponentsProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.PaddingBetweenItemComponents = (int)nmPaddingBetweenItemsComponentsProvider.Value;
        }

        private void SpacingBetweenItemsProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ItemSpacing = (int)nmSpacingBetweenItemsProvider.Value;
        }

        private void ShouldDrawTopItemSpacingForFirstItemCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ShouldDrawTopItemSpacingForFirstItem = chkShouldDrawTopItemSpacingForFirstItem.Checked;
        }

        private void MinimumItemTopAndBottomMarginValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.MinimumItemTopAndBottomMargin = (int)nmMinimumItemTopAndBottomMargin.Value;
        }

        private void ItemMouseHoverBorderThicknessProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ItemMouseHoverBorderThickness = (int)nmItemMouseHoverBorderThicknessProvider.Value;
        }

        private void CheckedStateImageBrowserClick(object sender, EventArgs e)
        {
            var fileName = GetSelectedFileName();

            if (!string.IsNullOrEmpty(fileName))
            {
                checkedImageListBox1.CheckedStateImage = new Bitmap(fileName);
            }
        }

        private void UncheckedStateImageBrowserClick(object sender, EventArgs e)
        {
            var fileName = GetSelectedFileName();
            
            if (!string.IsNullOrEmpty(fileName))
            {
                checkedImageListBox1.UncheckedStateImage = new Bitmap(fileName);
            }
        }

        private string GetSelectedFileName()
        {
            var result = _openFileDialog.ShowDialog(this);

            if (result == DialogResult.OK || result == DialogResult.Yes)
            {
                return _openFileDialog.FileName;
            }

            return null;
        }

        private void EnableAlternatingColorsCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ShouldEnableAlternatingColors = chkEnableAlternatingColors.Checked;
            btnAltEndColor.Enabled = chkEnableAlternatingColors.Checked;
            btnAltStartColor.Enabled = chkEnableAlternatingColors.Checked;
        }

        private void AlternateStartColorClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemAlternateStartColor = color;
            }
        }

        private void AlternateEndColorClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemAlternateEndColor = color;
            }
        }

        private Color GetSelectedColor()
        {
            var result = _colorDialog.ShowDialog(this);

            if (result == DialogResult.OK || result == DialogResult.Yes)
            {
                return _colorDialog.Color;
            }

            return Color.Empty;
        }

        private void AlternateGradientFactorProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ItemAlternateGradientFactor = (float)nmAlternateGradientFactorProvider.Value;
        }

        private void ContentTextColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemContentTextColor = color;
            }
        }

        private void TitleTextColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemTitleTextColor = color;
            }
        }

        private void ItemUnselectedContentTextColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemUnselectedContentTextColor = color;
            }
        }

        private void ItemUnselectedTitleTextColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemUnselectedTitleTextColor = color;
            }
        }

        private void HoverContentTextColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemMouseHoverContentTextForeColor = color;
            }
        }

        private void HoverTitleTextColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemMouseHoverTitleForeColor = color;
            }
        }

        private void DisabledItemStartColorClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemDisabledStartColor = color;
            }
        }

        private void DisabledItemEndColorClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemDisabledEndColor = color;
            }
        }

        private Font GetSelectedFont()
        {
            var result = _fontDialog.ShowDialog(this);

            if (result == DialogResult.OK || result == DialogResult.Yes)
            {
                return _fontDialog.Font;
            }

            return null;
        }

        private void TooltipContentFontProviderClick(object sender, EventArgs e)
        {
            var font = GetSelectedFont();

            if (font != null)
            {
                checkedImageListBox1.ItemTooltipContentFont = font;
            }
        }

        private void TooltipTitleFontProviderClick(object sender, EventArgs e)
        {
            var font = GetSelectedFont();

            if (font != null)
            {
                checkedImageListBox1.ItemTooltipTitleFont = font;
            }
        }

        private void ItemContentFontProviderClick(object sender, EventArgs e)
        {
            var font = GetSelectedFont();

            if (font != null)
            {
                checkedImageListBox1.ItemContentFont = font;
            }
        }

        private void ItemTitleFontProviderClick(object sender, EventArgs e)
        {
            var font = GetSelectedFont();

            if (font != null)
            {
                checkedImageListBox1.ItemTitleFont = font;
            }
        }

        private void ItemUnselectedStartColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemUnselectedStartColor = color;
            }
        }

        private void ItemUnselectedEndColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemUnselectedEndColor = color;
            }
        }

        private void ItemUnselectedColorGradientProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ItemUnselectedGradientFactor = (float)nmItemUnselectedColorGradientProvider.Value;
        }

        private void ItemSelectedColorGradientProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ItemSelectedGradientFactor = (float)nmItemSelectedColorGradientProvider.Value;
        }

        private void ItemSelectedBorderColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemSelectedBorderColor = color;
            }
        }

        private void ItemUnselectedBorderColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemUnselectedBorderColor = color;
            }
        }

        private void ItemSelectedStartColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemSelectedStartColor = color;
            }
        }

        private void ItemSelectedEndColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemSelectedEndColor = color;
            }
        }

        private void ItemMouseHoverGradientFactorProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ItemMouseHoverGradientFactor = (float) nmItemMouseHoverGradientFactorProvider.Value;
        }

        private void ItemReadOnlyStartColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemReadOnlyStartColor = color;
            }
        }

        private void ItemReadOnlyEndColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemReadOnlyEndColor = color;
            }
        }

        private void ItemReadOnlyBorderColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemReadOnlyBorderColor = color;
            }
        }

        private void ItemDisabledContentTextColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemDisabledContentTextColor = color;
            }
        }

        private void ItemDisabledTitleTextColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemDisabledTitleTextColor = color;
            }
        }

        private void ReadOnlyTitleTextColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemReadOnlyTitleTextColor = color;
            }
        }

        private void ReadOnlyContentTextColorProviderClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.ItemReadOnlyContentTextColor = color;
            }
        }

        private void ItemCheckUnCheckAllowedStatusCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.IsItemCheckUncheckAllowed = chkItemCheckUnCheckAllowedStatus.Checked;
            nmItemIndexProvider.Enabled = chkItemCheckUnCheckAllowedStatus.Checked;
            chkCheckOperationOption.Enabled = chkItemCheckUnCheckAllowedStatus.Checked;
            btnCheckAll.Enabled = chkItemCheckUnCheckAllowedStatus.Checked;
            btnUncheckAll.Enabled = chkItemCheckUnCheckAllowedStatus.Checked;
            btnUndefinedStateCheckAll.Enabled = chkItemCheckUnCheckAllowedStatus.Checked;
        }

        private void ChkEventOnItemCheckStateChangedCheckedChanged(object sender, EventArgs e)
        {
            if (chkEventOnItemCheckStateChanged.Checked)
            {
                checkedImageListBox1.ItemCheckStateChanged += CheckedImageListBox1OnOnItemCheckStateChanged;
            }
            else
            {
                checkedImageListBox1.ItemCheckStateChanged -= CheckedImageListBox1OnOnItemCheckStateChanged;
            }
        }

        private void CheckedImageListBox1OnOnItemCheckStateChanged(object sender, ItemCheckStateChangedEventArgs onItemCheckStateChangedEventArgs)
        {
            extItemCheckStateChangedInfo.Text =
                string.Format(
                "Check state changed item index: {1}{0}Old check-state: {2}{0}New check-state: {3}{0}", 
                Environment.NewLine,
                checkedImageListBox1.SelectedIndex,
                onItemCheckStateChangedEventArgs.OldCheckState.HasValue ? onItemCheckStateChangedEventArgs.OldCheckState.ToString() : "Not Checkable",
                onItemCheckStateChangedEventArgs.NewCheckState.HasValue ? onItemCheckStateChangedEventArgs.NewCheckState.ToString() : "Not Checkable");
        }

        private void EnableItemImageAnimationCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.ShouldAnimateItemImage = chkEnableItemImageAnimation.Checked;
        }

        private void DrawSidebarCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.IsItemSidebarDrawingEnabled = chkDrawSidebar.Checked;

            btnSiderbarStartColor.Enabled =
                btnSiderbarEndColor.Enabled =
                    nmSidebarWidthProvider.Enabled =
                        chkDrawSidebarBorder.Enabled = 
                            cmbSidebarGradientMode.Enabled = checkedImageListBox1.IsItemSidebarDrawingEnabled;
                
        }

        private void DrawSidebarBorderCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.IsItemSidebarBorderDrawingEnabled = chkDrawSidebarBorder.Checked;

            btnSidebarBorderColor.Enabled =
                nmSidebarBorderThicknessProvider.Enabled = checkedImageListBox1.IsItemSidebarBorderDrawingEnabled;
        }

        private void SiderbarStartColorClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.SidebarItemHoveredStateStartColor = color;
            }
        }

        private void SidebarWidthProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.SidebarWidth = (int) nmSidebarWidthProvider.Value;
        }

        private void SidebarBorderThicknessProviderValueChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.SidebarBorderThickness = (int)nmSidebarBorderThicknessProvider.Value;
        }

        private void SidebarGradientModeSelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbSidebarGradientMode.SelectedItem.ToString())
            {
                case "Horizontal": checkedImageListBox1.SidebarGradientMode = LinearGradientMode.Horizontal;
                    break;
                case "Vertical": checkedImageListBox1.SidebarGradientMode = LinearGradientMode.Vertical;
                    break;
                case "ForwardDiagonal": checkedImageListBox1.SidebarGradientMode = LinearGradientMode.ForwardDiagonal;
                    break;
                case "BackwardDiagonal": checkedImageListBox1.SidebarGradientMode = LinearGradientMode.BackwardDiagonal;
                    break;
            }
        }

        private void SiderbarEndColorClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.SidebarItemHoveredStateEndColor = color;
            }
        }

        private void BorderColorClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.SidebarItemHoveredStateBorderColor = color;
            }
        }

        private void DrawSidebarBorderEnabledChanged(object sender, EventArgs e)
        {
            nmSidebarBorderThicknessProvider.Enabled = checkedImageListBox1.IsItemSidebarDrawingEnabled;
            btnSidebarBorderColor.Enabled = checkedImageListBox1.IsItemSidebarDrawingEnabled;
        }

        private void ItemsAnnotationCheckedChanged(object sender, EventArgs e)
        {
            checkedImageListBox1.IsAnnotationEnabled = chkItemsAnnotation.Checked;
        }

        private void ItemAnnotationImagePickerClick(object sender, EventArgs e)
        {
            var fileDialog = new OpenFileDialog
            {
                Filter = @"PNG|*.png|BMP|*.bmp",
                Title = @"Choose an image file for annotation..."
            };

            var result = fileDialog.ShowDialog(this);
            
            if (result == DialogResult.OK || result == DialogResult.Yes)
            {
                checkedImageListBox1.AnnotationImageOnMouseHover = new Bitmap(fileDialog.FileName);
            }
        }

        private void ItemAnnotationImageClickedCheckedChanged(object sender, EventArgs e)
        {
            if (chkItemAnnotationImageClicked.Checked)
            {
                checkedImageListBox1.AnnotationImageClicked += CheckedImageListBoxAnnotationImageClicked;
            }
            else
            {
                checkedImageListBox1.AnnotationImageClicked -= CheckedImageListBoxAnnotationImageClicked;
            }
        }

        private void CheckedImageListBoxAnnotationImageClicked(object sender, EventArgs e)
        {
            MessageBox.Show(@"The annotation object was clicked by the user.", @"Annotation clicked", MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void ItemImageClickCheckedChanged(object sender, EventArgs e)
        {
            if (chkItemImageClicked.Checked)
            {
                checkedImageListBox1.ItemImageClicked += CheckedImageListBoxItemImageClicked;
            }
            else
            {
                checkedImageListBox1.ItemImageClicked -= CheckedImageListBoxItemImageClicked;
            }
        }

        private void CheckedImageListBoxItemImageClicked(object sender, EventArgs e)
        {
            MessageBox.Show(@"The item image was clicked by the user.", @"Image clicked", MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void SidebarSelectedStateStartColorClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.SidebarItemSelectedStateStartColor = color;
            }
        }

        private void SidebarSelectedStateEndColorClick(object sender, EventArgs e)
        {
            var color = GetSelectedColor();

            if (color != Color.Empty)
            {
                checkedImageListBox1.SidebarItemSelectedStateEndColor = color;
            }
        }
    }
}
