using System;
using System.Drawing;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.TextControls;

namespace BinaryExtendedTextDemo
{
    /// <summary>
    /// Summary description for BinaryExtendedTextDemoForm.
    /// </summary>
    public class BinaryExtendedTextDemoForm : ModernChromeWindow
    {
        public BinaryExtendedTextDemoForm()
        {
            InitializeComponent();
            Construct();
        }

        private void Construct()
        {
            _blinkColor = Color.Red;
            _blinkInterval = 500;
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
        }

        private void HandleFormLoaded(object sender, EventArgs e)
        {
            string[] s = { "Normal", "Dotted" };
            _cmbControlBorderStyle.Items.AddRange(s);
            _cmbControlBorderStyle.SelectedIndex = 0;

            _binaryExtendedText1.PasswordChar = _txtPasswordCharacterToUse.Text.Trim() != ""
                ? _txtPasswordCharacterToUse.Text[0]
                : (char)(0);

            _upDownDepthFactor.Value = Convert.ToInt32(_binaryExtendedText1.DotBorderDepth);
            _upDownGapFactor.Value = Convert.ToInt32(_binaryExtendedText1.DotBorderGap);
        }

        private void HandleTextBoxExtendedStateSetupChanged(object sender, EventArgs e)
        {
            if (_btnControlStyleExtended.Checked != true) return;
            _binaryExtendedText1.ExtendedState = _binaryExtendedText2.ExtendedState = true;
            if (!_btnControlEnabled.Checked) return;
            _groupBox7.Enabled = _btnBorderColor.Enabled = _chkBoxAlwaysShowBorder.Enabled = _cmbControlBorderStyle.Enabled = _grpBox.Enabled = _upDownDepthFactor.Enabled = _upDownGapFactor.Enabled = true;
        }

        private void HandleTextBoxAlwaysShowBorderStateSetupChanged(object sender, EventArgs e)
        {
            if (!_btnControlStyleNormal.Checked) return;
            _binaryExtendedText1.ExtendedState = _binaryExtendedText2.ExtendedState = _btnBorderColor.Enabled = _chkBoxAlwaysShowBorder.Enabled = _cmbControlBorderStyle.Enabled = _grpBox.Enabled = false;
            _upDownDepthFactor.Enabled = _upDownGapFactor.Enabled = _groupBox7.Enabled = false;
        }

        private void UpdateTextBoxBorderColour(object sender, EventArgs e)
        {
            if (DialogResult.Cancel == _clrDlg.ShowDialog()) return;
            _binaryExtendedText1.BorderColor = _binaryExtendedText2.BorderColor = _clrDlg.Color;
        }

        private void UpdateTextBoxBorderDisplayStyle(object sender, EventArgs e)
        {
            _binaryExtendedText1.ShowBorderAlways = _binaryExtendedText2.ShowBorderAlways = (_chkBoxAlwaysShowBorder.CheckState == CheckState.Checked);
        }

        private void UpdateTextBoxEnabledState(object sender, EventArgs e)
        {
            _binaryExtendedText1.Enabled = _binaryExtendedText2.Enabled = true;

            if (!_btnControlStyleExtended.Checked) return;
            _chkBoxAlwaysShowBorder.Enabled = _btnBorderColor.Enabled = _cmbControlBorderStyle.Enabled = _grpBox.Enabled = _upDownDepthFactor.Enabled = _upDownGapFactor.Enabled = _groupBox7.Enabled = true;
        }

        private void HandleTextBoxControlDisabledStateChange(object sender, EventArgs e)
        {
            _binaryExtendedText1.Enabled = _binaryExtendedText2.Enabled = _chkBoxAlwaysShowBorder.Enabled = _btnBorderColor.Enabled = _cmbControlBorderStyle.Enabled = _grpBox.Enabled = _upDownDepthFactor.Enabled = false;
            _upDownGapFactor.Enabled = _groupBox7.Enabled = false;
        }

        private void HandleBorderStyleSelectionChanged(object sender, EventArgs e)
        {
            if (_cmbControlBorderStyle.SelectedIndex == 0)
            {
                _grpBox.Enabled = _upDownDepthFactor.Enabled = _upDownGapFactor.Enabled = false;
                _binaryExtendedText1.DrawBorder = _binaryExtendedText2.DrawBorder = BorderState.Normal;
            }
            else
            {
                _grpBox.Enabled = _upDownDepthFactor.Enabled = _upDownGapFactor.Enabled = true;
                _binaryExtendedText1.DrawBorder = _binaryExtendedText2.DrawBorder = BorderState.Dotted;
            }
        }

        private void HandleTextBoxDottedBorderDepthValueChanged(object sender, EventArgs e)
        {
            _binaryExtendedText1.DotBorderDepth = _binaryExtendedText2.DotBorderDepth = Convert.ToInt32(_upDownDepthFactor.Value);
        }

        private void HandleTextBoxDottedBorderGapValueChanged(object sender, EventArgs e)
        {
            _binaryExtendedText1.DotBorderGap = _binaryExtendedText2.DotBorderGap = Convert.ToInt32(_upDownGapFactor.Value);
        }

        private void HandleTextBoxPasswordCharacterChanged(object sender, EventArgs e)
        {
            if (_txtPasswordCharacterToUse.Text.Trim() != string.Empty)
            {
                _binaryExtendedText1.PasswordChar = _binaryExtendedText2.PasswordChar = _txtPasswordCharacterToUse.Text[0];
            }
            else
            {
                _binaryExtendedText1.PasswordChar = _binaryExtendedText2.PasswordChar = (char)(0);
            }
        }

        private void HandlePasswordCharacterUsage(object sender, EventArgs e)
        {
            switch (_chkBoxUsePasswordChar.CheckState)
            {
                case CheckState.Checked:
                    _binaryExtendedText1.UseEnhancedPasswordChar = true;
                    break;
                case CheckState.Unchecked:
                    _binaryExtendedText1.UseEnhancedPasswordChar = false;
                    break;
            }

            switch (_chkBoxUsePasswordChar.CheckState)
            {
                case CheckState.Checked:
                    _binaryExtendedText2.UseEnhancedPasswordChar = true;
                    break;
                case CheckState.Unchecked:
                    _binaryExtendedText2.UseEnhancedPasswordChar = false;
                    break;
            }
        }

        private void SetupTextBoxBlickColour(object sender, EventArgs e)
        {
            if (DialogResult.Cancel == _clrDlg.ShowDialog()) return;
            _blinkColor = _clrDlg.Color;
        }

        private void SetupTextBoxBlinkInterval(object sender, EventArgs e)
        {
            _blinkInterval = Convert.ToInt32(_upDownBlinkInterval.Value);
        }

        private void PerformTextBoxBlink(object sender, EventArgs e)
        {
            if (_btnBlink.Text == "Start Blinking")
            {
                _chkBoxAlwaysShowBorder.Enabled = false;
                _btnBlink.Text = "Stop blinking";
                _binaryExtendedText1.StartToBlink(_blinkColor, _blinkInterval);
                _binaryExtendedText2.StartToBlink(_blinkColor, _blinkInterval);
            }
            else
            {
                _chkBoxAlwaysShowBorder.Enabled = true;
                _btnBlink.Text = "Start Blinking";
                _binaryExtendedText1.StopBlinking();
                _binaryExtendedText2.StopBlinking();
            }
        }

        private void SetupTextBoxNotInFocusBorderColour(object sender, EventArgs e)
        {
            if (DialogResult.Cancel == _clrDlg.ShowDialog()) return;
            _binaryExtendedText1.BorderColorWhenControlIsNotInFocus = _clrDlg.Color;
            _binaryExtendedText2.BorderColorWhenControlIsNotInFocus = _clrDlg.Color;
        }

        #region Infrastructure bits

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_components != null)
                {
                    _components.Dispose();
                }
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BinaryExtendedTextDemoForm));
            this._groupBox1 = new System.Windows.Forms.GroupBox();
            this._binaryExtendedText1 = new Binarymission.WinForms.Controls.TextControls.BinaryExtendedText();
            this._groupBox2 = new System.Windows.Forms.GroupBox();
            this._btnBorderColorWhenTextBoxIsNotInFocus = new SmartButton();
            this._groupBox7 = new System.Windows.Forms.GroupBox();
            this._label4 = new System.Windows.Forms.Label();
            this._upDownBlinkInterval = new System.Windows.Forms.NumericUpDown();
            this._btnBlink = new SmartButton();
            this._btnBlinkColor = new SmartButton();
            this._chkBoxUsePasswordChar = new System.Windows.Forms.CheckBox();
            this._txtPasswordCharacterToUse = new System.Windows.Forms.TextBox();
            this._label3 = new System.Windows.Forms.Label();
            this._grpBox = new System.Windows.Forms.GroupBox();
            this._upDownGapFactor = new System.Windows.Forms.NumericUpDown();
            this._upDownDepthFactor = new System.Windows.Forms.NumericUpDown();
            this._label2 = new System.Windows.Forms.Label();
            this._label1 = new System.Windows.Forms.Label();
            this._groupBox6 = new System.Windows.Forms.GroupBox();
            this._cmbControlBorderStyle = new System.Windows.Forms.ComboBox();
            this._groupBox5 = new System.Windows.Forms.GroupBox();
            this._btnControlDisable = new System.Windows.Forms.RadioButton();
            this._btnControlEnabled = new System.Windows.Forms.RadioButton();
            this._groupBox4 = new System.Windows.Forms.GroupBox();
            this._chkBoxAlwaysShowBorder = new System.Windows.Forms.CheckBox();
            this._btnBorderColor = new SmartButton();
            this._groupBox3 = new System.Windows.Forms.GroupBox();
            this._btnControlStyleNormal = new System.Windows.Forms.RadioButton();
            this._btnControlStyleExtended = new System.Windows.Forms.RadioButton();
            this._clrDlg = new System.Windows.Forms.ColorDialog();
            this._statusBar1 = new System.Windows.Forms.StatusBar();
            this._binaryExtendedText2 = new Binarymission.WinForms.Controls.TextControls.BinaryExtendedText();
            this._label5 = new System.Windows.Forms.Label();
            this._groupBox1.SuspendLayout();
            this._groupBox2.SuspendLayout();
            this._groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._upDownBlinkInterval)).BeginInit();
            this._grpBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._upDownGapFactor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._upDownDepthFactor)).BeginInit();
            this._groupBox6.SuspendLayout();
            this._groupBox5.SuspendLayout();
            this._groupBox4.SuspendLayout();
            this._groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // _groupBox1
            // 
            this._groupBox1.Controls.Add(this._binaryExtendedText1);
            this._groupBox1.Location = new System.Drawing.Point(8, 8);
            this._groupBox1.Name = "_groupBox1";
            this._groupBox1.Size = new System.Drawing.Size(424, 56);
            this._groupBox1.TabIndex = 1;
            this._groupBox1.TabStop = false;
            this._groupBox1.Text = "BinaryExtendedText .NET control";
            // 
            // _binaryExtendedText1
            // 
            this._binaryExtendedText1.BorderColor = System.Drawing.SystemColors.Highlight;
            this._binaryExtendedText1.BorderColorWhenControlIsNotInFocus = System.Drawing.SystemColors.ControlDark;
            this._binaryExtendedText1.DotBorderDepth = 4;
            this._binaryExtendedText1.DotBorderGap = 5;
            this._binaryExtendedText1.DrawBorder = Binarymission.WinForms.Controls.TextControls.BorderState.Normal;
            this._binaryExtendedText1.ExtendedState = true;
            this._binaryExtendedText1.Location = new System.Drawing.Point(8, 20);
            this._binaryExtendedText1.Name = "_binaryExtendedText1";
            this._binaryExtendedText1.ShowBorderAlways = false;
            this._binaryExtendedText1.Size = new System.Drawing.Size(408, 20);
            this._binaryExtendedText1.TabIndex = 0;
            this._binaryExtendedText1.UseEnhancedPasswordChar = false;
            // 
            // _groupBox2
            // 
            this._groupBox2.Controls.Add(this._btnBorderColorWhenTextBoxIsNotInFocus);
            this._groupBox2.Controls.Add(this._groupBox7);
            this._groupBox2.Controls.Add(this._chkBoxUsePasswordChar);
            this._groupBox2.Controls.Add(this._txtPasswordCharacterToUse);
            this._groupBox2.Controls.Add(this._label3);
            this._groupBox2.Controls.Add(this._grpBox);
            this._groupBox2.Controls.Add(this._groupBox6);
            this._groupBox2.Controls.Add(this._groupBox5);
            this._groupBox2.Controls.Add(this._groupBox4);
            this._groupBox2.Controls.Add(this._btnBorderColor);
            this._groupBox2.Controls.Add(this._groupBox3);
            this._groupBox2.Location = new System.Drawing.Point(8, 72);
            this._groupBox2.Name = "_groupBox2";
            this._groupBox2.Size = new System.Drawing.Size(424, 406);
            this._groupBox2.TabIndex = 3;
            this._groupBox2.TabStop = false;
            this._groupBox2.Text = "Options illustrating the Properties of BinaryExtendedText .NET control";
            // 
            // _btnBorderColorWhenTextBoxIsNotInFocus
            // 
            this._btnBorderColorWhenTextBoxIsNotInFocus.Location = new System.Drawing.Point(8, 283);
            this._btnBorderColorWhenTextBoxIsNotInFocus.Name = "_btnBorderColorWhenTextBoxIsNotInFocus";
            this._btnBorderColorWhenTextBoxIsNotInFocus.Size = new System.Drawing.Size(408, 39);
            this._btnBorderColorWhenTextBoxIsNotInFocus.TabIndex = 19;
            this._btnBorderColorWhenTextBoxIsNotInFocus.Text = "Set border color for when the textbox control is not in focus...";
            this._btnBorderColorWhenTextBoxIsNotInFocus.Click += new System.EventHandler(this.SetupTextBoxNotInFocusBorderColour);
            // 
            // _groupBox7
            // 
            this._groupBox7.Controls.Add(this._label4);
            this._groupBox7.Controls.Add(this._upDownBlinkInterval);
            this._groupBox7.Controls.Add(this._btnBlink);
            this._groupBox7.Controls.Add(this._btnBlinkColor);
            this._groupBox7.Location = new System.Drawing.Point(8, 339);
            this._groupBox7.Name = "_groupBox7";
            this._groupBox7.Size = new System.Drawing.Size(408, 56);
            this._groupBox7.TabIndex = 18;
            this._groupBox7.TabStop = false;
            this._groupBox7.Text = "Blinking properties";
            // 
            // _label4
            // 
            this._label4.Location = new System.Drawing.Point(128, 27);
            this._label4.Name = "_label4";
            this._label4.Size = new System.Drawing.Size(56, 16);
            this._label4.TabIndex = 3;
            this._label4.Text = "Interval :-";
            // 
            // _upDownBlinkInterval
            // 
            this._upDownBlinkInterval.Location = new System.Drawing.Point(184, 24);
            this._upDownBlinkInterval.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this._upDownBlinkInterval.Name = "_upDownBlinkInterval";
            this._upDownBlinkInterval.Size = new System.Drawing.Size(104, 20);
            this._upDownBlinkInterval.TabIndex = 2;
            this._upDownBlinkInterval.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this._upDownBlinkInterval.TextChanged += new System.EventHandler(this.SetupTextBoxBlinkInterval);
            this._upDownBlinkInterval.ValueChanged += new System.EventHandler(this.SetupTextBoxBlinkInterval);
            // 
            // _btnBlink
            // 
            this._btnBlink.Location = new System.Drawing.Point(312, 19);
            this._btnBlink.Name = "_btnBlink";
            this._btnBlink.Size = new System.Drawing.Size(88, 28);
            this._btnBlink.TabIndex = 1;
            this._btnBlink.Text = "Start Blinking";
            this._btnBlink.Click += new System.EventHandler(this.PerformTextBoxBlink);
            // 
            // _btnBlinkColor
            // 
            this._btnBlinkColor.Location = new System.Drawing.Point(16, 19);
            this._btnBlinkColor.Name = "_btnBlinkColor";
            this._btnBlinkColor.Size = new System.Drawing.Size(96, 28);
            this._btnBlinkColor.TabIndex = 0;
            this._btnBlinkColor.Text = "Blink color...";
            this._btnBlinkColor.Click += new System.EventHandler(this.SetupTextBoxBlickColour);
            // 
            // _chkBoxUsePasswordChar
            // 
            this._chkBoxUsePasswordChar.Location = new System.Drawing.Point(160, 208);
            this._chkBoxUsePasswordChar.Name = "_chkBoxUsePasswordChar";
            this._chkBoxUsePasswordChar.Size = new System.Drawing.Size(208, 16);
            this._chkBoxUsePasswordChar.TabIndex = 17;
            this._chkBoxUsePasswordChar.Text = "Use Enhanced password character";
            this._chkBoxUsePasswordChar.CheckedChanged += new System.EventHandler(this.HandlePasswordCharacterUsage);
            // 
            // _txtPasswordCharacterToUse
            // 
            this._txtPasswordCharacterToUse.Location = new System.Drawing.Point(16, 208);
            this._txtPasswordCharacterToUse.MaxLength = 1;
            this._txtPasswordCharacterToUse.Name = "_txtPasswordCharacterToUse";
            this._txtPasswordCharacterToUse.Size = new System.Drawing.Size(88, 20);
            this._txtPasswordCharacterToUse.TabIndex = 16;
            this._txtPasswordCharacterToUse.TextChanged += new System.EventHandler(this.HandleTextBoxPasswordCharacterChanged);
            // 
            // _label3
            // 
            this._label3.Location = new System.Drawing.Point(14, 192);
            this._label3.Name = "_label3";
            this._label3.Size = new System.Drawing.Size(136, 16);
            this._label3.TabIndex = 15;
            this._label3.Text = "Password Character";
            // 
            // _grpBox
            // 
            this._grpBox.Controls.Add(this._upDownGapFactor);
            this._grpBox.Controls.Add(this._upDownDepthFactor);
            this._grpBox.Controls.Add(this._label2);
            this._grpBox.Controls.Add(this._label1);
            this._grpBox.Location = new System.Drawing.Point(232, 128);
            this._grpBox.Name = "_grpBox";
            this._grpBox.Size = new System.Drawing.Size(184, 56);
            this._grpBox.TabIndex = 14;
            this._grpBox.TabStop = false;
            this._grpBox.Text = "Dotted border properties";
            // 
            // _upDownGapFactor
            // 
            this._upDownGapFactor.Location = new System.Drawing.Point(136, 24);
            this._upDownGapFactor.Name = "_upDownGapFactor";
            this._upDownGapFactor.Size = new System.Drawing.Size(40, 20);
            this._upDownGapFactor.TabIndex = 5;
            this._upDownGapFactor.ValueChanged += new System.EventHandler(this.HandleTextBoxDottedBorderGapValueChanged);
            // 
            // _upDownDepthFactor
            // 
            this._upDownDepthFactor.Location = new System.Drawing.Point(56, 24);
            this._upDownDepthFactor.Name = "_upDownDepthFactor";
            this._upDownDepthFactor.Size = new System.Drawing.Size(40, 20);
            this._upDownDepthFactor.TabIndex = 4;
            this._upDownDepthFactor.ValueChanged += new System.EventHandler(this.HandleTextBoxDottedBorderDepthValueChanged);
            // 
            // _label2
            // 
            this._label2.Location = new System.Drawing.Point(104, 24);
            this._label2.Name = "_label2";
            this._label2.Size = new System.Drawing.Size(32, 24);
            this._label2.TabIndex = 3;
            this._label2.Text = "Gap";
            // 
            // _label1
            // 
            this._label1.Location = new System.Drawing.Point(16, 24);
            this._label1.Name = "_label1";
            this._label1.Size = new System.Drawing.Size(40, 16);
            this._label1.TabIndex = 2;
            this._label1.Text = "Depth";
            // 
            // _groupBox6
            // 
            this._groupBox6.Controls.Add(this._cmbControlBorderStyle);
            this._groupBox6.Location = new System.Drawing.Point(8, 128);
            this._groupBox6.Name = "_groupBox6";
            this._groupBox6.Size = new System.Drawing.Size(216, 56);
            this._groupBox6.TabIndex = 13;
            this._groupBox6.TabStop = false;
            this._groupBox6.Text = "Control border";
            // 
            // _cmbControlBorderStyle
            // 
            this._cmbControlBorderStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cmbControlBorderStyle.Location = new System.Drawing.Point(8, 24);
            this._cmbControlBorderStyle.Name = "_cmbControlBorderStyle";
            this._cmbControlBorderStyle.Size = new System.Drawing.Size(200, 21);
            this._cmbControlBorderStyle.TabIndex = 0;
            this._cmbControlBorderStyle.SelectedIndexChanged += new System.EventHandler(this.HandleBorderStyleSelectionChanged);
            // 
            // _groupBox5
            // 
            this._groupBox5.Controls.Add(this._btnControlDisable);
            this._groupBox5.Controls.Add(this._btnControlEnabled);
            this._groupBox5.Location = new System.Drawing.Point(8, 72);
            this._groupBox5.Name = "_groupBox5";
            this._groupBox5.Size = new System.Drawing.Size(408, 48);
            this._groupBox5.TabIndex = 9;
            this._groupBox5.TabStop = false;
            this._groupBox5.Text = "Control state";
            // 
            // _btnControlDisable
            // 
            this._btnControlDisable.Location = new System.Drawing.Point(216, 24);
            this._btnControlDisable.Name = "_btnControlDisable";
            this._btnControlDisable.Size = new System.Drawing.Size(160, 16);
            this._btnControlDisable.TabIndex = 11;
            this._btnControlDisable.Text = "Disabled";
            this._btnControlDisable.CheckedChanged += new System.EventHandler(this.HandleTextBoxControlDisabledStateChange);
            // 
            // _btnControlEnabled
            // 
            this._btnControlEnabled.Checked = true;
            this._btnControlEnabled.Location = new System.Drawing.Point(16, 24);
            this._btnControlEnabled.Name = "_btnControlEnabled";
            this._btnControlEnabled.Size = new System.Drawing.Size(176, 16);
            this._btnControlEnabled.TabIndex = 10;
            this._btnControlEnabled.TabStop = true;
            this._btnControlEnabled.Text = "Enabled";
            this._btnControlEnabled.CheckedChanged += new System.EventHandler(this.UpdateTextBoxEnabledState);
            // 
            // _groupBox4
            // 
            this._groupBox4.Controls.Add(this._chkBoxAlwaysShowBorder);
            this._groupBox4.Location = new System.Drawing.Point(176, 19);
            this._groupBox4.Name = "_groupBox4";
            this._groupBox4.Size = new System.Drawing.Size(240, 48);
            this._groupBox4.TabIndex = 7;
            this._groupBox4.TabStop = false;
            this._groupBox4.Text = "Control Border";
            // 
            // _chkBoxAlwaysShowBorder
            // 
            this._chkBoxAlwaysShowBorder.Location = new System.Drawing.Point(16, 24);
            this._chkBoxAlwaysShowBorder.Name = "_chkBoxAlwaysShowBorder";
            this._chkBoxAlwaysShowBorder.Size = new System.Drawing.Size(216, 16);
            this._chkBoxAlwaysShowBorder.TabIndex = 8;
            this._chkBoxAlwaysShowBorder.Text = "Always show control\'s border ";
            this._chkBoxAlwaysShowBorder.CheckedChanged += new System.EventHandler(this.UpdateTextBoxBorderDisplayStyle);
            // 
            // _btnBorderColor
            // 
            this._btnBorderColor.Location = new System.Drawing.Point(8, 240);
            this._btnBorderColor.Name = "_btnBorderColor";
            this._btnBorderColor.Size = new System.Drawing.Size(408, 39);
            this._btnBorderColor.TabIndex = 12;
            this._btnBorderColor.Text = "Set border color...";
            this._btnBorderColor.Click += new System.EventHandler(this.UpdateTextBoxBorderColour);
            // 
            // _groupBox3
            // 
            this._groupBox3.Controls.Add(this._btnControlStyleNormal);
            this._groupBox3.Controls.Add(this._btnControlStyleExtended);
            this._groupBox3.Location = new System.Drawing.Point(8, 19);
            this._groupBox3.Name = "_groupBox3";
            this._groupBox3.Size = new System.Drawing.Size(160, 48);
            this._groupBox3.TabIndex = 4;
            this._groupBox3.TabStop = false;
            this._groupBox3.Text = "Control style";
            // 
            // _btnControlStyleNormal
            // 
            this._btnControlStyleNormal.Location = new System.Drawing.Point(80, 24);
            this._btnControlStyleNormal.Name = "_btnControlStyleNormal";
            this._btnControlStyleNormal.Size = new System.Drawing.Size(64, 16);
            this._btnControlStyleNormal.TabIndex = 6;
            this._btnControlStyleNormal.Text = "Normal";
            this._btnControlStyleNormal.CheckedChanged += new System.EventHandler(this.HandleTextBoxAlwaysShowBorderStateSetupChanged);
            // 
            // _btnControlStyleExtended
            // 
            this._btnControlStyleExtended.Checked = true;
            this._btnControlStyleExtended.Location = new System.Drawing.Point(8, 24);
            this._btnControlStyleExtended.Name = "_btnControlStyleExtended";
            this._btnControlStyleExtended.Size = new System.Drawing.Size(72, 16);
            this._btnControlStyleExtended.TabIndex = 5;
            this._btnControlStyleExtended.TabStop = true;
            this._btnControlStyleExtended.Text = "Extended";
            this._btnControlStyleExtended.CheckedChanged += new System.EventHandler(this.HandleTextBoxExtendedStateSetupChanged);
            // 
            // _statusBar1
            // 
            this._statusBar1.Location = new System.Drawing.Point(0, 643);
            this._statusBar1.Name = "_statusBar1";
            this._statusBar1.Size = new System.Drawing.Size(455, 16);
            this._statusBar1.TabIndex = 4;
            this._statusBar1.Text = "BinaryExtendedText .NET demo! Copyright � http://www.binarymission.co.uk";
            // 
            // _binaryExtendedText2
            // 
            this._binaryExtendedText2.BorderColor = System.Drawing.SystemColors.Highlight;
            this._binaryExtendedText2.BorderColorWhenControlIsNotInFocus = System.Drawing.SystemColors.ControlDark;
            this._binaryExtendedText2.DotBorderDepth = 4;
            this._binaryExtendedText2.DotBorderGap = 5;
            this._binaryExtendedText2.DrawBorder = Binarymission.WinForms.Controls.TextControls.BorderState.Dotted;
            this._binaryExtendedText2.ExtendedState = true;
            this._binaryExtendedText2.Location = new System.Drawing.Point(16, 515);
            this._binaryExtendedText2.Multiline = true;
            this._binaryExtendedText2.Name = "_binaryExtendedText2";
            this._binaryExtendedText2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this._binaryExtendedText2.ShowBorderAlways = false;
            this._binaryExtendedText2.Size = new System.Drawing.Size(408, 72);
            this._binaryExtendedText2.TabIndex = 7;
            this._binaryExtendedText2.UseEnhancedPasswordChar = false;
            // 
            // _label5
            // 
            this._label5.Location = new System.Drawing.Point(16, 491);
            this._label5.Name = "_label5";
            this._label5.Size = new System.Drawing.Size(280, 16);
            this._label5.TabIndex = 8;
            this._label5.Text = "BinaryExtendedText .NET control in Multi-line mode:";
            // 
            // BinaryExtendedTextDemo
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(455, 659);
            this.Controls.Add(this._label5);
            this.Controls.Add(this._binaryExtendedText2);
            this.Controls.Add(this._statusBar1);
            this.Controls.Add(this._groupBox2);
            this.Controls.Add(this._groupBox1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BinaryExtendedTextDemo";
            this.TitlebarText = "Binarymission ExtendedText .NET Demo";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.HandleFormLoaded);
            this._groupBox1.ResumeLayout(false);
            this._groupBox1.PerformLayout();
            this._groupBox2.ResumeLayout(false);
            this._groupBox2.PerformLayout();
            this._groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._upDownBlinkInterval)).EndInit();
            this._grpBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._upDownGapFactor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._upDownDepthFactor)).EndInit();
            this._groupBox6.ResumeLayout(false);
            this._groupBox5.ResumeLayout(false);
            this._groupBox4.ResumeLayout(false);
            this._groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.DoEvents();
            Application.Run(new BinaryExtendedTextDemoForm());
        }

        private Color _blinkColor;
        private int _blinkInterval;
        private GroupBox _groupBox1;
        private GroupBox _groupBox2;
        private GroupBox _groupBox3;
        private RadioButton _btnControlStyleExtended;
        private RadioButton _btnControlStyleNormal;
        private ColorDialog _clrDlg;
        private SmartButton _btnBorderColor;
        private GroupBox _groupBox4;
        private CheckBox _chkBoxAlwaysShowBorder;
        private GroupBox _groupBox5;
        private RadioButton _btnControlEnabled;
        private RadioButton _btnControlDisable;
        private StatusBar _statusBar1;
        private GroupBox _groupBox6;
        private ComboBox _cmbControlBorderStyle;
        private Label _label1;
        private Label _label2;
        private GroupBox _grpBox;
        private NumericUpDown _upDownDepthFactor;
        private NumericUpDown _upDownGapFactor;
        private Label _label3;
        private TextBox _txtPasswordCharacterToUse;
        private CheckBox _chkBoxUsePasswordChar;
        private GroupBox _groupBox7;
        private SmartButton _btnBlinkColor;
        private SmartButton _btnBlink;
        private NumericUpDown _upDownBlinkInterval;
        private Label _label4;
        private BinaryExtendedText _binaryExtendedText1;
        private BinaryExtendedText _binaryExtendedText2;
        private Label _label5;
        private SmartButton _btnBorderColorWhenTextBoxIsNotInFocus;
        private System.ComponentModel.Container _components = null;

        #endregion Infrastructure bits
    }
}
