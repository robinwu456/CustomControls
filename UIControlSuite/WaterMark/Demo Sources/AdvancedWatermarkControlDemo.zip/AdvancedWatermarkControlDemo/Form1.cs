﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ColorPickers;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace AdvancedWatermarkControlDemo
{
    public partial class Form1 : ModernChromeWindow
    {
        public Form1()
        {
            InitializeComponent();
            InitialiseUiState();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
        }

        private void InitialiseUiState()
        {
            cmbControlScrollbars.Items.AddRange(Enum.GetNames(typeof (ScrollBars)));
            cmbControlScrollbars.SelectedIndex = 0;
            watermarkImageWidthSelector.Enabled = shouldRenderWatermarkImage.Checked;
            watermarkImageHeightSelector.Enabled = shouldRenderWatermarkImage.Checked;
            watermarkImageSelector.Enabled = shouldRenderWatermarkImage.Checked;
        }

        private void cmbControlScrollbars_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (cmbControlScrollbars.SelectedItem == null) return;
            watermarkTextBox2.TextScrollBars = (ScrollBars) Enum.Parse(typeof(ScrollBars), cmbControlScrollbars.SelectedItem.ToString());
        }
        
        private void watermarkFontSelector_SelectedIndexChanged(object sender, EventArgs e)
        {
            var fontnstance = watermarkFontSelector.SelectedItem;

            if (fontnstance == null) return;

            var fontStringInstance = fontnstance.ToString();

            var fontConverter = new FontConverter();
            var selectedFont =
                fontConverter.ConvertFromString(fontStringInstance) as Font;

            watermarkTextBox1.WatermarkTextFont = selectedFont;
            watermarkTextBox2.WatermarkTextFont = selectedFont;
        }

        private void watermarkForeColorSelector_SelectedColorChanged(object sender, BinaryColorPickerExtendedEventArgs e)
        {
            watermarkTextBox1.WatermarkTextForeColor = watermarkForeColorSelector.SelectedColor;
            watermarkTextBox2.WatermarkTextForeColor = watermarkForeColorSelector.SelectedColor;
        }

        private void watermarkBorderColorSelector_SelectedColorChanged(object sender, BinaryColorPickerExtendedEventArgs e)
        {
            watermarkTextBox1.BorderColor = watermarkBorderColorSelector.SelectedColor;
            watermarkTextBox2.BorderColor = watermarkBorderColorSelector.SelectedColor;
        }

        private void watermarkBackgroundColor_SelectedColorChanged(object sender, BinaryColorPickerExtendedEventArgs e)
        {
            watermarkTextBox1.WatermarkBackColor = watermarkBackgroundColor.SelectedColor;
            watermarkTextBox2.WatermarkBackColor = watermarkBackgroundColor.SelectedColor;
        }

        private void shouldRenderWatermarkImage_CheckedChanged(object sender, EventArgs e)
        {
            watermarkTextBox1.ShouldRenderWatermarkImage = shouldRenderWatermarkImage.Checked;
            watermarkTextBox2.ShouldRenderWatermarkImage = shouldRenderWatermarkImage.Checked;
            watermarkImageWidthSelector.Value = 0;
            watermarkImageHeightSelector.Value = 0;
            watermarkImageWidthSelector.Enabled = shouldRenderWatermarkImage.Checked;
            watermarkImageHeightSelector.Enabled = shouldRenderWatermarkImage.Checked;
            watermarkImageSelector.Enabled = shouldRenderWatermarkImage.Checked;
        }

        private void watermarkImageSelector_Click(object sender, EventArgs e)
        {
            var result = openFileDialog1.ShowDialog(this);

            if (result == DialogResult.Abort || result == DialogResult.Cancel || result == DialogResult.Ignore ||
                result == DialogResult.No || result == DialogResult.None)
                return;

            if (!string.IsNullOrEmpty(openFileDialog1.FileName))
            {
                watermarkTextBox1.WatermarkImage = (Bitmap) Image.FromFile(openFileDialog1.FileName);
                watermarkTextBox1.WatermarkImageSize = new Size((int)watermarkImageWidthSelector.Value, (int)watermarkImageHeightSelector.Value);

                watermarkTextBox2.WatermarkImage = (Bitmap)Image.FromFile(openFileDialog1.FileName);
                watermarkTextBox2.WatermarkImageSize = new Size((int)watermarkImageWidthSelector.Value, (int)watermarkImageHeightSelector.Value);
            }
        }

        private void watermarkImageWidthSelector_ValueChanged(object sender, EventArgs e)
        {
            watermarkTextBox1.WatermarkImageSize = new Size((int)watermarkImageWidthSelector.Value, (int)watermarkImageHeightSelector.Value);
            watermarkTextBox2.WatermarkImageSize = new Size((int)watermarkImageWidthSelector.Value, (int)watermarkImageHeightSelector.Value);
        }

        private void watermarkImageHeightSelector_ValueChanged(object sender, EventArgs e)
        {
            watermarkTextBox1.WatermarkImageSize = new Size((int)watermarkImageWidthSelector.Value, (int)watermarkImageHeightSelector.Value);
            watermarkTextBox2.WatermarkImageSize = new Size((int)watermarkImageWidthSelector.Value, (int)watermarkImageHeightSelector.Value);
        }

        private void btnExitApp_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void advancedFontDialog_Click(object sender, EventArgs e)
        {
            var result = fontDialog1.ShowDialog(this);

            if (result == DialogResult.Abort || result == DialogResult.Cancel || result == DialogResult.Ignore ||
                result == DialogResult.No || result == DialogResult.None)
                return;

            watermarkTextBox1.WatermarkTextFont = fontDialog1.Font;
            watermarkTextBox2.WatermarkTextFont = fontDialog1.Font;
        }
    }
}
