using System;
using System.ComponentModel;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.BinaryButtonSuite;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryButtonSuiteDemo
{
    /// <summary>
    /// Summary description for BinaryButtonSuiteDemoForm.
    /// </summary>
    public class BinaryButtonSuiteDemoForm : ModernChromeWindow
	{
		public BinaryButtonSuiteDemoForm()
		{
			InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlue;
		}

        private void HandleApplicationExitRequest(object sender, EventArgs e)
        {
            Close();
        }

        private void UpdateDemoArtefactsUi(object sender, EventArgs e)
        {
            _grpBoxBinaryControls.Enabled = _grpgroupBox2.Enabled = _checkBox1.Checked;
        }

        #region Inftastructure bits

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (_components != null) 
				{
					_components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BinaryButtonSuiteDemoForm));
            this._grpBoxBinaryControls = new System.Windows.Forms.GroupBox();
            this._grpgroupBox3 = new System.Windows.Forms.GroupBox();
            this._binaryRadioButton2 = new Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedRadioButton();
            this._binaryRadioButton1 = new Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedRadioButton();
            this._binaryCheckBox3 = new Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox();
            this._binaryCheckBox2 = new Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox();
            this._binaryCheckBox1 = new Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox();
            this._grpgroupBox2 = new System.Windows.Forms.GroupBox();
            this._grpgroupBox4 = new System.Windows.Forms.GroupBox();
            this._msRadioButton2 = new System.Windows.Forms.RadioButton();
            this._msRadioButton1 = new System.Windows.Forms.RadioButton();
            this._msCheckBox3 = new System.Windows.Forms.CheckBox();
            this._msCheckBox2 = new System.Windows.Forms.CheckBox();
            this._msCheckBox1 = new System.Windows.Forms.CheckBox();
            this._buttonClose = new System.Windows.Forms.Button();
            this._checkBox1 = new System.Windows.Forms.CheckBox();
            this._grpBoxBinaryControls.SuspendLayout();
            this._grpgroupBox3.SuspendLayout();
            this._grpgroupBox2.SuspendLayout();
            this._grpgroupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // _grpBoxBinaryControls
            // 
            this._grpBoxBinaryControls.Controls.Add(this._grpgroupBox3);
            this._grpBoxBinaryControls.Controls.Add(this._binaryCheckBox3);
            this._grpBoxBinaryControls.Controls.Add(this._binaryCheckBox2);
            this._grpBoxBinaryControls.Controls.Add(this._binaryCheckBox1);
            this._grpBoxBinaryControls.Location = new System.Drawing.Point(8, 8);
            this._grpBoxBinaryControls.Name = "_grpBoxBinaryControls";
            this._grpBoxBinaryControls.Size = new System.Drawing.Size(352, 120);
            this._grpBoxBinaryControls.TabIndex = 0;
            this._grpBoxBinaryControls.TabStop = false;
            this._grpBoxBinaryControls.Text = "CheckBox/Radio buttons from BinaryButtonSuite .NET";
            // 
            // _grpgroupBox3
            // 
            this._grpgroupBox3.Controls.Add(this._binaryRadioButton2);
            this._grpgroupBox3.Controls.Add(this._binaryRadioButton1);
            this._grpgroupBox3.Location = new System.Drawing.Point(160, 24);
            this._grpgroupBox3.Name = "_grpgroupBox3";
            this._grpgroupBox3.Size = new System.Drawing.Size(184, 80);
            this._grpgroupBox3.TabIndex = 3;
            this._grpgroupBox3.TabStop = false;
            this._grpgroupBox3.Text = "Final choice";
            // 
            // _binaryRadioButton2
            // 
            this._binaryRadioButton2.ControlBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this._binaryRadioButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._binaryRadioButton2.Location = new System.Drawing.Point(16, 48);
            this._binaryRadioButton2.Name = "_binaryRadioButton2";
            this._binaryRadioButton2.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this._binaryRadioButton2.OnFocusControlColor = System.Drawing.Color.Red;
            this._binaryRadioButton2.Size = new System.Drawing.Size(160, 16);
            this._binaryRadioButton2.TabIndex = 1;
            this._binaryRadioButton2.Text = "Just .NET controls please!";
            // 
            // _binaryRadioButton1
            // 
            this._binaryRadioButton1.Checked = true;
            this._binaryRadioButton1.ControlBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this._binaryRadioButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._binaryRadioButton1.Location = new System.Drawing.Point(16, 24);
            this._binaryRadioButton1.Name = "_binaryRadioButton1";
            this._binaryRadioButton1.NormalBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this._binaryRadioButton1.OnFocusControlColor = System.Drawing.Color.Red;
            this._binaryRadioButton1.Size = new System.Drawing.Size(152, 16);
            this._binaryRadioButton1.TabIndex = 0;
            this._binaryRadioButton1.TabStop = true;
            this._binaryRadioButton1.Text = "Al of them";
            // 
            // _binaryCheckBox3
            // 
            this._binaryCheckBox3.Checked = true;
            this._binaryCheckBox3.CheckState = System.Windows.Forms.CheckState.Checked;
            this._binaryCheckBox3.ControlBackColor = System.Drawing.SystemColors.Window;
            this._binaryCheckBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._binaryCheckBox3.Location = new System.Drawing.Point(16, 80);
            this._binaryCheckBox3.Name = "_binaryCheckBox3";
            this._binaryCheckBox3.NormalControlColor = System.Drawing.Color.Blue;
            this._binaryCheckBox3.OnFocusControlColor = System.Drawing.Color.Red;
            this._binaryCheckBox3.Size = new System.Drawing.Size(104, 16);
            this._binaryCheckBox3.TabIndex = 2;
            this._binaryCheckBox3.Text = "ActiveX Controls";
            // 
            // _binaryCheckBox2
            // 
            this._binaryCheckBox2.Checked = true;
            this._binaryCheckBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this._binaryCheckBox2.ControlBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this._binaryCheckBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._binaryCheckBox2.Location = new System.Drawing.Point(16, 56);
            this._binaryCheckBox2.Name = "_binaryCheckBox2";
            this._binaryCheckBox2.NormalControlColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this._binaryCheckBox2.OnFocusControlColor = System.Drawing.Color.Red;
            this._binaryCheckBox2.Size = new System.Drawing.Size(120, 16);
            this._binaryCheckBox2.TabIndex = 1;
            this._binaryCheckBox2.Text = "COM Components";
            // 
            // _binaryCheckBox1
            // 
            this._binaryCheckBox1.Checked = true;
            this._binaryCheckBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this._binaryCheckBox1.ControlBackColor = System.Drawing.SystemColors.Window;
            this._binaryCheckBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._binaryCheckBox1.Location = new System.Drawing.Point(16, 32);
            this._binaryCheckBox1.Name = "_binaryCheckBox1";
            this._binaryCheckBox1.NormalControlColor = System.Drawing.Color.Green;
            this._binaryCheckBox1.OnFocusControlColor = System.Drawing.Color.Red;
            this._binaryCheckBox1.Size = new System.Drawing.Size(96, 16);
            this._binaryCheckBox1.TabIndex = 0;
            this._binaryCheckBox1.Text = ".NET Controls";
            // 
            // _grpgroupBox2
            // 
            this._grpgroupBox2.Controls.Add(this._grpgroupBox4);
            this._grpgroupBox2.Controls.Add(this._msCheckBox3);
            this._grpgroupBox2.Controls.Add(this._msCheckBox2);
            this._grpgroupBox2.Controls.Add(this._msCheckBox1);
            this._grpgroupBox2.Location = new System.Drawing.Point(8, 144);
            this._grpgroupBox2.Name = "_grpgroupBox2";
            this._grpgroupBox2.Size = new System.Drawing.Size(352, 128);
            this._grpgroupBox2.TabIndex = 1;
            this._grpgroupBox2.TabStop = false;
            this._grpgroupBox2.Text = "CheckBox/Radio buttons from Standard .NET Farmework";
            // 
            // _grpgroupBox4
            // 
            this._grpgroupBox4.Controls.Add(this._msRadioButton2);
            this._grpgroupBox4.Controls.Add(this._msRadioButton1);
            this._grpgroupBox4.Location = new System.Drawing.Point(160, 24);
            this._grpgroupBox4.Name = "_grpgroupBox4";
            this._grpgroupBox4.Size = new System.Drawing.Size(184, 88);
            this._grpgroupBox4.TabIndex = 3;
            this._grpgroupBox4.TabStop = false;
            this._grpgroupBox4.Text = "Final choice";
            // 
            // _msRadioButton2
            // 
            this._msRadioButton2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._msRadioButton2.Location = new System.Drawing.Point(16, 48);
            this._msRadioButton2.Name = "_msRadioButton2";
            this._msRadioButton2.Size = new System.Drawing.Size(152, 16);
            this._msRadioButton2.TabIndex = 1;
            this._msRadioButton2.Text = "Just .NET controls please!";
            // 
            // _msRadioButton1
            // 
            this._msRadioButton1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._msRadioButton1.Location = new System.Drawing.Point(16, 24);
            this._msRadioButton1.Name = "_msRadioButton1";
            this._msRadioButton1.Size = new System.Drawing.Size(152, 16);
            this._msRadioButton1.TabIndex = 0;
            this._msRadioButton1.Text = "All of them";
            // 
            // _msCheckBox3
            // 
            this._msCheckBox3.Checked = true;
            this._msCheckBox3.CheckState = System.Windows.Forms.CheckState.Checked;
            this._msCheckBox3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._msCheckBox3.Location = new System.Drawing.Point(16, 80);
            this._msCheckBox3.Name = "_msCheckBox3";
            this._msCheckBox3.Size = new System.Drawing.Size(136, 16);
            this._msCheckBox3.TabIndex = 2;
            this._msCheckBox3.Text = "ActiveX Controls";
            // 
            // _msCheckBox2
            // 
            this._msCheckBox2.Checked = true;
            this._msCheckBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this._msCheckBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._msCheckBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this._msCheckBox2.Location = new System.Drawing.Point(16, 56);
            this._msCheckBox2.Name = "_msCheckBox2";
            this._msCheckBox2.Size = new System.Drawing.Size(136, 16);
            this._msCheckBox2.TabIndex = 1;
            this._msCheckBox2.Text = "COM Components";
            // 
            // _msCheckBox1
            // 
            this._msCheckBox1.Checked = true;
            this._msCheckBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this._msCheckBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._msCheckBox1.Location = new System.Drawing.Point(16, 32);
            this._msCheckBox1.Name = "_msCheckBox1";
            this._msCheckBox1.Size = new System.Drawing.Size(136, 16);
            this._msCheckBox1.TabIndex = 0;
            this._msCheckBox1.Text = ".NET Controls";
            // 
            // _buttonClose
            // 
            this._buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._buttonClose.Location = new System.Drawing.Point(277, 298);
            this._buttonClose.Name = "_buttonClose";
            this._buttonClose.Size = new System.Drawing.Size(75, 29);
            this._buttonClose.TabIndex = 4;
            this._buttonClose.Text = "E&xit";
            this._buttonClose.UseVisualStyleBackColor = true;
            this._buttonClose.Click += new System.EventHandler(this.HandleApplicationExitRequest);
            // 
            // checkBox1
            // 
            this._checkBox1.AutoSize = true;
            this._checkBox1.Checked = true;
            this._checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this._checkBox1.Location = new System.Drawing.Point(12, 298);
            this._checkBox1.Name = "_checkBox1";
            this._checkBox1.Size = new System.Drawing.Size(99, 17);
            this._checkBox1.TabIndex = 5;
            this._checkBox1.Text = "Enable controls";
            this._checkBox1.UseVisualStyleBackColor = true;
            this._checkBox1.CheckedChanged += new System.EventHandler(this.UpdateDemoArtefactsUi);
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BorderColorDisabledCloseCommandButton = System.Drawing.Color.Transparent;
            this.BorderColorDisabledMaximiseRestoreCommandButton = System.Drawing.Color.Transparent;
            this.BorderColorDisabledMinimizeCommandButton = System.Drawing.Color.Transparent;
            this.BorderColorNormalCloseCommandButton = System.Drawing.Color.CornflowerBlue;
            this.BorderColorNormalMaximiseRestoreCommandButton = System.Drawing.Color.CornflowerBlue;
            this.BorderColorNormalMinimizeCommandButton = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(386, 379);
            this.Controls.Add(this._checkBox1);
            this.Controls.Add(this._buttonClose);
            this.Controls.Add(this._grpgroupBox2);
            this.Controls.Add(this._grpBoxBinaryControls);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.ForegroundInternalVisualForNormalCloseCommandButton = System.Drawing.Color.Black;
            this.ForegroundInternalVisualForNormalMaximizeRestoreCommandButton = System.Drawing.Color.Black;
            this.ForegroundInternalVisualForNormalMinimizeCommandButton = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.TitlebarText = "Binarymission ButtonSuite Demo";
            this.WindowChromeBorderColor = System.Drawing.Color.CornflowerBlue;
            this.WindowChromeEndColor = System.Drawing.Color.LightBlue;
            this.WindowChromeStartColor = System.Drawing.Color.CornflowerBlue;
            this.WindowChromeTheme = Binarymission.WinForms.Controls.ContainerControls.Windows.Enums.WindowChromeTheme.OfficeBlue;
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this._grpBoxBinaryControls.ResumeLayout(false);
            this._grpgroupBox3.ResumeLayout(false);
            this._grpgroupBox2.ResumeLayout(false);
            this._grpgroupBox4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
            Application.EnableVisualStyles();
            Application.DoEvents();
            Application.Run(new BinaryButtonSuiteDemoForm());
		}

        private GroupBox _grpBoxBinaryControls;
        private GroupBox _grpgroupBox2;
        private GroupBox _grpgroupBox3;
        private CheckBox _msCheckBox1;
        private CheckBox _msCheckBox2;
        private CheckBox _msCheckBox3;
        private GroupBox _grpgroupBox4;
        private RadioButton _msRadioButton1;
        private RadioButton _msRadioButton2;
        private ExtendedRadioButton _binaryRadioButton2;
        private ExtendedRadioButton _binaryRadioButton1;
        private ExtendedCheckBox _binaryCheckBox3;
        private ExtendedCheckBox _binaryCheckBox2;
        private ExtendedCheckBox _binaryCheckBox1;
        private Button _buttonClose;
        private CheckBox _checkBox1;

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private readonly Container _components = null;

        #endregion Inftastructure bits
    }
}
