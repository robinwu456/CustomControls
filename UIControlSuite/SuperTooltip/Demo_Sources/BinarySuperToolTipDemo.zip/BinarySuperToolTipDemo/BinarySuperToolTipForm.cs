using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.ExtendedToolTips;

namespace BinarySuperToolTipDemo
{
    public partial class BinarySuperToolTipForm : ModernChromeWindow
    {
        public BinarySuperToolTipForm()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            HandleDefaultRenderingModeSelectionChanged(radioButtonDefaultRenderingMode, null);
        }

        private void HandleOwnerDrawnRenderingModeSelectionChanged(object sender, EventArgs e)
        {
            if (radioButtonOwnerDrawnRenderingMode.Checked)
            {
                binarySuperToolTip1.HeaderDraw += HandleHeaderDrawing;
                binarySuperToolTip1.BodyDraw += HandleBodyDrawing;
                binarySuperToolTip1.FooterDraw += HandleFooterDraw;
                binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(buttonRenderSuperTooltip, true);
                binarySuperToolTip1.SetBinarySuperToolTipCustomSize(buttonRenderSuperTooltip, new Size(500, 475));
            }

            radioButtonDefaultRenderingMode.Checked = !radioButtonOwnerDrawnRenderingMode.Checked;

            if (radioButtonOwnerDrawnRenderingMode.Checked)
            {
                var control = sender as Control;
                if (control != null) UpdateSelectedOptionBackColor(control.Parent);
            }
            else
            {
                var control1 = sender as Control;
                if (control1 != null) UpdateLeavingOptionBackColor(control1.Parent);
            }
        }

        private void HandleFooterDraw(object sender, BinarySuperToolTipDrawingEventArgs be)
        {
            if (be == null) return;

            using (var pen = new Pen(Color.Black, 2.0f))
            {
                be.Graphics.DrawRectangle(pen, Rectangle.Round(be.DrawingRectangle));

                var rect = new RectangleF(be.DrawingRectangle.Left + 1, be.DrawingRectangle.Top + 1,
                    be.DrawingRectangle.Width - 1, be.DrawingRectangle.Height - 1);

                using (var brush = new SolidBrush(Color.CadetBlue))
                {
                    be.Graphics.FillRectangle(brush, rect);
                }

                var sf = new StringFormat
                {
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center,
                    FormatFlags = StringFormatFlags.LineLimit,
                    Trimming = StringTrimming.EllipsisWord
                };

                using (var font = new Font(Font.FontFamily, 10.0f, FontStyle.Bold))
                {
                    using (var brush2 = new SolidBrush(Color.White))
                    {
                        be.Graphics.DrawString("Isn't BinarySuperToolTip .NET component, cool? ;-)",
                        font,
                        brush2,
                        rect,
                        sf);
                    }
                }
            }
        }

        private static void HandleBodyDrawing(object sender, BinarySuperToolTipDrawingEventArgs be)
        {
            if (be == null) return;

            // A sample code block, if you just want to run some text rendering.
            /*drawEventArgs.Graphics.DrawRectangle(new Pen(Color.Black, 2.0f), Rectangle.Round(drawEventArgs.DrawingRectangle));
                RectangleF rect = new RectangleF(drawEventArgs.DrawingRectangle.Left + 1, drawEventArgs.DrawingRectangle.Top + 1,
                    drawEventArgs.DrawingRectangle.Width - 1, drawEventArgs.DrawingRectangle.Height - 1);
                drawEventArgs.Graphics.FillRectangle(new SolidBrush(Color.White), rect);

                StringFormat sf = new StringFormat();
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;
                sf.FormatFlags = StringFormatFlags.LineLimit;
                sf.Trimming = StringTrimming.EllipsisWord;
                drawEventArgs.Graphics.DrawString("My custom tooltip body drawing! ;-)", new Font(this.Font.FontFamily, 10.0f, FontStyle.Bold), new SolidBrush(Color.Blue), rect, sf);
                */

            using (var bmp = Image.FromStream(Assembly.Load(Assembly.GetExecutingAssembly().FullName).
                                                                        GetManifestResourceStream($"BinarySuperToolTipDemo.Resources.sample.jpg")) as Bitmap)
            {
                if (bmp != null)
                    be.Graphics.DrawImage(bmp, be.DrawingRectangle);
            }
        }

        private void HandleHeaderDrawing(object sender, BinarySuperToolTipDrawingEventArgs be)
        {
            if (be == null) return;

            using (var pen = new Pen(Color.Black, 2.0f))
            {
                be.Graphics.DrawRectangle(pen, Rectangle.Round(be.DrawingRectangle));
                var rect = new RectangleF(be.DrawingRectangle.Left + 1, be.DrawingRectangle.Top + 1,
                    be.DrawingRectangle.Width - 1, be.DrawingRectangle.Height - 1);

                using (var brush = new SolidBrush(Color.LightSlateGray))
                {
                    be.Graphics.FillRectangle(brush, rect);
                }

                var layoutRect = Rectangle.Round(new RectangleF(rect.Left + 4, rect.Top, rect.Width - 4, rect.Height));

                var sf = new StringFormat
                {
                    Alignment = StringAlignment.Near,
                    LineAlignment = StringAlignment.Center,
                    FormatFlags = StringFormatFlags.LineLimit,
                    Trimming = StringTrimming.EllipsisWord
                };

                using (var font = new Font(Font.FontFamily, 11.0f, FontStyle.Regular))
                {
                    using (var brush2 = new SolidBrush(Color.White))
                        be.Graphics.DrawString(
                        "The header, body and the footer areas are rendered using the user specified custom drawing code.",
                        font,
                        brush2,
                        layoutRect,
                        sf);
                }
            }
        }

        private void HandleDefaultRenderingModeSelectionChanged(object sender, EventArgs e)
        {
            if (radioButtonDefaultRenderingMode.Checked)
            {
                binarySuperToolTip1.HeaderDraw -= HandleHeaderDrawing;
                binarySuperToolTip1.BodyDraw -= HandleBodyDrawing;
                binarySuperToolTip1.FooterDraw -= HandleFooterDraw;

                binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(buttonRenderSuperTooltip, true);
                binarySuperToolTip1.SetBinarySuperToolTipCustomSize(buttonRenderSuperTooltip, new Size(545, 338));
            }

            radioButtonOwnerDrawnRenderingMode.Checked = !radioButtonDefaultRenderingMode.Checked;

            if (radioButtonDefaultRenderingMode.Checked)
            {
                //var control = sender as Control;
                //if (control != null) UpdateSelectedOptionBackColor(control.Parent);
            }
            else
            {
                //var control1 = sender as Control;
                //if (control1 != null) UpdateLeavingOptionBackColor(control1.Parent);
            }
        }

        private static void UpdateSelectedOptionBackColor(Control control)
        {
            //control.BackColor = Color.Bisque;
        }

        private static void UpdateLeavingOptionBackColor(Control control)
        {
            //control.BackColor = Color.FromArgb(192, 255, 192);
        }
    }
}