using Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite;

namespace BinarySuperToolTipDemo
{
    partial class BinarySuperToolTipForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            var resources = new System.ComponentModel.ComponentResourceManager(typeof(BinarySuperToolTipForm));
            this.binarySuperToolTip1 = new Binarymission.WinForms.Controls.ExtendedToolTips.BinarySuperToolTip();
            this.buttonRenderSuperTooltip = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.defaultOptionPanel = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.radioButtonDefaultRenderingMode = new System.Windows.Forms.RadioButton();
            this.ownerDrawingOptionPanel = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.radioButtonOwnerDrawnRenderingMode = new System.Windows.Forms.RadioButton();
            this.defaultOptionPanel.SuspendLayout();
            this.ownerDrawingOptionPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // binarySuperToolTip1
            // 
            this.binarySuperToolTip1.OwnerDraw = true;
            // 
            // buttonRenderSuperTooltip
            // 
            this.buttonRenderSuperTooltip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientEndColor(this.buttonRenderSuperTooltip, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientStartColor(this.buttonRenderSuperTooltip, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingSolidColor(this.buttonRenderSuperTooltip, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingStyle(this.buttonRenderSuperTooltip, Binarymission.WinForms.Controls.ExtendedToolTips.DrawingStyle.Gradient);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyFooterSeparatingLineDepth(this.buttonRenderSuperTooltip, 1F);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImage(this.buttonRenderSuperTooltip, ((System.Drawing.Image)(resources.GetObject("buttonRenderSuperTooltip.BinarySuperToolTipBodyImage"))));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImageTransparencyColor(this.buttonRenderSuperTooltip, System.Drawing.Color.Transparent);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyText(this.buttonRenderSuperTooltip, resources.GetString("buttonRenderSuperTooltip.BinarySuperToolTipBodyText"));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextFont(this.buttonRenderSuperTooltip, new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0))));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextForeColor(this.buttonRenderSuperTooltip, System.Drawing.Color.Black);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColor(this.buttonRenderSuperTooltip, System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))));
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColourAroundImage(this.buttonRenderSuperTooltip, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBuiltInColorScheme(this.buttonRenderSuperTooltip, Binarymission.WinForms.Controls.ExtendedToolTips.ColorScheme.LightGreen);
            this.binarySuperToolTip1.SetBinarySuperToolTipCustomSize(this.buttonRenderSuperTooltip, new System.Drawing.Size(445, 258));
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorder(this.buttonRenderSuperTooltip, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorderAroundBodyImage(this.buttonRenderSuperTooltip, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawFooterIcon(this.buttonRenderSuperTooltip, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawLineSeparatingBodyAndFooterArea(this.buttonRenderSuperTooltip, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawTitleIcon(this.buttonRenderSuperTooltip, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterIcon(this.buttonRenderSuperTooltip, ((System.Drawing.Icon)(resources.GetObject("buttonRenderSuperTooltip.BinarySuperToolTipFooterIcon"))));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterText(this.buttonRenderSuperTooltip, "Footer drawn by BinarySuperToolTip .NET");
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextFont(this.buttonRenderSuperTooltip, new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0))));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextForeColor(this.buttonRenderSuperTooltip, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipGradientDrawingOrientationAngle(this.buttonRenderSuperTooltip, 270F);
            this.binarySuperToolTip1.SetBinarySuperToolTipLineColorOnTopOfFooterArea(this.buttonRenderSuperTooltip, System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleText(this.buttonRenderSuperTooltip, "Header drawn by BinarySuperToolTip .NET");
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextFont(this.buttonRenderSuperTooltip, new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0))));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextForeColor(this.buttonRenderSuperTooltip, System.Drawing.Color.Black);
            this.binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(this.buttonRenderSuperTooltip, true);
            this.buttonRenderSuperTooltip.BorderColor = System.Drawing.Color.Black;
            this.buttonRenderSuperTooltip.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this.buttonRenderSuperTooltip.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this.buttonRenderSuperTooltip.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this.buttonRenderSuperTooltip.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this.buttonRenderSuperTooltip.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this.buttonRenderSuperTooltip.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this.buttonRenderSuperTooltip.ContextMenuProperties.UseGradientPainting = true;
            this.buttonRenderSuperTooltip.DefaultTheme = true;
            this.buttonRenderSuperTooltip.DialogResult = System.Windows.Forms.DialogResult.None;
            this.buttonRenderSuperTooltip.DrawMenuButtonSeparator = true;
            this.buttonRenderSuperTooltip.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this.buttonRenderSuperTooltip.DropDownMenuItems = null;
            this.buttonRenderSuperTooltip.EndColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonRenderSuperTooltip.IsRenderingTheme = false;
            this.buttonRenderSuperTooltip.LinearGradientRenderingAngle = 90F;
            this.buttonRenderSuperTooltip.Location = new System.Drawing.Point(35, 287);
            this.buttonRenderSuperTooltip.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this.buttonRenderSuperTooltip.MenuButtonSeparatorLineHeight = -1;
            this.buttonRenderSuperTooltip.Name = "buttonRenderSuperTooltip";
            this.buttonRenderSuperTooltip.PushedEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonRenderSuperTooltip.PushedStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonRenderSuperTooltip.Size = new System.Drawing.Size(226, 36);
            this.buttonRenderSuperTooltip.StartColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonRenderSuperTooltip.TabIndex = 1;
            this.buttonRenderSuperTooltip.Text = "Hover on me!";
            this.buttonRenderSuperTooltip.TextStringFormat = null;
            this.binarySuperToolTip1.SetToolTip(this.buttonRenderSuperTooltip, resources.GetString("buttonRenderSuperTooltip.ToolTip"));
            this.buttonRenderSuperTooltip.TransparentColor = System.Drawing.Color.Empty;
            this.buttonRenderSuperTooltip.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this.buttonRenderSuperTooltip.UseCustomTextStringFormat = false;
            this.buttonRenderSuperTooltip.UseUserDefinedColorForArrowMark = true;
            this.buttonRenderSuperTooltip.UseUserDefinedColorForMenuButtonSeparator = true;
            this.buttonRenderSuperTooltip.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientEndColor(this.label2, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientStartColor(this.label2, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingSolidColor(this.label2, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingStyle(this.label2, Binarymission.WinForms.Controls.ExtendedToolTips.DrawingStyle.Solid);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyFooterSeparatingLineDepth(this.label2, 1F);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImageTransparencyColor(this.label2, System.Drawing.Color.Transparent);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyText(this.label2, "");
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextFont(this.label2, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextForeColor(this.label2, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColor(this.label2, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColourAroundImage(this.label2, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBuiltInColorScheme(this.label2, Binarymission.WinForms.Controls.ExtendedToolTips.ColorScheme.Custom);
            this.binarySuperToolTip1.SetBinarySuperToolTipCustomSize(this.label2, new System.Drawing.Size(0, 0));
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorder(this.label2, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorderAroundBodyImage(this.label2, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawFooterIcon(this.label2, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawLineSeparatingBodyAndFooterArea(this.label2, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawTitleIcon(this.label2, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextFont(this.label2, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextForeColor(this.label2, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipGradientDrawingOrientationAngle(this.label2, 270F);
            this.binarySuperToolTip1.SetBinarySuperToolTipLineColorOnTopOfFooterArea(this.label2, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextFont(this.label2, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextForeColor(this.label2, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(this.label2, false);
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(33, 228);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(371, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "A button control working with BinarySuperToolTip component:";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientEndColor(this.label6, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientStartColor(this.label6, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingSolidColor(this.label6, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingStyle(this.label6, Binarymission.WinForms.Controls.ExtendedToolTips.DrawingStyle.Solid);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyFooterSeparatingLineDepth(this.label6, 1F);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImageTransparencyColor(this.label6, System.Drawing.Color.Transparent);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyText(this.label6, "");
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextFont(this.label6, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextForeColor(this.label6, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColor(this.label6, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColourAroundImage(this.label6, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBuiltInColorScheme(this.label6, Binarymission.WinForms.Controls.ExtendedToolTips.ColorScheme.Custom);
            this.binarySuperToolTip1.SetBinarySuperToolTipCustomSize(this.label6, new System.Drawing.Size(0, 0));
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorder(this.label6, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorderAroundBodyImage(this.label6, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawFooterIcon(this.label6, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawLineSeparatingBodyAndFooterArea(this.label6, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawTitleIcon(this.label6, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextFont(this.label6, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextForeColor(this.label6, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipGradientDrawingOrientationAngle(this.label6, 270F);
            this.binarySuperToolTip1.SetBinarySuperToolTipLineColorOnTopOfFooterArea(this.label6, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextFont(this.label6, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextForeColor(this.label6, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(this.label6, false);
            this.label6.Location = new System.Drawing.Point(33, 249);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(480, 21);
            this.label6.TabIndex = 9;
            this.label6.Text = "Hover your mouse over the button control instance, to see the SuperTooltip compon" +
    "ent in action.";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientEndColor(this.panel3, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientStartColor(this.panel3, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingSolidColor(this.panel3, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingStyle(this.panel3, Binarymission.WinForms.Controls.ExtendedToolTips.DrawingStyle.Solid);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyFooterSeparatingLineDepth(this.panel3, 1F);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImageTransparencyColor(this.panel3, System.Drawing.Color.Transparent);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyText(this.panel3, "");
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextFont(this.panel3, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextForeColor(this.panel3, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColor(this.panel3, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColourAroundImage(this.panel3, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBuiltInColorScheme(this.panel3, Binarymission.WinForms.Controls.ExtendedToolTips.ColorScheme.Custom);
            this.binarySuperToolTip1.SetBinarySuperToolTipCustomSize(this.panel3, new System.Drawing.Size(0, 0));
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorder(this.panel3, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorderAroundBodyImage(this.panel3, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawFooterIcon(this.panel3, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawLineSeparatingBodyAndFooterArea(this.panel3, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawTitleIcon(this.panel3, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextFont(this.panel3, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextForeColor(this.panel3, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipGradientDrawingOrientationAngle(this.panel3, 270F);
            this.binarySuperToolTip1.SetBinarySuperToolTipLineColorOnTopOfFooterArea(this.panel3, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextFont(this.panel3, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextForeColor(this.panel3, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(this.panel3, false);
            this.panel3.Location = new System.Drawing.Point(16, 211);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(803, 134);
            this.panel3.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientEndColor(this.label3, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientStartColor(this.label3, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingSolidColor(this.label3, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingStyle(this.label3, Binarymission.WinForms.Controls.ExtendedToolTips.DrawingStyle.Solid);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyFooterSeparatingLineDepth(this.label3, 1F);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImageTransparencyColor(this.label3, System.Drawing.Color.Transparent);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyText(this.label3, "");
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextFont(this.label3, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextForeColor(this.label3, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColor(this.label3, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColourAroundImage(this.label3, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBuiltInColorScheme(this.label3, Binarymission.WinForms.Controls.ExtendedToolTips.ColorScheme.Custom);
            this.binarySuperToolTip1.SetBinarySuperToolTipCustomSize(this.label3, new System.Drawing.Size(0, 0));
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorder(this.label3, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorderAroundBodyImage(this.label3, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawFooterIcon(this.label3, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawLineSeparatingBodyAndFooterArea(this.label3, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawTitleIcon(this.label3, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextFont(this.label3, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextForeColor(this.label3, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipGradientDrawingOrientationAngle(this.label3, 270F);
            this.binarySuperToolTip1.SetBinarySuperToolTipLineColorOnTopOfFooterArea(this.label3, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextFont(this.label3, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextForeColor(this.label3, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(this.label3, false);
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(231, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "BinarySuperToolTip rendering mode:";
            // 
            // defaultOptionPanel
            // 
            this.defaultOptionPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientEndColor(this.defaultOptionPanel, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientStartColor(this.defaultOptionPanel, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingSolidColor(this.defaultOptionPanel, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingStyle(this.defaultOptionPanel, Binarymission.WinForms.Controls.ExtendedToolTips.DrawingStyle.Solid);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyFooterSeparatingLineDepth(this.defaultOptionPanel, 1F);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImageTransparencyColor(this.defaultOptionPanel, System.Drawing.Color.Transparent);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyText(this.defaultOptionPanel, "");
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextFont(this.defaultOptionPanel, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextForeColor(this.defaultOptionPanel, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColor(this.defaultOptionPanel, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColourAroundImage(this.defaultOptionPanel, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBuiltInColorScheme(this.defaultOptionPanel, Binarymission.WinForms.Controls.ExtendedToolTips.ColorScheme.Custom);
            this.binarySuperToolTip1.SetBinarySuperToolTipCustomSize(this.defaultOptionPanel, new System.Drawing.Size(0, 0));
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorder(this.defaultOptionPanel, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorderAroundBodyImage(this.defaultOptionPanel, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawFooterIcon(this.defaultOptionPanel, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawLineSeparatingBodyAndFooterArea(this.defaultOptionPanel, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawTitleIcon(this.defaultOptionPanel, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextFont(this.defaultOptionPanel, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextForeColor(this.defaultOptionPanel, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipGradientDrawingOrientationAngle(this.defaultOptionPanel, 270F);
            this.binarySuperToolTip1.SetBinarySuperToolTipLineColorOnTopOfFooterArea(this.defaultOptionPanel, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextFont(this.defaultOptionPanel, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextForeColor(this.defaultOptionPanel, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(this.defaultOptionPanel, false);
            this.defaultOptionPanel.Controls.Add(this.label5);
            this.defaultOptionPanel.Controls.Add(this.radioButtonDefaultRenderingMode);
            this.defaultOptionPanel.Location = new System.Drawing.Point(15, 53);
            this.defaultOptionPanel.Name = "defaultOptionPanel";
            this.defaultOptionPanel.Size = new System.Drawing.Size(368, 122);
            this.defaultOptionPanel.TabIndex = 7;
            // 
            // label5
            // 
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientEndColor(this.label5, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientStartColor(this.label5, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingSolidColor(this.label5, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingStyle(this.label5, Binarymission.WinForms.Controls.ExtendedToolTips.DrawingStyle.Solid);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyFooterSeparatingLineDepth(this.label5, 1F);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImageTransparencyColor(this.label5, System.Drawing.Color.Transparent);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyText(this.label5, "");
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextFont(this.label5, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextForeColor(this.label5, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColor(this.label5, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColourAroundImage(this.label5, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBuiltInColorScheme(this.label5, Binarymission.WinForms.Controls.ExtendedToolTips.ColorScheme.Custom);
            this.binarySuperToolTip1.SetBinarySuperToolTipCustomSize(this.label5, new System.Drawing.Size(0, 0));
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorder(this.label5, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorderAroundBodyImage(this.label5, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawFooterIcon(this.label5, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawLineSeparatingBodyAndFooterArea(this.label5, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawTitleIcon(this.label5, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextFont(this.label5, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextForeColor(this.label5, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipGradientDrawingOrientationAngle(this.label5, 270F);
            this.binarySuperToolTip1.SetBinarySuperToolTipLineColorOnTopOfFooterArea(this.label5, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextFont(this.label5, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextForeColor(this.label5, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(this.label5, false);
            this.label5.Location = new System.Drawing.Point(20, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(324, 26);
            this.label5.TabIndex = 5;
            this.label5.Text = "With this option, BinarySuperTolTip draws the tooltip using some sample property " +
    "values we have setup)";
            // 
            // radioButtonDefaultRenderingMode
            // 
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientEndColor(this.radioButtonDefaultRenderingMode, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientStartColor(this.radioButtonDefaultRenderingMode, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingSolidColor(this.radioButtonDefaultRenderingMode, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingStyle(this.radioButtonDefaultRenderingMode, Binarymission.WinForms.Controls.ExtendedToolTips.DrawingStyle.Solid);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyFooterSeparatingLineDepth(this.radioButtonDefaultRenderingMode, 1F);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImageTransparencyColor(this.radioButtonDefaultRenderingMode, System.Drawing.Color.Transparent);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyText(this.radioButtonDefaultRenderingMode, "");
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextFont(this.radioButtonDefaultRenderingMode, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextForeColor(this.radioButtonDefaultRenderingMode, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColor(this.radioButtonDefaultRenderingMode, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColourAroundImage(this.radioButtonDefaultRenderingMode, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBuiltInColorScheme(this.radioButtonDefaultRenderingMode, Binarymission.WinForms.Controls.ExtendedToolTips.ColorScheme.Custom);
            this.binarySuperToolTip1.SetBinarySuperToolTipCustomSize(this.radioButtonDefaultRenderingMode, new System.Drawing.Size(0, 0));
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorder(this.radioButtonDefaultRenderingMode, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorderAroundBodyImage(this.radioButtonDefaultRenderingMode, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawFooterIcon(this.radioButtonDefaultRenderingMode, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawLineSeparatingBodyAndFooterArea(this.radioButtonDefaultRenderingMode, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawTitleIcon(this.radioButtonDefaultRenderingMode, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextFont(this.radioButtonDefaultRenderingMode, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextForeColor(this.radioButtonDefaultRenderingMode, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipGradientDrawingOrientationAngle(this.radioButtonDefaultRenderingMode, 270F);
            this.binarySuperToolTip1.SetBinarySuperToolTipLineColorOnTopOfFooterArea(this.radioButtonDefaultRenderingMode, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextFont(this.radioButtonDefaultRenderingMode, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextForeColor(this.radioButtonDefaultRenderingMode, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(this.radioButtonDefaultRenderingMode, false);
            this.radioButtonDefaultRenderingMode.Checked = true;
            this.radioButtonDefaultRenderingMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDefaultRenderingMode.Location = new System.Drawing.Point(23, 38);
            this.radioButtonDefaultRenderingMode.Name = "radioButtonDefaultRenderingMode";
            this.radioButtonDefaultRenderingMode.Size = new System.Drawing.Size(325, 20);
            this.radioButtonDefaultRenderingMode.TabIndex = 4;
            this.radioButtonDefaultRenderingMode.TabStop = true;
            this.radioButtonDefaultRenderingMode.Text = "Default rendering mode";
            this.radioButtonDefaultRenderingMode.UseVisualStyleBackColor = true;
            this.radioButtonDefaultRenderingMode.CheckedChanged += new System.EventHandler(this.HandleDefaultRenderingModeSelectionChanged);
            // 
            // ownerDrawingOptionPanel
            // 
            this.ownerDrawingOptionPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientEndColor(this.ownerDrawingOptionPanel, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientStartColor(this.ownerDrawingOptionPanel, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingSolidColor(this.ownerDrawingOptionPanel, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingStyle(this.ownerDrawingOptionPanel, Binarymission.WinForms.Controls.ExtendedToolTips.DrawingStyle.Solid);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyFooterSeparatingLineDepth(this.ownerDrawingOptionPanel, 1F);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImageTransparencyColor(this.ownerDrawingOptionPanel, System.Drawing.Color.Transparent);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyText(this.ownerDrawingOptionPanel, "");
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextFont(this.ownerDrawingOptionPanel, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextForeColor(this.ownerDrawingOptionPanel, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColor(this.ownerDrawingOptionPanel, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColourAroundImage(this.ownerDrawingOptionPanel, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBuiltInColorScheme(this.ownerDrawingOptionPanel, Binarymission.WinForms.Controls.ExtendedToolTips.ColorScheme.Custom);
            this.binarySuperToolTip1.SetBinarySuperToolTipCustomSize(this.ownerDrawingOptionPanel, new System.Drawing.Size(0, 0));
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorder(this.ownerDrawingOptionPanel, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorderAroundBodyImage(this.ownerDrawingOptionPanel, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawFooterIcon(this.ownerDrawingOptionPanel, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawLineSeparatingBodyAndFooterArea(this.ownerDrawingOptionPanel, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawTitleIcon(this.ownerDrawingOptionPanel, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextFont(this.ownerDrawingOptionPanel, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextForeColor(this.ownerDrawingOptionPanel, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipGradientDrawingOrientationAngle(this.ownerDrawingOptionPanel, 270F);
            this.binarySuperToolTip1.SetBinarySuperToolTipLineColorOnTopOfFooterArea(this.ownerDrawingOptionPanel, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextFont(this.ownerDrawingOptionPanel, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextForeColor(this.ownerDrawingOptionPanel, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(this.ownerDrawingOptionPanel, false);
            this.ownerDrawingOptionPanel.Controls.Add(this.label4);
            this.ownerDrawingOptionPanel.Controls.Add(this.radioButtonOwnerDrawnRenderingMode);
            this.ownerDrawingOptionPanel.Location = new System.Drawing.Point(401, 53);
            this.ownerDrawingOptionPanel.Name = "ownerDrawingOptionPanel";
            this.ownerDrawingOptionPanel.Size = new System.Drawing.Size(418, 122);
            this.ownerDrawingOptionPanel.TabIndex = 8;
            // 
            // label4
            // 
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientEndColor(this.label4, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientStartColor(this.label4, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingSolidColor(this.label4, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingStyle(this.label4, Binarymission.WinForms.Controls.ExtendedToolTips.DrawingStyle.Solid);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyFooterSeparatingLineDepth(this.label4, 1F);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImageTransparencyColor(this.label4, System.Drawing.Color.Transparent);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyText(this.label4, "");
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextFont(this.label4, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextForeColor(this.label4, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColor(this.label4, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColourAroundImage(this.label4, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBuiltInColorScheme(this.label4, Binarymission.WinForms.Controls.ExtendedToolTips.ColorScheme.Custom);
            this.binarySuperToolTip1.SetBinarySuperToolTipCustomSize(this.label4, new System.Drawing.Size(0, 0));
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorder(this.label4, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorderAroundBodyImage(this.label4, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawFooterIcon(this.label4, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawLineSeparatingBodyAndFooterArea(this.label4, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawTitleIcon(this.label4, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextFont(this.label4, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextForeColor(this.label4, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipGradientDrawingOrientationAngle(this.label4, 270F);
            this.binarySuperToolTip1.SetBinarySuperToolTipLineColorOnTopOfFooterArea(this.label4, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextFont(this.label4, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextForeColor(this.label4, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(this.label4, false);
            this.label4.Location = new System.Drawing.Point(15, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(340, 33);
            this.label4.TabIndex = 7;
            this.label4.Text = "With this option, BinarySuperToolTip .NET runs the custom drawing code for drawin" +
    "g the tooltip\'s header, footer and the body";
            // 
            // radioButtonOwnerDrawnRenderingMode
            // 
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientEndColor(this.radioButtonOwnerDrawnRenderingMode, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientStartColor(this.radioButtonOwnerDrawnRenderingMode, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingSolidColor(this.radioButtonOwnerDrawnRenderingMode, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingStyle(this.radioButtonOwnerDrawnRenderingMode, Binarymission.WinForms.Controls.ExtendedToolTips.DrawingStyle.Solid);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyFooterSeparatingLineDepth(this.radioButtonOwnerDrawnRenderingMode, 1F);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImageTransparencyColor(this.radioButtonOwnerDrawnRenderingMode, System.Drawing.Color.Transparent);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyText(this.radioButtonOwnerDrawnRenderingMode, "");
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextFont(this.radioButtonOwnerDrawnRenderingMode, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextForeColor(this.radioButtonOwnerDrawnRenderingMode, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColor(this.radioButtonOwnerDrawnRenderingMode, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColourAroundImage(this.radioButtonOwnerDrawnRenderingMode, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBuiltInColorScheme(this.radioButtonOwnerDrawnRenderingMode, Binarymission.WinForms.Controls.ExtendedToolTips.ColorScheme.Custom);
            this.binarySuperToolTip1.SetBinarySuperToolTipCustomSize(this.radioButtonOwnerDrawnRenderingMode, new System.Drawing.Size(0, 0));
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorder(this.radioButtonOwnerDrawnRenderingMode, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorderAroundBodyImage(this.radioButtonOwnerDrawnRenderingMode, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawFooterIcon(this.radioButtonOwnerDrawnRenderingMode, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawLineSeparatingBodyAndFooterArea(this.radioButtonOwnerDrawnRenderingMode, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawTitleIcon(this.radioButtonOwnerDrawnRenderingMode, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextFont(this.radioButtonOwnerDrawnRenderingMode, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextForeColor(this.radioButtonOwnerDrawnRenderingMode, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipGradientDrawingOrientationAngle(this.radioButtonOwnerDrawnRenderingMode, 270F);
            this.binarySuperToolTip1.SetBinarySuperToolTipLineColorOnTopOfFooterArea(this.radioButtonOwnerDrawnRenderingMode, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextFont(this.radioButtonOwnerDrawnRenderingMode, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextForeColor(this.radioButtonOwnerDrawnRenderingMode, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(this.radioButtonOwnerDrawnRenderingMode, false);
            this.radioButtonOwnerDrawnRenderingMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonOwnerDrawnRenderingMode.Location = new System.Drawing.Point(17, 40);
            this.radioButtonOwnerDrawnRenderingMode.Name = "radioButtonOwnerDrawnRenderingMode";
            this.radioButtonOwnerDrawnRenderingMode.Size = new System.Drawing.Size(338, 21);
            this.radioButtonOwnerDrawnRenderingMode.TabIndex = 6;
            this.radioButtonOwnerDrawnRenderingMode.Text = "Owner drawing mode";
            this.radioButtonOwnerDrawnRenderingMode.UseVisualStyleBackColor = true;
            this.radioButtonOwnerDrawnRenderingMode.CheckedChanged += new System.EventHandler(this.HandleOwnerDrawnRenderingModeSelectionChanged);
            // 
            // BinarySuperToolTipForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientEndColor(this, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingGradientStartColor(this, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingSolidColor(this, System.Drawing.SystemColors.Info);
            this.binarySuperToolTip1.SetBinarySuperToolTipBackgroundDrawingStyle(this, Binarymission.WinForms.Controls.ExtendedToolTips.DrawingStyle.Solid);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyFooterSeparatingLineDepth(this, 1F);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyImageTransparencyColor(this, System.Drawing.Color.Transparent);
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyText(this, "");
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextFont(this, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipBodyTextForeColor(this, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColor(this, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBorderColourAroundImage(this, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipBuiltInColorScheme(this, Binarymission.WinForms.Controls.ExtendedToolTips.ColorScheme.Custom);
            this.binarySuperToolTip1.SetBinarySuperToolTipCustomSize(this, new System.Drawing.Size(0, 0));
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorder(this, true);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawBorderAroundBodyImage(this, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawFooterIcon(this, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawLineSeparatingBodyAndFooterArea(this, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipDrawTitleIcon(this, false);
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextFont(this, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipFooterTextForeColor(this, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipGradientDrawingOrientationAngle(this, 270F);
            this.binarySuperToolTip1.SetBinarySuperToolTipLineColorOnTopOfFooterArea(this, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextFont(this, new System.Drawing.Font("Arial", 10F));
            this.binarySuperToolTip1.SetBinarySuperToolTipTitleTextForeColor(this, System.Drawing.SystemColors.WindowText);
            this.binarySuperToolTip1.SetBinarySuperToolTipUseCustomSizing(this, false);
            this.ClientSize = new System.Drawing.Size(845, 394);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ownerDrawingOptionPanel);
            this.Controls.Add(this.defaultOptionPanel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonRenderSuperTooltip);
            this.Controls.Add(this.panel3);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BinarySuperToolTipForm";
            this.TitlebarText = "Binarymission SuperTooltip .NET control Demo";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.defaultOptionPanel.ResumeLayout(false);
            this.ownerDrawingOptionPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Binarymission.WinForms.Controls.ExtendedToolTips.BinarySuperToolTip binarySuperToolTip1;
        private SmartButton buttonRenderSuperTooltip;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel defaultOptionPanel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton radioButtonDefaultRenderingMode;
        private System.Windows.Forms.Panel ownerDrawingOptionPanel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton radioButtonOwnerDrawnRenderingMode;
    }
}

