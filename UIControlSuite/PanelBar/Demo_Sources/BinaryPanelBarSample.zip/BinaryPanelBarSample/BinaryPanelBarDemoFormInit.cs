﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.AdvancedNavigationControls;
using Binarymission.WinForms.Controls.NavigationControls;

namespace BinaryPanelBarSample
{
    public partial class BinaryPanelBarDemoForm
    {
        private BinaryPanelBar _binaryPanelBar1;
        private BinaryPanelBarButton _binaryPanelBarButton1;
        private BinaryPanelBarButton _binaryPanelBarButton2;
        private BinaryPanelBarButton _binaryPanelBarButton3;
        private BinaryPanelBarButton _binaryPanelBarButton4;
        private BinaryPanelBarContainedPanel _binaryPanelBarContainedPanel1;
        private Button _btnExit;
        private ComboBox _comboBox1;
        private Label _label1;
        private Button _btnStartColor;
        private Button _btnEndColor;
        private ColorDialog _colorDialog1;
        private CheckBox _chkUseCustomColorsForRenderingTheControl;
        private Button _btnEndColor2;
        private Button _btnStartColor2;
        private BinaryPanelBarContainedPanel _binaryPanelBarContainedPanel2;
        private Label _label2;
        private ComboBox _comboBox2;
        private BinaryHeaderControl _binaryHeaderControl1;
        private BinaryScrollablePanel _binaryScrollablePanel1;
        private CheckBox _chkKeepBarInCollapsedMode;
        private CheckBox _chkRenderBarInExpandCollapseMode;
        private BinaryPanelBarContainedPanel _binaryPanelBarContainedPanel3;
        private CheckBox _checkBox3;
        private Label _label3;
        private StatusStrip _statusStrip1;
        private ToolStripStatusLabel _toolStripStatusLabel1;
        private SplitContainer _splitContainer1;
        private int _splitterWidth;
        private int _nonCollapsedModeSizeForSplitterLeftPanel;
        private bool _alwaysKeepControlInCollapsedMode;

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        /// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Binarymission.WinForms.Controls.AdvancedNavigationControls.BinaryPanelBar.AddShowNavigationOptionsMenuResourceProvider addShowNavigationOptionsMenuResourceProvider4 = new Binarymission.WinForms.Controls.AdvancedNavigationControls.BinaryPanelBar.AddShowNavigationOptionsMenuResourceProvider();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BinaryPanelBarDemoForm));
            _btnExit = new System.Windows.Forms.Button();
            _comboBox1 = new System.Windows.Forms.ComboBox();
            _label1 = new System.Windows.Forms.Label();
            _btnStartColor = new System.Windows.Forms.Button();
            _btnEndColor = new System.Windows.Forms.Button();
            _colorDialog1 = new System.Windows.Forms.ColorDialog();
            _chkUseCustomColorsForRenderingTheControl = new System.Windows.Forms.CheckBox();
            _chkKeepBarInCollapsedMode = new System.Windows.Forms.CheckBox();
            _chkRenderBarInExpandCollapseMode = new System.Windows.Forms.CheckBox();
            _label3 = new System.Windows.Forms.Label();
            _statusStrip1 = new System.Windows.Forms.StatusStrip();
            _toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            _splitContainer1 = new System.Windows.Forms.SplitContainer();
            _binaryPanelBar1 = new Binarymission.WinForms.Controls.AdvancedNavigationControls.BinaryPanelBar();
            _binaryPanelBarContainedPanel1 = new Binarymission.WinForms.Controls.AdvancedNavigationControls.BinaryPanelBarContainedPanel();
            _binaryHeaderControl1 = new Binarymission.WinForms.Controls.NavigationControls.BinaryHeaderControl();
            _binaryScrollablePanel1 = new Binarymission.WinForms.Controls.NavigationControls.BinaryScrollablePanel();
            _checkBox3 = new System.Windows.Forms.CheckBox();
            _btnEndColor2 = new System.Windows.Forms.Button();
            _btnStartColor2 = new System.Windows.Forms.Button();
            _binaryPanelBarContainedPanel2 = new Binarymission.WinForms.Controls.AdvancedNavigationControls.BinaryPanelBarContainedPanel();
            _label2 = new System.Windows.Forms.Label();
            _comboBox2 = new System.Windows.Forms.ComboBox();
            _binaryPanelBarContainedPanel3 = new Binarymission.WinForms.Controls.AdvancedNavigationControls.BinaryPanelBarContainedPanel();
            _binaryPanelBarButton1 = new Binarymission.WinForms.Controls.AdvancedNavigationControls.BinaryPanelBarButton();
            _binaryPanelBarButton2 = new Binarymission.WinForms.Controls.AdvancedNavigationControls.BinaryPanelBarButton();
            _binaryPanelBarButton3 = new Binarymission.WinForms.Controls.AdvancedNavigationControls.BinaryPanelBarButton();
            _binaryPanelBarButton4 = new Binarymission.WinForms.Controls.AdvancedNavigationControls.BinaryPanelBarButton();
            _statusStrip1.SuspendLayout();
            _splitContainer1.Panel1.SuspendLayout();
            _splitContainer1.Panel2.SuspendLayout();
            _splitContainer1.SuspendLayout();
            _binaryPanelBar1.SuspendLayout();
            _binaryPanelBarContainedPanel1.SuspendLayout();
            _binaryHeaderControl1.SuspendLayout();
            _binaryScrollablePanel1.SuspendLayout();
            _binaryPanelBarContainedPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // _btnExit
            // 
            _btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            _btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            _btnExit.Location = new System.Drawing.Point(256, 460);
            _btnExit.Name = "_btnExit";
            _btnExit.Size = new System.Drawing.Size(88, 32);
            _btnExit.TabIndex = 2;
            _btnExit.Text = "E&xit";
            _btnExit.Click += new System.EventHandler(ExitAppClicked);
            // 
            // _comboBox1
            // 
            _comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            _comboBox1.FormattingEnabled = true;
            _comboBox1.Items.AddRange(new object[] {
            "Default Outlook - Blue",
            "Default Outlook - Olive",
            "Default Outlook - Silver",
            "OfficeRenderingStyle - Blue",
            "OfficeRenderingStyle - Olive",
            "OfficeRenderingStyle - Silver",
            "WindowsOSThemeSettings",
            "Custom"});
            _comboBox1.Location = new System.Drawing.Point(26, 35);
            _comboBox1.Name = "_comboBox1";
            _comboBox1.Size = new System.Drawing.Size(274, 21);
            _comboBox1.TabIndex = 3;
            _comboBox1.SelectedIndexChanged += new System.EventHandler(ThemeAndColorSchemesSelectedIndexChanged);
            // 
            // _label1
            // 
            _label1.AutoSize = true;
            _label1.Location = new System.Drawing.Point(23, 16);
            _label1.Name = "_label1";
            _label1.Size = new System.Drawing.Size(83, 13);
            _label1.TabIndex = 4;
            _label1.Text = "Rendering style:";
            // 
            // _btnStartColor
            // 
            _btnStartColor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            _btnStartColor.Location = new System.Drawing.Point(27, 125);
            _btnStartColor.Name = "_btnStartColor";
            _btnStartColor.Size = new System.Drawing.Size(88, 32);
            _btnStartColor.TabIndex = 5;
            _btnStartColor.Text = "Start color...";
            _btnStartColor.Click += new System.EventHandler(UpdateStartColor);
            // 
            // _btnEndColor
            // 
            _btnEndColor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            _btnEndColor.Location = new System.Drawing.Point(121, 125);
            _btnEndColor.Name = "_btnEndColor";
            _btnEndColor.Size = new System.Drawing.Size(88, 32);
            _btnEndColor.TabIndex = 6;
            _btnEndColor.Text = "End color...";
            _btnEndColor.Click += new System.EventHandler(UpdateEndColor);
            // 
            // _chkUseCustomColorsForRenderingTheControl
            // 
            _chkUseCustomColorsForRenderingTheControl.FlatStyle = System.Windows.Forms.FlatStyle.System;
            _chkUseCustomColorsForRenderingTheControl.Location = new System.Drawing.Point(26, 87);
            _chkUseCustomColorsForRenderingTheControl.Name = "_chkUseCustomColorsForRenderingTheControl";
            _chkUseCustomColorsForRenderingTheControl.Size = new System.Drawing.Size(230, 32);
            _chkUseCustomColorsForRenderingTheControl.TabIndex = 7;
            _chkUseCustomColorsForRenderingTheControl.Text = "Use custom colors for rendering the control";
            _chkUseCustomColorsForRenderingTheControl.CheckedChanged += new System.EventHandler(HandleUseCustomColorsForRenderingTheControlCheckedChanged);
            // 
            // _chkKeepBarInCollapsedMode
            // 
            _chkKeepBarInCollapsedMode.AutoSize = true;
            _chkKeepBarInCollapsedMode.Location = new System.Drawing.Point(27, 177);
            _chkKeepBarInCollapsedMode.Name = "_chkKeepBarInCollapsedMode";
            _chkKeepBarInCollapsedMode.Size = new System.Drawing.Size(254, 17);
            _chkKeepBarInCollapsedMode.TabIndex = 9;
            _chkKeepBarInCollapsedMode.Text = "Disable BinaryPanelBar to be in Expanded mode";
            _chkKeepBarInCollapsedMode.UseVisualStyleBackColor = true;
            _chkKeepBarInCollapsedMode.CheckedChanged += new System.EventHandler(HandleKeepBarInCollapsedModeCheckedChanged);
            // 
            // _chkRenderBarInExpandCollapseMode
            // 
            _chkRenderBarInExpandCollapseMode.AutoSize = true;
            _chkRenderBarInExpandCollapseMode.Checked = true;
            _chkRenderBarInExpandCollapseMode.CheckState = System.Windows.Forms.CheckState.Checked;
            _chkRenderBarInExpandCollapseMode.Location = new System.Drawing.Point(26, 198);
            _chkRenderBarInExpandCollapseMode.Name = "_chkRenderBarInExpandCollapseMode";
            _chkRenderBarInExpandCollapseMode.Size = new System.Drawing.Size(228, 17);
            _chkRenderBarInExpandCollapseMode.TabIndex = 10;
            _chkRenderBarInExpandCollapseMode.Text = "Render panelbar in Expand/collapse mode";
            _chkRenderBarInExpandCollapseMode.UseVisualStyleBackColor = true;
            _chkRenderBarInExpandCollapseMode.CheckedChanged += new System.EventHandler(HandleRenderBarInExpandCollapseModeCheckedChanged);
            // 
            // _label3
            // 
            _label3.Location = new System.Drawing.Point(24, 265);
            _label3.Name = "_label3";
            _label3.Size = new System.Drawing.Size(316, 45);
            _label3.TabIndex = 11;
            _label3.Text = "Note that there are several other properties and events that you can customise an" +
    "d handle respectively, almost all of them from the Visual studio design environm" +
    "ent itself.";
            // 
            // _statusStrip1
            // 
            _statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            _toolStripStatusLabel1});
            _statusStrip1.Location = new System.Drawing.Point(0, 505);
            _statusStrip1.Name = "_statusStrip1";
            _statusStrip1.Size = new System.Drawing.Size(607, 22);
            _statusStrip1.TabIndex = 12;
            _statusStrip1.Text = "statusStrip1";
            // 
            // _toolStripStatusLabel1
            // 
            _toolStripStatusLabel1.Name = "_toolStripStatusLabel1";
            _toolStripStatusLabel1.Size = new System.Drawing.Size(418, 17);
            _toolStripStatusLabel1.Text = "Copyright (C) Binarymission, UK. Web home: http://www.binarymission.co.uk";
            // 
            // _splitContainer1
            // 
            _splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            _splitContainer1.Location = new System.Drawing.Point(0, 0);
            _splitContainer1.Name = "_splitContainer1";
            // 
            // _splitContainer1.Panel1
            // 
            _splitContainer1.Panel1.Controls.Add(_binaryPanelBar1);
            _splitContainer1.Panel1.SizeChanged += new System.EventHandler(HandleSplitContainerPanelSizeChanged);
            _splitContainer1.Panel1MinSize = 36;
            // 
            // _splitContainer1.Panel2
            // 
            _splitContainer1.Panel2.BackColor = System.Drawing.Color.White;
            _splitContainer1.Panel2.Controls.Add(_btnExit);
            _splitContainer1.Panel2.Controls.Add(_label3);
            _splitContainer1.Panel2.Controls.Add(_comboBox1);
            _splitContainer1.Panel2.Controls.Add(_chkRenderBarInExpandCollapseMode);
            _splitContainer1.Panel2.Controls.Add(_label1);
            _splitContainer1.Panel2.Controls.Add(_chkKeepBarInCollapsedMode);
            _splitContainer1.Panel2.Controls.Add(_btnStartColor);
            _splitContainer1.Panel2.Controls.Add(_chkUseCustomColorsForRenderingTheControl);
            _splitContainer1.Panel2.Controls.Add(_btnEndColor);
            _splitContainer1.Size = new System.Drawing.Size(607, 505);
            _splitContainer1.SplitterDistance = 243;
            _splitContainer1.TabIndex = 13;
            // 
            // _binaryPanelBar1
            // 
            _binaryPanelBar1.AddShowNavigationOptionsMenuItem = true;
            addShowNavigationOptionsMenuResourceProvider4.AddOrRemoveButtonsText = "Add or Remove Buttons";
            addShowNavigationOptionsMenuResourceProvider4.NavigationPaneOptionsText = "Navigation Pane Options...";
            addShowNavigationOptionsMenuResourceProvider4.ShowFewerButtonsText = "Show Fewer Buttons";
            addShowNavigationOptionsMenuResourceProvider4.ShowMoreButtonsText = "Show More Buttons";
            _binaryPanelBar1.AddShowNavigationOptionsMenuResourceProviderInstance = addShowNavigationOptionsMenuResourceProvider4;
            _binaryPanelBar1.ButtonBorderStyle = Binarymission.WinForms.Controls.AdvancedNavigationControls.BorderStyle.Thin;
            _binaryPanelBar1.CollapseExpandButtonColor = System.Drawing.SystemColors.WindowText;
            _binaryPanelBar1.ContextMenuChevronColor = System.Drawing.Color.Black;
            _binaryPanelBar1.ControlBorderStyle = Binarymission.WinForms.Controls.AdvancedNavigationControls.BorderStyle.Thin;
            _binaryPanelBar1.Controls.Add(_binaryPanelBarContainedPanel1);
            _binaryPanelBar1.Controls.Add(_binaryPanelBarContainedPanel2);
            _binaryPanelBar1.Controls.Add(_binaryPanelBarContainedPanel3);
            _binaryPanelBar1.Controls.Add(_binaryPanelBarButton1);
            _binaryPanelBar1.Controls.Add(_binaryPanelBarButton2);
            _binaryPanelBar1.Controls.Add(_binaryPanelBarButton3);
            _binaryPanelBar1.Controls.Add(_binaryPanelBarButton4);
            _binaryPanelBar1.CustomChevronImage = null;
            _binaryPanelBar1.CustomImageTransparentColor = System.Drawing.Color.Empty;
            _binaryPanelBar1.EndColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(219)))), ((int)(((byte)(249)))));
            _binaryPanelBar1.ForeColor = System.Drawing.SystemColors.WindowText;
            _binaryPanelBar1.GripperColor = System.Drawing.Color.Green;
            _binaryPanelBar1.GripperHeight = 8;
            _binaryPanelBar1.HowManyPanelButtonsToShow = 4;
            _binaryPanelBar1.ItemColorRenderingStyle = Binarymission.WinForms.Controls.AdvancedNavigationControls.ItemColorRenderingStyle.Default;
            _binaryPanelBar1.LeftMarginForDrawingMainHeaderText = 2;
            _binaryPanelBar1.Location = new System.Drawing.Point(0, 0);
            _binaryPanelBar1.MainHeaderTextColor = System.Drawing.SystemColors.WindowText;
            _binaryPanelBar1.MainHeaderTextFont = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            _binaryPanelBar1.MenuItemAvailableButtonCheckedStateBorderColor = System.Drawing.Color.Empty;
            _binaryPanelBar1.MenuItemSelectionBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            _binaryPanelBar1.Name = "_binaryPanelBar1";
            _binaryPanelBar1.Padding = new System.Windows.Forms.Padding(1);
            _binaryPanelBar1.PanelBarWindowFillColorWhenInCollapsedModeAndTheContainedPanelIsShowing = System.Drawing.SystemColors.Info;
            _binaryPanelBar1.PanelBarWindowFillColorWhenInCollpasedMode = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            _binaryPanelBar1.PanelBarWindowTextColorWhenInCollpasedMode = System.Drawing.SystemColors.Highlight;
            _binaryPanelBar1.PanelText = "Projects";
            _binaryPanelBar1.PanelWindowTextFontWhenInCollapsedMode = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            _binaryPanelBar1.PanelWindowTextWhenGripperIsOnMove = "Working...";
            _binaryPanelBar1.ReflectCurrentXPThemeColorOnLoad = true;
            _binaryPanelBar1.RenderInOutlookStyleExpandCollapseMode = true;
            _binaryPanelBar1.ShouldAutoResetFocusToControlAfterPopupWindowHide = false;
            _binaryPanelBar1.Size = new System.Drawing.Size(243, 467);
            _binaryPanelBar1.StartColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            _binaryPanelBar1.TabIndex = 0;
            _binaryPanelBar1.TopMarginForDrawingMainHeaderText = 2;
            _binaryPanelBar1.UpdateWhenSystemColorsChanges = true;
            _binaryPanelBar1.UseSolidBrushWhenPaintingButtons = false;
            _binaryPanelBar1.WirePanelBarButtonClickEventToBaseBarButton = true;
            _binaryPanelBar1.XPThemeToEmulate = Binarymission.WinForms.Controls.AdvancedNavigationControls.XpTheme.Blue;
            // 
            // _binaryPanelBarContainedPanel1
            // 
            _binaryPanelBarContainedPanel1.AutoScroll = true;
            _binaryPanelBarContainedPanel1.BackColor = System.Drawing.Color.White;
            _binaryPanelBarContainedPanel1.Controls.Add(_binaryHeaderControl1);
            _binaryPanelBarContainedPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            _binaryPanelBarContainedPanel1.Location = new System.Drawing.Point(1, 26);
            _binaryPanelBarContainedPanel1.Name = "_binaryPanelBarContainedPanel1";
            _binaryPanelBarContainedPanel1.Size = new System.Drawing.Size(241, 272);
            _binaryPanelBarContainedPanel1.TabIndex = 1;
            // 
            // _binaryHeaderControl1
            // 
            _binaryHeaderControl1.BackgroundGradientDrawingDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            _binaryHeaderControl1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            _binaryHeaderControl1.BorderWidth = 2;
            _binaryHeaderControl1.ContextMenuArrowColor = System.Drawing.Color.Transparent;
            _binaryHeaderControl1.ContextMenuEllipseColor = System.Drawing.Color.Transparent;
            _binaryHeaderControl1.ContextMenuImageType = Binarymission.WinForms.Controls.NavigationControls.ContextMenuButtonImageType.Default;
            _binaryHeaderControl1.ContextMenuType = Binarymission.WinForms.Controls.NavigationControls.ContextMenuType.ContextMenuStrip;
            _binaryHeaderControl1.ControlIsInExpandedState = true;
            _binaryHeaderControl1.Controls.Add(_binaryScrollablePanel1);
            _binaryHeaderControl1.CustomContextMenuButtonImageTransparencyColor = System.Drawing.Color.Transparent;
            _binaryHeaderControl1.CustomIconForContextMenuButton = null;
            _binaryHeaderControl1.CustomImageForContextMenuButton = null;
            _binaryHeaderControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            _binaryHeaderControl1.DrawBorderAround = Binarymission.WinForms.Controls.NavigationControls.DrawBorderAround.None;
            _binaryHeaderControl1.DrawFooter = true;
            _binaryHeaderControl1.EnableCollapseExpandButton = false;
            _binaryHeaderControl1.EnableHeaderContextMenu = true;
            _binaryHeaderControl1.EndColorForBackgroundRendering = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(221)))), ((int)(((byte)(250)))));
            _binaryHeaderControl1.EndColorForFooterRendering = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(221)))), ((int)(((byte)(250)))));
            _binaryHeaderControl1.EndColorForHeaderRendering = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(221)))), ((int)(((byte)(250)))));
            _binaryHeaderControl1.ExpandCollapseCircleFillColor = System.Drawing.SystemColors.Window;
            _binaryHeaderControl1.ExpandCollapseUpDownArrowsFillColor = System.Drawing.SystemColors.WindowText;
            _binaryHeaderControl1.FooterBorderColor = System.Drawing.Color.White;
            _binaryHeaderControl1.FooterBorderThickness = 2F;
            _binaryHeaderControl1.FooterCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            _binaryHeaderControl1.FooterCaptionHeight = 20;
            _binaryHeaderControl1.FooterGradientDrawingDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            _binaryHeaderControl1.FooterText = "Footer text!";
            _binaryHeaderControl1.FooterTextForeColor = System.Drawing.SystemColors.ActiveCaption;
            _binaryHeaderControl1.HeaderBitmapTransparencyColor = System.Drawing.Color.Transparent;
            _binaryHeaderControl1.HeaderBorderColor = System.Drawing.SystemColors.ControlText;
            _binaryHeaderControl1.HeaderBorderThickness = 1F;
            _binaryHeaderControl1.HeaderCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            _binaryHeaderControl1.HeaderCaptionHeight = 26;
            _binaryHeaderControl1.HeaderContextMenu = null;
            _binaryHeaderControl1.HeaderContextMenuStrip = null;
            _binaryHeaderControl1.HeaderFooterDrawingStyle = Binarymission.WinForms.Controls.NavigationControls.HeaderFooterDrawingStyle.Default;
            _binaryHeaderControl1.HeaderGradientDrawingDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            _binaryHeaderControl1.HeaderIcon = null;
            _binaryHeaderControl1.HeaderImage = null;
            _binaryHeaderControl1.HeaderImageType = Binarymission.WinForms.Controls.NavigationControls.HeaderImageType.Icon;
            _binaryHeaderControl1.HeaderLocation = Binarymission.WinForms.Controls.NavigationControls.HeaderLocation.Top;
            _binaryHeaderControl1.HeaderText = "Header text";
            _binaryHeaderControl1.HeaderTextForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            _binaryHeaderControl1.Location = new System.Drawing.Point(0, 0);
            _binaryHeaderControl1.Name = "_binaryHeaderControl1";
            _binaryHeaderControl1.Size = new System.Drawing.Size(241, 272);
            _binaryHeaderControl1.StartColorForBackgroundRendering = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            _binaryHeaderControl1.StartColorForFooterRendering = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            _binaryHeaderControl1.StartColorForHeaderRendering = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            _binaryHeaderControl1.TabIndex = 9;
            _binaryHeaderControl1.UseAntiAliasingAsHeaderCaptionTextRenderingHint = false;
            _binaryHeaderControl1.UseCustomImageForContextMenuButton = false;
            // 
            // _binaryScrollablePanel1
            // 
            _binaryScrollablePanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            _binaryScrollablePanel1.AutoScroll = true;
            _binaryScrollablePanel1.BackColor = System.Drawing.Color.White;
            _binaryScrollablePanel1.Controls.Add(_checkBox3);
            _binaryScrollablePanel1.Controls.Add(_btnEndColor2);
            _binaryScrollablePanel1.Controls.Add(_btnStartColor2);
            _binaryScrollablePanel1.EndColorForGradientRendering = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(219)))), ((int)(((byte)(249)))));
            _binaryScrollablePanel1.GradientDrawingDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            _binaryScrollablePanel1.Location = new System.Drawing.Point(1, 1);
            _binaryScrollablePanel1.Name = "_binaryScrollablePanel1";
            _binaryScrollablePanel1.Size = new System.Drawing.Size(235, 220);
            _binaryScrollablePanel1.StartColorForGradientRendering = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            _binaryScrollablePanel1.TabIndex = 11;
            // 
            // _checkBox3
            // 
            _checkBox3.BackColor = System.Drawing.Color.Transparent;
            _checkBox3.Location = new System.Drawing.Point(8, 14);
            _checkBox3.Name = "_checkBox3";
            _checkBox3.Size = new System.Drawing.Size(234, 28);
            _checkBox3.TabIndex = 11;
            _checkBox3.Text = "Use custom colors for rendering the control";
            _checkBox3.UseVisualStyleBackColor = false;
            // 
            // _btnEndColor2
            // 
            _btnEndColor2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            _btnEndColor2.Location = new System.Drawing.Point(123, 52);
            _btnEndColor2.Name = "_btnEndColor2";
            _btnEndColor2.Size = new System.Drawing.Size(88, 32);
            _btnEndColor2.TabIndex = 9;
            _btnEndColor2.Text = "End color...";
            // 
            // _btnStartColor2
            // 
            _btnStartColor2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            _btnStartColor2.Location = new System.Drawing.Point(29, 52);
            _btnStartColor2.Name = "_btnStartColor2";
            _btnStartColor2.Size = new System.Drawing.Size(88, 32);
            _btnStartColor2.TabIndex = 8;
            _btnStartColor2.Text = "Start color...";
            // 
            // _binaryPanelBarContainedPanel2
            // 
            _binaryPanelBarContainedPanel2.AutoScroll = true;
            _binaryPanelBarContainedPanel2.BackColor = System.Drawing.Color.White;
            _binaryPanelBarContainedPanel2.Controls.Add(_label2);
            _binaryPanelBarContainedPanel2.Controls.Add(_comboBox2);
            _binaryPanelBarContainedPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            _binaryPanelBarContainedPanel2.Location = new System.Drawing.Point(1, 26);
            _binaryPanelBarContainedPanel2.Name = "_binaryPanelBarContainedPanel2";
            _binaryPanelBarContainedPanel2.Size = new System.Drawing.Size(241, 400);
            _binaryPanelBarContainedPanel2.TabIndex = 8;
            // 
            // _label2
            // 
            _label2.AutoSize = true;
            _label2.Location = new System.Drawing.Point(-97, 21);
            _label2.Name = "_label2";
            _label2.Size = new System.Drawing.Size(83, 13);
            _label2.TabIndex = 6;
            _label2.Text = "Rendering style:";
            // 
            // _comboBox2
            // 
            _comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            _comboBox2.FormattingEnabled = true;
            _comboBox2.Items.AddRange(new object[] {
            "Default Outlook - Blue",
            "Default Outlook - Olive",
            "Default Outlook - Silver",
            "OfficeRenderingStyle - Blue",
            "OfficeRenderingStyle - Olive",
            "OfficeRenderingStyle - Silver",
            "Custom"});
            _comboBox2.Location = new System.Drawing.Point(14, 38);
            _comboBox2.Name = "_comboBox2";
            _comboBox2.Size = new System.Drawing.Size(182, 21);
            _comboBox2.TabIndex = 5;
            // 
            // _binaryPanelBarContainedPanel3
            // 
            _binaryPanelBarContainedPanel3.AutoScroll = true;
            _binaryPanelBarContainedPanel3.BackColor = System.Drawing.Color.White;
            _binaryPanelBarContainedPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            _binaryPanelBarContainedPanel3.Location = new System.Drawing.Point(1, 26);
            _binaryPanelBarContainedPanel3.Name = "_binaryPanelBarContainedPanel3";
            _binaryPanelBarContainedPanel3.Size = new System.Drawing.Size(241, 400);
            _binaryPanelBarContainedPanel3.TabIndex = 11;
            // 
            // _binaryPanelBarButton1
            // 
            _binaryPanelBarButton1.BackColor = System.Drawing.Color.Transparent;
            _binaryPanelBarButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("_binaryPanelBarButton1.BackgroundImage")));
            _binaryPanelBarButton1.ButtonBorderStyle = Binarymission.WinForms.Controls.AdvancedNavigationControls.BorderStyle.Thin;
            _binaryPanelBarButton1.ButtonImage = global::BinaryPanelBarSample.Properties.Resources.Projects;
            _binaryPanelBarButton1.ButtonSmallImage = null;
            _binaryPanelBarButton1.ButtonText = "Projects";
            _binaryPanelBarButton1.ContainedPanel = _binaryPanelBarContainedPanel1;
            _binaryPanelBarButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            _binaryPanelBarButton1.Dock = System.Windows.Forms.DockStyle.Bottom;
            _binaryPanelBarButton1.EndColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(219)))), ((int)(((byte)(249)))));
            _binaryPanelBarButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            _binaryPanelBarButton1.ForeColor = System.Drawing.SystemColors.WindowText;
            _binaryPanelBarButton1.ItemColorRenderingStyle = Binarymission.WinForms.Controls.AdvancedNavigationControls.ItemColorRenderingStyle.Default;
            _binaryPanelBarButton1.Location = new System.Drawing.Point(1, 306);
            _binaryPanelBarButton1.Name = "_binaryPanelBarButton1";
            _binaryPanelBarButton1.NotAvailableForUse = false;
            _binaryPanelBarButton1.ParentControl = null;
            _binaryPanelBarButton1.Size = new System.Drawing.Size(241, 32);
            _binaryPanelBarButton1.StartColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            _binaryPanelBarButton1.TabIndex = 5;
            _binaryPanelBarButton1.WirePanelBarButtonClickEventToBaseBarButton = true;
            // 
            // _binaryPanelBarButton2
            // 
            _binaryPanelBarButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("_binaryPanelBarButton2.BackgroundImage")));
            _binaryPanelBarButton2.ButtonBorderStyle = Binarymission.WinForms.Controls.AdvancedNavigationControls.BorderStyle.Thin;
            _binaryPanelBarButton2.ButtonImage = global::BinaryPanelBarSample.Properties.Resources.Customers;
            _binaryPanelBarButton2.ButtonSmallImage = null;
            _binaryPanelBarButton2.ButtonText = "Customers";
            _binaryPanelBarButton2.ContainedPanel = _binaryPanelBarContainedPanel2;
            _binaryPanelBarButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            _binaryPanelBarButton2.Dock = System.Windows.Forms.DockStyle.Bottom;
            _binaryPanelBarButton2.EndColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(219)))), ((int)(((byte)(249)))));
            _binaryPanelBarButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            _binaryPanelBarButton2.ItemColorRenderingStyle = Binarymission.WinForms.Controls.AdvancedNavigationControls.ItemColorRenderingStyle.Default;
            _binaryPanelBarButton2.Location = new System.Drawing.Point(1, 338);
            _binaryPanelBarButton2.Name = "_binaryPanelBarButton2";
            _binaryPanelBarButton2.NotAvailableForUse = false;
            _binaryPanelBarButton2.ParentControl = null;
            _binaryPanelBarButton2.Size = new System.Drawing.Size(241, 32);
            _binaryPanelBarButton2.StartColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            _binaryPanelBarButton2.TabIndex = 6;
            _binaryPanelBarButton2.WirePanelBarButtonClickEventToBaseBarButton = true;
            // 
            // _binaryPanelBarButton3
            // 
            _binaryPanelBarButton3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("_binaryPanelBarButton3.BackgroundImage")));
            _binaryPanelBarButton3.ButtonBorderStyle = Binarymission.WinForms.Controls.AdvancedNavigationControls.BorderStyle.Thin;
            _binaryPanelBarButton3.ButtonImage = global::BinaryPanelBarSample.Properties.Resources.Sales;
            _binaryPanelBarButton3.ButtonSmallImage = null;
            _binaryPanelBarButton3.ButtonText = "Sales";
            _binaryPanelBarButton3.ContainedPanel = _binaryPanelBarContainedPanel3;
            _binaryPanelBarButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            _binaryPanelBarButton3.Dock = System.Windows.Forms.DockStyle.Bottom;
            _binaryPanelBarButton3.EndColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(219)))), ((int)(((byte)(249)))));
            _binaryPanelBarButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            _binaryPanelBarButton3.ItemColorRenderingStyle = Binarymission.WinForms.Controls.AdvancedNavigationControls.ItemColorRenderingStyle.Default;
            _binaryPanelBarButton3.Location = new System.Drawing.Point(1, 370);
            _binaryPanelBarButton3.Name = "_binaryPanelBarButton3";
            _binaryPanelBarButton3.NotAvailableForUse = false;
            _binaryPanelBarButton3.ParentControl = null;
            _binaryPanelBarButton3.Size = new System.Drawing.Size(241, 32);
            _binaryPanelBarButton3.StartColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            _binaryPanelBarButton3.TabIndex = 7;
            _binaryPanelBarButton3.WirePanelBarButtonClickEventToBaseBarButton = true;
            // 
            // _binaryPanelBarButton4
            // 
            _binaryPanelBarButton4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("_binaryPanelBarButton4.BackgroundImage")));
            _binaryPanelBarButton4.ButtonBorderStyle = Binarymission.WinForms.Controls.AdvancedNavigationControls.BorderStyle.Thin;
            _binaryPanelBarButton4.ButtonImage = global::BinaryPanelBarSample.Properties.Resources.Reports;
            _binaryPanelBarButton4.ButtonSmallImage = null;
            _binaryPanelBarButton4.ButtonText = "Reports";
            _binaryPanelBarButton4.ContainedPanel = null;
            _binaryPanelBarButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            _binaryPanelBarButton4.Dock = System.Windows.Forms.DockStyle.Bottom;
            _binaryPanelBarButton4.EndColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(219)))), ((int)(((byte)(249)))));
            _binaryPanelBarButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            _binaryPanelBarButton4.ItemColorRenderingStyle = Binarymission.WinForms.Controls.AdvancedNavigationControls.ItemColorRenderingStyle.Default;
            _binaryPanelBarButton4.Location = new System.Drawing.Point(1, 402);
            _binaryPanelBarButton4.Name = "_binaryPanelBarButton4";
            _binaryPanelBarButton4.NotAvailableForUse = false;
            _binaryPanelBarButton4.ParentControl = null;
            _binaryPanelBarButton4.Size = new System.Drawing.Size(241, 32);
            _binaryPanelBarButton4.StartColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            _binaryPanelBarButton4.TabIndex = 8;
            _binaryPanelBarButton4.WirePanelBarButtonClickEventToBaseBarButton = true;
            // 
            // Form1
            // 
            AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            BackColor = System.Drawing.Color.White;
            BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            BorderColorDisabledCloseCommandButton = System.Drawing.Color.Transparent;
            BorderColorDisabledMaximiseRestoreCommandButton = System.Drawing.Color.Transparent;
            BorderColorDisabledMinimizeCommandButton = System.Drawing.Color.Transparent;
            BorderColorNormalCloseCommandButton = System.Drawing.Color.CornflowerBlue;
            BorderColorNormalMaximiseRestoreCommandButton = System.Drawing.Color.CornflowerBlue;
            BorderColorNormalMinimizeCommandButton = System.Drawing.Color.CornflowerBlue;
            ClientSize = new System.Drawing.Size(607, 527);
            Controls.Add(_splitContainer1);
            Controls.Add(_statusStrip1);
            DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            ForegroundInternalVisualForNormalCloseCommandButton = System.Drawing.Color.Black;
            ForegroundInternalVisualForNormalMaximizeRestoreCommandButton = System.Drawing.Color.Black;
            ForegroundInternalVisualForNormalMinimizeCommandButton = System.Drawing.Color.Black;
            Icon = ((System.Drawing.Icon)(resources.GetObject("$Icon")));
            MaximizeBox = false;
            Name = "Form1";
            WindowChromeBorderColor = System.Drawing.Color.CornflowerBlue;
            WindowChromeEndColor = System.Drawing.Color.LightBlue;
            WindowChromeStartColor = System.Drawing.Color.CornflowerBlue;
            WindowChromeTheme = Binarymission.WinForms.Controls.ContainerControls.Windows.Enums.WindowChromeTheme.OfficeBlue;
            WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            Load += new System.EventHandler(Form1_Load);
            _statusStrip1.ResumeLayout(false);
            _statusStrip1.PerformLayout();
            _splitContainer1.Panel1.ResumeLayout(false);
            _splitContainer1.Panel2.ResumeLayout(false);
            _splitContainer1.Panel2.PerformLayout();
            _splitContainer1.ResumeLayout(false);
            _binaryPanelBar1.ResumeLayout(false);
            _binaryPanelBar1.PerformLayout();
            _binaryPanelBarContainedPanel1.ResumeLayout(false);
            _binaryHeaderControl1.ResumeLayout(false);
            _binaryScrollablePanel1.ResumeLayout(false);
            _binaryPanelBarContainedPanel2.ResumeLayout(false);
            _binaryPanelBarContainedPanel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new BinaryPanelBarDemoForm());
        }
    }
}
