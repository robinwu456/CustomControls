using System;
using System.Drawing;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.AdvancedNavigationControls;
using Binarymission.WinForms.Controls.AdvancedNavigationControls.EventObjects;
using Binarymission.WinForms.Controls.NavigationControls;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryPanelBarSample
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public partial class BinaryPanelBarDemoForm : ModernChromeWindow
	{
		public BinaryPanelBarDemoForm()
		{
			InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlue;
		    TitlebarText = @"Binarymission PanelBar .NET control demo";
		}
        
		private void Form1_Load(object sender, System.EventArgs e)
		{
            _comboBox1.SelectedIndex = 0;
            _btnStartColor.Enabled = _chkUseCustomColorsForRenderingTheControl.Checked;
            _btnEndColor.Enabled = _chkUseCustomColorsForRenderingTheControl.Checked;

            var resourceProviderInstance 
                = new BinaryPanelBar.AddShowNavigationOptionsMenuResourceProvider
                {
                    AddOrRemoveButtonsText = "Add or Remove Buttons",
                    NavigationPaneOptionsText = "Show Options...",
                    ShowFewerButtonsText = "Show Fewer Buttons",
                    ShowMoreButtonsText = "Show More Buttons"
                };

		    _binaryPanelBar1.AddShowNavigationOptionsMenuResourceProviderInstance = resourceProviderInstance;
            SetParentForButtons();
            SetButtonCustomColors();
		}

        private void SetParentForButtons()
        {
            foreach (var button in _binaryPanelBar1.PanelBarButtons)
                button.ParentControl = _binaryPanelBar1;
        }

        private void SetButtonCustomColors()
        {
            _binaryPanelBar1.XPThemeToEmulate = XpTheme.None;
            _binaryPanelBarButton1.StartColor = Color.Orange;            
        }

		private void ExitAppClicked(object sender, System.EventArgs e)
		{
			Close();
		}
        
		private void ThemeAndColorSchemesSelectedIndexChanged(object sender, EventArgs e)
        {
            switch(_comboBox1.SelectedIndex)
            {
                case 0:
                    _chkUseCustomColorsForRenderingTheControl.Checked = false;
                    _binaryPanelBar1.ItemColorRenderingStyle = ItemColorRenderingStyle.Default;
                    _binaryPanelBar1.XPThemeToEmulate = XpTheme.Blue;
                    _binaryHeaderControl1.ColorScheme = Binarymission.WinForms.Controls.NavigationControls.ColorScheme.Blue;
                    break;
                case 1:
                    _chkUseCustomColorsForRenderingTheControl.Checked = false;
                    _binaryPanelBar1.ItemColorRenderingStyle = ItemColorRenderingStyle.Default;
                    _binaryPanelBar1.XPThemeToEmulate = XpTheme.Olive;
                    _binaryHeaderControl1.ColorScheme = Binarymission.WinForms.Controls.NavigationControls.ColorScheme.Olive;
                    break;
                case 2:
                    _chkUseCustomColorsForRenderingTheControl.Checked = false;
                    _binaryPanelBar1.ItemColorRenderingStyle = ItemColorRenderingStyle.Default;
                    _binaryPanelBar1.XPThemeToEmulate = XpTheme.Silver;
                    _binaryHeaderControl1.ColorScheme = Binarymission.WinForms.Controls.NavigationControls.ColorScheme.Silver;
                    break;
                case 3:
                    _chkUseCustomColorsForRenderingTheControl.Checked = false;
                    _binaryPanelBar1.ItemColorRenderingStyle = ItemColorRenderingStyle.OfficeStyleRenderer;
                    _binaryPanelBar1.XPThemeToEmulate = XpTheme.Blue;
                    _binaryHeaderControl1.ColorScheme = Binarymission.WinForms.Controls.NavigationControls.ColorScheme.Blue;
                    break;
                case 4:
                    _chkUseCustomColorsForRenderingTheControl.Checked = false;
                    _binaryPanelBar1.ItemColorRenderingStyle = ItemColorRenderingStyle.OfficeStyleRenderer;
                    _binaryPanelBar1.XPThemeToEmulate = XpTheme.Olive;
                    _binaryHeaderControl1.ColorScheme = Binarymission.WinForms.Controls.NavigationControls.ColorScheme.Olive;
                    break;
                case 5:
                    _chkUseCustomColorsForRenderingTheControl.Checked = false;
                    _binaryPanelBar1.ItemColorRenderingStyle = ItemColorRenderingStyle.OfficeStyleRenderer;
                    _binaryPanelBar1.XPThemeToEmulate = XpTheme.Silver;
                    _binaryHeaderControl1.ColorScheme = Binarymission.WinForms.Controls.NavigationControls.ColorScheme.Silver;
                    break;
                case 6:
                    _chkUseCustomColorsForRenderingTheControl.Checked = true;
                    _binaryPanelBar1.XPThemeToEmulate = XpTheme.None;
                    _binaryPanelBar1.ItemColorRenderingStyle = ItemColorRenderingStyle.WindowsOSThemeSettings;
                    _binaryHeaderControl1.ColorScheme = Binarymission.WinForms.Controls.NavigationControls.ColorScheme.None;
                    break;
                case 7:
                    _chkUseCustomColorsForRenderingTheControl.Checked = true;
                    _binaryPanelBar1.ItemColorRenderingStyle = ItemColorRenderingStyle.Default;
                    _binaryPanelBar1.XPThemeToEmulate = XpTheme.None;
                    _binaryHeaderControl1.ColorScheme = Binarymission.WinForms.Controls.NavigationControls.ColorScheme.None;
                    break;
                default: _chkUseCustomColorsForRenderingTheControl.Checked = true; break;
            }
        }

        private void UpdateEndColor(object sender, EventArgs e)
        {
            _colorDialog1.Color = _binaryPanelBar1.EndColor;
            if (_colorDialog1.ShowDialog() == DialogResult.Cancel) return;
            _binaryPanelBar1.EndColor = _colorDialog1.Color;
            _binaryHeaderControl1.EndColorForBackgroundRendering = _colorDialog1.Color;
            _binaryHeaderControl1.EndColorForHeaderRendering = _colorDialog1.Color;
            _binaryHeaderControl1.EndColorForFooterRendering = _colorDialog1.Color;
            _btnStartColor.ForeColor = _colorDialog1.Color;
        }

        private void UpdateStartColor(object sender, EventArgs e)
        {
            _colorDialog1.Color = _binaryPanelBar1.StartColor;
            if (_colorDialog1.ShowDialog() == DialogResult.Cancel) return;
            _binaryPanelBar1.StartColor = _colorDialog1.Color;
            _binaryHeaderControl1.StartColorForBackgroundRendering = _colorDialog1.Color;
            _binaryHeaderControl1.StartColorForHeaderRendering = _colorDialog1.Color;
            _binaryHeaderControl1.StartColorForFooterRendering = _colorDialog1.Color;
            _btnStartColor.ForeColor = _colorDialog1.Color;
        }

        private void HandleUseCustomColorsForRenderingTheControlCheckedChanged(object sender, EventArgs e)
        {
            _btnStartColor.Enabled = _chkUseCustomColorsForRenderingTheControl.Checked;
            _btnEndColor.Enabled = _chkUseCustomColorsForRenderingTheControl.Checked;
            if(_chkUseCustomColorsForRenderingTheControl.Checked)
            {
                _binaryPanelBar1.XPThemeToEmulate = XpTheme.None;
            }
            _comboBox1.SelectedIndex = _comboBox1.Items.Count - 1;
        }

	    private void HandleKeepBarInCollapsedModeCheckedChanged(object sender, EventArgs e)
        {
            _alwaysKeepControlInCollapsedMode = _chkKeepBarInCollapsedMode.Checked;
            _binaryPanelBar1.Invalidate();
        }

        private void HandleRenderBarInExpandCollapseModeCheckedChanged(object sender, EventArgs e)
        {
            _binaryPanelBar1.RenderInOutlookStyleExpandCollapseMode = _chkRenderBarInExpandCollapseMode.Checked;
            _chkKeepBarInCollapsedMode.Enabled = _chkRenderBarInExpandCollapseMode.Checked;
        }
        
	    private void HandleSplitContainerPanelSizeChanged(object sender, EventArgs e)
        {
            _splitterWidth = _splitContainer1.Panel1.Size.Width;
            _binaryPanelBar1.Size = new Size(_splitterWidth, _binaryPanelBar1.Size.Height);
        }

        private void HandleCollapseExpandButtonClicked(object sender, CollapseExpandEventArgs e)
        {
            if (!e.IsExpanded)
            {
                _nonCollapsedModeSizeForSplitterLeftPanel = _splitContainer1.SplitterDistance;
                _splitContainer1.SplitterDistance = _binaryPanelBar1.Size.Width;
            }
            else
            {
                _splitContainer1.SplitterDistance = _nonCollapsedModeSizeForSplitterLeftPanel;
                _binaryPanelBar1.Size = new Size(_nonCollapsedModeSizeForSplitterLeftPanel, _binaryPanelBar1.Size.Height);
            }
        }

        private void HandleEventAboutToCollapseOrExpand(object sender, AboutToCollapseOrExpandEventArgs e)
        {
            if (e.IsAboutToExpand)
            {
                e.ShouldCancel = _alwaysKeepControlInCollapsedMode;
            }
        }
	}
}
