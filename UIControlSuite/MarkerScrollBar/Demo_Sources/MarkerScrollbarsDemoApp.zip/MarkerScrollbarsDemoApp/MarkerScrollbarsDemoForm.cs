﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.MarkerScrollBar;
using Binarymission.WinForms.Controls.MarkerScrollBar.Entities;
using Binarymission.WinForms.Controls.ScrollBars.Enums;

namespace MarkerScrollbarsDemoApp
{
    public partial class MarkerScrollbarsDemoForm : ModernChromeWindow
    {
        private double _picture1X, _picture1Y;

        // Let's setup the scrollbar instances that we can use as scroller for a picture box control
        private MarkerHorizontalScrollBar _horizontalScrollBar1;
        private MarkerVerticalScrollBar _verticalScrollBar1;
        
        public MarkerScrollbarsDemoForm()
        {
            InitializeComponent();
            InitialiseScrollbarInstances();
            SubscribeToScrollbarAndTargetScrolledControlEvents();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
        }

        private void InitialiseUiArtefactsState()
        {
            cmbbxColorTheme.Items.AddRange(Enum.GetNames(typeof(ColorTheme)));
            numericSpinnerScrollerSize.Value = _horizontalScrollBar1.HorizontalScrollBarHeight;
            cmbbxColorTheme.SelectedIndex = 0;
            chkEnableMarkers.Checked = true;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            
            // Let's customize the custom scrollbar controls with various desired property values like height, width, color, etc.
            // Note that there are many more properties that we can customize, including plugging-in our own renderer for each part of the scrollbar control (like Thumb, Track, etc.)
            // Please refer to the API help guide to see what all more you can do with the control's customization.

            // But here, we will customize some handful of properties... just to prove the point...

            CustomiseScrollbarInstances();
            InitialiseUiArtefactsState();
        }

        private void InitialiseScrollbarInstances()
        {
            _horizontalScrollBar1 = new MarkerHorizontalScrollBar();
            _verticalScrollBar1 = new MarkerVerticalScrollBar();
            
            Controls.Add(_horizontalScrollBar1);
            Controls.Add(_verticalScrollBar1);
        }

        private void CustomiseScrollbarInstances()
        {
            _horizontalScrollBar1.ScrollBarRenderingConfigurator.ColorTheme = ColorTheme.OfficeBlue;
            _verticalScrollBar1.ScrollBarRenderingConfigurator.ColorTheme = ColorTheme.OfficeBlue;

            _horizontalScrollBar1.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = Color.Teal;
            _verticalScrollBar1.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = Color.Teal;

            _horizontalScrollBar1.HorizontalScrollBarHeightChanged += _horizontalScrollBar1_HorizontalScrollBarHeightChanged;
            _verticalScrollBar1.VerticalScrollBarWidthChanged += _verticalScrollBar1_VerticalScrollBarWidthChanged;

            // Setup various other core properties, i.e. the size and location of the scrollbar controls in relation to the other control 
            // that we are trying to attach the custom scrollbar to (i.e. picture box control in this case).
         
            _horizontalScrollBar1.Width = pictureBox1.Width;
            _horizontalScrollBar1.HorizontalScrollBarHeight = 24;
            _horizontalScrollBar1.Left = pictureBox1.Left;
            _horizontalScrollBar1.Top = pictureBox1.Bottom;
            _horizontalScrollBar1.MaximumScrollRange = pictureBox1.Image.Width - pictureBox1.Width;
            _verticalScrollBar1.Height = pictureBox1.Height;
            _verticalScrollBar1.VerticalScrollBarWidth = 24;
            _verticalScrollBar1.Left = pictureBox1.Left + pictureBox1.Width;
            _verticalScrollBar1.Top = pictureBox1.Top;
            _verticalScrollBar1.MaximumScrollRange = pictureBox1.Image.Height - pictureBox1.Height;
            
            RebuildScrollBarMarks();
        }

        private void RebuildScrollBarMarks()
        {
            _horizontalScrollBar1.ScrollBarMarks.Clear();
            _verticalScrollBar1.ScrollBarMarks.Clear();

            _verticalScrollBar1.ScrollBarMarks.Add(new ScrollBarRangeMark
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, _verticalScrollBar1.MaximumScrollRange - 50, "Shape = Rectangle"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.Brown,
                StartColor = Color.Orange,
                Size = new Size(7, 7),
                Value = 155,
                EndValue = _verticalScrollBar1.MaximumScrollRange - 50,
                RenderMode = ScrollBarShapedMarkMode.FillSolid,
                Shape = ScrollBarShapedMarkShape.Rectangle
            });

            _verticalScrollBar1.ScrollBarMarks.Add(new ScrollBarShapeMark()
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, 35, "Shape = Rectangle"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.White,
                StartColor = Color.DarkViolet,
                Size = new Size(12, 7),
                Value = 35,
                RenderMode = ScrollBarShapedMarkMode.FillSolid,
                Shape = ScrollBarShapedMarkShape.Rectangle
            });

            _verticalScrollBar1.ScrollBarMarks.Add(new ScrollBarShapeMark()
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, 125, "Shape = Rectangle"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.Brown,
                StartColor = Color.Yellow,
                Size = new Size(17, 7),
                Value = 125,
                Alignment = ScrollBarMarkAlignment.Right,
                RenderMode = ScrollBarShapedMarkMode.FillSolid,
                Shape = ScrollBarShapedMarkShape.Rectangle
            });


            _verticalScrollBar1.ScrollBarMarks.Add(new ScrollBarShapeMark()
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, 90, "Shape = Rectangle"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.Brown,
                Size = new Size(17, 24),
                StartColor = Color.Brown,
                EndColor = Color.White,
                LinearGradientAngle = 135f,
                Value = 90,
                Alignment = ScrollBarMarkAlignment.Center,
                RenderMode = ScrollBarShapedMarkMode.FillGradient,
                Shape = ScrollBarShapedMarkShape.Rectangle
            });

            _verticalScrollBar1.ScrollBarMarks.Add(new ScrollBarShapeMark()
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, 145, "Shape = Rectangle"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.Brown,
                StartColor = Color.White,
                Size = new Size(18, 5),
                Value = 145,
                RenderMode = ScrollBarShapedMarkMode.FillSolid,
                Shape = ScrollBarShapedMarkShape.Rectangle
            });

            _horizontalScrollBar1.ScrollBarMarks.Add(new ScrollBarRangeMark
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, 100, "Shape = Rectangle"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.Brown,
                StartColor = Color.Green,
                Size = new Size(7, 7),
                Value =  100,
                EndValue = _horizontalScrollBar1.MaximumScrollRange - 200,
                RenderMode = ScrollBarShapedMarkMode.FillSolid,
                Shape = ScrollBarShapedMarkShape.Rectangle
            });

            _horizontalScrollBar1.ScrollBarMarks.Add(new ScrollBarShapeMark
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, _horizontalScrollBar1.MaximumScrollRange, "Shape = Rectangle"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.Red,
                StartColor = Color.Red,
                Size = new Size(7, 7),
                Value = _horizontalScrollBar1.MaximumScrollRange,
                RenderMode = ScrollBarShapedMarkMode.FillSolid,
                Shape = ScrollBarShapedMarkShape.Rectangle
            });

            _horizontalScrollBar1.ScrollBarMarks.Add(new ScrollBarShapeMark
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, 225, "Shape = Rectangle"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.Red,
                Alignment = ScrollBarMarkAlignment.Center,
                StartColor = Color.Red,
                Size = new Size(7, 7),
                Value = 225,
                RenderMode = ScrollBarShapedMarkMode.FillSolid,
                Shape = ScrollBarShapedMarkShape.Rectangle
            });

            _horizontalScrollBar1.ScrollBarMarks.Add(new ScrollBarShapeMark
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, 250, "Shape = Rectangle"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                Alignment = ScrollBarMarkAlignment.Top,
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.Black,
                StartColor = Color.Orange,
                Size = new Size(12, 7),
                Value = 250,
                RenderMode = ScrollBarShapedMarkMode.FillSolid,
                Shape = ScrollBarShapedMarkShape.Rectangle
            });

            _horizontalScrollBar1.ScrollBarMarks.Add(new ScrollBarShapeMark
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, 285, "Shape = Rectangle"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                Alignment = ScrollBarMarkAlignment.Center,
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.Brown,
                StartColor = Color.Yellow,
                Size = new Size(21, 7),
                Value = 285,
                RenderMode = ScrollBarShapedMarkMode.FillSolid,
                Shape = ScrollBarShapedMarkShape.Rectangle
            });

            _verticalScrollBar1.ScrollBarMarks.Add(new ScrollBarShapeMark
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, _verticalScrollBar1.MaximumScrollRange, "Shape = Oval"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.Brown,
                StartColor = Color.Orange,
                Size = new Size(24, 17),
                Alignment = ScrollBarMarkAlignment.Right,
                Value = _verticalScrollBar1.MaximumScrollRange,
                RenderMode = ScrollBarShapedMarkMode.FillSolid,
                Shape = ScrollBarShapedMarkShape.Oval
            });

            _horizontalScrollBar1.ScrollBarMarks.Add(new ScrollBarShapeMark
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, _horizontalScrollBar1.MaximumScrollRange - 50, "Shape = Oval"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.Brown,
                StartColor = Color.Orange,
                Size = new Size(42, 17),
                Alignment = ScrollBarMarkAlignment.Bottom,
                Value = _horizontalScrollBar1.MaximumScrollRange - 50,
                RenderMode = ScrollBarShapedMarkMode.FillSolid,
                Shape = ScrollBarShapedMarkShape.Oval
            });

            _horizontalScrollBar1.ScrollBarMarks.Add(new ScrollBarShapeMark
            {
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, _horizontalScrollBar1.MaximumScrollRange - 325, "Shape = Rectangle"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                ShouldDrawBorder = true,
                BorderThickness = 1,
                BorderColor = Color.Brown,
                StartColor = Color.Orange,
                EndColor = Color.Yellow,
                LinearGradientAngle = 75f,
                Size = new Size(22, 9),
                Alignment = ScrollBarMarkAlignment.Center,
                Value = _horizontalScrollBar1.MaximumScrollRange - 325,
                RenderMode = ScrollBarShapedMarkMode.FillGradient,
                Shape = ScrollBarShapedMarkShape.Rectangle
            });

            _verticalScrollBar1.ScrollBarMarks.Add(new ScrollBarImageMark()
            {
                ShouldDrawBorder = false,
                BorderColor = Color.Red,
                BorderThickness = 1,
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, 50, "Sizing mode = UserSize"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                Alignment = ScrollBarMarkAlignment.Center, 
                Size = new Size(12, 12),
                Value = 50,
                SizingMode = ImageMarkSizingMode.UserSize,
                Image = Properties.Resources.stop
            });

            _horizontalScrollBar1.ScrollBarMarks.Add(new ScrollBarImageMark()
            {
                ShouldDrawBorder = false,
                BorderColor = Color.Orange,
                BorderThickness = 1,
                ToolTipInfo = string.Format("Value = {1}{0}{2}{0}", Environment.NewLine, 50, "Sizing mode = UserSize"),
                IsToolTipBalloon = false,
                ToolTipTitle = "Scrollbar Marker metadata",
                ToolTipIcon = ToolTipIcon.Info, 
                Alignment = ScrollBarMarkAlignment.Center,
                Size = new Size(50, 50),
                Value = 50,
                SizingMode = ImageMarkSizingMode.UserSize,
                Image = Properties.Resources.stop
            });

            _verticalScrollBar1.Invalidate();
            _horizontalScrollBar1.Invalidate();
        }

        void _verticalScrollBar1_VerticalScrollBarWidthChanged(object sender, EventArgs e)
        {
            RebuildScrollBarMarks();
        }

        void _horizontalScrollBar1_HorizontalScrollBarHeightChanged(object sender, EventArgs e)
        {
            RebuildScrollBarMarks();
        }

        private void SubscribeToScrollbarAndTargetScrolledControlEvents()
        {
            // Lets subscribe to some core events of the custom scrollbar control...

            // Typically, you only need to subscribe to the two important events - "PositionChanged" and "Scroll".

            // On the horizontal scrollbar instance
            _horizontalScrollBar1.PositionChanged += _horizontalScrollBar1_PositionChanged;
            _horizontalScrollBar1.Scroll += horizontalScrollBar1_Scroll;
            
            // On the vertical scollbar instance
            _verticalScrollBar1.PositionChanged += _verticalScrollBar1_PositionChanged;
            _verticalScrollBar1.Scroll += verticalScrollBar1_Scroll;
            
            // Lets also subscribe to the paint event of the target control (picture box control in our case here)... 
            // so we can move (scroll) the picture as we desire, when the scrollbar events are raised.
            pictureBox1.Paint += pictureBox1_Paint;
        }

        private void numericSpinnerScrollerSize_ValueChanged(object sender, EventArgs e)
        {
            _horizontalScrollBar1.HorizontalScrollBarHeight = (int)numericSpinnerScrollerSize.Value;
            _verticalScrollBar1.VerticalScrollBarWidth = (int)numericSpinnerScrollerSize.Value;
        }

        private void cmbbxColorTheme_SelectedIndexChanged(object sender, EventArgs e)
        {
            _horizontalScrollBar1.ScrollBarRenderingConfigurator.ColorTheme = (ColorTheme)Enum.Parse(typeof(ColorTheme),
                cmbbxColorTheme.SelectedItem.ToString());
            _verticalScrollBar1.ScrollBarRenderingConfigurator.ColorTheme = (ColorTheme)Enum.Parse(typeof(ColorTheme),
                cmbbxColorTheme.SelectedItem.ToString());
            _horizontalScrollBar1.Invalidate();
            _verticalScrollBar1.Invalidate();
        }
        
        void _horizontalScrollBar1_PositionChanged(object sender, Binarymission.WinForms.Controls.ScrollBars.Events.PositionChangedArgs e)
        {
            _picture1X = _horizontalScrollBar1.Position;
            pictureBox1.Invalidate();
        }

        void _verticalScrollBar1_PositionChanged(object sender, Binarymission.WinForms.Controls.ScrollBars.Events.PositionChangedArgs e)
        {
            _picture1Y = _verticalScrollBar1.Position;
            pictureBox1.Invalidate();
        }

        void verticalScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            _picture1Y = _verticalScrollBar1.Position;
            pictureBox1.Refresh();
        }

        void horizontalScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            _picture1X = _horizontalScrollBar1.Position;
            pictureBox1.Refresh();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            // NOTE: Obviously this way (as below) of redrawing is not the ideal way to do the redrawing of any .NET control, specifically picture box control.
            // But I have this in place here just to prove the point of how to use custom scrollbar controls with any other control.
            // For better performant way of scrolling and redrawing a picture box, please use P/Invoke and Win32 APIs or consider using our ScrollablePictureViewer control (if you want), which is 
            // pre-written from scratch for offering much better performance when redrawing its view.

            // But for demo purposes, this should do well, since all we are proving here is show how to use the custom scrollbar controls with any other control/user control.
            e.Graphics.DrawImage(pictureBox1.Image, e.ClipRectangle, (int)_picture1X, (int)_picture1Y, e.ClipRectangle.Width,
                e.ClipRectangle.Height, GraphicsUnit.Pixel);
        }

        private void chkEnableMarkers_CheckedChanged(object sender, EventArgs e)
        {
            _verticalScrollBar1.ShouldEnableMarkerDrawing =
                _horizontalScrollBar1.ShouldEnableMarkerDrawing = chkEnableMarkers.Checked;
        }
    }
}
