namespace BinarycomboboxHeaderFooterSample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnIconFilePath = new System.Windows.Forms.Button();
            this.txtIconFileName = new System.Windows.Forms.TextBox();
            this.btnBitmapFilePath = new System.Windows.Forms.Button();
            this.txtBitmapFileName = new System.Windows.Forms.TextBox();
            this.binaryTextComboBoxHeaderImagetype = new Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFooter = new System.Windows.Forms.TextBox();
            this.txtHeader = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.chkDrawFooter = new System.Windows.Forms.CheckBox();
            this.chkEnableHeaderFooter = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.binaryTextComboBoxMulticolumn = new Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox();
            this.salesdataBindingSource = new System.Windows.Forms.BindingSource();
            this.testDataSet = new BinarycomboboxHeaderFooterSample.TestDataSet();
            this.salesdataTableAdapter = new BinarycomboboxHeaderFooterSample.TestDataSetTableAdapters.SalesdataTableAdapter();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.salesdataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(233, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "BinaryCombobox instance in Multi-column mode";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(171, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Header / Footer rendering options";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnIconFilePath);
            this.panel2.Controls.Add(this.txtIconFileName);
            this.panel2.Controls.Add(this.btnBitmapFilePath);
            this.panel2.Controls.Add(this.txtBitmapFileName);
            this.panel2.Controls.Add(this.binaryTextComboBoxHeaderImagetype);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtFooter);
            this.panel2.Controls.Add(this.txtHeader);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.chkDrawFooter);
            this.panel2.Location = new System.Drawing.Point(15, 105);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(356, 193);
            this.panel2.TabIndex = 6;
            // 
            // btnIconFilePath
            // 
            this.btnIconFilePath.Location = new System.Drawing.Point(308, 106);
            this.btnIconFilePath.Name = "btnIconFilePath";
            this.btnIconFilePath.Size = new System.Drawing.Size(27, 23);
            this.btnIconFilePath.TabIndex = 14;
            this.btnIconFilePath.Text = "...";
            this.btnIconFilePath.UseVisualStyleBackColor = true;
            this.btnIconFilePath.Click += new System.EventHandler(this.btnIconFilePath_Click);
            // 
            // txtIconFileName
            // 
            this.txtIconFileName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIconFileName.Location = new System.Drawing.Point(164, 107);
            this.txtIconFileName.Name = "txtIconFileName";
            this.txtIconFileName.Size = new System.Drawing.Size(144, 21);
            this.txtIconFileName.TabIndex = 13;
            // 
            // btnBitmapFilePath
            // 
            this.btnBitmapFilePath.Location = new System.Drawing.Point(308, 83);
            this.btnBitmapFilePath.Name = "btnBitmapFilePath";
            this.btnBitmapFilePath.Size = new System.Drawing.Size(27, 23);
            this.btnBitmapFilePath.TabIndex = 12;
            this.btnBitmapFilePath.Text = "...";
            this.btnBitmapFilePath.UseVisualStyleBackColor = true;
            this.btnBitmapFilePath.Click += new System.EventHandler(this.btnBitmapFilePath_Click);
            // 
            // txtBitmapFileName
            // 
            this.txtBitmapFileName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBitmapFileName.Location = new System.Drawing.Point(164, 84);
            this.txtBitmapFileName.Name = "txtBitmapFileName";
            this.txtBitmapFileName.Size = new System.Drawing.Size(144, 21);
            this.txtBitmapFileName.TabIndex = 11;
            // 
            // binaryTextComboBoxHeaderImagetype
            // 
            this.binaryTextComboBoxHeaderImagetype.AlphaBlendFactorForControlPainting = 100;
            this.binaryTextComboBoxHeaderImagetype.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryTextComboBoxHeaderImagetype.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryTextComboBoxHeaderImagetype.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.binaryTextComboBoxHeaderImagetype.AutoComplete = true;
            this.binaryTextComboBoxHeaderImagetype.AutoCompleteBasedOnCompleteMatchWithAnItemInTheList = false;
            this.binaryTextComboBoxHeaderImagetype.AutoCompleteIsCaseSensitive = true;
            this.binaryTextComboBoxHeaderImagetype.AutoCompleteStyleForMultiColumnModeIsMultiColumn = false;
            this.binaryTextComboBoxHeaderImagetype.BackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxHeaderImagetype.BuiltinFilterOnNonStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxHeaderImagetype.BuiltinFilterOnStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxHeaderImagetype.BusyIndicatorText = "Processing...";
            this.binaryTextComboBoxHeaderImagetype.ColumnDataTypeFormatInfoContainers = null;
            this.binaryTextComboBoxHeaderImagetype.ColumnsToDisplay = null;
            this.binaryTextComboBoxHeaderImagetype.ColumnWidths = null;
            this.binaryTextComboBoxHeaderImagetype.ComboBoxIsReadOnly = false;
            this.binaryTextComboBoxHeaderImagetype.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxHeaderImagetype.CSVFileSaveAs = "MultiColumnDataViewExport.csv";
            this.binaryTextComboBoxHeaderImagetype.CustomColumnNameForAutomaticRowSelection = null;
            this.binaryTextComboBoxHeaderImagetype.CustomComparerImplementor = null;
            this.binaryTextComboBoxHeaderImagetype.CustomControlBorderColor = System.Drawing.Color.Black;
            this.binaryTextComboBoxHeaderImagetype.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxHeaderImagetype.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxHeaderImagetype.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this.binaryTextComboBoxHeaderImagetype.CustomPaintingColor = System.Drawing.Color.Silver;
            this.binaryTextComboBoxHeaderImagetype.DataMember = null;
            this.binaryTextComboBoxHeaderImagetype.DataSourceViewCustomSortingExpression = null;
            this.binaryTextComboBoxHeaderImagetype.DesiredFilterColumn = 0;
            this.binaryTextComboBoxHeaderImagetype.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryTextComboBoxHeaderImagetype.DrawTheControlBasedOnWindowsOS = true;
            this.binaryTextComboBoxHeaderImagetype.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxHeaderImagetype.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxHeaderImagetype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryTextComboBoxHeaderImagetype.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxHeaderImagetype.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxHeaderImagetype.DropDownWindowBorderThickness = 1F;
            this.binaryTextComboBoxHeaderImagetype.DropDownWindowDisplayOrientation = Binarymission.WinForms.Controls.ListControls.DropDownWindowDisplayOrientation.Default;
            this.binaryTextComboBoxHeaderImagetype.DropStyleIsMultiColumn = false;
            this.binaryTextComboBoxHeaderImagetype.EnableAlphaBlendingForFilterAndGroupingPanelBackColor = true;
            this.binaryTextComboBoxHeaderImagetype.Enabled = false;
            this.binaryTextComboBoxHeaderImagetype.EnableDrawingHeaderFooterWhenInMultiColumnMode = false;
            this.binaryTextComboBoxHeaderImagetype.ExtendedDropdownButtonImage = null;
            this.binaryTextComboBoxHeaderImagetype.ExtendedDropdownButtonInternalImage = null;
            this.binaryTextComboBoxHeaderImagetype.FilterAndGroupingPanelBackColor = System.Drawing.Color.Empty;
            this.binaryTextComboBoxHeaderImagetype.FilteringIsON = false;
            this.binaryTextComboBoxHeaderImagetype.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryTextComboBoxHeaderImagetype.GroupItemsWhenInMultiColumnDisplayMode = false;
            this.binaryTextComboBoxHeaderImagetype.GroupMultiColumnDisplayModeDataBasedOnThisColumn = 0;
            this.binaryTextComboBoxHeaderImagetype.HeadersToDisplay = null;
            this.binaryTextComboBoxHeaderImagetype.IsAutoCompleteModeAppendSuggestInMultiColumnMode = false;
            this.binaryTextComboBoxHeaderImagetype.IsCustomisationOfColumnDisplayEnabledInMultiColumnAutoSuggestMode = false;
            this.binaryTextComboBoxHeaderImagetype.IsFilterSearchResultBasedOnColumnDataType = true;
            this.binaryTextComboBoxHeaderImagetype.IsInExtendedReadOnlyMode = false;
            this.binaryTextComboBoxHeaderImagetype.Items.AddRange(new object[] {
            "None",
            "Bitmap",
            "Icon"});
            this.binaryTextComboBoxHeaderImagetype.KeepBindingContextInSyncWithParent = false;
            this.binaryTextComboBoxHeaderImagetype.KeepTheFilterAndGroupingViewsCollapsedAtStartUp = true;
            this.binaryTextComboBoxHeaderImagetype.KeepTheFilterAndGroupingViewsPaneFullyCollapsedAtStartup = false;
            this.binaryTextComboBoxHeaderImagetype.Location = new System.Drawing.Point(164, 55);
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownSize = new System.Drawing.Size(500, 250);
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.ColumnHeaderFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.ColumnHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.DrawFooter = false;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.FooterCaptionFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.FooterSurfaceHeight = 20;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.FooterText = "";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = null;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.HeaderCaptionFont = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor = System.Drawing.Color.Silver;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.HeaderIcon = null;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.HeaderImageType = Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Icon;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.HeaderSurfaceHeight = 20;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.HeaderText = "";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropDownWindowConfigurationData.NoDataToDisplayMessageText = "There are no items to display.";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropListBackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropListFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropListForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropListGridLines = true;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropListHoverSelection = false;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDroplistWindowAnimationStyle = Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnDropListWindowIsResizable = true;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewBusyProcessingText = "Processing the query... please wait...";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewNoDataFoundText = "There is no data to display.";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewSortingGlyphColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableDataGroupingText = "Enable data grouping";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableFilterOptionsText = "Enable filter options";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.ContextMenuItemExportDataToCSV = "Export data to CSV";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.ContextMenuItemShowCommandBarText = "Show command bar";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemBuiltInFilter = "Built-in filter";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemCustomExpression = "Custom expression";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemFilterOnThisColumn = "Filter on this column:";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowItemEnableGrouping = "Enable \"grouping\"";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowItemFilterDataWhileTheUserTypesExpression = "Filter data while the user types expression?";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpression = "Filter expression:";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionType = "Filter expression type:";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionTypeComboBoxTooltip = resources.GetString("resource.WindowItemFilterExpressionTypeComboBoxTooltip");
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowItemFilteringStatusPart = "Filter status: Filtering is currently using";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowItemGroupOnThisColumn = "Group on this column:";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowItemHideFilterAndGroupingOptions = "Hide filter and grouping options";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowItemShowFilterAndGroupingOptions = "Show filter and grouping options";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowItemUseFilterToRetrieveData = "Use filter to retrieve data";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowStatusBarCustomExpressionErrorMessage = "Invalid custom expression. Please correct.";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnViewUIElementsTextProvider.WindowTaskStatusMessageForCSVExportSuccessful = "                Command result: CSV export successful.";
            this.binaryTextComboBoxHeaderImagetype.MultiColumnWindowColumnsHorizontalAlignments = ((System.Collections.Generic.IList<System.Windows.Forms.HorizontalAlignment>)(resources.GetObject("binaryTextComboBoxHeaderImagetype.MultiColumnWindowColumnsHorizontalAlignments")));
            this.binaryTextComboBoxHeaderImagetype.Name = "binaryTextComboBoxHeaderImagetype";
            this.binaryTextComboBoxHeaderImagetype.SelectedIndexFromDropList = -1;
            this.binaryTextComboBoxHeaderImagetype.ShareCustomMultiColumnSizeAcrossDataListAndFilterGroupingOptionsPane = true;
            this.binaryTextComboBoxHeaderImagetype.ShouldAllowUserInputWhileProcessingMultiColumnAutoCompleDropDownView = true;
            this.binaryTextComboBoxHeaderImagetype.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryTextComboBoxHeaderImagetype.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryTextComboBoxHeaderImagetype.ShouldDrawExtendedDropdownButton = false;
            this.binaryTextComboBoxHeaderImagetype.ShouldPersistUserSetColumnWidthsAcrossFilterSessions = false;
            this.binaryTextComboBoxHeaderImagetype.ShowBorderAlways = true;
            this.binaryTextComboBoxHeaderImagetype.ShowDropDownMultiColumnWindowAfterAdjustingForVirtualAvaliableScreenSpace = false;
            this.binaryTextComboBoxHeaderImagetype.ShowEmptyDropListViewWhenThereAreNoData = true;
            this.binaryTextComboBoxHeaderImagetype.ShowFilterOptionsInMultiColumnMode = false;
            this.binaryTextComboBoxHeaderImagetype.Size = new System.Drawing.Size(171, 22);
            this.binaryTextComboBoxHeaderImagetype.SizeForMultiColumnAutoCompleteSuggestionDropDownWindow = new System.Drawing.Size(0, 0);
            this.binaryTextComboBoxHeaderImagetype.SizesForMultiColumnAutoCompleteSuggestionDropDownWindowColumns = null;
            this.binaryTextComboBoxHeaderImagetype.TabIndex = 10;
            this.binaryTextComboBoxHeaderImagetype.TableToLoad = null;
            this.binaryTextComboBoxHeaderImagetype.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxHeaderImagetype.SelectedIndexChanged += new System.EventHandler(this.binaryTextComboBoxHeaderImagetype_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Enabled = false;
            this.label7.Location = new System.Drawing.Point(16, 112);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Icon Filename";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Enabled = false;
            this.label6.Location = new System.Drawing.Point(16, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Bitmap Filename";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Enabled = false;
            this.label3.Location = new System.Drawing.Point(14, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Imagetype for the Header";
            // 
            // txtFooter
            // 
            this.txtFooter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFooter.Enabled = false;
            this.txtFooter.Location = new System.Drawing.Point(164, 160);
            this.txtFooter.Name = "txtFooter";
            this.txtFooter.Size = new System.Drawing.Size(171, 21);
            this.txtFooter.TabIndex = 5;
            this.txtFooter.TextChanged += new System.EventHandler(this.txtFooter_TextChanged);
            // 
            // txtHeader
            // 
            this.txtHeader.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtHeader.Enabled = false;
            this.txtHeader.Location = new System.Drawing.Point(164, 24);
            this.txtHeader.Name = "txtHeader";
            this.txtHeader.Size = new System.Drawing.Size(171, 21);
            this.txtHeader.TabIndex = 4;
            this.txtHeader.TextChanged += new System.EventHandler(this.txtHeader_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Enabled = false;
            this.label5.Location = new System.Drawing.Point(16, 162);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Text for the footer:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Enabled = false;
            this.label4.Location = new System.Drawing.Point(13, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Text for the header";
            // 
            // chkDrawFooter
            // 
            this.chkDrawFooter.AutoSize = true;
            this.chkDrawFooter.Enabled = false;
            this.chkDrawFooter.Location = new System.Drawing.Point(19, 142);
            this.chkDrawFooter.Name = "chkDrawFooter";
            this.chkDrawFooter.Size = new System.Drawing.Size(84, 17);
            this.chkDrawFooter.TabIndex = 1;
            this.chkDrawFooter.Text = "Draw footer";
            this.chkDrawFooter.UseVisualStyleBackColor = true;
            this.chkDrawFooter.CheckedChanged += new System.EventHandler(this.chkDrawFooter_CheckedChanged);
            // 
            // chkEnableHeaderFooter
            // 
            this.chkEnableHeaderFooter.AutoSize = true;
            this.chkEnableHeaderFooter.Location = new System.Drawing.Point(14, 96);
            this.chkEnableHeaderFooter.Name = "chkEnableHeaderFooter";
            this.chkEnableHeaderFooter.Size = new System.Drawing.Size(184, 17);
            this.chkEnableHeaderFooter.TabIndex = 0;
            this.chkEnableHeaderFooter.Text = "Enabled header/footer rendering";
            this.chkEnableHeaderFooter.UseVisualStyleBackColor = true;
            this.chkEnableHeaderFooter.CheckedChanged += new System.EventHandler(this.chkEnableHeaderFooter_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(305, 313);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(66, 29);
            this.button1.TabIndex = 8;
            this.button1.Text = "&Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // binaryTextComboBoxMulticolumn
            // 
            this.binaryTextComboBoxMulticolumn.AlphaBlendFactorForControlPainting = 100;
            this.binaryTextComboBoxMulticolumn.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryTextComboBoxMulticolumn.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryTextComboBoxMulticolumn.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.binaryTextComboBoxMulticolumn.AutoComplete = true;
            this.binaryTextComboBoxMulticolumn.AutoCompleteBasedOnCompleteMatchWithAnItemInTheList = false;
            this.binaryTextComboBoxMulticolumn.AutoCompleteIsCaseSensitive = true;
            this.binaryTextComboBoxMulticolumn.AutoCompleteStyleForMultiColumnModeIsMultiColumn = false;
            this.binaryTextComboBoxMulticolumn.BackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumn.BuiltinFilterOnNonStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxMulticolumn.BuiltinFilterOnStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxMulticolumn.BusyIndicatorText = "Processing...";
            this.binaryTextComboBoxMulticolumn.ColumnDataTypeFormatInfoContainers = null;
            this.binaryTextComboBoxMulticolumn.ColumnsToDisplay = null;
            this.binaryTextComboBoxMulticolumn.ColumnWidths = null;
            this.binaryTextComboBoxMulticolumn.ComboBoxIsReadOnly = false;
            this.binaryTextComboBoxMulticolumn.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.CSVFileSaveAs = "MultiColumnDataViewExport.csv";
            this.binaryTextComboBoxMulticolumn.CustomColumnNameForAutomaticRowSelection = null;
            this.binaryTextComboBoxMulticolumn.CustomComparerImplementor = null;
            this.binaryTextComboBoxMulticolumn.CustomControlBorderColor = System.Drawing.Color.Black;
            this.binaryTextComboBoxMulticolumn.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumn.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumn.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this.binaryTextComboBoxMulticolumn.CustomPaintingColor = System.Drawing.Color.Gray;
            this.binaryTextComboBoxMulticolumn.DataMember = null;
            this.binaryTextComboBoxMulticolumn.DataSource = this.salesdataBindingSource;
            this.binaryTextComboBoxMulticolumn.DataSourceViewCustomSortingExpression = null;
            this.binaryTextComboBoxMulticolumn.DesiredFilterColumn = 0;
            this.binaryTextComboBoxMulticolumn.DisplayMember = "CompanyName";
            this.binaryTextComboBoxMulticolumn.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryTextComboBoxMulticolumn.DrawTheControlBasedOnWindowsOS = true;
            this.binaryTextComboBoxMulticolumn.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumn.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxMulticolumn.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumn.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumn.DropDownWindowBorderThickness = 1F;
            this.binaryTextComboBoxMulticolumn.DropDownWindowDisplayOrientation = Binarymission.WinForms.Controls.ListControls.DropDownWindowDisplayOrientation.Default;
            this.binaryTextComboBoxMulticolumn.DropStyleIsMultiColumn = true;
            this.binaryTextComboBoxMulticolumn.EnableAlphaBlendingForFilterAndGroupingPanelBackColor = true;
            this.binaryTextComboBoxMulticolumn.EnableDrawingHeaderFooterWhenInMultiColumnMode = false;
            this.binaryTextComboBoxMulticolumn.ExtendedDropdownButtonImage = null;
            this.binaryTextComboBoxMulticolumn.ExtendedDropdownButtonInternalImage = null;
            this.binaryTextComboBoxMulticolumn.FilterAndGroupingPanelBackColor = System.Drawing.Color.Empty;
            this.binaryTextComboBoxMulticolumn.FilteringIsON = false;
            this.binaryTextComboBoxMulticolumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryTextComboBoxMulticolumn.GroupItemsWhenInMultiColumnDisplayMode = false;
            this.binaryTextComboBoxMulticolumn.GroupMultiColumnDisplayModeDataBasedOnThisColumn = 0;
            this.binaryTextComboBoxMulticolumn.HeadersToDisplay = null;
            this.binaryTextComboBoxMulticolumn.IsAutoCompleteModeAppendSuggestInMultiColumnMode = false;
            this.binaryTextComboBoxMulticolumn.IsCustomisationOfColumnDisplayEnabledInMultiColumnAutoSuggestMode = false;
            this.binaryTextComboBoxMulticolumn.IsFilterSearchResultBasedOnColumnDataType = true;
            this.binaryTextComboBoxMulticolumn.IsInExtendedReadOnlyMode = false;
            this.binaryTextComboBoxMulticolumn.KeepBindingContextInSyncWithParent = false;
            this.binaryTextComboBoxMulticolumn.KeepTheFilterAndGroupingViewsCollapsedAtStartUp = true;
            this.binaryTextComboBoxMulticolumn.KeepTheFilterAndGroupingViewsPaneFullyCollapsedAtStartup = false;
            this.binaryTextComboBoxMulticolumn.Location = new System.Drawing.Point(18, 34);
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownSize = new System.Drawing.Size(500, 250);
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.ColumnHeaderFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.ColumnHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.DrawFooter = false;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.FooterCaptionFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.FooterSurfaceHeight = 20;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.FooterText = "";
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = null;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderCaptionFont = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor = System.Drawing.Color.Silver;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderIcon = null;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderImageType = Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Icon;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderSurfaceHeight = 20;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderText = "";
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.NoDataToDisplayMessageText = "There are no items to display.";
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListBackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListGridLines = true;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListHoverSelection = false;
            this.binaryTextComboBoxMulticolumn.MultiColumnDroplistWindowAnimationStyle = Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListWindowIsResizable = true;
            this.binaryTextComboBoxMulticolumn.MultiColumnViewBusyProcessingText = "Processing the query... please wait...";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewNoDataFoundText = "There is no data to display.";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewSortingGlyphColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableDataGroupingText = "Enable data grouping";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableFilterOptionsText = "Enable filter options";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemExportDataToCSV = "Export data to CSV";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemShowCommandBarText = "Show command bar";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemBuiltInFilter = "Built-in filter";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemCustomExpression = "Custom expression";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemFilterOnThisColumn = "Filter on this column:";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemEnableGrouping = "Enable \"grouping\"";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterDataWhileTheUserTypesExpression = "Filter data while the user types expression?";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpression = "Filter expression:";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionType = "Filter expression type:";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionTypeComboBoxTooltip = resources.GetString("resource.WindowItemFilterExpressionTypeComboBoxTooltip1");
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilteringStatusPart = "Filter status: Filtering is currently using";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemGroupOnThisColumn = "Group on this column:";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemHideFilterAndGroupingOptions = "Hide filter and grouping options";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemShowFilterAndGroupingOptions = "Show filter and grouping options";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemUseFilterToRetrieveData = "Use filter to retrieve data";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowStatusBarCustomExpressionErrorMessage = "Invalid custom expression. Please correct.";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowTaskStatusMessageForCSVExportSuccessful = "                Command result: CSV export successful.";
            this.binaryTextComboBoxMulticolumn.MultiColumnWindowColumnsHorizontalAlignments = ((System.Collections.Generic.IList<System.Windows.Forms.HorizontalAlignment>)(resources.GetObject("binaryTextComboBoxMulticolumn.MultiColumnWindowColumnsHorizontalAlignments")));
            this.binaryTextComboBoxMulticolumn.Name = "binaryTextComboBoxMulticolumn";
            this.binaryTextComboBoxMulticolumn.SelectedIndexFromDropList = -1;
            this.binaryTextComboBoxMulticolumn.ShareCustomMultiColumnSizeAcrossDataListAndFilterGroupingOptionsPane = true;
            this.binaryTextComboBoxMulticolumn.ShouldAllowUserInputWhileProcessingMultiColumnAutoCompleDropDownView = true;
            this.binaryTextComboBoxMulticolumn.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryTextComboBoxMulticolumn.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryTextComboBoxMulticolumn.ShouldDrawExtendedDropdownButton = false;
            this.binaryTextComboBoxMulticolumn.ShouldPersistUserSetColumnWidthsAcrossFilterSessions = false;
            this.binaryTextComboBoxMulticolumn.ShowBorderAlways = true;
            this.binaryTextComboBoxMulticolumn.ShowDropDownMultiColumnWindowAfterAdjustingForVirtualAvaliableScreenSpace = false;
            this.binaryTextComboBoxMulticolumn.ShowEmptyDropListViewWhenThereAreNoData = true;
            this.binaryTextComboBoxMulticolumn.ShowFilterOptionsInMultiColumnMode = false;
            this.binaryTextComboBoxMulticolumn.Size = new System.Drawing.Size(222, 22);
            this.binaryTextComboBoxMulticolumn.SizeForMultiColumnAutoCompleteSuggestionDropDownWindow = new System.Drawing.Size(0, 0);
            this.binaryTextComboBoxMulticolumn.SizesForMultiColumnAutoCompleteSuggestionDropDownWindowColumns = null;
            this.binaryTextComboBoxMulticolumn.TabIndex = 9;
            this.binaryTextComboBoxMulticolumn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxMulticolumn.ValueMember = "ID";
            // 
            // salesdataBindingSource
            // 
            this.salesdataBindingSource.DataMember = "Salesdata";
            this.salesdataBindingSource.DataSource = this.testDataSet;
            // 
            // testDataSet
            // 
            this.testDataSet.DataSetName = "TestDataSet";
            this.testDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // salesdataTableAdapter
            // 
            this.salesdataTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(398, 390);
            this.Controls.Add(this.chkEnableHeaderFooter);
            this.Controls.Add(this.binaryTextComboBoxMulticolumn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.salesdataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtFooter;
        private System.Windows.Forms.TextBox txtHeader;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkDrawFooter;
        private System.Windows.Forms.CheckBox chkEnableHeaderFooter;
        private System.Windows.Forms.Button button1;
        private Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox binaryTextComboBoxMulticolumn;
        private TestDataSet testDataSet;
        private System.Windows.Forms.BindingSource salesdataBindingSource;
        private BinarycomboboxHeaderFooterSample.TestDataSetTableAdapters.SalesdataTableAdapter salesdataTableAdapter;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox binaryTextComboBoxHeaderImagetype;
        private System.Windows.Forms.Button btnBitmapFilePath;
        private System.Windows.Forms.TextBox txtBitmapFileName;
        private System.Windows.Forms.Button btnIconFilePath;
        private System.Windows.Forms.TextBox txtIconFileName;
    }
}

