using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinarycomboboxHeaderFooterSample
{
    public partial class Form1 : ModernChromeWindow
    {
        public Form1()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"Header / Footer Demo";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'testDataSet.Salesdata' table. You can move, or remove it, as needed.
            this.salesdataTableAdapter.Fill(this.testDataSet.Salesdata);
            binaryTextComboBoxHeaderImagetype.SelectedIndex = 0;
        }

        private void chkEnableHeaderFooter_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.EnableDrawingHeaderFooterWhenInMultiColumnMode = chkEnableHeaderFooter.Checked;

            label4.Enabled = chkEnableHeaderFooter.Checked; 
            txtHeader.Enabled = chkEnableHeaderFooter.Checked; 
            label3.Enabled = chkEnableHeaderFooter.Checked; 
            binaryTextComboBoxHeaderImagetype.Enabled = chkEnableHeaderFooter.Checked;
            chkDrawFooter.Enabled = chkEnableHeaderFooter.Checked; 

            if (binaryTextComboBoxHeaderImagetype.SelectedIndex != 0)
            {
                switch(binaryTextComboBoxHeaderImagetype.SelectedIndex)
                {
                    case 1 :
                        txtBitmapFileName.Enabled = chkEnableHeaderFooter.Checked;
                        btnBitmapFilePath.Enabled = chkEnableHeaderFooter.Checked;
                        break;

                    case 2:
                        txtIconFileName.Enabled = chkEnableHeaderFooter.Checked;
                        btnIconFilePath.Enabled = chkEnableHeaderFooter.Checked;
                        break;

                    default:
                        break;
                }                
            }

            if (chkDrawFooter.Checked)
            {
                txtFooter.Enabled = chkEnableHeaderFooter.Checked;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtHeader_TextChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderText =
                txtHeader.Text;
        }

        private void chkDrawFooter_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.DrawFooter =
                chkDrawFooter.Checked;
            txtFooter.Enabled = chkDrawFooter.Checked;
        }

        private void txtFooter_TextChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.FooterText =
                txtFooter.Text;
        }

        private void btnBitmapFilePath_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "BMP Files (*.bmp)|*.bmp";
            
            if (DialogResult.Cancel != openFileDialog.ShowDialog())
            {
                Bitmap bmp = new Bitmap(openFileDialog.FileName);

                binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = bmp;

                txtBitmapFileName.Text = openFileDialog.FileName;
            }
        }

        private void binaryTextComboBoxHeaderImagetype_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(binaryTextComboBoxHeaderImagetype.SelectedIndex)
            {
                case 0: binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderImageType = 
                        Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.None;
                    txtBitmapFileName.Enabled = false;
                    txtIconFileName.Enabled = false;
                    label6.Enabled = false;
                    label7.Enabled = false;
                    break;
                case 1: binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderImageType = 
                        Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Bitmap;
                        txtBitmapFileName.Enabled = true;
                        label6.Enabled = true;
                        label7.Enabled = false;
                        txtIconFileName.Enabled = false;
                    break;
                case 2: binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderImageType = 
                        Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Icon;
                        txtBitmapFileName.Enabled = false;
                        txtIconFileName.Enabled = true;
                        label6.Enabled = false;
                        label7.Enabled = true;
                    break;
                default:
                    break;
            }            
        }

        private void btnIconFilePath_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "ICO Files (*.ico)|*.ico";

            if (DialogResult.Cancel != openFileDialog.ShowDialog())
            {
                Icon fileicon = new Icon(openFileDialog.FileName);
                binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderIcon = fileicon;
                txtIconFileName.Text = openFileDialog.FileName;
            }
        }

    }
}