namespace BinaryComboboxUICustomisation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.binaryTextComboBox1 = new Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox();
            this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customersTestDataSet = new BinaryComboboxUICustomisation.CustomersTestDataSet();
            this.customersTableAdapter = new BinaryComboboxUICustomisation.CustomersTestDataSetTableAdapters.CustomersTableAdapter();
            this.label8 = new System.Windows.Forms.Label();
            this.chkMulticolumnMode = new System.Windows.Forms.CheckBox();
            this.chkFlatStyle = new System.Windows.Forms.CheckBox();
            this.chkWindowResize = new System.Windows.Forms.CheckBox();
            this.chkColumnSizing = new System.Windows.Forms.CheckBox();
            this.chkDragDropColumns = new System.Windows.Forms.CheckBox();
            this.chkShowBorder = new System.Windows.Forms.CheckBox();
            this.chkShowGridLines = new System.Windows.Forms.CheckBox();
            this.chkMouseHovering = new System.Windows.Forms.CheckBox();
            this.cmbAnimationStyle = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbStyle = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.numericUpDownAnimationInterval = new System.Windows.Forms.NumericUpDown();
            this.chkPerformAnimation = new System.Windows.Forms.CheckBox();
            this.cmbMouseClickLevel = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersTestDataSet)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAnimationInterval)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "BinaryCombobox";
            // 
            // binaryTextComboBox1
            // 
            this.binaryTextComboBox1.AlphaBlendFactorForControlPainting = 100;
            this.binaryTextComboBox1.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryTextComboBox1.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryTextComboBox1.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.binaryTextComboBox1.AnimateDropDownWindow = true;
            this.binaryTextComboBox1.AnimationInterval = 50;
            this.binaryTextComboBox1.AutoComplete = true;
            this.binaryTextComboBox1.AutoCompleteBasedOnCompleteMatchWithAnItemInTheList = false;
            this.binaryTextComboBox1.AutoCompleteIsCaseSensitive = true;
            this.binaryTextComboBox1.AutoCompleteStyleForMultiColumnModeIsMultiColumn = false;
            this.binaryTextComboBox1.BackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBox1.BuiltinFilterOnNonStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBox1.BuiltinFilterOnStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBox1.BusyIndicatorText = "Processing...";
            this.binaryTextComboBox1.ColumnDataTypeFormatInfoContainers = null;
            this.binaryTextComboBox1.ColumnsToDisplay = null;
            this.binaryTextComboBox1.ColumnWidths = null;
            this.binaryTextComboBox1.ComboBoxIsReadOnly = false;
            this.binaryTextComboBox1.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBox1.CSVFileSaveAs = "MultiColumnDataViewExport.csv";
            this.binaryTextComboBox1.CustomColumnNameForAutomaticRowSelection = null;
            this.binaryTextComboBox1.CustomComparerImplementor = null;
            this.binaryTextComboBox1.CustomControlBorderColor = System.Drawing.Color.Black;
            this.binaryTextComboBox1.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBox1.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBox1.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this.binaryTextComboBox1.CustomPaintingColor = System.Drawing.Color.Silver;
            this.binaryTextComboBox1.DataMember = null;
            this.binaryTextComboBox1.DataSource = this.customersBindingSource;
            this.binaryTextComboBox1.DataSourceViewCustomSortingExpression = null;
            this.binaryTextComboBox1.DesiredFilterColumn = 0;
            this.binaryTextComboBox1.DisplayMember = "CompanyName";
            this.binaryTextComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryTextComboBox1.DrawTheControlBasedOnWindowsOS = false;
            this.binaryTextComboBox1.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBox1.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBox1.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBox1.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBox1.DropDownWindowBorderThickness = 1F;
            this.binaryTextComboBox1.DropDownWindowDisplayOrientation = Binarymission.WinForms.Controls.ListControls.DropDownWindowDisplayOrientation.Default;
            this.binaryTextComboBox1.DropStyleIsMultiColumn = true;
            this.binaryTextComboBox1.EnableAlphaBlendingForFilterAndGroupingPanelBackColor = true;
            this.binaryTextComboBox1.EnableDrawingHeaderFooterWhenInMultiColumnMode = false;
            this.binaryTextComboBox1.ExtendedDropdownButtonImage = null;
            this.binaryTextComboBox1.ExtendedDropdownButtonInternalImage = null;
            this.binaryTextComboBox1.FilterAndGroupingPanelBackColor = System.Drawing.Color.Empty;
            this.binaryTextComboBox1.FilteringIsON = false;
            this.binaryTextComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryTextComboBox1.GroupItemsWhenInMultiColumnDisplayMode = false;
            this.binaryTextComboBox1.GroupMultiColumnDisplayModeDataBasedOnThisColumn = 0;
            this.binaryTextComboBox1.HeadersToDisplay = null;
            this.binaryTextComboBox1.IsAutoCompleteModeAppendSuggestInMultiColumnMode = false;
            this.binaryTextComboBox1.IsCustomisationOfColumnDisplayEnabledInMultiColumnAutoSuggestMode = false;
            this.binaryTextComboBox1.IsFilterSearchResultBasedOnColumnDataType = true;
            this.binaryTextComboBox1.IsInExtendedReadOnlyMode = false;
            this.binaryTextComboBox1.KeepBindingContextInSyncWithParent = false;
            this.binaryTextComboBox1.KeepTheFilterAndGroupingViewsCollapsedAtStartUp = true;
            this.binaryTextComboBox1.KeepTheFilterAndGroupingViewsPaneFullyCollapsedAtStartup = false;
            this.binaryTextComboBox1.Location = new System.Drawing.Point(17, 46);
            this.binaryTextComboBox1.MultiColumnDropDownSize = new System.Drawing.Size(500, 250);
            this.binaryTextComboBox1.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.ColumnHeaderFont = new System.Drawing.Font("Arial", 12F);
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.ColumnHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.DrawFooter = true;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.FooterCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.FooterSurfaceHeight = 20;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.FooterText = "";
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = null;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor = System.Drawing.Color.Silver;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderIcon = null;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderImageType = Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Icon;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderSurfaceHeight = 20;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderText = "";
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.NoDataToDisplayMessageText = "There are no items to display.";
            this.binaryTextComboBox1.MultiColumnDropListBackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBox1.MultiColumnDropListFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBox1.MultiColumnDropListForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBox1.MultiColumnDropListGridLines = true;
            this.binaryTextComboBox1.MultiColumnDropListHoverSelection = false;
            this.binaryTextComboBox1.MultiColumnDroplistWindowAnimationStyle = Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
            this.binaryTextComboBox1.MultiColumnDropListWindowIsResizable = true;
            this.binaryTextComboBox1.MultiColumnViewBusyProcessingText = "Processing the query... please wait...";
            this.binaryTextComboBox1.MultiColumnViewNoDataFoundText = "There is no data to display.";
            this.binaryTextComboBox1.MultiColumnViewSortingGlyphColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableDataGroupingText = "Enable data grouping";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableFilterOptionsText = "Enable filter options";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.ContextMenuItemExportDataToCSV = "Export data to CSV";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.ContextMenuItemShowCommandBarText = "Show command bar";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemBuiltInFilter = "Built-in filter";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemCustomExpression = "Custom expression";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemFilterOnThisColumn = "Filter on this column:";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemEnableGrouping = "Enable \"grouping\"";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemFilterDataWhileTheUserTypesExpression = "Filter data while the user types expression?";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpression = "Filter expression:";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionType = "Filter expression type:";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionTypeComboBoxTooltip = resources.GetString("resource.WindowItemFilterExpressionTypeComboBoxTooltip");
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemFilteringStatusPart = "Filter status: Filtering is currently using";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemGroupOnThisColumn = "Group on this column:";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemHideFilterAndGroupingOptions = "Hide filter and grouping options";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemShowFilterAndGroupingOptions = "Show filter and grouping options";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemUseFilterToRetrieveData = "Use filter to retrieve data";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowStatusBarCustomExpressionErrorMessage = "Invalid custom expression. Please correct.";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowTaskStatusMessageForCSVExportSuccessful = "                Command result: CSV export successful.";
            this.binaryTextComboBox1.MultiColumnWindowColumnsHorizontalAlignments = ((System.Collections.Generic.IList<System.Windows.Forms.HorizontalAlignment>)(resources.GetObject("binaryTextComboBox1.MultiColumnWindowColumnsHorizontalAlignments")));
            this.binaryTextComboBox1.Name = "binaryTextComboBox1";
            this.binaryTextComboBox1.SelectedIndexFromDropList = -1;
            this.binaryTextComboBox1.ShareCustomMultiColumnSizeAcrossDataListAndFilterGroupingOptionsPane = true;
            this.binaryTextComboBox1.ShouldAllowUserInputWhileProcessingMultiColumnAutoCompleDropDownView = true;
            this.binaryTextComboBox1.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryTextComboBox1.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryTextComboBox1.ShouldDrawExtendedDropdownButton = false;
            this.binaryTextComboBox1.ShouldPersistUserSetColumnWidthsAcrossFilterSessions = false;
            this.binaryTextComboBox1.ShowBorderAlways = true;
            this.binaryTextComboBox1.ShowDropDownMultiColumnWindowAfterAdjustingForVirtualAvaliableScreenSpace = false;
            this.binaryTextComboBox1.ShowEmptyDropListViewWhenThereAreNoData = true;
            this.binaryTextComboBox1.ShowFilterOptionsInMultiColumnMode = false;
            this.binaryTextComboBox1.Size = new System.Drawing.Size(220, 21);
            this.binaryTextComboBox1.SizeForMultiColumnAutoCompleteSuggestionDropDownWindow = new System.Drawing.Size(0, 0);
            this.binaryTextComboBox1.SizesForMultiColumnAutoCompleteSuggestionDropDownWindowColumns = null;
            this.binaryTextComboBox1.TabIndex = 4;
            this.binaryTextComboBox1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBox1.ValueMember = "CustomerID";
            // 
            // customersBindingSource
            // 
            this.customersBindingSource.DataMember = "Customers";
            this.customersBindingSource.DataSource = this.customersTestDataSet;
            // 
            // customersTestDataSet
            // 
            this.customersTestDataSet.DataSetName = "CustomersTestDataSet";
            this.customersTestDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Enabled = false;
            this.label8.Location = new System.Drawing.Point(5, 166);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Animation style";
            // 
            // chkMulticolumnMode
            // 
            this.chkMulticolumnMode.AutoSize = true;
            this.chkMulticolumnMode.Checked = true;
            this.chkMulticolumnMode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMulticolumnMode.Location = new System.Drawing.Point(7, 15);
            this.chkMulticolumnMode.Name = "chkMulticolumnMode";
            this.chkMulticolumnMode.Size = new System.Drawing.Size(266, 17);
            this.chkMulticolumnMode.TabIndex = 15;
            this.chkMulticolumnMode.Text = "Display the dropdown window in Multicolumn mode";
            this.chkMulticolumnMode.UseVisualStyleBackColor = true;
            this.chkMulticolumnMode.CheckedChanged += new System.EventHandler(this.chkMulticolumnMode_CheckedChanged);
            // 
            // chkFlatStyle
            // 
            this.chkFlatStyle.AutoSize = true;
            this.chkFlatStyle.Checked = true;
            this.chkFlatStyle.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkFlatStyle.Location = new System.Drawing.Point(7, 39);
            this.chkFlatStyle.Name = "chkFlatStyle";
            this.chkFlatStyle.Size = new System.Drawing.Size(150, 17);
            this.chkFlatStyle.TabIndex = 16;
            this.chkFlatStyle.Text = "Display control in Flat style";
            this.chkFlatStyle.UseVisualStyleBackColor = true;
            this.chkFlatStyle.CheckedChanged += new System.EventHandler(this.chkFlatStyle_CheckedChanged);
            // 
            // chkWindowResize
            // 
            this.chkWindowResize.AutoSize = true;
            this.chkWindowResize.Checked = true;
            this.chkWindowResize.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkWindowResize.Location = new System.Drawing.Point(8, 18);
            this.chkWindowResize.Name = "chkWindowResize";
            this.chkWindowResize.Size = new System.Drawing.Size(257, 17);
            this.chkWindowResize.TabIndex = 17;
            this.chkWindowResize.Text = "Allow user sizing of Multicolum dropdown window";
            this.chkWindowResize.UseVisualStyleBackColor = true;
            this.chkWindowResize.CheckedChanged += new System.EventHandler(this.chkWindowResize_CheckedChanged);
            // 
            // chkColumnSizing
            // 
            this.chkColumnSizing.AutoSize = true;
            this.chkColumnSizing.Checked = true;
            this.chkColumnSizing.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkColumnSizing.Location = new System.Drawing.Point(207, 41);
            this.chkColumnSizing.Name = "chkColumnSizing";
            this.chkColumnSizing.Size = new System.Drawing.Size(157, 17);
            this.chkColumnSizing.TabIndex = 18;
            this.chkColumnSizing.Text = "Allow user sizing of columns";
            this.chkColumnSizing.UseVisualStyleBackColor = true;
            this.chkColumnSizing.CheckedChanged += new System.EventHandler(this.chkColumnSizing_CheckedChanged);
            // 
            // chkDragDropColumns
            // 
            this.chkDragDropColumns.AutoSize = true;
            this.chkDragDropColumns.Location = new System.Drawing.Point(8, 41);
            this.chkDragDropColumns.Name = "chkDragDropColumns";
            this.chkDragDropColumns.Size = new System.Drawing.Size(181, 17);
            this.chkDragDropColumns.TabIndex = 19;
            this.chkDragDropColumns.Text = "Allow users to drag-drop columns";
            this.chkDragDropColumns.UseVisualStyleBackColor = true;
            this.chkDragDropColumns.CheckedChanged += new System.EventHandler(this.chkDragDropColumns_CheckedChanged);
            // 
            // chkShowBorder
            // 
            this.chkShowBorder.AutoSize = true;
            this.chkShowBorder.Checked = true;
            this.chkShowBorder.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowBorder.Location = new System.Drawing.Point(7, 62);
            this.chkShowBorder.Name = "chkShowBorder";
            this.chkShowBorder.Size = new System.Drawing.Size(121, 17);
            this.chkShowBorder.TabIndex = 20;
            this.chkShowBorder.Text = "Show border always";
            this.chkShowBorder.UseVisualStyleBackColor = true;
            this.chkShowBorder.CheckedChanged += new System.EventHandler(this.chkShowBorder_CheckedChanged);
            // 
            // chkShowGridLines
            // 
            this.chkShowGridLines.AutoSize = true;
            this.chkShowGridLines.Checked = true;
            this.chkShowGridLines.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowGridLines.Location = new System.Drawing.Point(207, 64);
            this.chkShowGridLines.Name = "chkShowGridLines";
            this.chkShowGridLines.Size = new System.Drawing.Size(97, 17);
            this.chkShowGridLines.TabIndex = 21;
            this.chkShowGridLines.Text = "Show grid lines";
            this.chkShowGridLines.UseVisualStyleBackColor = true;
            this.chkShowGridLines.CheckedChanged += new System.EventHandler(this.chkShowGridLines_CheckedChanged);
            // 
            // chkMouseHovering
            // 
            this.chkMouseHovering.AutoSize = true;
            this.chkMouseHovering.Location = new System.Drawing.Point(8, 64);
            this.chkMouseHovering.Name = "chkMouseHovering";
            this.chkMouseHovering.Size = new System.Drawing.Size(144, 17);
            this.chkMouseHovering.TabIndex = 22;
            this.chkMouseHovering.Text = "Mouse hovering on items";
            this.chkMouseHovering.UseVisualStyleBackColor = true;
            this.chkMouseHovering.CheckedChanged += new System.EventHandler(this.chkMouseHovering_CheckedChanged);
            // 
            // cmbAnimationStyle
            // 
            this.cmbAnimationStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAnimationStyle.Enabled = false;
            this.cmbAnimationStyle.FormattingEnabled = true;
            this.cmbAnimationStyle.Items.AddRange(new object[] {
            "Vanish",
            "ReSize",
            "None"});
            this.cmbAnimationStyle.Location = new System.Drawing.Point(247, 163);
            this.cmbAnimationStyle.Name = "cmbAnimationStyle";
            this.cmbAnimationStyle.Size = new System.Drawing.Size(157, 21);
            this.cmbAnimationStyle.TabIndex = 23;
            this.cmbAnimationStyle.SelectedIndexChanged += new System.EventHandler(this.cmbAnimationStyle_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 13);
            this.label2.TabIndex = 24;
            this.label2.Text = "BinaryCombobox style";
            // 
            // cmbStyle
            // 
            this.cmbStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStyle.FormattingEnabled = true;
            this.cmbStyle.Items.AddRange(new object[] {
            "DropDown",
            "DropDownList"});
            this.cmbStyle.Location = new System.Drawing.Point(247, 81);
            this.cmbStyle.Name = "cmbStyle";
            this.cmbStyle.Size = new System.Drawing.Size(157, 21);
            this.cmbStyle.TabIndex = 25;
            this.cmbStyle.SelectedIndexChanged += new System.EventHandler(this.cmbStyle_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.chkShowBorder);
            this.panel1.Controls.Add(this.chkFlatStyle);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cmbStyle);
            this.panel1.Controls.Add(this.chkMulticolumnMode);
            this.panel1.Location = new System.Drawing.Point(17, 129);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(422, 118);
            this.panel1.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(177, 13);
            this.label3.TabIndex = 27;
            this.label3.Text = "Customisation options for the control";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 292);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(290, 13);
            this.label4.TabIndex = 28;
            this.label4.Text = "Customisation options for the Multicolumn dropdown window";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.numericUpDownAnimationInterval);
            this.panel2.Controls.Add(this.chkPerformAnimation);
            this.panel2.Controls.Add(this.cmbMouseClickLevel);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.chkDragDropColumns);
            this.panel2.Controls.Add(this.chkColumnSizing);
            this.panel2.Controls.Add(this.cmbAnimationStyle);
            this.panel2.Controls.Add(this.chkMouseHovering);
            this.panel2.Controls.Add(this.chkShowGridLines);
            this.panel2.Controls.Add(this.chkWindowResize);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(17, 311);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(422, 227);
            this.panel2.TabIndex = 29;
            // 
            // numericUpDownAnimationInterval
            // 
            this.numericUpDownAnimationInterval.Enabled = false;
            this.numericUpDownAnimationInterval.Location = new System.Drawing.Point(247, 194);
            this.numericUpDownAnimationInterval.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownAnimationInterval.Name = "numericUpDownAnimationInterval";
            this.numericUpDownAnimationInterval.Size = new System.Drawing.Size(157, 20);
            this.numericUpDownAnimationInterval.TabIndex = 30;
            this.numericUpDownAnimationInterval.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // chkPerformAnimation
            // 
            this.chkPerformAnimation.AutoSize = true;
            this.chkPerformAnimation.Location = new System.Drawing.Point(7, 133);
            this.chkPerformAnimation.Name = "chkPerformAnimation";
            this.chkPerformAnimation.Size = new System.Drawing.Size(262, 17);
            this.chkPerformAnimation.TabIndex = 29;
            this.chkPerformAnimation.Text = "Perform animation while closing dropdown window";
            this.chkPerformAnimation.UseVisualStyleBackColor = true;
            this.chkPerformAnimation.CheckedChanged += new System.EventHandler(this.chkPerformAnimation_CheckedChanged);
            // 
            // cmbMouseClickLevel
            // 
            this.cmbMouseClickLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMouseClickLevel.FormattingEnabled = true;
            this.cmbMouseClickLevel.Items.AddRange(new object[] {
            "SingleClick",
            "DoubleClick"});
            this.cmbMouseClickLevel.Location = new System.Drawing.Point(247, 93);
            this.cmbMouseClickLevel.Name = "cmbMouseClickLevel";
            this.cmbMouseClickLevel.Size = new System.Drawing.Size(157, 21);
            this.cmbMouseClickLevel.TabIndex = 28;
            this.cmbMouseClickLevel.SelectedIndexChanged += new System.EventHandler(this.cmbMouseClickLevel_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 13);
            this.label6.TabIndex = 27;
            this.label6.Text = " Item selection mouseclick level";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Enabled = false;
            this.label5.Location = new System.Drawing.Point(5, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 13);
            this.label5.TabIndex = 26;
            this.label5.Text = "Animation Interval";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(385, 550);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(54, 23);
            this.button1.TabIndex = 30;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(466, 621);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.binaryTextComboBox1);
            this.Controls.Add(this.label1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersTestDataSet)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAnimationInterval)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox binaryTextComboBox1;
        private CustomersTestDataSet customersTestDataSet;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private BinaryComboboxUICustomisation.CustomersTestDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox chkMulticolumnMode;
        private System.Windows.Forms.CheckBox chkFlatStyle;
        private System.Windows.Forms.CheckBox chkWindowResize;
        private System.Windows.Forms.CheckBox chkColumnSizing;
        private System.Windows.Forms.CheckBox chkDragDropColumns;
        private System.Windows.Forms.CheckBox chkShowBorder;
        private System.Windows.Forms.CheckBox chkShowGridLines;
        private System.Windows.Forms.CheckBox chkMouseHovering;
        private System.Windows.Forms.ComboBox cmbAnimationStyle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbStyle;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbMouseClickLevel;
        private System.Windows.Forms.CheckBox chkPerformAnimation;
        private System.Windows.Forms.NumericUpDown numericUpDownAnimationInterval;
    }
}

