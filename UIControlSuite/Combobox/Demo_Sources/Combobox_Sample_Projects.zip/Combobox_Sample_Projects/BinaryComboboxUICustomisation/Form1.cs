using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryComboboxUICustomisation
{
    public partial class Form1 : ModernChromeWindow
    {
        public Form1()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"UI Customisation Demo";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'customersTestDataSet.Customers' table. You can move, or remove it, as needed.
            this.customersTableAdapter.Fill(this.customersTestDataSet.Customers);

            RetrievePresets();

        }

        private void chkMulticolumnMode_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBox1.DropStyleIsMultiColumn =
                chkMulticolumnMode.Checked;
        }

        private void chkFlatStyle_CheckedChanged(object sender, EventArgs e)
        {
            //In order to have the control display in the standard windows style, 
            //the property "DrawTheControlBasedOnWindowsOS" should be set to False.            

            binaryTextComboBox1.DisplayStyleIsFlat =
                chkFlatStyle.Checked;
        }

        private void chkWindowResize_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBox1.MultiColumnDropListWindowIsResizable =
                chkWindowResize.Checked;
        }

        private void chkColumnSizing_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBox1.EnableUserColumnResizing =
                chkColumnSizing.Checked;
        }

        private void chkDragDropColumns_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBox1.ShouldAllowDragDropOfColumns =
                chkDragDropColumns.Checked;
        }

        private void chkShowBorder_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBox1.ShowBorderAlways =
                chkShowBorder.Checked;
        }

        private void chkShowGridLines_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBox1.MultiColumnDropListGridLines =
                chkShowGridLines.Checked;
        }

        private void chkMouseHovering_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBox1.MultiColumnDropListHoverSelection =
                chkMouseHovering.Checked;
        }

        private void cmbAnimationStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbAnimationStyle.SelectedIndex)
            {
                case 0:
                    binaryTextComboBox1.MultiColumnDroplistWindowAnimationStyle =
                        Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.Vanish;
                    break;

                case 1:
                    binaryTextComboBox1.MultiColumnDroplistWindowAnimationStyle =
                        Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.ReSize;
                    break;

                case 2:
                    binaryTextComboBox1.MultiColumnDroplistWindowAnimationStyle =
                        Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
                    break;

                default:
                    break;
            }
        }


        private void cmbStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbStyle.SelectedIndex)
            {
                case 0:
                    binaryTextComboBox1.DropDownStyle = ComboBoxStyle.DropDown;
                    break;

                case 1:
                    binaryTextComboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
                    break;

                default:
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmbMouseClickLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbMouseClickLevel.SelectedIndex)
            {
                case 0:
                    binaryTextComboBox1.ItemSelectionClick = 
                        Binarymission.WinForms.Controls.ListControls.ItemSelectionClick.SingleClick;
                    break;

                case 1:
                    binaryTextComboBox1.ItemSelectionClick = 
                        Binarymission.WinForms.Controls.ListControls.ItemSelectionClick.DoubleClick;
                    break;

                default:
                    break;
            }

        }

        private void chkPerformAnimation_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBox1.AnimateDropDownWindow = chkPerformAnimation.Checked;
            label5.Enabled = chkPerformAnimation.Checked;
            label8.Enabled = chkPerformAnimation.Checked;
            cmbAnimationStyle.Enabled = chkPerformAnimation.Checked;
            numericUpDownAnimationInterval.Enabled = chkPerformAnimation.Checked;
        }

        private void RetrievePresets()
        {
            cmbAnimationStyle.SelectedIndex = 2;
            cmbStyle.SelectedIndex = 0;
            cmbMouseClickLevel.SelectedIndex = 1;
        }


    }
}