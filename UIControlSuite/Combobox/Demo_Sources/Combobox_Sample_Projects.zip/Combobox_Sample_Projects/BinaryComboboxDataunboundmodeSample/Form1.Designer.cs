namespace BinaryComboboxDataunboundmodeSample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.binaryTextComboBoxSingleColumnUnbound = new Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // binaryTextComboBoxSingleColumnUnbound
            // 
            this.binaryTextComboBoxSingleColumnUnbound.AlphaBlendFactorForControlPainting = 100;
            this.binaryTextComboBoxSingleColumnUnbound.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryTextComboBoxSingleColumnUnbound.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryTextComboBoxSingleColumnUnbound.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.binaryTextComboBoxSingleColumnUnbound.AutoComplete = true;
            this.binaryTextComboBoxSingleColumnUnbound.AutoCompleteBasedOnCompleteMatchWithAnItemInTheList = false;
            this.binaryTextComboBoxSingleColumnUnbound.AutoCompleteIsCaseSensitive = true;
            this.binaryTextComboBoxSingleColumnUnbound.AutoCompleteStyleForMultiColumnModeIsMultiColumn = false;
            this.binaryTextComboBoxSingleColumnUnbound.BackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSingleColumnUnbound.BuiltinFilterOnNonStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxSingleColumnUnbound.BuiltinFilterOnStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxSingleColumnUnbound.BusyIndicatorText = "Processing...";
            this.binaryTextComboBoxSingleColumnUnbound.ColumnDataTypeFormatInfoContainers = null;
            this.binaryTextComboBoxSingleColumnUnbound.ColumnsToDisplay = null;
            this.binaryTextComboBoxSingleColumnUnbound.ColumnWidths = null;
            this.binaryTextComboBoxSingleColumnUnbound.ComboBoxIsReadOnly = false;
            this.binaryTextComboBoxSingleColumnUnbound.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumnUnbound.CSVFileSaveAs = "MultiColumnDataViewExport.csv";
            this.binaryTextComboBoxSingleColumnUnbound.CustomColumnNameForAutomaticRowSelection = null;
            this.binaryTextComboBoxSingleColumnUnbound.CustomComparerImplementor = null;
            this.binaryTextComboBoxSingleColumnUnbound.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryTextComboBoxSingleColumnUnbound.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSingleColumnUnbound.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSingleColumnUnbound.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this.binaryTextComboBoxSingleColumnUnbound.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryTextComboBoxSingleColumnUnbound.DataMember = null;
            this.binaryTextComboBoxSingleColumnUnbound.DataSourceViewCustomSortingExpression = null;
            this.binaryTextComboBoxSingleColumnUnbound.DesiredFilterColumn = 0;
            this.binaryTextComboBoxSingleColumnUnbound.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryTextComboBoxSingleColumnUnbound.DrawTheControlBasedOnWindowsOS = true;
            this.binaryTextComboBoxSingleColumnUnbound.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSingleColumnUnbound.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxSingleColumnUnbound.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSingleColumnUnbound.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSingleColumnUnbound.DropDownWindowBorderThickness = 1F;
            this.binaryTextComboBoxSingleColumnUnbound.DropDownWindowDisplayOrientation = Binarymission.WinForms.Controls.ListControls.DropDownWindowDisplayOrientation.Default;
            this.binaryTextComboBoxSingleColumnUnbound.DropStyleIsMultiColumn = false;
            this.binaryTextComboBoxSingleColumnUnbound.EnableAlphaBlendingForFilterAndGroupingPanelBackColor = true;
            this.binaryTextComboBoxSingleColumnUnbound.EnableDrawingHeaderFooterWhenInMultiColumnMode = true;
            this.binaryTextComboBoxSingleColumnUnbound.ExtendedDropdownButtonImage = null;
            this.binaryTextComboBoxSingleColumnUnbound.ExtendedDropdownButtonInternalImage = null;
            this.binaryTextComboBoxSingleColumnUnbound.FilterAndGroupingPanelBackColor = System.Drawing.Color.Empty;
            this.binaryTextComboBoxSingleColumnUnbound.FilteringIsON = false;
            this.binaryTextComboBoxSingleColumnUnbound.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryTextComboBoxSingleColumnUnbound.GroupItemsWhenInMultiColumnDisplayMode = false;
            this.binaryTextComboBoxSingleColumnUnbound.GroupMultiColumnDisplayModeDataBasedOnThisColumn = 0;
            this.binaryTextComboBoxSingleColumnUnbound.HeadersToDisplay = null;
            this.binaryTextComboBoxSingleColumnUnbound.IsAutoCompleteModeAppendSuggestInMultiColumnMode = false;
            this.binaryTextComboBoxSingleColumnUnbound.IsCustomisationOfColumnDisplayEnabledInMultiColumnAutoSuggestMode = false;
            this.binaryTextComboBoxSingleColumnUnbound.IsFilterSearchResultBasedOnColumnDataType = true;
            this.binaryTextComboBoxSingleColumnUnbound.IsInExtendedReadOnlyMode = false;
            this.binaryTextComboBoxSingleColumnUnbound.Items.AddRange(new object[] {
            "France",
            "Germany",
            "Denmark",
            "Switzerland",
            "Netherlands",
            "U.K.",
            "Sweden",
            "Spain",
            "U.S.A."});
            this.binaryTextComboBoxSingleColumnUnbound.KeepBindingContextInSyncWithParent = false;
            this.binaryTextComboBoxSingleColumnUnbound.KeepTheFilterAndGroupingViewsCollapsedAtStartUp = true;
            this.binaryTextComboBoxSingleColumnUnbound.KeepTheFilterAndGroupingViewsPaneFullyCollapsedAtStartup = false;
            this.binaryTextComboBoxSingleColumnUnbound.Location = new System.Drawing.Point(20, 51);
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownSize = new System.Drawing.Size(500, 250);
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.ColumnHeaderFont = new System.Drawing.Font("Arial", 12F);
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.ColumnHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.DrawFooter = true;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.FooterCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.FooterSurfaceHeight = 20;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.FooterText = "";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = null;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor = System.Drawing.SystemColors.Control;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderIcon = null;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderImageType = Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Icon;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderSurfaceHeight = 20;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderText = "";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.NoDataToDisplayMessageText = "There are no items to display.";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropListBackColor = System.Drawing.Color.Yellow;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropListFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropListForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropListGridLines = true;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropListHoverSelection = false;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDroplistWindowAnimationStyle = Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropListWindowIsResizable = true;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewBusyProcessingText = "Processing the query... please wait...";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewNoDataFoundText = "There is no data to display.";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewSortingGlyphColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableDataGroupingText = "Enable data grouping";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableFilterOptionsText = "Enable filter options";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.ContextMenuItemExportDataToCSV = "Export data to CSV";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.ContextMenuItemShowCommandBarText = "Show command bar";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemBuiltInFilter = "Built-in filter";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemCustomExpression = "Custom expression";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemFilterOnThisColumn = "Filter on this column:";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemEnableGrouping = "Enable \"grouping\"";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemFilterDataWhileTheUserTypesExpression = "Filter data while the user types expression?";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpression = "Filter expression:";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionType = "Filter expression type:";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionTypeComboBoxTooltip = resources.GetString("resource.WindowItemFilterExpressionTypeComboBoxTooltip");
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemFilteringStatusPart = "Filter status: Filtering is currently using";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemGroupOnThisColumn = "Group on this column:";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemHideFilterAndGroupingOptions = "Hide filter and grouping options";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemShowFilterAndGroupingOptions = "Show filter and grouping options";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemUseFilterToRetrieveData = "Use filter to retrieve data";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowStatusBarCustomExpressionErrorMessage = "Invalid custom expression. Please correct.";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowTaskStatusMessageForCSVExportSuccessful = "                Command result: CSV export successful.";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnWindowColumnsHorizontalAlignments = ((System.Collections.Generic.IList<System.Windows.Forms.HorizontalAlignment>)(resources.GetObject("binaryTextComboBoxSingleColumnUnbound.MultiColumnWindowColumnsHorizontalAlignment" +
        "s")));
            this.binaryTextComboBoxSingleColumnUnbound.Name = "binaryTextComboBoxSingleColumnUnbound";
            this.binaryTextComboBoxSingleColumnUnbound.SelectedIndexFromDropList = -1;
            this.binaryTextComboBoxSingleColumnUnbound.ShareCustomMultiColumnSizeAcrossDataListAndFilterGroupingOptionsPane = true;
            this.binaryTextComboBoxSingleColumnUnbound.ShouldAllowUserInputWhileProcessingMultiColumnAutoCompleDropDownView = true;
            this.binaryTextComboBoxSingleColumnUnbound.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryTextComboBoxSingleColumnUnbound.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryTextComboBoxSingleColumnUnbound.ShouldDrawExtendedDropdownButton = false;
            this.binaryTextComboBoxSingleColumnUnbound.ShouldPersistUserSetColumnWidthsAcrossFilterSessions = false;
            this.binaryTextComboBoxSingleColumnUnbound.ShowBorderAlways = true;
            this.binaryTextComboBoxSingleColumnUnbound.ShowDropDownMultiColumnWindowAfterAdjustingForVirtualAvaliableScreenSpace = false;
            this.binaryTextComboBoxSingleColumnUnbound.ShowEmptyDropListViewWhenThereAreNoData = true;
            this.binaryTextComboBoxSingleColumnUnbound.ShowFilterOptionsInMultiColumnMode = true;
            this.binaryTextComboBoxSingleColumnUnbound.Size = new System.Drawing.Size(205, 21);
            this.binaryTextComboBoxSingleColumnUnbound.SizeForMultiColumnAutoCompleteSuggestionDropDownWindow = new System.Drawing.Size(0, 0);
            this.binaryTextComboBoxSingleColumnUnbound.SizesForMultiColumnAutoCompleteSuggestionDropDownWindowColumns = null;
            this.binaryTextComboBoxSingleColumnUnbound.TabIndex = 0;
            this.binaryTextComboBoxSingleColumnUnbound.TableToLoad = null;
            this.binaryTextComboBoxSingleColumnUnbound.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(261, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Binarycombobox in single column data unbound mode";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(280, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "All you will have to do is to set the items collection and run";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(246, 137);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 20);
            this.button1.TabIndex = 3;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(319, 204);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.binaryTextComboBoxSingleColumnUnbound);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox binaryTextComboBoxSingleColumnUnbound;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
    }
}

