using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryImageComboboxSample
{
    public partial class Form1 : ModernChromeWindow
    {
        public Form1()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"Image combo customisation";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'tasksDataSet.Tasklist' table. You can move, or remove it, as needed.
            this.tasklistTableAdapter.Fill(this.tasksDataSet.Tasklist);
            binaryImageComboBoxDataUnbound.SelectedIndex = 0;

        }

        private void chkDrawRectDataUnbound_CheckedChanged(object sender, EventArgs e)
        {
            binaryImageComboBoxDataUnbound.DrawRectangleAroundImage = chkDrawRectDataUnbound.Checked;
        }

        private void chkDrawRectDataBound_CheckedChanged(object sender, EventArgs e)
        {
            binaryImageComboBoxDataBound.DrawRectangleAroundImage = chkDrawRectDataBound.Checked;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}