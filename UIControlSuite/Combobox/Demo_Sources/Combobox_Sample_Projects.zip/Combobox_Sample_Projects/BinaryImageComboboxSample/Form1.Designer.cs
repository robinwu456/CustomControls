namespace BinaryImageComboboxSample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.binaryImageComboBoxDataUnbound = new Binarymission.WinForms.Controls.ListControls.BinaryImageComboBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.binaryImageComboBoxDataBound = new Binarymission.WinForms.Controls.ListControls.BinaryImageComboBox();
            this.tasklistBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tasksDataSet = new BinaryImageComboboxSample.TasksDataSet();
            this.tasklistTableAdapter = new BinaryImageComboboxSample.TasksDataSetTableAdapters.TasklistTableAdapter();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.chkDrawRectDataUnbound = new System.Windows.Forms.CheckBox();
            this.chkDrawRectDataBound = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tasklistBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tasksDataSet)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // binaryImageComboBoxDataUnbound
            // 
            this.binaryImageComboBoxDataUnbound.AlphaBlendFactorForControlPainting = 100;
            this.binaryImageComboBoxDataUnbound.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryImageComboBoxDataUnbound.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryImageComboBoxDataUnbound.BackColor = System.Drawing.SystemColors.Window;
            this.binaryImageComboBoxDataUnbound.Bitmaps = null;
            this.binaryImageComboBoxDataUnbound.BitmapsAssociatedText = null;
            this.binaryImageComboBoxDataUnbound.ColorForDrawingRectangleAroundImage = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBoxDataUnbound.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryImageComboBoxDataUnbound.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBoxDataUnbound.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryImageComboBoxDataUnbound.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryImageComboBoxDataUnbound.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBoxDataUnbound.DesiredHeightForDrawingTheImages = 32;
            this.binaryImageComboBoxDataUnbound.DesiredWidthForDrawingTheImages = 32;
            this.binaryImageComboBoxDataUnbound.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryImageComboBoxDataUnbound.DrawRectangleAroundImage = false;
            this.binaryImageComboBoxDataUnbound.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryImageComboBoxDataUnbound.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryImageComboBoxDataUnbound.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryImageComboBoxDataUnbound.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryImageComboBoxDataUnbound.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryImageComboBoxDataUnbound.DropDownWindowBorderThickness = 1F;
            this.binaryImageComboBoxDataUnbound.ExtendedDropdownButtonImage = null;
            this.binaryImageComboBoxDataUnbound.ExtendedDropdownButtonInternalImage = null;
            this.binaryImageComboBoxDataUnbound.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryImageComboBoxDataUnbound.FormattingEnabled = true;
            this.binaryImageComboBoxDataUnbound.Imagelist = this.imageList1;
            this.binaryImageComboBoxDataUnbound.IsInExtendedReadOnlyMode = false;
            this.binaryImageComboBoxDataUnbound.ItemHeight = 36;
            this.binaryImageComboBoxDataUnbound.Items.AddRange(new object[] {
            "Email Customer!",
            "Buy Products!",
            "Download Products!",
            "Preview Sales data!"});
            this.binaryImageComboBoxDataUnbound.Location = new System.Drawing.Point(18, 41);
            this.binaryImageComboBoxDataUnbound.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryImageComboBoxDataUnbound.MultiColumnWindowColumnsHorizontalAlignments = null;
            this.binaryImageComboBoxDataUnbound.Name = "binaryImageComboBoxDataUnbound";
            this.binaryImageComboBoxDataUnbound.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryImageComboBoxDataUnbound.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryImageComboBoxDataUnbound.ShouldDrawExtendedDropdownButton = false;
            this.binaryImageComboBoxDataUnbound.ShowBorderAlways = true;
            this.binaryImageComboBoxDataUnbound.Size = new System.Drawing.Size(207, 42);
            this.binaryImageComboBoxDataUnbound.TabIndex = 0;
            this.binaryImageComboBoxDataUnbound.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryImageComboBoxDataUnbound.UseImageListForComboBox = true;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "bill_mail-edit.png");
            this.imageList1.Images.SetKeyName(1, "currency_dollar.png");
            this.imageList1.Images.SetKeyName(2, "cabinet-cloud.png");
            this.imageList1.Images.SetKeyName(3, "bill-bookmark.png");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "BinaryImageCombobox in data unbound mode";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "1. Add items to items collection";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(279, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "2. Setup an Imagelist with the required Images and its size";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(332, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "1. Datasource, Display member and Value member set via Smart tags";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(12, 14);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(358, 33);
            this.label11.TabIndex = 11;
            this.label11.Text = "In the above BinaryImagecombobox instance, the following have been set via the pr" +
    "operty editor";
            // 
            // binaryImageComboBoxDataBound
            // 
            this.binaryImageComboBoxDataBound.AlphaBlendFactorForControlPainting = 100;
            this.binaryImageComboBoxDataBound.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryImageComboBoxDataBound.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryImageComboBoxDataBound.BackColor = System.Drawing.SystemColors.Window;
            this.binaryImageComboBoxDataBound.Bitmaps = null;
            this.binaryImageComboBoxDataBound.BitmapsAssociatedText = null;
            this.binaryImageComboBoxDataBound.ColorForDrawingRectangleAroundImage = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBoxDataBound.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryImageComboBoxDataBound.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBoxDataBound.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryImageComboBoxDataBound.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryImageComboBoxDataBound.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBoxDataBound.DataSource = this.tasklistBindingSource;
            this.binaryImageComboBoxDataBound.DesiredHeightForDrawingTheImages = 32;
            this.binaryImageComboBoxDataBound.DesiredWidthForDrawingTheImages = 32;
            this.binaryImageComboBoxDataBound.DisplayMember = "Taskname";
            this.binaryImageComboBoxDataBound.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryImageComboBoxDataBound.DrawRectangleAroundImage = false;
            this.binaryImageComboBoxDataBound.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryImageComboBoxDataBound.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryImageComboBoxDataBound.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryImageComboBoxDataBound.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryImageComboBoxDataBound.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryImageComboBoxDataBound.DropDownWindowBorderThickness = 1F;
            this.binaryImageComboBoxDataBound.ExtendedDropdownButtonImage = null;
            this.binaryImageComboBoxDataBound.ExtendedDropdownButtonInternalImage = null;
            this.binaryImageComboBoxDataBound.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryImageComboBoxDataBound.FormattingEnabled = true;
            this.binaryImageComboBoxDataBound.Imagelist = this.imageList1;
            this.binaryImageComboBoxDataBound.IsInExtendedReadOnlyMode = false;
            this.binaryImageComboBoxDataBound.ItemHeight = 36;
            this.binaryImageComboBoxDataBound.Location = new System.Drawing.Point(18, 329);
            this.binaryImageComboBoxDataBound.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryImageComboBoxDataBound.MultiColumnWindowColumnsHorizontalAlignments = null;
            this.binaryImageComboBoxDataBound.Name = "binaryImageComboBoxDataBound";
            this.binaryImageComboBoxDataBound.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryImageComboBoxDataBound.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryImageComboBoxDataBound.ShouldDrawExtendedDropdownButton = false;
            this.binaryImageComboBoxDataBound.ShowBorderAlways = true;
            this.binaryImageComboBoxDataBound.Size = new System.Drawing.Size(219, 42);
            this.binaryImageComboBoxDataBound.TabIndex = 12;
            this.binaryImageComboBoxDataBound.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryImageComboBoxDataBound.UseImageListForComboBox = true;
            this.binaryImageComboBoxDataBound.ValueMember = "Id";
            // 
            // tasklistBindingSource
            // 
            this.tasklistBindingSource.DataMember = "Tasklist";
            this.tasklistBindingSource.DataSource = this.tasksDataSet;
            // 
            // tasksDataSet
            // 
            this.tasksDataSet.DataSetName = "TasksDataSet";
            this.tasksDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tasklistTableAdapter
            // 
            this.tasklistTableAdapter.ClearBeforeFill = true;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(9, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(387, 21);
            this.label5.TabIndex = 13;
            this.label5.Text = "In the above BinaryImagecombobox instance, the following have been set";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 56);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(279, 13);
            this.label12.TabIndex = 14;
            this.label12.Text = "2. Setup an Imagelist with the required Images and its size";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(19, 132);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(394, 135);
            this.panel1.TabIndex = 16;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(12, 91);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(383, 33);
            this.label9.TabIndex = 12;
            this.label9.Text = "3. Associate the Imagelist with the above dataunbound BinaryImagecombobox instanc" +
    "e";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 307);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(212, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "BinaryImageCombobox in data bound mode";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(19, 419);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(395, 121);
            this.panel2.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(7, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(383, 33);
            this.label6.TabIndex = 13;
            this.label6.Text = "3. Associate the Imagelist with the above databound BinaryImagecombobox instance " +
    "via the property editor";
            // 
            // chkDrawRectDataUnbound
            // 
            this.chkDrawRectDataUnbound.AutoSize = true;
            this.chkDrawRectDataUnbound.Location = new System.Drawing.Point(18, 105);
            this.chkDrawRectDataUnbound.Name = "chkDrawRectDataUnbound";
            this.chkDrawRectDataUnbound.Size = new System.Drawing.Size(183, 17);
            this.chkDrawRectDataUnbound.TabIndex = 13;
            this.chkDrawRectDataUnbound.Text = "Draw rectangle around the image";
            this.chkDrawRectDataUnbound.UseVisualStyleBackColor = true;
            this.chkDrawRectDataUnbound.CheckedChanged += new System.EventHandler(this.chkDrawRectDataUnbound_CheckedChanged);
            // 
            // chkDrawRectDataBound
            // 
            this.chkDrawRectDataBound.AutoSize = true;
            this.chkDrawRectDataBound.Location = new System.Drawing.Point(19, 393);
            this.chkDrawRectDataBound.Name = "chkDrawRectDataBound";
            this.chkDrawRectDataBound.Size = new System.Drawing.Size(183, 17);
            this.chkDrawRectDataBound.TabIndex = 19;
            this.chkDrawRectDataBound.Text = "Draw rectangle around the image";
            this.chkDrawRectDataBound.UseVisualStyleBackColor = true;
            this.chkDrawRectDataBound.CheckedChanged += new System.EventHandler(this.chkDrawRectDataBound_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(355, 563);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 23);
            this.button1.TabIndex = 20;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(441, 631);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.chkDrawRectDataBound);
            this.Controls.Add(this.chkDrawRectDataUnbound);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.binaryImageComboBoxDataBound);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.binaryImageComboBoxDataUnbound);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tasklistBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tasksDataSet)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Binarymission.WinForms.Controls.ListControls.BinaryImageComboBox binaryImageComboBoxDataUnbound;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private Binarymission.WinForms.Controls.ListControls.BinaryImageComboBox binaryImageComboBoxDataBound;
        private TasksDataSet tasksDataSet;
        private System.Windows.Forms.BindingSource tasklistBindingSource;
        private BinaryImageComboboxSample.TasksDataSetTableAdapters.TasklistTableAdapter tasklistTableAdapter;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox chkDrawRectDataUnbound;
        private System.Windows.Forms.CheckBox chkDrawRectDataBound;
        private System.Windows.Forms.Button button1;
    }
}

