namespace BinaryImageComboboxStylesSample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.binaryImageComboBox1 = new Binarymission.WinForms.Controls.ListControls.BinaryImageComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.binaryImageComboBox2 = new Binarymission.WinForms.Controls.ListControls.BinaryImageComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // binaryImageComboBox1
            // 
            this.binaryImageComboBox1.AlphaBlendFactorForControlPainting = 100;
            this.binaryImageComboBox1.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryImageComboBox1.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryImageComboBox1.BackColor = System.Drawing.SystemColors.Window;
            this.binaryImageComboBox1.Bitmaps = null;
            this.binaryImageComboBox1.BitmapsAssociatedText = null;
            this.binaryImageComboBox1.ColorForDrawingRectangleAroundImage = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBox1.ComboListStyle = Binarymission.WinForms.Controls.ListControls.ListStyle.DriveList;
            this.binaryImageComboBox1.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryImageComboBox1.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBox1.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryImageComboBox1.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryImageComboBox1.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBox1.DesiredHeightForDrawingTheImages = 32;
            this.binaryImageComboBox1.DesiredWidthForDrawingTheImages = 20;
            this.binaryImageComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.binaryImageComboBox1.DrawRectangleAroundImage = true;
            this.binaryImageComboBox1.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryImageComboBox1.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryImageComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryImageComboBox1.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryImageComboBox1.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryImageComboBox1.DropDownWindowBorderThickness = 1F;
            this.binaryImageComboBox1.ExtendedDropdownButtonImage = null;
            this.binaryImageComboBox1.ExtendedDropdownButtonInternalImage = null;
            this.binaryImageComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryImageComboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryImageComboBox1.FormattingEnabled = true;
            this.binaryImageComboBox1.IsInExtendedReadOnlyMode = false;
            this.binaryImageComboBox1.ItemHeight = 32;
            this.binaryImageComboBox1.Items.AddRange(new object[] {
            "Computer",
            "Floppy Disk Drive (A:)",
            "Local Disk (C:)",
            "DVD RW Drive (D:)",
            "DVD Drive (E:)",
            "Seagate Backup Plus Drive (G:)",
            "Removable Disk (H:)",
            "Removable Disk (I:)",
            "Removable Disk (J:)",
            "Removable Disk (K:)",
            "Computer",
            "Floppy Disk Drive (A:)",
            "Local Disk (C:)",
            "DVD RW Drive (D:)",
            "DVD Drive (E:)",
            "Seagate Backup Plus Drive (F:)",
            "Removable Disk (H:)",
            "Removable Disk (I:)",
            "Removable Disk (J:)",
            "Removable Disk (K:)",
            "Computer",
            "Floppy Disk Drive (A:)",
            "Local Disk (C:)",
            "DVD RW Drive (D:)",
            "DVD Drive (E:)",
            "Seagate Backup Plus Drive (F:)",
            "Removable Disk (H:)",
            "Removable Disk (I:)",
            "Removable Disk (J:)",
            "Removable Disk (K:)",
            "Computer",
            "Floppy Disk Drive (A:)",
            "Local Disk (C:)",
            "DVD RW Drive (D:)",
            "DVD Drive (E:)",
            "Seagate Backup Plus Drive (F:)",
            "Binarymission - Large backup (G:)",
            "Removable Disk (H:)",
            "Removable Disk (I:)",
            "Removable Disk (J:)",
            "Removable Disk (K:)",
            "Computer",
            "Floppy Disk Drive (A:)",
            "Local Disk (C:)",
            "DVD RW Drive (D:)",
            "DVD Drive (E:)",
            "Removable Disk (F:)",
            "Removable Disk (G:)",
            "Removable Disk (H:)",
            "Removable Disk (I:)",
            "Binarymission-Auto-backup (J:)",
            "Computer",
            "Floppy Disk Drive (A:)",
            "Binarymission - Main drive (C:)",
            "DVD RW Drive (D:)",
            "DVD Drive (E:)",
            "Removable Disk (G:)",
            "Removable Disk (H:)",
            "Removable Disk (I:)",
            "DVD Drive (J:)",
            "Removable Disk (K:)",
            "Binarymission - Large backup (L:)",
            "Computer",
            "OS (C:)",
            "DATA (D:)",
            "HP_RECOVERY (E:)",
            "DVD RW Drive (F:)",
            "limavss (\\\\ma-lima-001) (Y:)",
            "limavss (\\\\ma-lima-001) (Z:)",
            "My Computer",
            "3� Floppy (A:)",
            "Local Disk (C:)",
            "DVD Drive (D:)",
            "DVD-RW Drive (E:)",
            "Removable Disk (G:)",
            "Removable Disk (H:)",
            "Removable Disk (I:)",
            "Removable Disk (J:)",
            "My Computer",
            "3� Floppy (A:)",
            "Local Disk (C:)",
            "DVD Drive (D:)",
            "DVD-RW Drive (E:)",
            "Removable Disk (G:)",
            "Removable Disk (H:)",
            "Removable Disk (I:)",
            "Removable Disk (J:)",
            "My Computer",
            "3� Floppy (A:)",
            "Local Disk (C:)",
            "DVD Drive (D:)",
            "DVD-RW Drive (E:)",
            "Removable Disk (G:)",
            "Removable Disk (H:)",
            "Removable Disk (I:)",
            "Removable Disk (J:)",
            "My Computer",
            "3� Floppy (A:)",
            "Local Disk (C:)",
            "DVD Drive (D:)",
            "DVD-RW Drive (E:)",
            "Removable Disk (G:)",
            "Removable Disk (H:)",
            "Removable Disk (I:)",
            "Removable Disk (J:)",
            "My Computer",
            "3� Floppy (A:)",
            "Local Disk (C:)",
            "5June08EveningSundar (D:)",
            "DVD-RW Drive (E:)",
            "Removable Disk (G:)",
            "Removable Disk (H:)",
            "Removable Disk (I:)",
            "Removable Disk (J:)"});
            this.binaryImageComboBox1.Location = new System.Drawing.Point(16, 46);
            this.binaryImageComboBox1.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryImageComboBox1.MultiColumnWindowColumnsHorizontalAlignments = null;
            this.binaryImageComboBox1.Name = "binaryImageComboBox1";
            this.binaryImageComboBox1.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryImageComboBox1.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryImageComboBox1.ShouldDrawExtendedDropdownButton = false;
            this.binaryImageComboBox1.ShowBorderAlways = true;
            this.binaryImageComboBox1.Size = new System.Drawing.Size(366, 38);
            this.binaryImageComboBox1.TabIndex = 0;
            this.binaryImageComboBox1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryImageComboBox1.UseImageListForComboBox = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "ImageCombobox in Drive-list style:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(330, 242);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(55, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // binaryImageComboBox2
            // 
            this.binaryImageComboBox2.AlphaBlendFactorForControlPainting = 100;
            this.binaryImageComboBox2.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryImageComboBox2.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryImageComboBox2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryImageComboBox2.Bitmaps = null;
            this.binaryImageComboBox2.BitmapsAssociatedText = null;
            this.binaryImageComboBox2.ColorForDrawingRectangleAroundImage = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBox2.ComboListStyle = Binarymission.WinForms.Controls.ListControls.ListStyle.FontList;
            this.binaryImageComboBox2.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryImageComboBox2.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBox2.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryImageComboBox2.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryImageComboBox2.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBox2.DesiredHeightForDrawingTheImages = 24;
            this.binaryImageComboBox2.DesiredWidthForDrawingTheImages = 20;
            this.binaryImageComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.binaryImageComboBox2.DrawRectangleAroundImage = true;
            this.binaryImageComboBox2.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryImageComboBox2.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryImageComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryImageComboBox2.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryImageComboBox2.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryImageComboBox2.DropDownWindowBorderThickness = 1F;
            this.binaryImageComboBox2.ExtendedDropdownButtonImage = null;
            this.binaryImageComboBox2.ExtendedDropdownButtonInternalImage = null;
            this.binaryImageComboBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryImageComboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryImageComboBox2.FormattingEnabled = true;
            this.binaryImageComboBox2.IntegralHeight = false;
            this.binaryImageComboBox2.IsInExtendedReadOnlyMode = false;
            this.binaryImageComboBox2.ItemHeight = 32;
            this.binaryImageComboBox2.Items.AddRange(new object[] {
            "Agency FB",
            "Algerian",
            "Andalus",
            "Angsana New",
            "AngsanaUPC",
            "Aparajita",
            "Arabic Typesetting",
            "Arial",
            "Arial Black",
            "Arial Narrow",
            "Arial Rounded MT Bold",
            "Arial Unicode MS",
            "Baskerville Old Face",
            "Batang",
            "BatangChe",
            "Bauhaus 93",
            "Bell MT",
            "Berlin Sans FB",
            "Bernard MT Condensed",
            "Blackadder ITC",
            "Bodoni MT",
            "Bodoni MT Black",
            "Bodoni MT Condensed",
            "Bodoni MT Poster Compressed",
            "Book Antiqua",
            "Bookman Old Style",
            "Bradley Hand ITC",
            "Britannic Bold",
            "Broadway",
            "Browallia New",
            "BrowalliaUPC",
            "Buxton Sketch",
            "Calibri",
            "Calibri Light",
            "Californian FB",
            "Calisto MT",
            "Cambria",
            "Cambria Math",
            "Candara",
            "Castellar",
            "Centaur",
            "Century",
            "Century Gothic",
            "Century Schoolbook",
            "Chiller",
            "Colonna MT",
            "Comic Sans MS",
            "Consolas",
            "Constantia",
            "Cooper Black",
            "Copperplate Gothic Bold",
            "Copperplate Gothic Light",
            "Corbel",
            "Cordia New",
            "CordiaUPC",
            "Courier New",
            "Curlz MT",
            "DaunPenh",
            "David",
            "DengXian",
            "DFKai-SB",
            "DilleniaUPC",
            "DokChampa",
            "Dotum",
            "DotumChe",
            "Ebrima",
            "Edwardian Script ITC",
            "Elephant",
            "Engravers MT",
            "Eras Bold ITC",
            "Eras Demi ITC",
            "Eras Light ITC",
            "Eras Medium ITC",
            "Estrangelo Edessa",
            "EucrosiaUPC",
            "Euphemia",
            "FangSong",
            "Felix Titling",
            "Footlight MT Light",
            "Forte",
            "Franklin Gothic Book",
            "Franklin Gothic Demi",
            "Franklin Gothic Demi Cond",
            "Franklin Gothic Heavy",
            "Franklin Gothic Medium",
            "Franklin Gothic Medium Cond",
            "FrankRuehl",
            "FreesiaUPC",
            "Freestyle Script",
            "French Script MT",
            "Gabriola",
            "Gadugi",
            "Garamond",
            "Gautami",
            "Georgia",
            "Gigi",
            "Gill Sans MT",
            "Gill Sans MT Condensed",
            "Gill Sans MT Ext Condensed Bold",
            "Gill Sans Ultra Bold",
            "Gill Sans Ultra Bold Condensed",
            "Gisha",
            "Gloucester MT Extra Condensed",
            "Goudy Old Style",
            "Goudy Stout",
            "Gulim",
            "GulimChe",
            "Gungsuh",
            "GungsuhChe",
            "Haettenschweiler",
            "Harrington",
            "High Tower Text",
            "Impact",
            "Imprint MT Shadow",
            "Informal Roman",
            "IrisUPC",
            "Iskoola Pota",
            "JasmineUPC",
            "Jing Jing",
            "Jokerman",
            "Juice ITC",
            "KaiTi",
            "Kalinga",
            "Kartika",
            "Khmer UI",
            "KodchiangUPC",
            "Kokila",
            "Kootenay",
            "Kristen ITC",
            "Kunstler Script",
            "Lao UI",
            "Latha",
            "Leelawadee",
            "Levenim MT",
            "LilyUPC",
            "Lindsey",
            "Lucida Bright",
            "Lucida Calligraphy",
            "Lucida Console",
            "Lucida Fax",
            "Lucida Handwriting",
            "Lucida Sans",
            "Lucida Sans Typewriter",
            "Lucida Sans Unicode",
            "Maiandra GD",
            "Malgun Gothic",
            "Mangal",
            "Marlett",
            "Matura MT Script Capitals",
            "Meiryo",
            "Meiryo UI",
            "Microsoft Himalaya",
            "Microsoft JhengHei",
            "Microsoft JhengHei UI",
            "Microsoft MHei",
            "Microsoft NeoGothic",
            "Microsoft New Tai Lue",
            "Microsoft PhagsPa",
            "Microsoft Sans Serif",
            "Microsoft Tai Le",
            "Microsoft Uighur",
            "Microsoft YaHei",
            "Microsoft YaHei UI",
            "Microsoft Yi Baiti",
            "MingLiU",
            "MingLiU-ExtB",
            "MingLiU_HKSCS",
            "MingLiU_HKSCS-ExtB",
            "Miramonte",
            "Miriam",
            "Miriam Fixed",
            "Mistral",
            "Modern No. 20",
            "Moire",
            "Moire ExtraBold",
            "Moire Light",
            "Mongolian Baiti",
            "MoolBoran",
            "Motorwerk",
            "MS Gothic",
            "MS Mincho",
            "MS PGothic",
            "MS PMincho",
            "MS UI Gothic",
            "MV Boli",
            "Narkisim",
            "News Gothic",
            "Niagara Engraved",
            "Niagara Solid",
            "Nirmala UI",
            "NSimSun",
            "Nyala",
            "OCR A Extended",
            "Old English Text MT",
            "Onyx",
            "Palatino Linotype",
            "Papyrus",
            "Parchment",
            "Pericles",
            "Pericles Light",
            "Perpetua",
            "Perpetua Titling MT",
            "Pescadero",
            "Plantagenet Cherokee",
            "Playbill",
            "PMingLiU",
            "PMingLiU-ExtB",
            "Poor Richard",
            "Pristina",
            "Quartz MS",
            "Raavi",
            "Rage Italic",
            "Ravie",
            "Rockwell",
            "Rockwell Condensed",
            "Rockwell Extra Bold",
            "Rod",
            "Sakkal Majalla",
            "Script MT Bold",
            "Segoe Keycaps",
            "Segoe Marker",
            "Segoe Print",
            "Segoe Script",
            "Segoe UI",
            "Segoe UI Light",
            "Segoe UI Mono",
            "Segoe UI Semibold",
            "Segoe UI Semilight",
            "Segoe UI Symbol",
            "Segoe WP",
            "Segoe WP Black",
            "Segoe WP Light",
            "Segoe WP Semibold",
            "Segoe WP SemiLight",
            "Shonar Bangla",
            "Showcard Gothic",
            "Shruti",
            "SimHei",
            "Simplified Arabic",
            "Simplified Arabic Fixed",
            "SimSun",
            "SimSun-ExtB",
            "SketchFlow Print",
            "Snap ITC",
            "Stencil",
            "Sylfaen",
            "Symbol",
            "Tahoma",
            "Tempus Sans ITC",
            "Times New Roman",
            "Traditional Arabic",
            "Trebuchet MS",
            "Tunga",
            "Tw Cen MT",
            "Tw Cen MT Condensed",
            "Tw Cen MT Condensed Extra Bold",
            "Utsaah",
            "Vani",
            "Verdana",
            "Vijaya",
            "Viner Hand ITC",
            "Vladimir Script",
            "Vrinda",
            "Wasco Sans",
            "Webdings",
            "Wide Latin",
            "Wingdings",
            "Wingdings 2",
            "Wingdings 3",
            "Yu Gothic",
            "Agency FB",
            "Algerian",
            "Andalus",
            "Angsana New",
            "AngsanaUPC",
            "Aparajita",
            "Arabic Typesetting",
            "Arial",
            "Arial Black",
            "Arial Narrow",
            "Arial Rounded MT Bold",
            "Arial Unicode MS",
            "Baskerville Old Face",
            "Batang",
            "BatangChe",
            "Bauhaus 93",
            "Bell MT",
            "Berlin Sans FB",
            "Bernard MT Condensed",
            "Blackadder ITC",
            "Bodoni MT",
            "Bodoni MT Black",
            "Bodoni MT Condensed",
            "Bodoni MT Poster Compressed",
            "Book Antiqua",
            "Bookman Old Style",
            "Bradley Hand ITC",
            "Britannic Bold",
            "Broadway",
            "Browallia New",
            "BrowalliaUPC",
            "Buxton Sketch",
            "Calibri",
            "Calibri Light",
            "Californian FB",
            "Calisto MT",
            "Cambria",
            "Cambria Math",
            "Candara",
            "Castellar",
            "Centaur",
            "Century",
            "Century Gothic",
            "Century Schoolbook",
            "Chiller",
            "Colonna MT",
            "Comic Sans MS",
            "Consolas",
            "Constantia",
            "Cooper Black",
            "Copperplate Gothic Bold",
            "Copperplate Gothic Light",
            "Corbel",
            "Cordia New",
            "CordiaUPC",
            "Courier New",
            "Curlz MT",
            "DaunPenh",
            "David",
            "DengXian",
            "DFKai-SB",
            "DilleniaUPC",
            "DokChampa",
            "Dotum",
            "DotumChe",
            "Ebrima",
            "Edwardian Script ITC",
            "Elephant",
            "Engravers MT",
            "Eras Bold ITC",
            "Eras Demi ITC",
            "Eras Light ITC",
            "Eras Medium ITC",
            "Estrangelo Edessa",
            "EucrosiaUPC",
            "Euphemia",
            "FangSong",
            "Felix Titling",
            "Footlight MT Light",
            "Forte",
            "Franklin Gothic Book",
            "Franklin Gothic Demi",
            "Franklin Gothic Demi Cond",
            "Franklin Gothic Heavy",
            "Franklin Gothic Medium",
            "Franklin Gothic Medium Cond",
            "FrankRuehl",
            "FreesiaUPC",
            "Freestyle Script",
            "French Script MT",
            "Gabriola",
            "Gadugi",
            "Garamond",
            "Gautami",
            "Georgia",
            "Gigi",
            "Gill Sans MT",
            "Gill Sans MT Condensed",
            "Gill Sans MT Ext Condensed Bold",
            "Gill Sans Ultra Bold",
            "Gill Sans Ultra Bold Condensed",
            "Gisha",
            "Gloucester MT Extra Condensed",
            "Goudy Old Style",
            "Goudy Stout",
            "Gulim",
            "GulimChe",
            "Gungsuh",
            "GungsuhChe",
            "Haettenschweiler",
            "Harrington",
            "High Tower Text",
            "Impact",
            "Imprint MT Shadow",
            "Informal Roman",
            "IrisUPC",
            "Iskoola Pota",
            "JasmineUPC",
            "Jing Jing",
            "Jokerman",
            "Juice ITC",
            "KaiTi",
            "Kalinga",
            "Kartika",
            "Khmer UI",
            "KodchiangUPC",
            "Kokila",
            "Kootenay",
            "Kristen ITC",
            "Kunstler Script",
            "Lao UI",
            "Latha",
            "Leelawadee",
            "Levenim MT",
            "LilyUPC",
            "Lindsey",
            "Lucida Bright",
            "Lucida Calligraphy",
            "Lucida Console",
            "Lucida Fax",
            "Lucida Handwriting",
            "Lucida Sans",
            "Lucida Sans Typewriter",
            "Lucida Sans Unicode",
            "Maiandra GD",
            "Malgun Gothic",
            "Mangal",
            "Marlett",
            "Matura MT Script Capitals",
            "Meiryo",
            "Meiryo UI",
            "Microsoft Himalaya",
            "Microsoft JhengHei",
            "Microsoft JhengHei UI",
            "Microsoft MHei",
            "Microsoft NeoGothic",
            "Microsoft New Tai Lue",
            "Microsoft PhagsPa",
            "Microsoft Sans Serif",
            "Microsoft Tai Le",
            "Microsoft Uighur",
            "Microsoft YaHei",
            "Microsoft YaHei UI",
            "Microsoft Yi Baiti",
            "MingLiU",
            "MingLiU-ExtB",
            "MingLiU_HKSCS",
            "MingLiU_HKSCS-ExtB",
            "Miramonte",
            "Miriam",
            "Miriam Fixed",
            "Mistral",
            "Modern No. 20",
            "Moire",
            "Moire ExtraBold",
            "Moire Light",
            "Mongolian Baiti",
            "MoolBoran",
            "Motorwerk",
            "MS Gothic",
            "MS Mincho",
            "MS PGothic",
            "MS PMincho",
            "MS UI Gothic",
            "MV Boli",
            "Narkisim",
            "News Gothic",
            "Niagara Engraved",
            "Niagara Solid",
            "Nirmala UI",
            "NSimSun",
            "Nyala",
            "OCR A Extended",
            "Old English Text MT",
            "Onyx",
            "Palatino Linotype",
            "Papyrus",
            "Parchment",
            "Pericles",
            "Pericles Light",
            "Perpetua",
            "Perpetua Titling MT",
            "Pescadero",
            "Plantagenet Cherokee",
            "Playbill",
            "PMingLiU",
            "PMingLiU-ExtB",
            "Poor Richard",
            "Pristina",
            "Quartz MS",
            "Raavi",
            "Rage Italic",
            "Ravie",
            "Rockwell",
            "Rockwell Condensed",
            "Rockwell Extra Bold",
            "Rod",
            "Sakkal Majalla",
            "Script MT Bold",
            "Segoe Keycaps",
            "Segoe Marker",
            "Segoe Print",
            "Segoe Script",
            "Segoe UI",
            "Segoe UI Light",
            "Segoe UI Mono",
            "Segoe UI Semibold",
            "Segoe UI Semilight",
            "Segoe UI Symbol",
            "Segoe WP",
            "Segoe WP Black",
            "Segoe WP Light",
            "Segoe WP Semibold",
            "Segoe WP SemiLight",
            "Shonar Bangla",
            "Showcard Gothic",
            "Shruti",
            "SimHei",
            "Simplified Arabic",
            "Simplified Arabic Fixed",
            "SimSun",
            "SimSun-ExtB",
            "SketchFlow Print",
            "Snap ITC",
            "Stencil",
            "Sylfaen",
            "Symbol",
            "Tahoma",
            "Tempus Sans ITC",
            "Times New Roman",
            "Traditional Arabic",
            "Trebuchet MS",
            "Tunga",
            "Tw Cen MT",
            "Tw Cen MT Condensed",
            "Tw Cen MT Condensed Extra Bold",
            "Utsaah",
            "Vani",
            "Verdana",
            "Vijaya",
            "Viner Hand ITC",
            "Vladimir Script",
            "Vrinda",
            "Wasco Sans",
            "Webdings",
            "Wide Latin",
            "Wingdings",
            "Wingdings 2",
            "Wingdings 3",
            "Yu Gothic"});
            this.binaryImageComboBox2.Location = new System.Drawing.Point(16, 129);
            this.binaryImageComboBox2.MaxDropDownItems = 20;
            this.binaryImageComboBox2.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryImageComboBox2.MultiColumnWindowColumnsHorizontalAlignments = null;
            this.binaryImageComboBox2.Name = "binaryImageComboBox2";
            this.binaryImageComboBox2.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryImageComboBox2.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryImageComboBox2.ShouldDrawExtendedDropdownButton = false;
            this.binaryImageComboBox2.ShowBorderAlways = true;
            this.binaryImageComboBox2.Size = new System.Drawing.Size(366, 38);
            this.binaryImageComboBox2.TabIndex = 5;
            this.binaryImageComboBox2.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryImageComboBox2.UseImageListForComboBox = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "ImageCombobox in Font-list style:";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(23, 209);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(141, 17);
            this.radioButton1.TabIndex = 7;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Use default (control) font";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(192, 209);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(193, 17);
            this.radioButton2.TabIndex = 8;
            this.radioButton2.Text = "Use the selected Font instance font";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Font-list font display style:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(405, 311);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.binaryImageComboBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.binaryImageComboBox1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Binarymission.WinForms.Controls.ListControls.BinaryImageComboBox binaryImageComboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private Binarymission.WinForms.Controls.ListControls.BinaryImageComboBox binaryImageComboBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Label label2;
    }
}

