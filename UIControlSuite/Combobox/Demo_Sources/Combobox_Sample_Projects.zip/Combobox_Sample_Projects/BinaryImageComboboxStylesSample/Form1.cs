using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryImageComboboxStylesSample
{
    public partial class Form1 : ModernChromeWindow
    {
        public Form1()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"Image Combo styles";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            binaryImageComboBox1.ComboListStyle =
                Binarymission.WinForms.Controls.ListControls.ListStyle.DriveList;

            binaryImageComboBox2.ComboListStyle =
                Binarymission.WinForms.Controls.ListControls.ListStyle.FontList;
            binaryImageComboBox2.FontDisplayStyle =
                Binarymission.WinForms.Controls.ListControls.FontNameDisplayStyle.DisplayUsingControlFont;
            binaryImageComboBox1.Font = new Font(binaryImageComboBox1.Font.FontFamily, 10f);
            binaryImageComboBox2.Font = new Font(binaryImageComboBox2.Font.FontFamily, 11f);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            binaryImageComboBox2.FontDisplayStyle =
                Binarymission.WinForms.Controls.ListControls.FontNameDisplayStyle.DisplayUsingControlFont;
            binaryImageComboBox2.Font = new Font(binaryImageComboBox2.Font.FontFamily, 11f);
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            binaryImageComboBox2.FontDisplayStyle =
                Binarymission.WinForms.Controls.ListControls.FontNameDisplayStyle.DisplayUsingFontFamilyName;
            binaryImageComboBox2.Font = new Font(binaryImageComboBox2.Font.FontFamily, 11f);
        }
    }
}