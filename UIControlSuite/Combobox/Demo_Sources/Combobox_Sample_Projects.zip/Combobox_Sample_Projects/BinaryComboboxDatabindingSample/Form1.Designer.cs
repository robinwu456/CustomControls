namespace BinaryComboboxDatabindingSample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.binaryTextComboBoxMulticolumn = new Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox();
            this.salesdataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.testDataSet = new BinaryComboboxDatabindingSample.TestDataSet();
            this.salesdataTableAdapter = new BinaryComboboxDatabindingSample.TestDataSetTableAdapters.SalesdataTableAdapter();
            this.binaryTextComboBoxSinglecolumn = new Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox();
            this.salesdataBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.testDataSet1 = new BinaryComboboxDatabindingSample.TestDataSet1();
            this.salesdataTableAdapter1 = new BinaryComboboxDatabindingSample.TestDataSet1TableAdapters.SalesdataTableAdapter();
            this.btnClearDatasource = new System.Windows.Forms.Button();
            this.btnResetDatasource = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.salesdataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesdataBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(187, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Binarycombobox in Multi-column mode";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(15, 126);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(403, 139);
            this.panel1.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(6, 113);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(292, 19);
            this.label8.TabIndex = 7;
            this.label8.Text = "5. Set \'Show empty droplist window when there is no data\'";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(6, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(322, 33);
            this.label2.TabIndex = 2;
            this.label2.Text = "In the above Binarycombobox instance, the following have been set via smart tags";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(6, 95);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(214, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "4. Data display mode as  Multicolumn mode";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(6, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "1. Datasource";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(6, 77);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "3. Valuemember";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(6, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "2. Displaymember";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 352);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(194, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Binarycombobox in Single-column mode";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label23);
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.label25);
            this.panel5.Controls.Add(this.label26);
            this.panel5.Controls.Add(this.label27);
            this.panel5.Location = new System.Drawing.Point(15, 410);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(403, 119);
            this.panel5.TabIndex = 11;
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(6, 9);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(322, 33);
            this.label23.TabIndex = 2;
            this.label23.Text = "In the above Binarycombobox instance, the following have been set via smart tags";
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(6, 94);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(225, 19);
            this.label24.TabIndex = 6;
            this.label24.Text = "4. Data display mode as Singlecolumn mode";
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(6, 42);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(80, 13);
            this.label25.TabIndex = 3;
            this.label25.Text = "1. Datasource";
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(6, 77);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(95, 15);
            this.label26.TabIndex = 5;
            this.label26.Text = "3. Valuemember";
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(6, 59);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(95, 19);
            this.label27.TabIndex = 4;
            this.label27.Text = "2. Displaymember";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(371, 544);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(47, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "&Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // binaryTextComboBoxMulticolumn
            // 
            this.binaryTextComboBoxMulticolumn.AlphaBlendFactorForControlPainting = 100;
            this.binaryTextComboBoxMulticolumn.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryTextComboBoxMulticolumn.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryTextComboBoxMulticolumn.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.binaryTextComboBoxMulticolumn.AutoComplete = true;
            this.binaryTextComboBoxMulticolumn.AutoCompleteBasedOnCompleteMatchWithAnItemInTheList = false;
            this.binaryTextComboBoxMulticolumn.AutoCompleteIsCaseSensitive = true;
            this.binaryTextComboBoxMulticolumn.AutoCompleteStyleForMultiColumnModeIsMultiColumn = false;
            this.binaryTextComboBoxMulticolumn.BackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumn.BuiltinFilterOnNonStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxMulticolumn.BuiltinFilterOnStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxMulticolumn.BusyIndicatorText = "Processing...";
            this.binaryTextComboBoxMulticolumn.ColumnDataTypeFormatInfoContainers = null;
            this.binaryTextComboBoxMulticolumn.ColumnsToDisplay = null;
            this.binaryTextComboBoxMulticolumn.ColumnWidths = null;
            this.binaryTextComboBoxMulticolumn.ComboBoxIsReadOnly = false;
            this.binaryTextComboBoxMulticolumn.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.CSVFileSaveAs = "MultiColumnDataViewExport.csv";
            this.binaryTextComboBoxMulticolumn.CustomColumnNameForAutomaticRowSelection = null;
            this.binaryTextComboBoxMulticolumn.CustomComparerImplementor = null;
            this.binaryTextComboBoxMulticolumn.CustomControlBorderColor = System.Drawing.Color.Black;
            this.binaryTextComboBoxMulticolumn.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumn.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumn.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this.binaryTextComboBoxMulticolumn.CustomPaintingColor = System.Drawing.Color.Silver;
            this.binaryTextComboBoxMulticolumn.DataMember = null;
            this.binaryTextComboBoxMulticolumn.DataSource = this.salesdataBindingSource;
            this.binaryTextComboBoxMulticolumn.DataSourceViewCustomSortingExpression = null;
            this.binaryTextComboBoxMulticolumn.DesiredFilterColumn = 0;
            this.binaryTextComboBoxMulticolumn.DisplayMember = "CompanyName";
            this.binaryTextComboBoxMulticolumn.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryTextComboBoxMulticolumn.DrawTheControlBasedOnWindowsOS = true;
            this.binaryTextComboBoxMulticolumn.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumn.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxMulticolumn.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumn.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumn.DropDownWindowBorderThickness = 1F;
            this.binaryTextComboBoxMulticolumn.DropDownWindowDisplayOrientation = Binarymission.WinForms.Controls.ListControls.DropDownWindowDisplayOrientation.Default;
            this.binaryTextComboBoxMulticolumn.DropStyleIsMultiColumn = true;
            this.binaryTextComboBoxMulticolumn.EnableAlphaBlendingForFilterAndGroupingPanelBackColor = true;
            this.binaryTextComboBoxMulticolumn.EnableDrawingHeaderFooterWhenInMultiColumnMode = false;
            this.binaryTextComboBoxMulticolumn.ExtendedDropdownButtonImage = null;
            this.binaryTextComboBoxMulticolumn.ExtendedDropdownButtonInternalImage = null;
            this.binaryTextComboBoxMulticolumn.FilterAndGroupingPanelBackColor = System.Drawing.Color.Empty;
            this.binaryTextComboBoxMulticolumn.FilteringIsON = false;
            this.binaryTextComboBoxMulticolumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryTextComboBoxMulticolumn.GroupItemsWhenInMultiColumnDisplayMode = false;
            this.binaryTextComboBoxMulticolumn.GroupMultiColumnDisplayModeDataBasedOnThisColumn = 0;
            this.binaryTextComboBoxMulticolumn.HeadersToDisplay = null;
            this.binaryTextComboBoxMulticolumn.IsAutoCompleteModeAppendSuggestInMultiColumnMode = false;
            this.binaryTextComboBoxMulticolumn.IsCustomisationOfColumnDisplayEnabledInMultiColumnAutoSuggestMode = false;
            this.binaryTextComboBoxMulticolumn.IsFilterSearchResultBasedOnColumnDataType = true;
            this.binaryTextComboBoxMulticolumn.IsInExtendedReadOnlyMode = false;
            this.binaryTextComboBoxMulticolumn.KeepBindingContextInSyncWithParent = false;
            this.binaryTextComboBoxMulticolumn.KeepTheFilterAndGroupingViewsCollapsedAtStartUp = true;
            this.binaryTextComboBoxMulticolumn.KeepTheFilterAndGroupingViewsPaneFullyCollapsedAtStartup = false;
            this.binaryTextComboBoxMulticolumn.Location = new System.Drawing.Point(17, 54);
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownSize = new System.Drawing.Size(500, 250);
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.ColumnHeaderFont = new System.Drawing.Font("Arial", 12F);
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.ColumnHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.DrawFooter = true;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.FooterCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.FooterSurfaceHeight = 20;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.FooterText = "";
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = null;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor = System.Drawing.Color.Silver;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderIcon = null;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderImageType = Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Icon;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderSurfaceHeight = 20;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderText = "";
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.NoDataToDisplayMessageText = "There are no items to display.";
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListBackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListGridLines = true;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListHoverSelection = false;
            this.binaryTextComboBoxMulticolumn.MultiColumnDroplistWindowAnimationStyle = Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListWindowIsResizable = true;
            this.binaryTextComboBoxMulticolumn.MultiColumnViewBusyProcessingText = "Processing the query... please wait...";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewNoDataFoundText = "There is no data to display.";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewSortingGlyphColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableDataGroupingText = "Enable data grouping";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableFilterOptionsText = "Enable filter options";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemExportDataToCSV = "Export data to CSV";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemShowCommandBarText = "Show command bar";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemBuiltInFilter = "Built-in filter";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemCustomExpression = "Custom expression";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemFilterOnThisColumn = "Filter on this column:";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemEnableGrouping = "Enable \"grouping\"";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterDataWhileTheUserTypesExpression = "Filter data while the user types expression?";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpression = "Filter expression:";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionType = "Filter expression type:";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionTypeComboBoxTooltip = resources.GetString("resource.WindowItemFilterExpressionTypeComboBoxTooltip");
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilteringStatusPart = "Filter status: Filtering is currently using";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemGroupOnThisColumn = "Group on this column:";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemHideFilterAndGroupingOptions = "Hide filter and grouping options";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemShowFilterAndGroupingOptions = "Show filter and grouping options";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemUseFilterToRetrieveData = "Use filter to retrieve data";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowStatusBarCustomExpressionErrorMessage = "Invalid custom expression. Please correct.";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowTaskStatusMessageForCSVExportSuccessful = "                Command result: CSV export successful.";
            this.binaryTextComboBoxMulticolumn.MultiColumnWindowColumnsHorizontalAlignments = ((System.Collections.Generic.IList<System.Windows.Forms.HorizontalAlignment>)(resources.GetObject("binaryTextComboBoxMulticolumn.MultiColumnWindowColumnsHorizontalAlignments")));
            this.binaryTextComboBoxMulticolumn.Name = "binaryTextComboBoxMulticolumn";
            this.binaryTextComboBoxMulticolumn.SelectedIndexFromDropList = -1;
            this.binaryTextComboBoxMulticolumn.ShareCustomMultiColumnSizeAcrossDataListAndFilterGroupingOptionsPane = true;
            this.binaryTextComboBoxMulticolumn.ShouldAllowUserInputWhileProcessingMultiColumnAutoCompleDropDownView = true;
            this.binaryTextComboBoxMulticolumn.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryTextComboBoxMulticolumn.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryTextComboBoxMulticolumn.ShouldDrawExtendedDropdownButton = false;
            this.binaryTextComboBoxMulticolumn.ShouldPersistUserSetColumnWidthsAcrossFilterSessions = false;
            this.binaryTextComboBoxMulticolumn.ShowBorderAlways = true;
            this.binaryTextComboBoxMulticolumn.ShowDropDownMultiColumnWindowAfterAdjustingForVirtualAvaliableScreenSpace = false;
            this.binaryTextComboBoxMulticolumn.ShowEmptyDropListViewWhenThereAreNoData = true;
            this.binaryTextComboBoxMulticolumn.ShowFilterOptionsInMultiColumnMode = false;
            this.binaryTextComboBoxMulticolumn.Size = new System.Drawing.Size(211, 21);
            this.binaryTextComboBoxMulticolumn.SizeForMultiColumnAutoCompleteSuggestionDropDownWindow = new System.Drawing.Size(0, 0);
            this.binaryTextComboBoxMulticolumn.SizesForMultiColumnAutoCompleteSuggestionDropDownWindowColumns = null;
            this.binaryTextComboBoxMulticolumn.TabIndex = 12;
            this.binaryTextComboBoxMulticolumn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxMulticolumn.ValueMember = "ID";
            // 
            // salesdataBindingSource
            // 
            this.salesdataBindingSource.DataMember = "Salesdata";
            this.salesdataBindingSource.DataSource = this.testDataSet;
            // 
            // testDataSet
            // 
            this.testDataSet.DataSetName = "TestDataSet";
            this.testDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // salesdataTableAdapter
            // 
            this.salesdataTableAdapter.ClearBeforeFill = true;
            // 
            // binaryTextComboBoxSinglecolumn
            // 
            this.binaryTextComboBoxSinglecolumn.AlphaBlendFactorForControlPainting = 100;
            this.binaryTextComboBoxSinglecolumn.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryTextComboBoxSinglecolumn.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryTextComboBoxSinglecolumn.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.binaryTextComboBoxSinglecolumn.AutoComplete = true;
            this.binaryTextComboBoxSinglecolumn.AutoCompleteBasedOnCompleteMatchWithAnItemInTheList = false;
            this.binaryTextComboBoxSinglecolumn.AutoCompleteIsCaseSensitive = true;
            this.binaryTextComboBoxSinglecolumn.AutoCompleteStyleForMultiColumnModeIsMultiColumn = false;
            this.binaryTextComboBoxSinglecolumn.BackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSinglecolumn.BuiltinFilterOnNonStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxSinglecolumn.BuiltinFilterOnStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxSinglecolumn.BusyIndicatorText = "Processing...";
            this.binaryTextComboBoxSinglecolumn.ColumnDataTypeFormatInfoContainers = null;
            this.binaryTextComboBoxSinglecolumn.ColumnsToDisplay = null;
            this.binaryTextComboBoxSinglecolumn.ColumnWidths = null;
            this.binaryTextComboBoxSinglecolumn.ComboBoxIsReadOnly = false;
            this.binaryTextComboBoxSinglecolumn.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSinglecolumn.CSVFileSaveAs = "MultiColumnDataViewExport.csv";
            this.binaryTextComboBoxSinglecolumn.CustomColumnNameForAutomaticRowSelection = null;
            this.binaryTextComboBoxSinglecolumn.CustomComparerImplementor = null;
            this.binaryTextComboBoxSinglecolumn.CustomControlBorderColor = System.Drawing.Color.Black;
            this.binaryTextComboBoxSinglecolumn.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSinglecolumn.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSinglecolumn.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this.binaryTextComboBoxSinglecolumn.CustomPaintingColor = System.Drawing.Color.Silver;
            this.binaryTextComboBoxSinglecolumn.DataMember = null;
            this.binaryTextComboBoxSinglecolumn.DataSource = this.salesdataBindingSource1;
            this.binaryTextComboBoxSinglecolumn.DataSourceViewCustomSortingExpression = null;
            this.binaryTextComboBoxSinglecolumn.DesiredFilterColumn = 0;
            this.binaryTextComboBoxSinglecolumn.DisplayMember = "CompanyName";
            this.binaryTextComboBoxSinglecolumn.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryTextComboBoxSinglecolumn.DrawTheControlBasedOnWindowsOS = true;
            this.binaryTextComboBoxSinglecolumn.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSinglecolumn.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxSinglecolumn.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSinglecolumn.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSinglecolumn.DropDownWindowBorderThickness = 1F;
            this.binaryTextComboBoxSinglecolumn.DropDownWindowDisplayOrientation = Binarymission.WinForms.Controls.ListControls.DropDownWindowDisplayOrientation.Default;
            this.binaryTextComboBoxSinglecolumn.DropStyleIsMultiColumn = false;
            this.binaryTextComboBoxSinglecolumn.EnableAlphaBlendingForFilterAndGroupingPanelBackColor = true;
            this.binaryTextComboBoxSinglecolumn.EnableDrawingHeaderFooterWhenInMultiColumnMode = false;
            this.binaryTextComboBoxSinglecolumn.ExtendedDropdownButtonImage = null;
            this.binaryTextComboBoxSinglecolumn.ExtendedDropdownButtonInternalImage = null;
            this.binaryTextComboBoxSinglecolumn.FilterAndGroupingPanelBackColor = System.Drawing.Color.Empty;
            this.binaryTextComboBoxSinglecolumn.FilteringIsON = false;
            this.binaryTextComboBoxSinglecolumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryTextComboBoxSinglecolumn.GroupItemsWhenInMultiColumnDisplayMode = false;
            this.binaryTextComboBoxSinglecolumn.GroupMultiColumnDisplayModeDataBasedOnThisColumn = 0;
            this.binaryTextComboBoxSinglecolumn.HeadersToDisplay = null;
            this.binaryTextComboBoxSinglecolumn.IsAutoCompleteModeAppendSuggestInMultiColumnMode = false;
            this.binaryTextComboBoxSinglecolumn.IsCustomisationOfColumnDisplayEnabledInMultiColumnAutoSuggestMode = false;
            this.binaryTextComboBoxSinglecolumn.IsFilterSearchResultBasedOnColumnDataType = true;
            this.binaryTextComboBoxSinglecolumn.IsInExtendedReadOnlyMode = false;
            this.binaryTextComboBoxSinglecolumn.KeepBindingContextInSyncWithParent = false;
            this.binaryTextComboBoxSinglecolumn.KeepTheFilterAndGroupingViewsCollapsedAtStartUp = true;
            this.binaryTextComboBoxSinglecolumn.KeepTheFilterAndGroupingViewsPaneFullyCollapsedAtStartup = false;
            this.binaryTextComboBoxSinglecolumn.Location = new System.Drawing.Point(15, 375);
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownSize = new System.Drawing.Size(500, 250);
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.ColumnHeaderFont = new System.Drawing.Font("Arial", 12F);
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.ColumnHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.DrawFooter = true;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.FooterCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.FooterSurfaceHeight = 20;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.FooterText = "";
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = null;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.HeaderCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor = System.Drawing.Color.Silver;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.HeaderIcon = null;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.HeaderImageType = Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Icon;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.HeaderSurfaceHeight = 20;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.HeaderText = "";
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropDownWindowConfigurationData.NoDataToDisplayMessageText = "There are no items to display.";
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropListBackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropListFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropListForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropListGridLines = true;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropListHoverSelection = false;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDroplistWindowAnimationStyle = Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
            this.binaryTextComboBoxSinglecolumn.MultiColumnDropListWindowIsResizable = true;
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewBusyProcessingText = "Processing the query... please wait...";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewNoDataFoundText = "There is no data to display.";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewSortingGlyphColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableDataGroupingText = "Enable data grouping";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableFilterOptionsText = "Enable filter options";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemExportDataToCSV = "Export data to CSV";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemShowCommandBarText = "Show command bar";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemBuiltInFilter = "Built-in filter";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemCustomExpression = "Custom expression";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemFilterOnThisColumn = "Filter on this column:";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowItemEnableGrouping = "Enable \"grouping\"";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterDataWhileTheUserTypesExpression = "Filter data while the user types expression?";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpression = "Filter expression:";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionType = "Filter expression type:";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionTypeComboBoxTooltip = resources.GetString("resource.WindowItemFilterExpressionTypeComboBoxTooltip1");
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilteringStatusPart = "Filter status: Filtering is currently using";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowItemGroupOnThisColumn = "Group on this column:";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowItemHideFilterAndGroupingOptions = "Hide filter and grouping options";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowItemShowFilterAndGroupingOptions = "Show filter and grouping options";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowItemUseFilterToRetrieveData = "Use filter to retrieve data";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowStatusBarCustomExpressionErrorMessage = "Invalid custom expression. Please correct.";
            this.binaryTextComboBoxSinglecolumn.MultiColumnViewUIElementsTextProvider.WindowTaskStatusMessageForCSVExportSuccessful = "                Command result: CSV export successful.";
            this.binaryTextComboBoxSinglecolumn.MultiColumnWindowColumnsHorizontalAlignments = ((System.Collections.Generic.IList<System.Windows.Forms.HorizontalAlignment>)(resources.GetObject("binaryTextComboBoxSinglecolumn.MultiColumnWindowColumnsHorizontalAlignments")));
            this.binaryTextComboBoxSinglecolumn.Name = "binaryTextComboBoxSinglecolumn";
            this.binaryTextComboBoxSinglecolumn.SelectedIndexFromDropList = -1;
            this.binaryTextComboBoxSinglecolumn.ShareCustomMultiColumnSizeAcrossDataListAndFilterGroupingOptionsPane = true;
            this.binaryTextComboBoxSinglecolumn.ShouldAllowUserInputWhileProcessingMultiColumnAutoCompleDropDownView = true;
            this.binaryTextComboBoxSinglecolumn.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryTextComboBoxSinglecolumn.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryTextComboBoxSinglecolumn.ShouldDrawExtendedDropdownButton = false;
            this.binaryTextComboBoxSinglecolumn.ShouldPersistUserSetColumnWidthsAcrossFilterSessions = false;
            this.binaryTextComboBoxSinglecolumn.ShowBorderAlways = true;
            this.binaryTextComboBoxSinglecolumn.ShowDropDownMultiColumnWindowAfterAdjustingForVirtualAvaliableScreenSpace = false;
            this.binaryTextComboBoxSinglecolumn.ShowEmptyDropListViewWhenThereAreNoData = true;
            this.binaryTextComboBoxSinglecolumn.ShowFilterOptionsInMultiColumnMode = false;
            this.binaryTextComboBoxSinglecolumn.Size = new System.Drawing.Size(211, 21);
            this.binaryTextComboBoxSinglecolumn.SizeForMultiColumnAutoCompleteSuggestionDropDownWindow = new System.Drawing.Size(0, 0);
            this.binaryTextComboBoxSinglecolumn.SizesForMultiColumnAutoCompleteSuggestionDropDownWindowColumns = null;
            this.binaryTextComboBoxSinglecolumn.TabIndex = 13;
            this.binaryTextComboBoxSinglecolumn.TableToLoad = null;
            this.binaryTextComboBoxSinglecolumn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxSinglecolumn.ValueMember = "ID";
            // 
            // salesdataBindingSource1
            // 
            this.salesdataBindingSource1.DataMember = "Salesdata";
            this.salesdataBindingSource1.DataSource = this.testDataSet1;
            // 
            // testDataSet1
            // 
            this.testDataSet1.DataSetName = "TestDataSet1";
            this.testDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // salesdataTableAdapter1
            // 
            this.salesdataTableAdapter1.ClearBeforeFill = true;
            // 
            // btnClearDatasource
            // 
            this.btnClearDatasource.Location = new System.Drawing.Point(17, 85);
            this.btnClearDatasource.Name = "btnClearDatasource";
            this.btnClearDatasource.Size = new System.Drawing.Size(103, 21);
            this.btnClearDatasource.TabIndex = 14;
            this.btnClearDatasource.Text = "Clear datasource";
            this.btnClearDatasource.UseVisualStyleBackColor = true;
            this.btnClearDatasource.Click += new System.EventHandler(this.btnClearDatasource_Click);
            // 
            // btnResetDatasource
            // 
            this.btnResetDatasource.Location = new System.Drawing.Point(127, 85);
            this.btnResetDatasource.Name = "btnResetDatasource";
            this.btnResetDatasource.Size = new System.Drawing.Size(103, 21);
            this.btnResetDatasource.TabIndex = 15;
            this.btnResetDatasource.Text = "Reset datasource";
            this.btnResetDatasource.UseVisualStyleBackColor = true;
            this.btnResetDatasource.Click += new System.EventHandler(this.btnResetDatasource_Click);
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(14, 274);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(404, 60);
            this.label9.TabIndex = 8;
            this.label9.Text = resources.GetString("label9.Text");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(446, 614);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnResetDatasource);
            this.Controls.Add(this.btnClearDatasource);
            this.Controls.Add(this.binaryTextComboBoxSinglecolumn);
            this.Controls.Add(this.binaryTextComboBoxMulticolumn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.salesdataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesdataBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button1;
        private Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox binaryTextComboBoxMulticolumn;
        private TestDataSet testDataSet;
        private System.Windows.Forms.BindingSource salesdataBindingSource;
        private BinaryComboboxDatabindingSample.TestDataSetTableAdapters.SalesdataTableAdapter salesdataTableAdapter;
        private Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox binaryTextComboBoxSinglecolumn;
        private TestDataSet1 testDataSet1;
        private System.Windows.Forms.BindingSource salesdataBindingSource1;
        private BinaryComboboxDatabindingSample.TestDataSet1TableAdapters.SalesdataTableAdapter salesdataTableAdapter1;
        private System.Windows.Forms.Button btnClearDatasource;
        private System.Windows.Forms.Button btnResetDatasource;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}

