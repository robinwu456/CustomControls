using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryComboboxDatabindingSample
{
    public partial class Form1 : ModernChromeWindow
    {
        public Form1()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"Databinding Demo";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'testDataSet1.Salesdata' table. You can move, or remove it, as needed.
            this.salesdataTableAdapter1.Fill(this.testDataSet1.Salesdata);
            // TODO: This line of code loads data into the 'testDataSet.Salesdata' table. You can move, or remove it, as needed.
            this.salesdataTableAdapter.Fill(this.testDataSet.Salesdata);

            ValueMember = binaryTextComboBoxMulticolumn.ValueMember;
            DisplayMember = binaryTextComboBoxMulticolumn.DisplayMember;            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private string ValueMember = null;
        private string DisplayMember = null;

        private void btnClearDatasource_Click(object sender, EventArgs e)
        {
            ValueMember = binaryTextComboBoxMulticolumn.ValueMember;
            DisplayMember = binaryTextComboBoxMulticolumn.DisplayMember;
            binaryTextComboBoxMulticolumn.DataSource = null;
        }

        private void btnResetDatasource_Click(object sender, EventArgs e)
        {
            // When re-setting the control's data source, please ensure to re-set the control's valueMember and DisplayMember properties
            // to null, and then again set to the appropriate values.
            binaryTextComboBoxMulticolumn.DataSource = null;
            binaryTextComboBoxMulticolumn.DataSource = salesdataBindingSource;
            binaryTextComboBoxMulticolumn.ValueMember = ValueMember;
            binaryTextComboBoxMulticolumn.DisplayMember = DisplayMember;
            
        }

    }
}