﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryComboBoxExtendedUIDemo
{
    public partial class Form1 : ModernChromeWindow
    {
        private const string FilesFilter = "Image Files (*.bmp, *.jpg, *.png)|*.bmp;*.jpg;*.png";
        public Form1()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"Extended UI Demo";

            openFileDialog1.Filter = FilesFilter;
            binaryTextComboBox1.SelectedIndex = 0;
            binaryTextComboBox1.SelectionLength = 0;
            binaryTextComboBox1.ShouldDrawExtendedDropdownButton = chkUseExtendedComboboxButtonRendering.Checked;
            btnSetCustomDropdownArrowImage.Enabled = chkUseExtendedComboboxButtonRendering.Checked &&
                                                     chkUseCustomImageForArrow.Checked;
            btnSetCustomDropdownImage.Enabled = chkUseExtendedComboboxButtonRendering.Checked && chkUseCustomImageAsDropdownForCombobox.Checked;

            chkUseCustomImageAsDropdownForCombobox.Enabled = chkUseCustomImageForArrow.Enabled = chkUseExtendedComboboxButtonRendering.Checked;
            
            btnOK.Select();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            var checkBoxInstanceState = (sender as CheckBox).Checked;
            binaryTextComboBox1.ShouldDrawExtendedDropdownButton = checkBoxInstanceState;
            btnSetCustomDropdownArrowImage.Enabled = checkBoxInstanceState && chkUseCustomImageForArrow.Checked;
            btnSetCustomDropdownImage.Enabled = checkBoxInstanceState && chkUseCustomImageAsDropdownForCombobox.Checked;
            chkUseCustomImageAsDropdownForCombobox.Enabled = checkBoxInstanceState;
            chkUseCustomImageForArrow.Enabled = checkBoxInstanceState;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                binaryTextComboBox1.ExtendedDropdownButtonInternalImage = new Bitmap(openFileDialog1.FileName);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                binaryTextComboBox1.ExtendedDropdownButtonImage = new Bitmap(openFileDialog1.FileName);
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            btnSetCustomDropdownImage.Enabled = chkUseCustomImageAsDropdownForCombobox.Checked;
            binaryTextComboBox1.ExtendedDropdownButtonImage = null;

            if (chkUseCustomImageAsDropdownForCombobox.Checked)
            {
                chkUseCustomImageForArrow.Checked = !chkUseCustomImageAsDropdownForCombobox.Checked;
            }

            binaryTextComboBox1.ExtendedDropdownButtonInternalImage = null;
        }

        private void chkUseCustomImageForArrow_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBox1.ExtendedDropdownButtonImage = null;

            if (chkUseCustomImageForArrow.Checked)
            {
                chkUseCustomImageAsDropdownForCombobox.Checked = !chkUseCustomImageForArrow.Checked;
            }

            binaryTextComboBox1.ExtendedDropdownButtonInternalImage = null;

            btnSetCustomDropdownArrowImage.Enabled = (sender as CheckBox).Checked && chkUseExtendedComboboxButtonRendering.Checked;
        }
    }
}
