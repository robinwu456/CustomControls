﻿namespace BinaryComboBoxExtendedUIDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnOK = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkUseCustomImageForArrow = new System.Windows.Forms.CheckBox();
            this.chkUseCustomImageAsDropdownForCombobox = new System.Windows.Forms.CheckBox();
            this.btnSetCustomDropdownImage = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSetCustomDropdownArrowImage = new System.Windows.Forms.Button();
            this.chkUseExtendedComboboxButtonRendering = new System.Windows.Forms.CheckBox();
            this.binaryTextComboBox1 = new Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(110, 324);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(122, 35);
            this.btnOK.TabIndex = 2;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "BinaryCombbox .NET";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkUseCustomImageForArrow);
            this.groupBox1.Controls.Add(this.chkUseCustomImageAsDropdownForCombobox);
            this.groupBox1.Controls.Add(this.btnSetCustomDropdownImage);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btnSetCustomDropdownArrowImage);
            this.groupBox1.Controls.Add(this.chkUseExtendedComboboxButtonRendering);
            this.groupBox1.Location = new System.Drawing.Point(23, 85);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(290, 216);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Combobox New Gui Options";
            // 
            // chkUseCustomImageForArrow
            // 
            this.chkUseCustomImageForArrow.AutoSize = true;
            this.chkUseCustomImageForArrow.Location = new System.Drawing.Point(11, 91);
            this.chkUseCustomImageForArrow.Name = "chkUseCustomImageForArrow";
            this.chkUseCustomImageForArrow.Size = new System.Drawing.Size(210, 17);
            this.chkUseCustomImageForArrow.TabIndex = 9;
            this.chkUseCustomImageForArrow.Text = "Use custom image for dropdown arrow:";
            this.chkUseCustomImageForArrow.UseVisualStyleBackColor = true;
            this.chkUseCustomImageForArrow.CheckedChanged += new System.EventHandler(this.chkUseCustomImageForArrow_CheckedChanged);
            // 
            // chkUseCustomImageAsDropdownForCombobox
            // 
            this.chkUseCustomImageAsDropdownForCombobox.AutoSize = true;
            this.chkUseCustomImageAsDropdownForCombobox.Location = new System.Drawing.Point(11, 157);
            this.chkUseCustomImageAsDropdownForCombobox.Name = "chkUseCustomImageAsDropdownForCombobox";
            this.chkUseCustomImageAsDropdownForCombobox.Size = new System.Drawing.Size(248, 17);
            this.chkUseCustomImageAsDropdownForCombobox.TabIndex = 8;
            this.chkUseCustomImageAsDropdownForCombobox.Text = "Use custom image for dropdown button section";
            this.chkUseCustomImageAsDropdownForCombobox.UseVisualStyleBackColor = true;
            this.chkUseCustomImageAsDropdownForCombobox.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // btnSetCustomDropdownImage
            // 
            this.btnSetCustomDropdownImage.Location = new System.Drawing.Point(10, 177);
            this.btnSetCustomDropdownImage.Name = "btnSetCustomDropdownImage";
            this.btnSetCustomDropdownImage.Size = new System.Drawing.Size(229, 26);
            this.btnSetCustomDropdownImage.TabIndex = 7;
            this.btnSetCustomDropdownImage.Text = "Browse custom dropdown button image...";
            this.btnSetCustomDropdownImage.UseVisualStyleBackColor = true;
            this.btnSetCustomDropdownImage.Click += new System.EventHandler(this.button3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Set custom arrow image:";
            // 
            // btnSetCustomDropdownArrowImage
            // 
            this.btnSetCustomDropdownArrowImage.Location = new System.Drawing.Point(10, 113);
            this.btnSetCustomDropdownArrowImage.Name = "btnSetCustomDropdownArrowImage";
            this.btnSetCustomDropdownArrowImage.Size = new System.Drawing.Size(179, 26);
            this.btnSetCustomDropdownArrowImage.TabIndex = 2;
            this.btnSetCustomDropdownArrowImage.Text = "Browse custom arrow image...";
            this.btnSetCustomDropdownArrowImage.UseVisualStyleBackColor = true;
            this.btnSetCustomDropdownArrowImage.Click += new System.EventHandler(this.button2_Click);
            // 
            // chkUseExtendedComboboxButtonRendering
            // 
            this.chkUseExtendedComboboxButtonRendering.AutoSize = true;
            this.chkUseExtendedComboboxButtonRendering.Location = new System.Drawing.Point(10, 25);
            this.chkUseExtendedComboboxButtonRendering.Name = "chkUseExtendedComboboxButtonRendering";
            this.chkUseExtendedComboboxButtonRendering.Size = new System.Drawing.Size(179, 17);
            this.chkUseExtendedComboboxButtonRendering.TabIndex = 0;
            this.chkUseExtendedComboboxButtonRendering.Text = "Use Extended Dropdown Button";
            this.chkUseExtendedComboboxButtonRendering.UseVisualStyleBackColor = true;
            this.chkUseExtendedComboboxButtonRendering.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // binaryTextComboBox1
            // 
            this.binaryTextComboBox1.AlphaBlendFactorForControlPainting = 100;
            this.binaryTextComboBox1.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryTextComboBox1.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryTextComboBox1.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.binaryTextComboBox1.AutoComplete = true;
            this.binaryTextComboBox1.AutoCompleteBasedOnCompleteMatchWithAnItemInTheList = false;
            this.binaryTextComboBox1.AutoCompleteIsCaseSensitive = true;
            this.binaryTextComboBox1.AutoCompleteStyleForMultiColumnModeIsMultiColumn = false;
            this.binaryTextComboBox1.BackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBox1.BuiltinFilterOnNonStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBox1.BuiltinFilterOnStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBox1.BusyIndicatorText = "Processing...";
            this.binaryTextComboBox1.ColumnDataTypeFormatInfoContainers = null;
            this.binaryTextComboBox1.ColumnsToDisplay = null;
            this.binaryTextComboBox1.ColumnWidths = null;
            this.binaryTextComboBox1.ComboBoxIsReadOnly = false;
            this.binaryTextComboBox1.ControlArrowColor = System.Drawing.Color.Black;
            this.binaryTextComboBox1.CSVFileSaveAs = "MultiColumnDataViewExport.csv";
            this.binaryTextComboBox1.CustomColumnNameForAutomaticRowSelection = null;
            this.binaryTextComboBox1.CustomComparerImplementor = null;
            this.binaryTextComboBox1.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryTextComboBox1.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBox1.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBox1.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this.binaryTextComboBox1.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryTextComboBox1.DataMember = null;
            this.binaryTextComboBox1.DataSourceViewCustomSortingExpression = null;
            this.binaryTextComboBox1.DesiredFilterColumn = 0;
            this.binaryTextComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryTextComboBox1.DrawTheControlBasedOnWindowsOS = true;
            this.binaryTextComboBox1.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBox1.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBox1.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBox1.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBox1.DropDownWindowBorderThickness = 1F;
            this.binaryTextComboBox1.DropDownWindowDisplayOrientation = Binarymission.WinForms.Controls.ListControls.DropDownWindowDisplayOrientation.Default;
            this.binaryTextComboBox1.DropStyleIsMultiColumn = false;
            this.binaryTextComboBox1.EnableAlphaBlendingForFilterAndGroupingPanelBackColor = true;
            this.binaryTextComboBox1.EnableDrawingHeaderFooterWhenInMultiColumnMode = false;
            this.binaryTextComboBox1.ExtendedDropdownButtonImage = null;
            this.binaryTextComboBox1.ExtendedDropdownButtonInternalImage = null;
            this.binaryTextComboBox1.FilterAndGroupingPanelBackColor = System.Drawing.Color.Empty;
            this.binaryTextComboBox1.FilteringIsON = false;
            this.binaryTextComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryTextComboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBox1.GroupItemsWhenInMultiColumnDisplayMode = false;
            this.binaryTextComboBox1.GroupMultiColumnDisplayModeDataBasedOnThisColumn = 0;
            this.binaryTextComboBox1.HeadersToDisplay = null;
            this.binaryTextComboBox1.IsAutoCompleteModeAppendSuggestInMultiColumnMode = false;
            this.binaryTextComboBox1.IsCustomisationOfColumnDisplayEnabledInMultiColumnAutoSuggestMode = false;
            this.binaryTextComboBox1.IsFilterSearchResultBasedOnColumnDataType = true;
            this.binaryTextComboBox1.IsInExtendedReadOnlyMode = false;
            this.binaryTextComboBox1.Items.AddRange(new object[] {
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday"});
            this.binaryTextComboBox1.KeepBindingContextInSyncWithParent = false;
            this.binaryTextComboBox1.KeepTheFilterAndGroupingViewsCollapsedAtStartUp = true;
            this.binaryTextComboBox1.KeepTheFilterAndGroupingViewsPaneFullyCollapsedAtStartup = false;
            this.binaryTextComboBox1.Location = new System.Drawing.Point(25, 36);
            this.binaryTextComboBox1.MultiColumnDropDownSize = new System.Drawing.Size(500, 250);
            this.binaryTextComboBox1.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.ColumnHeaderFont = new System.Drawing.Font("Arial", 12F);
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.ColumnHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.DrawFooter = true;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.FooterCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.FooterSurfaceHeight = 20;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.FooterText = "";
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = null;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor = System.Drawing.Color.Empty;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderIcon = null;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderImageType = Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Icon;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderSurfaceHeight = 20;
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.HeaderText = "";
            this.binaryTextComboBox1.MultiColumnDropDownWindowConfigurationData.NoDataToDisplayMessageText = "There are no items to display.";
            this.binaryTextComboBox1.MultiColumnDropListBackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBox1.MultiColumnDropListFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBox1.MultiColumnDropListForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBox1.MultiColumnDropListGridLines = true;
            this.binaryTextComboBox1.MultiColumnDropListHoverSelection = false;
            this.binaryTextComboBox1.MultiColumnDroplistWindowAnimationStyle = Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
            this.binaryTextComboBox1.MultiColumnDropListWindowIsResizable = true;
            this.binaryTextComboBox1.MultiColumnViewBusyProcessingText = "Processing the query... please wait...";
            this.binaryTextComboBox1.MultiColumnViewNoDataFoundText = "There is no data to display.";
            this.binaryTextComboBox1.MultiColumnViewSortingGlyphColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableDataGroupingText = "Enable data grouping";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableFilterOptionsText = "Enable filter options";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.ContextMenuItemExportDataToCSV = "Export data to CSV";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.ContextMenuItemShowCommandBarText = "Show command bar";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemBuiltInFilter = "Built-in filter";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemCustomExpression = "Custom expression";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemFilterOnThisColumn = "Filter on this column:";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemEnableGrouping = "Enable \"grouping\"";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemFilterDataWhileTheUserTypesExpression = "Filter data while the user types expression?";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpression = "Filter expression:";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionType = "Filter expression type:";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionTypeComboBoxTooltip = resources.GetString("resource.WindowItemFilterExpressionTypeComboBoxTooltip");
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemFilteringStatusPart = "Filter status: Filtering is currently using";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemGroupOnThisColumn = "Group on this column:";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemHideFilterAndGroupingOptions = "Hide filter and grouping options";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemShowFilterAndGroupingOptions = "Show filter and grouping options";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowItemUseFilterToRetrieveData = "Use filter to retrieve data";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowStatusBarCustomExpressionErrorMessage = "Invalid custom expression. Please correct.";
            this.binaryTextComboBox1.MultiColumnViewUIElementsTextProvider.WindowTaskStatusMessageForCSVExportSuccessful = "                Command result: CSV export successful.";
            this.binaryTextComboBox1.MultiColumnWindowColumnsHorizontalAlignments = ((System.Collections.Generic.IList<System.Windows.Forms.HorizontalAlignment>)(resources.GetObject("binaryTextComboBox1.MultiColumnWindowColumnsHorizontalAlignments")));
            this.binaryTextComboBox1.Name = "binaryTextComboBox1";
            this.binaryTextComboBox1.SelectedIndexFromDropList = -1;
            this.binaryTextComboBox1.ShareCustomMultiColumnSizeAcrossDataListAndFilterGroupingOptionsPane = true;
            this.binaryTextComboBox1.ShouldAllowUserInputWhileProcessingMultiColumnAutoCompleDropDownView = true;
            this.binaryTextComboBox1.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryTextComboBox1.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryTextComboBox1.ShouldDrawExtendedDropdownButton = false;
            this.binaryTextComboBox1.ShouldPersistUserSetColumnWidthsAcrossFilterSessions = false;
            this.binaryTextComboBox1.ShowBorderAlways = true;
            this.binaryTextComboBox1.ShowDropDownMultiColumnWindowAfterAdjustingForVirtualAvaliableScreenSpace = true;
            this.binaryTextComboBox1.ShowEmptyDropListViewWhenThereAreNoData = true;
            this.binaryTextComboBox1.ShowFilterOptionsInMultiColumnMode = true;
            this.binaryTextComboBox1.Size = new System.Drawing.Size(288, 23);
            this.binaryTextComboBox1.SizeForMultiColumnAutoCompleteSuggestionDropDownWindow = new System.Drawing.Size(0, 0);
            this.binaryTextComboBox1.SizesForMultiColumnAutoCompleteSuggestionDropDownWindowColumns = null;
            this.binaryTextComboBox1.TabIndex = 1;
            this.binaryTextComboBox1.TableToLoad = null;
            this.binaryTextComboBox1.Text = "binaryTextComboBox1";
            this.binaryTextComboBox1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(339, 408);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.binaryTextComboBox1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox binaryTextComboBox1;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkUseExtendedComboboxButtonRendering;
        private System.Windows.Forms.Button btnSetCustomDropdownImage;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSetCustomDropdownArrowImage;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.CheckBox chkUseCustomImageAsDropdownForCombobox;
        private System.Windows.Forms.CheckBox chkUseCustomImageForArrow;
    }
}

