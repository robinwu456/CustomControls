namespace BinaryImageComboboxColorCustomisationSample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.binaryColorPickerComboBoxRectangleColorAroundImage = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBoxDropdownWindowBackcolor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxDropdownArrowColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxPainting = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxBorder = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxForecolor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxBackcolor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.numericUpDownForItemSelection = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownForDropdownPressed = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownForPainting = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.binaryImageComboBox1 = new Binarymission.WinForms.Controls.ListControls.BinaryImageComboBox();
            this.tasklistBindingSource = new System.Windows.Forms.BindingSource();
            this.tasksDataSet = new BinaryImageComboboxColorCustomisationSample.TasksDataSet();
            this.imageList1 = new System.Windows.Forms.ImageList();
            this.tasklistTableAdapter = new BinaryImageComboboxColorCustomisationSample.TasksDataSetTableAdapters.TasklistTableAdapter();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForItemSelection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForDropdownPressed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForPainting)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tasklistBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tasksDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "BinaryImageCombobox";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(23, 126);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(98, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "Color customisation";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.binaryColorPickerComboBoxRectangleColorAroundImage);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.binaryColorPickerComboBoxDropdownWindowBackcolor);
            this.panel1.Controls.Add(this.binaryColorPickerComboBoxDropdownArrowColor);
            this.panel1.Controls.Add(this.binaryColorPickerComboBoxPainting);
            this.panel1.Controls.Add(this.binaryColorPickerComboBoxBorder);
            this.panel1.Controls.Add(this.binaryColorPickerComboBoxForecolor);
            this.panel1.Controls.Add(this.binaryColorPickerComboBoxBackcolor);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(26, 149);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(377, 204);
            this.panel1.TabIndex = 23;
            // 
            // binaryColorPickerComboBoxRectangleColorAroundImage
            // 
            this.binaryColorPickerComboBoxRectangleColorAroundImage.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.FormattingEnabled = true;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxRectangleColorAroundImage.Location = new System.Drawing.Point(217, 171);
            this.binaryColorPickerComboBoxRectangleColorAroundImage.Name = "binaryColorPickerComboBoxRectangleColorAroundImage";
            this.binaryColorPickerComboBoxRectangleColorAroundImage.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.Size = new System.Drawing.Size(135, 21);
            this.binaryColorPickerComboBoxRectangleColorAroundImage.TabIndex = 17;
            this.binaryColorPickerComboBoxRectangleColorAroundImage.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxRectangleColorAroundImage_SelectedColorChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 175);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(193, 13);
            this.label13.TabIndex = 16;
            this.label13.Text = "Color of the rectangle around the image";
            // 
            // binaryColorPickerComboBoxDropdownWindowBackcolor
            // 
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.Location = new System.Drawing.Point(217, 144);
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.Name = "binaryColorPickerComboBoxDropdownWindowBackcolor";
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.Size = new System.Drawing.Size(135, 21);
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.TabIndex = 15;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxDropdownWindowBackcolor_SelectedColorChanged);
            // 
            // binaryColorPickerComboBoxDropdownArrowColor
            // 
            this.binaryColorPickerComboBoxDropdownArrowColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxDropdownArrowColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxDropdownArrowColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxDropdownArrowColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxDropdownArrowColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxDropdownArrowColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxDropdownArrowColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxDropdownArrowColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxDropdownArrowColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxDropdownArrowColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxDropdownArrowColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxDropdownArrowColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxDropdownArrowColor.Location = new System.Drawing.Point(217, 117);
            this.binaryColorPickerComboBoxDropdownArrowColor.Name = "binaryColorPickerComboBoxDropdownArrowColor";
            this.binaryColorPickerComboBoxDropdownArrowColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxDropdownArrowColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxDropdownArrowColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxDropdownArrowColor.Size = new System.Drawing.Size(135, 21);
            this.binaryColorPickerComboBoxDropdownArrowColor.TabIndex = 14;
            this.binaryColorPickerComboBoxDropdownArrowColor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxDropdownArrowColor_SelectedColorChanged);
            // 
            // binaryColorPickerComboBoxPainting
            // 
            this.binaryColorPickerComboBoxPainting.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxPainting.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxPainting.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxPainting.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxPainting.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxPainting.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxPainting.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxPainting.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxPainting.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxPainting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxPainting.FormattingEnabled = true;
            this.binaryColorPickerComboBoxPainting.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxPainting.Location = new System.Drawing.Point(217, 90);
            this.binaryColorPickerComboBoxPainting.Name = "binaryColorPickerComboBoxPainting";
            this.binaryColorPickerComboBoxPainting.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxPainting.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxPainting.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxPainting.Size = new System.Drawing.Size(135, 21);
            this.binaryColorPickerComboBoxPainting.TabIndex = 13;
            this.binaryColorPickerComboBoxPainting.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxPainting_SelectedColorChanged);
            // 
            // binaryColorPickerComboBoxBorder
            // 
            this.binaryColorPickerComboBoxBorder.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxBorder.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxBorder.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxBorder.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxBorder.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxBorder.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxBorder.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxBorder.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxBorder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxBorder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxBorder.FormattingEnabled = true;
            this.binaryColorPickerComboBoxBorder.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxBorder.Location = new System.Drawing.Point(217, 63);
            this.binaryColorPickerComboBoxBorder.Name = "binaryColorPickerComboBoxBorder";
            this.binaryColorPickerComboBoxBorder.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxBorder.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxBorder.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxBorder.Size = new System.Drawing.Size(135, 21);
            this.binaryColorPickerComboBoxBorder.TabIndex = 12;
            this.binaryColorPickerComboBoxBorder.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxBorder_SelectedColorChanged);
            // 
            // binaryColorPickerComboBoxForecolor
            // 
            this.binaryColorPickerComboBoxForecolor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxForecolor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxForecolor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxForecolor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxForecolor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxForecolor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxForecolor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxForecolor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxForecolor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxForecolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxForecolor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxForecolor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxForecolor.Location = new System.Drawing.Point(217, 36);
            this.binaryColorPickerComboBoxForecolor.Name = "binaryColorPickerComboBoxForecolor";
            this.binaryColorPickerComboBoxForecolor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxForecolor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxForecolor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxForecolor.Size = new System.Drawing.Size(135, 21);
            this.binaryColorPickerComboBoxForecolor.TabIndex = 11;
            this.binaryColorPickerComboBoxForecolor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxForecolor_SelectedColorChanged);
            // 
            // binaryColorPickerComboBoxBackcolor
            // 
            this.binaryColorPickerComboBoxBackcolor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxBackcolor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxBackcolor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxBackcolor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxBackcolor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxBackcolor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxBackcolor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxBackcolor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxBackcolor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxBackcolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxBackcolor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxBackcolor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxBackcolor.Location = new System.Drawing.Point(217, 9);
            this.binaryColorPickerComboBoxBackcolor.Name = "binaryColorPickerComboBoxBackcolor";
            this.binaryColorPickerComboBoxBackcolor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxBackcolor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxBackcolor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxBackcolor.Size = new System.Drawing.Size(135, 21);
            this.binaryColorPickerComboBoxBackcolor.TabIndex = 10;
            this.binaryColorPickerComboBoxBackcolor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxBackcolor_SelectedColorChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 148);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(181, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Dropdown window background color";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(145, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Control dropdown arrow color";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Control painting color";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Control border color";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Control Forecolor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Control Backcolor";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(346, 536);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(58, 21);
            this.button1.TabIndex = 27;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(24, 389);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 13);
            this.label12.TabIndex = 26;
            this.label12.Text = "Alphablend color factor";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.numericUpDownForItemSelection);
            this.panel2.Controls.Add(this.numericUpDownForDropdownPressed);
            this.panel2.Controls.Add(this.numericUpDownForPainting);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(27, 412);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(377, 94);
            this.panel2.TabIndex = 25;
            // 
            // numericUpDownForItemSelection
            // 
            this.numericUpDownForItemSelection.Location = new System.Drawing.Point(235, 62);
            this.numericUpDownForItemSelection.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownForItemSelection.Name = "numericUpDownForItemSelection";
            this.numericUpDownForItemSelection.Size = new System.Drawing.Size(132, 20);
            this.numericUpDownForItemSelection.TabIndex = 20;
            this.numericUpDownForItemSelection.Value = new decimal(new int[] {
            70,
            0,
            0,
            0});
            this.numericUpDownForItemSelection.ValueChanged += new System.EventHandler(this.numericUpDownForItemSelection_ValueChanged);
            // 
            // numericUpDownForDropdownPressed
            // 
            this.numericUpDownForDropdownPressed.Location = new System.Drawing.Point(235, 36);
            this.numericUpDownForDropdownPressed.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownForDropdownPressed.Name = "numericUpDownForDropdownPressed";
            this.numericUpDownForDropdownPressed.Size = new System.Drawing.Size(132, 20);
            this.numericUpDownForDropdownPressed.TabIndex = 19;
            this.numericUpDownForDropdownPressed.Value = new decimal(new int[] {
            70,
            0,
            0,
            0});
            this.numericUpDownForDropdownPressed.ValueChanged += new System.EventHandler(this.numericUpDownForDropdownPressed_ValueChanged);
            // 
            // numericUpDownForPainting
            // 
            this.numericUpDownForPainting.Location = new System.Drawing.Point(235, 10);
            this.numericUpDownForPainting.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownForPainting.Name = "numericUpDownForPainting";
            this.numericUpDownForPainting.Size = new System.Drawing.Size(132, 20);
            this.numericUpDownForPainting.TabIndex = 18;
            this.numericUpDownForPainting.Value = new decimal(new int[] {
            135,
            0,
            0,
            0});
            this.numericUpDownForPainting.ValueChanged += new System.EventHandler(this.numericUpDownForPainting_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 64);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(198, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Alphablend factor for item selection color";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(180, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Alphablend factor for control painting";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 41);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(218, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Alphablend factor for dropdownpressed color";
            // 
            // binaryImageComboBox1
            // 
            this.binaryImageComboBox1.AlphaBlendFactorForControlPainting = 100;
            this.binaryImageComboBox1.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryImageComboBox1.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryImageComboBox1.BackColor = System.Drawing.SystemColors.Window;
            this.binaryImageComboBox1.Bitmaps = null;
            this.binaryImageComboBox1.BitmapsAssociatedText = null;
            this.binaryImageComboBox1.ColorForDrawingRectangleAroundImage = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBox1.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryImageComboBox1.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBox1.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryImageComboBox1.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryImageComboBox1.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryImageComboBox1.DataSource = this.tasklistBindingSource;
            this.binaryImageComboBox1.DesiredHeightForDrawingTheImages = 32;
            this.binaryImageComboBox1.DesiredWidthForDrawingTheImages = 32;
            this.binaryImageComboBox1.DisplayMember = "Taskname";
            this.binaryImageComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryImageComboBox1.DrawRectangleAroundImage = true;
            this.binaryImageComboBox1.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryImageComboBox1.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryImageComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryImageComboBox1.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryImageComboBox1.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryImageComboBox1.DropDownWindowBorderThickness = 1F;
            this.binaryImageComboBox1.ExtendedDropdownButtonImage = null;
            this.binaryImageComboBox1.ExtendedDropdownButtonInternalImage = null;
            this.binaryImageComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryImageComboBox1.FormattingEnabled = true;
            this.binaryImageComboBox1.Imagelist = this.imageList1;
            this.binaryImageComboBox1.IsInExtendedReadOnlyMode = false;
            this.binaryImageComboBox1.ItemHeight = 36;
            this.binaryImageComboBox1.Location = new System.Drawing.Point(26, 37);
            this.binaryImageComboBox1.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryImageComboBox1.MultiColumnWindowColumnsHorizontalAlignments = null;
            this.binaryImageComboBox1.Name = "binaryImageComboBox1";
            this.binaryImageComboBox1.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryImageComboBox1.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryImageComboBox1.ShouldDrawExtendedDropdownButton = false;
            this.binaryImageComboBox1.ShowBorderAlways = true;
            this.binaryImageComboBox1.Size = new System.Drawing.Size(305, 42);
            this.binaryImageComboBox1.TabIndex = 28;
            this.binaryImageComboBox1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryImageComboBox1.UseImageListForComboBox = true;
            this.binaryImageComboBox1.ValueMember = "Id";
            // 
            // tasklistBindingSource
            // 
            this.tasklistBindingSource.DataMember = "Tasklist";
            this.tasklistBindingSource.DataSource = this.tasksDataSet;
            // 
            // tasksDataSet
            // 
            this.tasksDataSet.DataSetName = "TasksDataSet";
            this.tasksDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "bill_mail-attach.png");
            this.imageList1.Images.SetKeyName(1, "card-print.png");
            this.imageList1.Images.SetKeyName(2, "history.png");
            this.imageList1.Images.SetKeyName(3, "phone.png");
            // 
            // tasklistTableAdapter
            // 
            this.tasklistTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(431, 604);
            this.Controls.Add(this.binaryImageComboBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForItemSelection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForDropdownPressed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForPainting)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tasklistBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tasksDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.NumericUpDown numericUpDownForItemSelection;
        private System.Windows.Forms.NumericUpDown numericUpDownForDropdownPressed;
        private System.Windows.Forms.NumericUpDown numericUpDownForPainting;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private Binarymission.WinForms.Controls.ListControls.BinaryImageComboBox binaryImageComboBox1;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxDropdownWindowBackcolor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxDropdownArrowColor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxPainting;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxBorder;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxForecolor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxBackcolor;
        private System.Windows.Forms.ImageList imageList1;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxRectangleColorAroundImage;
        private System.Windows.Forms.Label label13;
        private TasksDataSet tasksDataSet;
        private System.Windows.Forms.BindingSource tasklistBindingSource;
        private BinaryImageComboboxColorCustomisationSample.TasksDataSetTableAdapters.TasklistTableAdapter tasklistTableAdapter;
    }
}

