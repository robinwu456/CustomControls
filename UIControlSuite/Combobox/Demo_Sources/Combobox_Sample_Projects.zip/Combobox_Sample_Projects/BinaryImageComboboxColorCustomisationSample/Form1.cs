using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryImageComboboxColorCustomisationSample
{
    public partial class Form1 : ModernChromeWindow
    {
        public Form1()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"Image Combobox Demo";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'tasksDataSet.Tasklist' table. You can move, or remove it, as needed.
            this.tasklistTableAdapter.Fill(this.tasksDataSet.Tasklist);
            RetrievePresets();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void binaryColorPickerComboBoxBackcolor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryImageComboBox1.BackColor =
                binaryColorPickerComboBoxBackcolor.SelectedColor;
        }

        private void binaryColorPickerComboBoxForecolor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryImageComboBox1.ForeColor =
                binaryColorPickerComboBoxForecolor.SelectedColor;
        }

        private void binaryColorPickerComboBoxBorder_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryImageComboBox1.CustomControlBorderColor =
                binaryColorPickerComboBoxBorder.SelectedColor;
        }

        private void binaryColorPickerComboBoxPainting_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryImageComboBox1.CustomPaintingColor =
                binaryColorPickerComboBoxPainting.SelectedColor;
        }

        private void binaryColorPickerComboBoxDropdownArrowColor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryImageComboBox1.ControlArrowColor =
                binaryColorPickerComboBoxDropdownArrowColor.SelectedColor;
        }

        private void binaryColorPickerComboBoxDropdownWindowBackcolor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryImageComboBox1.DropDownWindowBackgroundColor =
                binaryColorPickerComboBoxDropdownWindowBackcolor.SelectedColor;
        }

        private void binaryColorPickerComboBoxRectangleColorAroundImage_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryImageComboBox1.ColorForDrawingRectangleAroundImage =
                binaryColorPickerComboBoxRectangleColorAroundImage.SelectedColor;
        }

        private void RetrievePresets()
        {
            binaryColorPickerComboBoxBackcolor.SelectedColor =
                binaryImageComboBox1.BackColor;

            binaryColorPickerComboBoxForecolor.SelectedColor =
                binaryImageComboBox1.ForeColor;

            binaryColorPickerComboBoxBorder.SelectedColor = 
                binaryImageComboBox1.CustomControlBorderColor;

            binaryColorPickerComboBoxPainting.SelectedColor =
                binaryImageComboBox1.CustomPaintingColor;

            binaryColorPickerComboBoxDropdownArrowColor.SelectedColor =
                binaryImageComboBox1.ControlArrowColor;

            binaryColorPickerComboBoxDropdownWindowBackcolor.SelectedColor =
                binaryImageComboBox1.DropDownWindowBackgroundColor;

            binaryColorPickerComboBoxRectangleColorAroundImage.SelectedColor =
                binaryImageComboBox1.ColorForDrawingRectangleAroundImage;
        }

        private void numericUpDownForPainting_ValueChanged(object sender, EventArgs e)
        {
            binaryImageComboBox1.AlphaBlendFactorForControlPainting =
                Convert.ToInt32(numericUpDownForPainting.Value);
        }

        private void numericUpDownForDropdownPressed_ValueChanged(object sender, EventArgs e)
        {
            binaryImageComboBox1.AlphaBlendFactorForDropDownPressedColor =
                Convert.ToInt32(numericUpDownForDropdownPressed.Value);
        }

        private void numericUpDownForItemSelection_ValueChanged(object sender, EventArgs e)
        {
            binaryImageComboBox1.AlphaBlendFactorForItemSelectionColor =
                Convert.ToInt32(numericUpDownForItemSelection.Value);
        }

    }
}