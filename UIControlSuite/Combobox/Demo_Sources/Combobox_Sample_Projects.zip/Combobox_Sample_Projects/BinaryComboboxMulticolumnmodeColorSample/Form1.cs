using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryComboboxMulticolumnmodeColorCustomisationSample
{
    public partial class Form1 : ModernChromeWindow
    {
        public Form1()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"Multi-column Demo";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'customersTestDataSet.Customers' table. You can move, or remove it, as needed.
            this.customersTableAdapter.Fill(this.customersTestDataSet.Customers);
            RetrievePresets();

        }

        private void binaryColorPickerComboBoxBackColor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.BackColor =
                binaryColorPickerComboBoxBackColor.SelectedColor;           

        }

        private void binaryColorPickerComboBoxForecolor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.ForeColor =
                binaryColorPickerComboBoxForecolor.SelectedColor;
        }

        private void binaryColorPickerComboBoxBorderColor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.CustomControlBorderColor =
                binaryColorPickerComboBoxBorderColor.SelectedColor;
        }

        private void binaryColorPickerComboBoxPaintingColor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.CustomPaintingColor =
                binaryColorPickerComboBoxPaintingColor.SelectedColor;
        }

        private void binaryColorPickerComboBoxDropdownArrowColor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.ControlArrowColor =
                binaryColorPickerComboBoxDropdownArrowColor.SelectedColor;
        }

        private void binaryColorPickerComboBoxDropdownWindowBackcolor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.MultiColumnDropListBackColor = 
                binaryColorPickerComboBoxDropdownWindowBackcolor.SelectedColor;
             
        }

        private void binaryColorPickerComboBoxDropdownWindowForecolor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.MultiColumnDropListForeColor =
                binaryColorPickerComboBoxDropdownWindowForecolor.SelectedColor;
        }

        private void binaryColorPickerComboBoxHeaderStartColor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor =
                binaryColorPickerComboBoxHeaderStartColor.SelectedColor;
        }

        private void binaryColorPickerComboBoxHeaderEndColor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor =
                binaryColorPickerComboBoxHeaderEndColor.SelectedColor;
        }

        private void binaryColorPickerComboBoxHeaderFooterForecolor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor =
                binaryColorPickerComboBoxHeaderFooterForecolor.SelectedColor;
        }

        private void binaryColorPickerComboBoxSortingGlyphColor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.MultiColumnViewSortingGlyphColor =
                binaryColorPickerComboBoxSortingGlyphColor.SelectedColor;
        }

        private void binaryColorPickerComboBoxFilterGroupingPanelBackcolor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.FilterAndGroupingPanelBackColor =
                binaryColorPickerComboBoxFilterGroupingPanelBackcolor.SelectedColor;
        }

        private void numericUpDownForPainting_ValueChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.AlphaBlendFactorForControlPainting =
                Convert.ToInt32(numericUpDownForPainting.Value);
        }

        private void numericUpDownForDropdownPressed_ValueChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.AlphaBlendFactorForDropDownPressedColor =
                Convert.ToInt32(numericUpDownForDropdownPressed.Value);
        }

        private void numericUpDownForItemSelection_ValueChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumn.AlphaBlendFactorForItemSelectionColor =
                Convert.ToInt32(numericUpDownForItemSelection.Value);
        }

        private void chkEnableAlphablendingForFilterGroupingPanel_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDownForFilterGroupPanel.Enabled = 
                chkEnableAlphablendingForFilterGroupingPanel.Checked;
        }

        private void numericUpDownForFilterGroupPanel_ValueChanged(object sender, EventArgs e)
        {
           binaryTextComboBoxMulticolumn.AlphaBlendingfactorForFilterAndGroupingPanelBackColor =
                Convert.ToInt32(numericUpDownForFilterGroupPanel.Value);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RetrievePresets()
        {
            binaryColorPickerComboBoxBackColor.SelectedColor =
                binaryTextComboBoxMulticolumn.BackColor;

            binaryColorPickerComboBoxForecolor.SelectedColor = 
                binaryTextComboBoxMulticolumn.ForeColor;

            binaryColorPickerComboBoxBorderColor.SelectedColor = 
                binaryTextComboBoxMulticolumn.CustomControlBorderColor;
            
            binaryColorPickerComboBoxPaintingColor.SelectedColor = 
                binaryTextComboBoxMulticolumn.CustomPaintingColor;

            binaryColorPickerComboBoxDropdownArrowColor.SelectedColor = 
                binaryTextComboBoxMulticolumn.ControlArrowColor;

            binaryColorPickerComboBoxDropdownWindowBackcolor.SelectedColor = 
                binaryTextComboBoxMulticolumn.MultiColumnDropListBackColor;

            binaryColorPickerComboBoxDropdownWindowForecolor.SelectedColor = 
                binaryTextComboBoxMulticolumn.MultiColumnDropListForeColor;

            binaryColorPickerComboBoxHeaderStartColor.SelectedColor =
                binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor;
            
            binaryColorPickerComboBoxHeaderEndColor.SelectedColor =
                binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor;

            binaryColorPickerComboBoxHeaderFooterForecolor.SelectedColor =
                binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor;

            binaryColorPickerComboBoxSortingGlyphColor.SelectedColor =
                binaryTextComboBoxMulticolumn.MultiColumnViewSortingGlyphColor;

            binaryColorPickerComboBoxFilterGroupingPanelBackcolor.SelectedColor = 
                binaryTextComboBoxMulticolumn.FilterAndGroupingPanelBackColor;
        }
    }
}