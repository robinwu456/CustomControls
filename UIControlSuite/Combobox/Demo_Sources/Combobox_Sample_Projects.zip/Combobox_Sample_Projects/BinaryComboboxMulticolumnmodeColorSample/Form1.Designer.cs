namespace BinaryComboboxMulticolumnmodeColorCustomisationSample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.binaryTextComboBoxMulticolumn = new Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox();
            this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customersTestDataSet = new BinaryComboboxMulticolumnmodeColorCustomisationSample.CustomersTestDataSet();
            this.customersTableAdapter = new BinaryComboboxMulticolumnmodeColorCustomisationSample.CustomersTestDataSetTableAdapters.CustomersTableAdapter();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.binaryColorPickerComboBoxDropdownArrowColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxPaintingColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxBorderColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxForecolor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxBackColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBoxDropdownWindowBackcolor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxDropdownWindowForecolor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxHeaderStartColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxHeaderEndColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBoxHeaderFooterForecolor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBoxSortingGlyphColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.chkEnableAlphablendingForFilterGroupingPanel = new System.Windows.Forms.CheckBox();
            this.numericUpDownForItemSelection = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownForDropdownPressed = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownForPainting = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownForFilterGroupPanel = new System.Windows.Forms.NumericUpDown();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersTestDataSet)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForItemSelection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForDropdownPressed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForPainting)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForFilterGroupPanel)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "BinaryCombobox in Multi-column mode";
            // 
            // binaryTextComboBoxMulticolumn
            // 
            this.binaryTextComboBoxMulticolumn.AlphaBlendFactorForControlPainting = 100;
            this.binaryTextComboBoxMulticolumn.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryTextComboBoxMulticolumn.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryTextComboBoxMulticolumn.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.binaryTextComboBoxMulticolumn.AutoComplete = true;
            this.binaryTextComboBoxMulticolumn.AutoCompleteBasedOnCompleteMatchWithAnItemInTheList = false;
            this.binaryTextComboBoxMulticolumn.AutoCompleteIsCaseSensitive = true;
            this.binaryTextComboBoxMulticolumn.AutoCompleteStyleForMultiColumnModeIsMultiColumn = false;
            this.binaryTextComboBoxMulticolumn.BackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumn.BuiltinFilterOnNonStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxMulticolumn.BuiltinFilterOnStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxMulticolumn.BusyIndicatorText = "Processing...";
            this.binaryTextComboBoxMulticolumn.ColumnDataTypeFormatInfoContainers = null;
            this.binaryTextComboBoxMulticolumn.ColumnsToDisplay = null;
            this.binaryTextComboBoxMulticolumn.ColumnWidths = null;
            this.binaryTextComboBoxMulticolumn.ComboBoxIsReadOnly = false;
            this.binaryTextComboBoxMulticolumn.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.CSVFileSaveAs = "MultiColumnDataViewExport.csv";
            this.binaryTextComboBoxMulticolumn.CustomColumnNameForAutomaticRowSelection = null;
            this.binaryTextComboBoxMulticolumn.CustomComparerImplementor = null;
            this.binaryTextComboBoxMulticolumn.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryTextComboBoxMulticolumn.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumn.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumn.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this.binaryTextComboBoxMulticolumn.CustomPaintingColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(169)))), ((int)(((byte)(225)))));
            this.binaryTextComboBoxMulticolumn.DataMember = null;
            this.binaryTextComboBoxMulticolumn.DataSource = this.customersBindingSource;
            this.binaryTextComboBoxMulticolumn.DataSourceViewCustomSortingExpression = null;
            this.binaryTextComboBoxMulticolumn.DesiredFilterColumn = 0;
            this.binaryTextComboBoxMulticolumn.DisplayMember = "CompanyName";
            this.binaryTextComboBoxMulticolumn.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryTextComboBoxMulticolumn.DrawTheControlBasedOnWindowsOS = true;
            this.binaryTextComboBoxMulticolumn.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumn.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxMulticolumn.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumn.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumn.DropDownWindowBorderThickness = 1F;
            this.binaryTextComboBoxMulticolumn.DropDownWindowDisplayOrientation = Binarymission.WinForms.Controls.ListControls.DropDownWindowDisplayOrientation.Default;
            this.binaryTextComboBoxMulticolumn.DropStyleIsMultiColumn = true;
            this.binaryTextComboBoxMulticolumn.EnableAlphaBlendingForFilterAndGroupingPanelBackColor = true;
            this.binaryTextComboBoxMulticolumn.EnableDrawingHeaderFooterWhenInMultiColumnMode = true;
            this.binaryTextComboBoxMulticolumn.ExtendedDropdownButtonImage = null;
            this.binaryTextComboBoxMulticolumn.ExtendedDropdownButtonInternalImage = null;
            this.binaryTextComboBoxMulticolumn.FilterAndGroupingPanelBackColor = System.Drawing.Color.Empty;
            this.binaryTextComboBoxMulticolumn.FilteringIsON = false;
            this.binaryTextComboBoxMulticolumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryTextComboBoxMulticolumn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumn.GroupItemsWhenInMultiColumnDisplayMode = false;
            this.binaryTextComboBoxMulticolumn.GroupMultiColumnDisplayModeDataBasedOnThisColumn = 0;
            this.binaryTextComboBoxMulticolumn.HeadersToDisplay = null;
            this.binaryTextComboBoxMulticolumn.IsAutoCompleteModeAppendSuggestInMultiColumnMode = false;
            this.binaryTextComboBoxMulticolumn.IsCustomisationOfColumnDisplayEnabledInMultiColumnAutoSuggestMode = false;
            this.binaryTextComboBoxMulticolumn.IsFilterSearchResultBasedOnColumnDataType = true;
            this.binaryTextComboBoxMulticolumn.IsInExtendedReadOnlyMode = false;
            this.binaryTextComboBoxMulticolumn.KeepBindingContextInSyncWithParent = false;
            this.binaryTextComboBoxMulticolumn.KeepTheFilterAndGroupingViewsCollapsedAtStartUp = true;
            this.binaryTextComboBoxMulticolumn.KeepTheFilterAndGroupingViewsPaneFullyCollapsedAtStartup = false;
            this.binaryTextComboBoxMulticolumn.Location = new System.Drawing.Point(31, 59);
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownSize = new System.Drawing.Size(500, 250);
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.ColumnHeaderFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.ColumnHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.DrawFooter = true;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.FooterCaptionFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.FooterSurfaceHeight = 20;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.FooterText = "Press F1 for more information!";
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = ((System.Drawing.Bitmap)(resources.GetObject("resource.HeaderBitmap")));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderCaptionFont = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(210)))), ((int)(((byte)(238)))));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(169)))), ((int)(((byte)(225)))));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderIcon = null;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderImageType = Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Bitmap;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderSurfaceHeight = 20;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.HeaderText = "Customer Details";
            this.binaryTextComboBoxMulticolumn.MultiColumnDropDownWindowConfigurationData.NoDataToDisplayMessageText = "There are no items to display.";
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListBackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListGridLines = true;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListHoverSelection = false;
            this.binaryTextComboBoxMulticolumn.MultiColumnDroplistWindowAnimationStyle = Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
            this.binaryTextComboBoxMulticolumn.MultiColumnDropListWindowIsResizable = true;
            this.binaryTextComboBoxMulticolumn.MultiColumnViewBusyProcessingText = "Processing the query... please wait...";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewNoDataFoundText = "There is no data to display.";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewSortingGlyphColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableDataGroupingText = "Enable data grouping";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableFilterOptionsText = "Enable filter options";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemExportDataToCSV = "Export data to CSV";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemShowCommandBarText = "Show command bar";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemBuiltInFilter = "Built-in filter";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemCustomExpression = "Custom expression";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemFilterOnThisColumn = "Filter on this column:";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemEnableGrouping = "Enable \"grouping\"";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterDataWhileTheUserTypesExpression = "Filter data while the user types expression?";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpression = "Filter expression:";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionType = "Filter expression type:";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionTypeComboBoxTooltip = resources.GetString("resource.WindowItemFilterExpressionTypeComboBoxTooltip");
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemFilteringStatusPart = "Filter status: Filtering is currently using";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemGroupOnThisColumn = "Group on this column:";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemHideFilterAndGroupingOptions = "Hide filter and grouping options";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemShowFilterAndGroupingOptions = "Show filter and grouping options";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowItemUseFilterToRetrieveData = "Use filter to retrieve data";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowStatusBarCustomExpressionErrorMessage = "Invalid custom expression. Please correct.";
            this.binaryTextComboBoxMulticolumn.MultiColumnViewUIElementsTextProvider.WindowTaskStatusMessageForCSVExportSuccessful = "                Command result: CSV export successful.";
            this.binaryTextComboBoxMulticolumn.MultiColumnWindowColumnsHorizontalAlignments = ((System.Collections.Generic.IList<System.Windows.Forms.HorizontalAlignment>)(resources.GetObject("binaryTextComboBoxMulticolumn.MultiColumnWindowColumnsHorizontalAlignments")));
            this.binaryTextComboBoxMulticolumn.Name = "binaryTextComboBoxMulticolumn";
            this.binaryTextComboBoxMulticolumn.SelectedIndexFromDropList = -1;
            this.binaryTextComboBoxMulticolumn.ShareCustomMultiColumnSizeAcrossDataListAndFilterGroupingOptionsPane = true;
            this.binaryTextComboBoxMulticolumn.ShouldAllowUserInputWhileProcessingMultiColumnAutoCompleDropDownView = true;
            this.binaryTextComboBoxMulticolumn.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryTextComboBoxMulticolumn.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryTextComboBoxMulticolumn.ShouldDrawExtendedDropdownButton = false;
            this.binaryTextComboBoxMulticolumn.ShouldPersistUserSetColumnWidthsAcrossFilterSessions = false;
            this.binaryTextComboBoxMulticolumn.ShowBorderAlways = true;
            this.binaryTextComboBoxMulticolumn.ShowDropDownMultiColumnWindowAfterAdjustingForVirtualAvaliableScreenSpace = false;
            this.binaryTextComboBoxMulticolumn.ShowEmptyDropListViewWhenThereAreNoData = true;
            this.binaryTextComboBoxMulticolumn.ShowFilterOptionsInMultiColumnMode = true;
            this.binaryTextComboBoxMulticolumn.Size = new System.Drawing.Size(174, 22);
            this.binaryTextComboBoxMulticolumn.SizeForMultiColumnAutoCompleteSuggestionDropDownWindow = new System.Drawing.Size(0, 0);
            this.binaryTextComboBoxMulticolumn.SizesForMultiColumnAutoCompleteSuggestionDropDownWindowColumns = null;
            this.binaryTextComboBoxMulticolumn.TabIndex = 2;
            this.binaryTextComboBoxMulticolumn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxMulticolumn.ValueMember = "CustomerID";
            // 
            // customersBindingSource
            // 
            this.customersBindingSource.DataMember = "Customers";
            this.customersBindingSource.DataSource = this.customersTestDataSet;
            // 
            // customersTestDataSet
            // 
            this.customersTestDataSet.DataSetName = "CustomersTestDataSet";
            this.customersTestDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(26, 107);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(166, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "Color customisation for the control";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.binaryColorPickerComboBoxDropdownArrowColor);
            this.panel1.Controls.Add(this.binaryColorPickerComboBoxPaintingColor);
            this.panel1.Controls.Add(this.binaryColorPickerComboBoxBorderColor);
            this.panel1.Controls.Add(this.binaryColorPickerComboBoxForecolor);
            this.panel1.Controls.Add(this.binaryColorPickerComboBoxBackColor);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(29, 130);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(377, 214);
            this.panel1.TabIndex = 23;
            // 
            // binaryColorPickerComboBoxDropdownArrowColor
            // 
            this.binaryColorPickerComboBoxDropdownArrowColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxDropdownArrowColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxDropdownArrowColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxDropdownArrowColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxDropdownArrowColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxDropdownArrowColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxDropdownArrowColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxDropdownArrowColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxDropdownArrowColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxDropdownArrowColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxDropdownArrowColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxDropdownArrowColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxDropdownArrowColor.Location = new System.Drawing.Point(216, 120);
            this.binaryColorPickerComboBoxDropdownArrowColor.Name = "binaryColorPickerComboBoxDropdownArrowColor";
            this.binaryColorPickerComboBoxDropdownArrowColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxDropdownArrowColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxDropdownArrowColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxDropdownArrowColor.Size = new System.Drawing.Size(142, 21);
            this.binaryColorPickerComboBoxDropdownArrowColor.TabIndex = 14;
            this.binaryColorPickerComboBoxDropdownArrowColor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxDropdownArrowColor_SelectedColorChanged);
            // 
            // binaryColorPickerComboBoxPaintingColor
            // 
            this.binaryColorPickerComboBoxPaintingColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxPaintingColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxPaintingColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxPaintingColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxPaintingColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxPaintingColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxPaintingColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxPaintingColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxPaintingColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxPaintingColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxPaintingColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxPaintingColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxPaintingColor.Location = new System.Drawing.Point(216, 93);
            this.binaryColorPickerComboBoxPaintingColor.Name = "binaryColorPickerComboBoxPaintingColor";
            this.binaryColorPickerComboBoxPaintingColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxPaintingColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxPaintingColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxPaintingColor.Size = new System.Drawing.Size(142, 21);
            this.binaryColorPickerComboBoxPaintingColor.TabIndex = 13;
            this.binaryColorPickerComboBoxPaintingColor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxPaintingColor_SelectedColorChanged);
            // 
            // binaryColorPickerComboBoxBorderColor
            // 
            this.binaryColorPickerComboBoxBorderColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxBorderColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxBorderColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxBorderColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxBorderColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxBorderColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxBorderColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxBorderColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxBorderColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxBorderColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxBorderColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxBorderColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxBorderColor.Location = new System.Drawing.Point(216, 66);
            this.binaryColorPickerComboBoxBorderColor.Name = "binaryColorPickerComboBoxBorderColor";
            this.binaryColorPickerComboBoxBorderColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxBorderColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxBorderColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxBorderColor.Size = new System.Drawing.Size(142, 21);
            this.binaryColorPickerComboBoxBorderColor.TabIndex = 12;
            this.binaryColorPickerComboBoxBorderColor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxBorderColor_SelectedColorChanged);
            // 
            // binaryColorPickerComboBoxForecolor
            // 
            this.binaryColorPickerComboBoxForecolor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxForecolor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxForecolor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxForecolor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxForecolor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxForecolor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxForecolor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxForecolor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxForecolor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxForecolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxForecolor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxForecolor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxForecolor.Location = new System.Drawing.Point(216, 39);
            this.binaryColorPickerComboBoxForecolor.Name = "binaryColorPickerComboBoxForecolor";
            this.binaryColorPickerComboBoxForecolor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxForecolor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxForecolor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxForecolor.Size = new System.Drawing.Size(142, 21);
            this.binaryColorPickerComboBoxForecolor.TabIndex = 11;
            this.binaryColorPickerComboBoxForecolor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxForecolor_SelectedColorChanged);
            // 
            // binaryColorPickerComboBoxBackColor
            // 
            this.binaryColorPickerComboBoxBackColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxBackColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxBackColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxBackColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxBackColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxBackColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxBackColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxBackColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxBackColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxBackColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxBackColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxBackColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxBackColor.Location = new System.Drawing.Point(216, 12);
            this.binaryColorPickerComboBoxBackColor.Name = "binaryColorPickerComboBoxBackColor";
            this.binaryColorPickerComboBoxBackColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxBackColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxBackColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxBackColor.Size = new System.Drawing.Size(142, 21);
            this.binaryColorPickerComboBoxBackColor.TabIndex = 10;
            this.binaryColorPickerComboBoxBackColor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxBackColor_SelectedColorChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(145, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Control dropdown arrow color";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Control painting color";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Control border color";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Control forecolor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Control backcolor";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(434, 107);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(220, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "Color customisation for the dropdown window";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(145, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Dropdown window backcolor";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 44);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(139, 13);
            this.label10.TabIndex = 26;
            this.label10.Text = "Dropdown window forecolor";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 71);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(138, 13);
            this.label12.TabIndex = 27;
            this.label12.Text = "Header rendering start color";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 98);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(136, 13);
            this.label13.TabIndex = 28;
            this.label13.Text = "Header rendering end color";
            // 
            // binaryColorPickerComboBoxDropdownWindowBackcolor
            // 
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.Location = new System.Drawing.Point(212, 14);
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.Name = "binaryColorPickerComboBoxDropdownWindowBackcolor";
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.Size = new System.Drawing.Size(142, 21);
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.TabIndex = 16;
            this.binaryColorPickerComboBoxDropdownWindowBackcolor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxDropdownWindowBackcolor_SelectedColorChanged);
            // 
            // binaryColorPickerComboBoxDropdownWindowForecolor
            // 
            this.binaryColorPickerComboBoxDropdownWindowForecolor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxDropdownWindowForecolor.Location = new System.Drawing.Point(212, 41);
            this.binaryColorPickerComboBoxDropdownWindowForecolor.Name = "binaryColorPickerComboBoxDropdownWindowForecolor";
            this.binaryColorPickerComboBoxDropdownWindowForecolor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.Size = new System.Drawing.Size(142, 21);
            this.binaryColorPickerComboBoxDropdownWindowForecolor.TabIndex = 29;
            this.binaryColorPickerComboBoxDropdownWindowForecolor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxDropdownWindowForecolor_SelectedColorChanged);
            // 
            // binaryColorPickerComboBoxHeaderStartColor
            // 
            this.binaryColorPickerComboBoxHeaderStartColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxHeaderStartColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxHeaderStartColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxHeaderStartColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxHeaderStartColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxHeaderStartColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxHeaderStartColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxHeaderStartColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxHeaderStartColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxHeaderStartColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxHeaderStartColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxHeaderStartColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxHeaderStartColor.Location = new System.Drawing.Point(212, 68);
            this.binaryColorPickerComboBoxHeaderStartColor.Name = "binaryColorPickerComboBoxHeaderStartColor";
            this.binaryColorPickerComboBoxHeaderStartColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxHeaderStartColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxHeaderStartColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxHeaderStartColor.Size = new System.Drawing.Size(142, 21);
            this.binaryColorPickerComboBoxHeaderStartColor.TabIndex = 30;
            this.binaryColorPickerComboBoxHeaderStartColor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxHeaderStartColor_SelectedColorChanged);
            // 
            // binaryColorPickerComboBoxHeaderEndColor
            // 
            this.binaryColorPickerComboBoxHeaderEndColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxHeaderEndColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxHeaderEndColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxHeaderEndColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxHeaderEndColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxHeaderEndColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxHeaderEndColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxHeaderEndColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxHeaderEndColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxHeaderEndColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxHeaderEndColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxHeaderEndColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxHeaderEndColor.Location = new System.Drawing.Point(212, 95);
            this.binaryColorPickerComboBoxHeaderEndColor.Name = "binaryColorPickerComboBoxHeaderEndColor";
            this.binaryColorPickerComboBoxHeaderEndColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxHeaderEndColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxHeaderEndColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxHeaderEndColor.Size = new System.Drawing.Size(142, 21);
            this.binaryColorPickerComboBoxHeaderEndColor.TabIndex = 31;
            this.binaryColorPickerComboBoxHeaderEndColor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxHeaderEndColor_SelectedColorChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 13);
            this.label7.TabIndex = 32;
            this.label7.Text = "Header/Footer text forecolor";
            // 
            // binaryColorPickerComboBoxHeaderFooterForecolor
            // 
            this.binaryColorPickerComboBoxHeaderFooterForecolor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxHeaderFooterForecolor.Location = new System.Drawing.Point(212, 122);
            this.binaryColorPickerComboBoxHeaderFooterForecolor.Name = "binaryColorPickerComboBoxHeaderFooterForecolor";
            this.binaryColorPickerComboBoxHeaderFooterForecolor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.Size = new System.Drawing.Size(142, 21);
            this.binaryColorPickerComboBoxHeaderFooterForecolor.TabIndex = 33;
            this.binaryColorPickerComboBoxHeaderFooterForecolor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxHeaderFooterForecolor_SelectedColorChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 152);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(94, 13);
            this.label14.TabIndex = 34;
            this.label14.Text = "Sorting glyph color";
            // 
            // binaryColorPickerComboBoxSortingGlyphColor
            // 
            this.binaryColorPickerComboBoxSortingGlyphColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxSortingGlyphColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxSortingGlyphColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxSortingGlyphColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxSortingGlyphColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxSortingGlyphColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxSortingGlyphColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxSortingGlyphColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxSortingGlyphColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxSortingGlyphColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxSortingGlyphColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxSortingGlyphColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxSortingGlyphColor.Location = new System.Drawing.Point(212, 149);
            this.binaryColorPickerComboBoxSortingGlyphColor.Name = "binaryColorPickerComboBoxSortingGlyphColor";
            this.binaryColorPickerComboBoxSortingGlyphColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxSortingGlyphColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxSortingGlyphColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxSortingGlyphColor.Size = new System.Drawing.Size(142, 21);
            this.binaryColorPickerComboBoxSortingGlyphColor.TabIndex = 35;
            this.binaryColorPickerComboBoxSortingGlyphColor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxSortingGlyphColor_SelectedColorChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 179);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(156, 13);
            this.label15.TabIndex = 36;
            this.label15.Text = "Filter/Grouping panel backcolor";
            // 
            // binaryColorPickerComboBoxFilterGroupingPanelBackcolor
            // 
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.Location = new System.Drawing.Point(212, 176);
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.Name = "binaryColorPickerComboBoxFilterGroupingPanelBackcolor";
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.Size = new System.Drawing.Size(142, 21);
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.TabIndex = 37;
            this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor.SelectedColorChanged += new System.EventHandler(this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor_SelectedColorChanged);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxFilterGroupingPanelBackcolor);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxSortingGlyphColor);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxHeaderFooterForecolor);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxHeaderEndColor);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxHeaderStartColor);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxDropdownWindowForecolor);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxDropdownWindowBackcolor);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(440, 133);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(371, 211);
            this.panel2.TabIndex = 38;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(26, 356);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(155, 13);
            this.label16.TabIndex = 39;
            this.label16.Text = "Alphablend color factor settings";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(5, 17);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(206, 13);
            this.label17.TabIndex = 38;
            this.label17.Text = "Alphablend factor for control painting color";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(5, 43);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(218, 13);
            this.label18.TabIndex = 40;
            this.label18.Text = "Alphablend factor for dropdownpressed color";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(5, 69);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(195, 13);
            this.label19.TabIndex = 41;
            this.label19.Text = "Alphablend factor for itemselection color";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(26, 125);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(252, 13);
            this.label20.TabIndex = 42;
            this.label20.Text = "Alphablend factor for filter/grouping panel backcolor";
            // 
            // chkEnableAlphablendingForFilterGroupingPanel
            // 
            this.chkEnableAlphablendingForFilterGroupingPanel.AutoSize = true;
            this.chkEnableAlphablendingForFilterGroupingPanel.Checked = true;
            this.chkEnableAlphablendingForFilterGroupingPanel.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkEnableAlphablendingForFilterGroupingPanel.Location = new System.Drawing.Point(8, 100);
            this.chkEnableAlphablendingForFilterGroupingPanel.Name = "chkEnableAlphablendingForFilterGroupingPanel";
            this.chkEnableAlphablendingForFilterGroupingPanel.Size = new System.Drawing.Size(290, 17);
            this.chkEnableAlphablendingForFilterGroupingPanel.TabIndex = 43;
            this.chkEnableAlphablendingForFilterGroupingPanel.Text = "Enable alphablending for filter/grouping panel backcolor";
            this.chkEnableAlphablendingForFilterGroupingPanel.UseVisualStyleBackColor = true;
            this.chkEnableAlphablendingForFilterGroupingPanel.CheckedChanged += new System.EventHandler(this.chkEnableAlphablendingForFilterGroupingPanel_CheckedChanged);
            // 
            // numericUpDownForItemSelection
            // 
            this.numericUpDownForItemSelection.Location = new System.Drawing.Point(294, 67);
            this.numericUpDownForItemSelection.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownForItemSelection.Name = "numericUpDownForItemSelection";
            this.numericUpDownForItemSelection.Size = new System.Drawing.Size(73, 20);
            this.numericUpDownForItemSelection.TabIndex = 46;
            this.numericUpDownForItemSelection.Value = new decimal(new int[] {
            70,
            0,
            0,
            0});
            this.numericUpDownForItemSelection.ValueChanged += new System.EventHandler(this.numericUpDownForItemSelection_ValueChanged);
            // 
            // numericUpDownForDropdownPressed
            // 
            this.numericUpDownForDropdownPressed.Location = new System.Drawing.Point(294, 41);
            this.numericUpDownForDropdownPressed.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownForDropdownPressed.Name = "numericUpDownForDropdownPressed";
            this.numericUpDownForDropdownPressed.Size = new System.Drawing.Size(73, 20);
            this.numericUpDownForDropdownPressed.TabIndex = 45;
            this.numericUpDownForDropdownPressed.Value = new decimal(new int[] {
            70,
            0,
            0,
            0});
            this.numericUpDownForDropdownPressed.ValueChanged += new System.EventHandler(this.numericUpDownForDropdownPressed_ValueChanged);
            // 
            // numericUpDownForPainting
            // 
            this.numericUpDownForPainting.Location = new System.Drawing.Point(294, 15);
            this.numericUpDownForPainting.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownForPainting.Name = "numericUpDownForPainting";
            this.numericUpDownForPainting.Size = new System.Drawing.Size(73, 20);
            this.numericUpDownForPainting.TabIndex = 44;
            this.numericUpDownForPainting.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numericUpDownForPainting.ValueChanged += new System.EventHandler(this.numericUpDownForPainting_ValueChanged);
            // 
            // numericUpDownForFilterGroupPanel
            // 
            this.numericUpDownForFilterGroupPanel.Location = new System.Drawing.Point(294, 123);
            this.numericUpDownForFilterGroupPanel.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownForFilterGroupPanel.Name = "numericUpDownForFilterGroupPanel";
            this.numericUpDownForFilterGroupPanel.Size = new System.Drawing.Size(73, 20);
            this.numericUpDownForFilterGroupPanel.TabIndex = 47;
            this.numericUpDownForFilterGroupPanel.Value = new decimal(new int[] {
            135,
            0,
            0,
            0});
            this.numericUpDownForFilterGroupPanel.ValueChanged += new System.EventHandler(this.numericUpDownForFilterGroupPanel_ValueChanged);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.numericUpDownForFilterGroupPanel);
            this.panel3.Controls.Add(this.numericUpDownForItemSelection);
            this.panel3.Controls.Add(this.numericUpDownForDropdownPressed);
            this.panel3.Controls.Add(this.numericUpDownForPainting);
            this.panel3.Controls.Add(this.chkEnableAlphablendingForFilterGroupingPanel);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Location = new System.Drawing.Point(32, 381);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(374, 159);
            this.panel3.TabIndex = 48;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(796, 520);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(57, 20);
            this.button1.TabIndex = 49;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(880, 591);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.binaryTextComboBoxMulticolumn);
            this.Controls.Add(this.label1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersTestDataSet)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForItemSelection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForDropdownPressed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForPainting)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownForFilterGroupPanel)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox binaryTextComboBoxMulticolumn;
        private CustomersTestDataSet customersTestDataSet;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private BinaryComboboxMulticolumnmodeColorCustomisationSample.CustomersTestDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxDropdownArrowColor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxPaintingColor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxBorderColor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxForecolor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxBackColor;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxDropdownWindowBackcolor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxDropdownWindowForecolor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxHeaderStartColor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxHeaderEndColor;
        private System.Windows.Forms.Label label7;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxHeaderFooterForecolor;
        private System.Windows.Forms.Label label14;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxSortingGlyphColor;
        private System.Windows.Forms.Label label15;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxFilterGroupingPanelBackcolor;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox chkEnableAlphablendingForFilterGroupingPanel;
        private System.Windows.Forms.NumericUpDown numericUpDownForItemSelection;
        private System.Windows.Forms.NumericUpDown numericUpDownForDropdownPressed;
        private System.Windows.Forms.NumericUpDown numericUpDownForPainting;
        private System.Windows.Forms.NumericUpDown numericUpDownForFilterGroupPanel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
    }
}

