using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryComboboxAutoCompleteSample
{
    public partial class Form1 : ModernChromeWindow
    {
        public Form1()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"AutoCompletion Demo";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'customersTestDataSet1.Customers' table. You can move, or remove it, as needed.
            this.customersTableAdapter1.Fill(this.customersTestDataSet1.Customers);
            // TODO: This line of code loads data into the 'customersTestDataSet.Customers' table. You can move, or remove it, as needed.
            this.customersTableAdapter.Fill(this.customersTestDataSet.Customers);
            cmbBxAutoCompleteMode1.SelectedIndex = 0;
            cmbBxAutoCompleteMode2.SelectedIndex = 0;
            cmbBxAutoCompleteMode3.SelectedIndex = 0;
            binaryTextComboBoxSingleColumnUnbound.SelectedIndex = 0;

            binaryTextComboBoxMultiColumn.TableToLoad = this.customersTestDataSet.Customers;

	        // Note that the below set properties are effective only if the Combobox control instance's ComboBoxIsReadOnly is set to true.

	        binaryTextComboBoxSingleColumnUnbound.IsInExtendedReadOnlyMode = true;
	        binaryTextComboBoxMultiColumn.IsInExtendedReadOnlyMode = true;
	        binaryTextComboBoxSingleColumn.IsInExtendedReadOnlyMode = true;
            chkIsAutoCompletionInMultiColumnDisplay.Enabled = chkAutoComplete1.Checked &&
                                                              cmbBxAutoCompleteMode1.SelectedItem.ToString().ToUpper()
                                                                  .Equals("Suggest".ToUpper());
        }

        private void chkAutoComplete1_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMultiColumn.AutoComplete = chkAutoComplete1.Checked;
            label2.Enabled = chkAutoComplete1.Checked;
            cmbBxAutoCompleteMode1.Enabled = chkAutoComplete1.Checked;
            var t = cmbBxAutoCompleteMode1.SelectedItem;
            chkIsAutoCompletionInMultiColumnDisplay.Enabled = chkAutoComplete1.Checked &&
                                                              cmbBxAutoCompleteMode1.SelectedItem.ToString().ToUpper()
                                                                  .Equals("Suggest".ToUpper());
        }

        private void cmbBxAutoCompleteMode1_SelectedIndexChanged(object sender, EventArgs e)
        {
            chkIsAutoCompletionInMultiColumnDisplay.Enabled = chkAutoComplete1.Checked &&
                                                              cmbBxAutoCompleteMode1.SelectedItem.ToString().ToUpper()
                                                                  .Equals("Suggest".ToUpper());

            switch(cmbBxAutoCompleteMode1.SelectedIndex)
            {
                case 0: binaryTextComboBoxMultiColumn.AutoCompleteMode = AutoCompleteMode.None;
                    break;

                case 1: binaryTextComboBoxMultiColumn.AutoCompleteMode = AutoCompleteMode.Suggest;
                    break;

                case 2: binaryTextComboBoxMultiColumn.AutoCompleteMode = AutoCompleteMode.Append;
                    break;

                case 3: binaryTextComboBoxMultiColumn.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    break;

                default: break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void chkBoxReadOnly1_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMultiColumn.ComboBoxIsReadOnly = chkBoxReadOnly1.Checked;
            cmbBxAutoCompleteMode1.Enabled = !chkBoxReadOnly1.Checked;
            
            binaryTextComboBoxMultiColumn.AutoCompleteMode = (AutoCompleteMode)Enum.Parse(typeof(AutoCompleteMode), cmbBxAutoCompleteMode1.SelectedItem.ToString());
            binaryTextComboBoxMultiColumn.AutoComplete = !chkBoxReadOnly1.Checked;

            chkIsAutoCompletionInMultiColumnDisplay.Enabled = !chkBoxReadOnly1.Checked;
            chkAutoComplete1.Enabled = !chkBoxReadOnly1.Checked;
        }

        private void chkBoxReadOnly2_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumn.ComboBoxIsReadOnly = chkBoxReadOnly2.Checked;

            cmbBxAutoCompleteMode2.Enabled = !chkBoxReadOnly2.Checked;

            binaryTextComboBoxSingleColumn.AutoCompleteMode = (AutoCompleteMode)Enum.Parse(typeof(AutoCompleteMode), cmbBxAutoCompleteMode2.SelectedItem.ToString());
            binaryTextComboBoxSingleColumn.AutoComplete = !chkBoxReadOnly2.Checked;

            chkAutoComplete1.Enabled = !chkBoxReadOnly1.Checked;
        }

        private void chkAutoComplete2_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumn.AutoComplete = chkAutoComplete2.Checked;
            label4.Enabled = chkAutoComplete2.Checked;
            cmbBxAutoCompleteMode2.Enabled = chkAutoComplete2.Checked;
        }

        private void cmbBxAutoCompleteMode2_SelectedIndexChanged(object sender, EventArgs e)
        { 
            switch (cmbBxAutoCompleteMode2.SelectedIndex)
            {
                case 0: binaryTextComboBoxSingleColumn.AutoCompleteMode = AutoCompleteMode.None;
                    break;

                case 1: binaryTextComboBoxSingleColumn.AutoCompleteMode = AutoCompleteMode.Suggest;                    
                    break;

                case 2: binaryTextComboBoxSingleColumn.AutoCompleteMode = AutoCompleteMode.Append;                    
                    break;

                case 3: binaryTextComboBoxSingleColumn.AutoCompleteMode = AutoCompleteMode.SuggestAppend;                    
                    break;

                default: break;
            }            
        }

        private void cmbBxAutoCompleteMode3_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbBxAutoCompleteMode3.SelectedIndex)
            {
                case 0: binaryTextComboBoxSingleColumnUnbound.AutoCompleteMode = AutoCompleteMode.None;
                    break;

                case 1: binaryTextComboBoxSingleColumnUnbound.AutoCompleteMode = AutoCompleteMode.Suggest;
                    break;

                case 2: binaryTextComboBoxSingleColumnUnbound.AutoCompleteMode = AutoCompleteMode.Append;
                    break;

                case 3: binaryTextComboBoxSingleColumnUnbound.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    break;

                default: break;
            }            
        }

        private void chkAutoComplete3_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumnUnbound.AutoComplete = chkAutoComplete3.Checked;
            label5.Enabled = chkAutoComplete3.Checked;
            cmbBxAutoCompleteMode3.Enabled = chkAutoComplete3.Checked;
        }

        private void chkBoxReadOnly3_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumnUnbound.ComboBoxIsReadOnly = chkBoxReadOnly3.Checked;

            cmbBxAutoCompleteMode3.Enabled = !chkBoxReadOnly3.Checked;

            binaryTextComboBoxSingleColumnUnbound.AutoCompleteMode = (AutoCompleteMode)Enum.Parse(typeof(AutoCompleteMode), cmbBxAutoCompleteMode3.SelectedItem.ToString());
            binaryTextComboBoxSingleColumnUnbound.AutoComplete = !chkBoxReadOnly3.Checked;

            chkAutoComplete3.Enabled = !chkBoxReadOnly3.Checked;
        }

        private void chkIsAutoCompletionInMultiColumnDisplay_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMultiColumn.AutoCompleteStyleForMultiColumnModeIsMultiColumn =
                chkIsAutoCompletionInMultiColumnDisplay.Checked;
        }
    }
}