namespace BinaryComboboxAutoCompleteSample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.customersTestDataSet = new BinaryComboboxAutoCompleteSample.CustomersTestDataSet();
            this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customersTableAdapter = new BinaryComboboxAutoCompleteSample.CustomersTestDataSetTableAdapters.CustomersTableAdapter();
            this.binaryTextComboBoxMultiColumn = new Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox();
            this.chkAutoComplete1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbBxAutoCompleteMode1 = new System.Windows.Forms.ComboBox();
            this.chkBoxReadOnly1 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.binaryTextComboBoxSingleColumn = new Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox();
            this.customersBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.customersTestDataSet1 = new BinaryComboboxAutoCompleteSample.CustomersTestDataSet1();
            this.label3 = new System.Windows.Forms.Label();
            this.chkBoxReadOnly2 = new System.Windows.Forms.CheckBox();
            this.chkAutoComplete2 = new System.Windows.Forms.CheckBox();
            this.customersTableAdapter1 = new BinaryComboboxAutoCompleteSample.CustomersTestDataSet1TableAdapters.CustomersTableAdapter();
            this.cmbBxAutoCompleteMode2 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbBxAutoCompleteMode3 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.chkBoxReadOnly3 = new System.Windows.Forms.CheckBox();
            this.chkAutoComplete3 = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.binaryTextComboBoxSingleColumnUnbound = new Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkIsAutoCompletionInMultiColumnDisplay = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.customersTestDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersTestDataSet1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // customersTestDataSet
            // 
            this.customersTestDataSet.DataSetName = "CustomersTestDataSet";
            this.customersTestDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customersBindingSource
            // 
            this.customersBindingSource.DataMember = "Customers";
            this.customersBindingSource.DataSource = this.customersTestDataSet;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // binaryTextComboBoxMultiColumn
            // 
            this.binaryTextComboBoxMultiColumn.AlphaBlendFactorForControlPainting = 100;
            this.binaryTextComboBoxMultiColumn.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryTextComboBoxMultiColumn.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryTextComboBoxMultiColumn.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.binaryTextComboBoxMultiColumn.AutoComplete = false;
            this.binaryTextComboBoxMultiColumn.AutoCompleteBasedOnCompleteMatchWithAnItemInTheList = false;
            this.binaryTextComboBoxMultiColumn.AutoCompleteIsCaseSensitive = false;
            this.binaryTextComboBoxMultiColumn.AutoCompleteStyleForMultiColumnModeIsMultiColumn = false;
            this.binaryTextComboBoxMultiColumn.BackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMultiColumn.BuiltinFilterOnNonStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxMultiColumn.BuiltinFilterOnStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxMultiColumn.BusyIndicatorText = "Processing...";
            this.binaryTextComboBoxMultiColumn.ColumnDataTypeFormatInfoContainers = null;
            this.binaryTextComboBoxMultiColumn.ColumnsToDisplay = null;
            this.binaryTextComboBoxMultiColumn.ColumnWidths = null;
            this.binaryTextComboBoxMultiColumn.ComboBoxIsReadOnly = false;
            this.binaryTextComboBoxMultiColumn.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMultiColumn.CSVFileSaveAs = "MultiColumnDataViewExport.csv";
            this.binaryTextComboBoxMultiColumn.CustomColumnNameForAutomaticRowSelection = null;
            this.binaryTextComboBoxMultiColumn.CustomComparerImplementor = null;
            this.binaryTextComboBoxMultiColumn.CustomControlBorderColor = System.Drawing.Color.Black;
            this.binaryTextComboBoxMultiColumn.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMultiColumn.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMultiColumn.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this.binaryTextComboBoxMultiColumn.CustomPaintingColor = System.Drawing.Color.Silver;
            this.binaryTextComboBoxMultiColumn.DataMember = null;
            this.binaryTextComboBoxMultiColumn.DataSource = this.customersBindingSource;
            this.binaryTextComboBoxMultiColumn.DataSourceViewCustomSortingExpression = null;
            this.binaryTextComboBoxMultiColumn.DesiredFilterColumn = 0;
            this.binaryTextComboBoxMultiColumn.DisplayMember = "CompanyName";
            this.binaryTextComboBoxMultiColumn.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryTextComboBoxMultiColumn.DrawTheControlBasedOnWindowsOS = true;
            this.binaryTextComboBoxMultiColumn.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMultiColumn.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxMultiColumn.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMultiColumn.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMultiColumn.DropDownWindowBorderThickness = 1F;
            this.binaryTextComboBoxMultiColumn.DropDownWindowDisplayOrientation = Binarymission.WinForms.Controls.ListControls.DropDownWindowDisplayOrientation.Default;
            this.binaryTextComboBoxMultiColumn.DropStyleIsMultiColumn = true;
            this.binaryTextComboBoxMultiColumn.EnableAlphaBlendingForFilterAndGroupingPanelBackColor = true;
            this.binaryTextComboBoxMultiColumn.EnableDrawingHeaderFooterWhenInMultiColumnMode = false;
            this.binaryTextComboBoxMultiColumn.ExtendedDropdownButtonImage = null;
            this.binaryTextComboBoxMultiColumn.ExtendedDropdownButtonInternalImage = null;
            this.binaryTextComboBoxMultiColumn.FilterAndGroupingPanelBackColor = System.Drawing.Color.Empty;
            this.binaryTextComboBoxMultiColumn.FilteringIsON = false;
            this.binaryTextComboBoxMultiColumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryTextComboBoxMultiColumn.GroupItemsWhenInMultiColumnDisplayMode = false;
            this.binaryTextComboBoxMultiColumn.GroupMultiColumnDisplayModeDataBasedOnThisColumn = 0;
            this.binaryTextComboBoxMultiColumn.HeadersToDisplay = null;
            this.binaryTextComboBoxMultiColumn.IsAutoCompleteModeAppendSuggestInMultiColumnMode = false;
            this.binaryTextComboBoxMultiColumn.IsCustomisationOfColumnDisplayEnabledInMultiColumnAutoSuggestMode = false;
            this.binaryTextComboBoxMultiColumn.IsFilterSearchResultBasedOnColumnDataType = true;
            this.binaryTextComboBoxMultiColumn.IsInExtendedReadOnlyMode = false;
            this.binaryTextComboBoxMultiColumn.KeepBindingContextInSyncWithParent = false;
            this.binaryTextComboBoxMultiColumn.KeepTheFilterAndGroupingViewsCollapsedAtStartUp = true;
            this.binaryTextComboBoxMultiColumn.KeepTheFilterAndGroupingViewsPaneFullyCollapsedAtStartup = false;
            this.binaryTextComboBoxMultiColumn.Location = new System.Drawing.Point(18, 15);
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownSize = new System.Drawing.Size(500, 250);
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.ColumnHeaderFont = new System.Drawing.Font("Arial", 12F);
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.ColumnHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.DrawFooter = true;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.FooterCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.FooterSurfaceHeight = 20;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.FooterText = "";
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = null;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.HeaderCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor = System.Drawing.Color.Silver;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.HeaderIcon = null;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.HeaderImageType = Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Icon;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.HeaderSurfaceHeight = 20;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.HeaderText = "";
            this.binaryTextComboBoxMultiColumn.MultiColumnDropDownWindowConfigurationData.NoDataToDisplayMessageText = "There are no items to display.";
            this.binaryTextComboBoxMultiColumn.MultiColumnDropListBackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropListFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMultiColumn.MultiColumnDropListForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropListGridLines = true;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropListHoverSelection = false;
            this.binaryTextComboBoxMultiColumn.MultiColumnDroplistWindowAnimationStyle = Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
            this.binaryTextComboBoxMultiColumn.MultiColumnDropListWindowIsResizable = true;
            this.binaryTextComboBoxMultiColumn.MultiColumnViewBusyProcessingText = "Processing the query... please wait...";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewNoDataFoundText = "There is no data to display.";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewSortingGlyphColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableDataGroupingText = "Enable data grouping";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableFilterOptionsText = "Enable filter options";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemExportDataToCSV = "Export data to CSV";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemShowCommandBarText = "Show command bar";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemBuiltInFilter = "Built-in filter";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemCustomExpression = "Custom expression";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemFilterOnThisColumn = "Filter on this column:";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowItemEnableGrouping = "Enable \"grouping\"";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterDataWhileTheUserTypesExpression = "Filter data while the user types expression?";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpression = "Filter expression:";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionType = "Filter expression type:";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionTypeComboBoxTooltip = resources.GetString("resource.WindowItemFilterExpressionTypeComboBoxTooltip");
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowItemFilteringStatusPart = "Filter status: Filtering is currently using";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowItemGroupOnThisColumn = "Group on this column:";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowItemHideFilterAndGroupingOptions = "Hide filter and grouping options";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowItemShowFilterAndGroupingOptions = "Show filter and grouping options";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowItemUseFilterToRetrieveData = "Use filter to retrieve data";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowStatusBarCustomExpressionErrorMessage = "Invalid custom expression. Please correct.";
            this.binaryTextComboBoxMultiColumn.MultiColumnViewUIElementsTextProvider.WindowTaskStatusMessageForCSVExportSuccessful = "                Command result: CSV export successful.";
            this.binaryTextComboBoxMultiColumn.MultiColumnWindowColumnsHorizontalAlignments = ((System.Collections.Generic.IList<System.Windows.Forms.HorizontalAlignment>)(resources.GetObject("binaryTextComboBoxMultiColumn.MultiColumnWindowColumnsHorizontalAlignments")));
            this.binaryTextComboBoxMultiColumn.Name = "binaryTextComboBoxMultiColumn";
            this.binaryTextComboBoxMultiColumn.SelectedIndexFromDropList = -1;
            this.binaryTextComboBoxMultiColumn.ShareCustomMultiColumnSizeAcrossDataListAndFilterGroupingOptionsPane = true;
            this.binaryTextComboBoxMultiColumn.ShouldAllowUserInputWhileProcessingMultiColumnAutoCompleDropDownView = true;
            this.binaryTextComboBoxMultiColumn.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryTextComboBoxMultiColumn.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryTextComboBoxMultiColumn.ShouldDrawExtendedDropdownButton = false;
            this.binaryTextComboBoxMultiColumn.ShouldPersistUserSetColumnWidthsAcrossFilterSessions = false;
            this.binaryTextComboBoxMultiColumn.ShowBorderAlways = true;
            this.binaryTextComboBoxMultiColumn.ShowDropDownMultiColumnWindowAfterAdjustingForVirtualAvaliableScreenSpace = false;
            this.binaryTextComboBoxMultiColumn.ShowEmptyDropListViewWhenThereAreNoData = true;
            this.binaryTextComboBoxMultiColumn.ShowFilterOptionsInMultiColumnMode = false;
            this.binaryTextComboBoxMultiColumn.Size = new System.Drawing.Size(185, 21);
            this.binaryTextComboBoxMultiColumn.SizeForMultiColumnAutoCompleteSuggestionDropDownWindow = new System.Drawing.Size(0, 0);
            this.binaryTextComboBoxMultiColumn.SizesForMultiColumnAutoCompleteSuggestionDropDownWindowColumns = null;
            this.binaryTextComboBoxMultiColumn.TabIndex = 0;
            this.binaryTextComboBoxMultiColumn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxMultiColumn.ValueMember = "CustomerID";
            // 
            // chkAutoComplete1
            // 
            this.chkAutoComplete1.AutoSize = true;
            this.chkAutoComplete1.Location = new System.Drawing.Point(18, 89);
            this.chkAutoComplete1.Name = "chkAutoComplete1";
            this.chkAutoComplete1.Size = new System.Drawing.Size(92, 17);
            this.chkAutoComplete1.TabIndex = 1;
            this.chkAutoComplete1.Text = "AutoComplete";
            this.chkAutoComplete1.UseVisualStyleBackColor = true;
            this.chkAutoComplete1.CheckedChanged += new System.EventHandler(this.chkAutoComplete1_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(293, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "BinaryCombobox in Multicolumn mode (Databound)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Enabled = false;
            this.label2.Location = new System.Drawing.Point(18, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "AutoComplete Mode";
            // 
            // cmbBxAutoCompleteMode1
            // 
            this.cmbBxAutoCompleteMode1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBxAutoCompleteMode1.Enabled = false;
            this.cmbBxAutoCompleteMode1.FormattingEnabled = true;
            this.cmbBxAutoCompleteMode1.Items.AddRange(new object[] {
            "None",
            "Suggest",
            "Append",
            "SuggestAppend"});
            this.cmbBxAutoCompleteMode1.Location = new System.Drawing.Point(127, 107);
            this.cmbBxAutoCompleteMode1.Name = "cmbBxAutoCompleteMode1";
            this.cmbBxAutoCompleteMode1.Size = new System.Drawing.Size(124, 21);
            this.cmbBxAutoCompleteMode1.TabIndex = 6;
            this.cmbBxAutoCompleteMode1.SelectedIndexChanged += new System.EventHandler(this.cmbBxAutoCompleteMode1_SelectedIndexChanged);
            // 
            // chkBoxReadOnly1
            // 
            this.chkBoxReadOnly1.AutoSize = true;
            this.chkBoxReadOnly1.Location = new System.Drawing.Point(18, 54);
            this.chkBoxReadOnly1.Name = "chkBoxReadOnly1";
            this.chkBoxReadOnly1.Size = new System.Drawing.Size(166, 17);
            this.chkBoxReadOnly1.TabIndex = 7;
            this.chkBoxReadOnly1.Text = "BinaryCombobox is Read-only";
            this.chkBoxReadOnly1.UseVisualStyleBackColor = true;
            this.chkBoxReadOnly1.CheckedChanged += new System.EventHandler(this.chkBoxReadOnly1_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(292, 581);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(54, 22);
            this.button1.TabIndex = 8;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // binaryTextComboBoxSingleColumn
            // 
            this.binaryTextComboBoxSingleColumn.AlphaBlendFactorForControlPainting = 100;
            this.binaryTextComboBoxSingleColumn.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryTextComboBoxSingleColumn.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryTextComboBoxSingleColumn.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.binaryTextComboBoxSingleColumn.AutoComplete = false;
            this.binaryTextComboBoxSingleColumn.AutoCompleteBasedOnCompleteMatchWithAnItemInTheList = false;
            this.binaryTextComboBoxSingleColumn.AutoCompleteIsCaseSensitive = false;
            this.binaryTextComboBoxSingleColumn.AutoCompleteStyleForMultiColumnModeIsMultiColumn = false;
            this.binaryTextComboBoxSingleColumn.BackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSingleColumn.BuiltinFilterOnNonStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxSingleColumn.BuiltinFilterOnStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxSingleColumn.BusyIndicatorText = "Processing...";
            this.binaryTextComboBoxSingleColumn.ColumnDataTypeFormatInfoContainers = null;
            this.binaryTextComboBoxSingleColumn.ColumnsToDisplay = null;
            this.binaryTextComboBoxSingleColumn.ColumnWidths = null;
            this.binaryTextComboBoxSingleColumn.ComboBoxIsReadOnly = false;
            this.binaryTextComboBoxSingleColumn.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumn.CSVFileSaveAs = "MultiColumnDataViewExport.csv";
            this.binaryTextComboBoxSingleColumn.CustomColumnNameForAutomaticRowSelection = null;
            this.binaryTextComboBoxSingleColumn.CustomComparerImplementor = null;
            this.binaryTextComboBoxSingleColumn.CustomControlBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryTextComboBoxSingleColumn.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSingleColumn.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSingleColumn.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this.binaryTextComboBoxSingleColumn.CustomPaintingColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryTextComboBoxSingleColumn.DataMember = null;
            this.binaryTextComboBoxSingleColumn.DataSource = this.customersBindingSource1;
            this.binaryTextComboBoxSingleColumn.DataSourceViewCustomSortingExpression = null;
            this.binaryTextComboBoxSingleColumn.DesiredFilterColumn = 0;
            this.binaryTextComboBoxSingleColumn.DisplayMember = "CompanyName";
            this.binaryTextComboBoxSingleColumn.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryTextComboBoxSingleColumn.DrawTheControlBasedOnWindowsOS = true;
            this.binaryTextComboBoxSingleColumn.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSingleColumn.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxSingleColumn.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSingleColumn.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSingleColumn.DropDownWindowBorderThickness = 1F;
            this.binaryTextComboBoxSingleColumn.DropDownWindowDisplayOrientation = Binarymission.WinForms.Controls.ListControls.DropDownWindowDisplayOrientation.Default;
            this.binaryTextComboBoxSingleColumn.DropStyleIsMultiColumn = false;
            this.binaryTextComboBoxSingleColumn.EnableAlphaBlendingForFilterAndGroupingPanelBackColor = true;
            this.binaryTextComboBoxSingleColumn.EnableDrawingHeaderFooterWhenInMultiColumnMode = false;
            this.binaryTextComboBoxSingleColumn.ExtendedDropdownButtonImage = null;
            this.binaryTextComboBoxSingleColumn.ExtendedDropdownButtonInternalImage = null;
            this.binaryTextComboBoxSingleColumn.FilterAndGroupingPanelBackColor = System.Drawing.Color.Empty;
            this.binaryTextComboBoxSingleColumn.FilteringIsON = false;
            this.binaryTextComboBoxSingleColumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryTextComboBoxSingleColumn.GroupItemsWhenInMultiColumnDisplayMode = false;
            this.binaryTextComboBoxSingleColumn.GroupMultiColumnDisplayModeDataBasedOnThisColumn = 0;
            this.binaryTextComboBoxSingleColumn.HeadersToDisplay = null;
            this.binaryTextComboBoxSingleColumn.IsAutoCompleteModeAppendSuggestInMultiColumnMode = false;
            this.binaryTextComboBoxSingleColumn.IsCustomisationOfColumnDisplayEnabledInMultiColumnAutoSuggestMode = false;
            this.binaryTextComboBoxSingleColumn.IsFilterSearchResultBasedOnColumnDataType = true;
            this.binaryTextComboBoxSingleColumn.IsInExtendedReadOnlyMode = false;
            this.binaryTextComboBoxSingleColumn.KeepBindingContextInSyncWithParent = false;
            this.binaryTextComboBoxSingleColumn.KeepTheFilterAndGroupingViewsCollapsedAtStartUp = true;
            this.binaryTextComboBoxSingleColumn.KeepTheFilterAndGroupingViewsPaneFullyCollapsedAtStartup = false;
            this.binaryTextComboBoxSingleColumn.Location = new System.Drawing.Point(16, 15);
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownSize = new System.Drawing.Size(500, 250);
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.ColumnHeaderFont = new System.Drawing.Font("Arial", 12F);
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.ColumnHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.DrawFooter = true;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.FooterCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.FooterSurfaceHeight = 20;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.FooterText = "";
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = null;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.HeaderCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.HeaderIcon = null;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.HeaderImageType = Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Icon;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.HeaderSurfaceHeight = 20;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.HeaderText = "";
            this.binaryTextComboBoxSingleColumn.MultiColumnDropDownWindowConfigurationData.NoDataToDisplayMessageText = "There are no items to display.";
            this.binaryTextComboBoxSingleColumn.MultiColumnDropListBackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropListFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxSingleColumn.MultiColumnDropListForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropListGridLines = true;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropListHoverSelection = false;
            this.binaryTextComboBoxSingleColumn.MultiColumnDroplistWindowAnimationStyle = Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
            this.binaryTextComboBoxSingleColumn.MultiColumnDropListWindowIsResizable = true;
            this.binaryTextComboBoxSingleColumn.MultiColumnViewBusyProcessingText = "Processing the query... please wait...";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewNoDataFoundText = "There is no data to display.";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewSortingGlyphColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableDataGroupingText = "Enable data grouping";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableFilterOptionsText = "Enable filter options";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemExportDataToCSV = "Export data to CSV";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.ContextMenuItemShowCommandBarText = "Show command bar";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemBuiltInFilter = "Built-in filter";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemCustomExpression = "Custom expression";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemFilterOnThisColumn = "Filter on this column:";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowItemEnableGrouping = "Enable \"grouping\"";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterDataWhileTheUserTypesExpression = "Filter data while the user types expression?";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpression = "Filter expression:";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionType = "Filter expression type:";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionTypeComboBoxTooltip = resources.GetString("resource.WindowItemFilterExpressionTypeComboBoxTooltip1");
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowItemFilteringStatusPart = "Filter status: Filtering is currently using";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowItemGroupOnThisColumn = "Group on this column:";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowItemHideFilterAndGroupingOptions = "Hide filter and grouping options";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowItemShowFilterAndGroupingOptions = "Show filter and grouping options";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowItemUseFilterToRetrieveData = "Use filter to retrieve data";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowStatusBarCustomExpressionErrorMessage = "Invalid custom expression. Please correct.";
            this.binaryTextComboBoxSingleColumn.MultiColumnViewUIElementsTextProvider.WindowTaskStatusMessageForCSVExportSuccessful = "                Command result: CSV export successful.";
            this.binaryTextComboBoxSingleColumn.MultiColumnWindowColumnsHorizontalAlignments = ((System.Collections.Generic.IList<System.Windows.Forms.HorizontalAlignment>)(resources.GetObject("binaryTextComboBoxSingleColumn.MultiColumnWindowColumnsHorizontalAlignments")));
            this.binaryTextComboBoxSingleColumn.Name = "binaryTextComboBoxSingleColumn";
            this.binaryTextComboBoxSingleColumn.SelectedIndexFromDropList = -1;
            this.binaryTextComboBoxSingleColumn.ShareCustomMultiColumnSizeAcrossDataListAndFilterGroupingOptionsPane = true;
            this.binaryTextComboBoxSingleColumn.ShouldAllowUserInputWhileProcessingMultiColumnAutoCompleDropDownView = true;
            this.binaryTextComboBoxSingleColumn.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryTextComboBoxSingleColumn.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryTextComboBoxSingleColumn.ShouldDrawExtendedDropdownButton = false;
            this.binaryTextComboBoxSingleColumn.ShouldPersistUserSetColumnWidthsAcrossFilterSessions = false;
            this.binaryTextComboBoxSingleColumn.ShowBorderAlways = true;
            this.binaryTextComboBoxSingleColumn.ShowDropDownMultiColumnWindowAfterAdjustingForVirtualAvaliableScreenSpace = false;
            this.binaryTextComboBoxSingleColumn.ShowEmptyDropListViewWhenThereAreNoData = true;
            this.binaryTextComboBoxSingleColumn.ShowFilterOptionsInMultiColumnMode = false;
            this.binaryTextComboBoxSingleColumn.Size = new System.Drawing.Size(187, 21);
            this.binaryTextComboBoxSingleColumn.SizeForMultiColumnAutoCompleteSuggestionDropDownWindow = new System.Drawing.Size(0, 0);
            this.binaryTextComboBoxSingleColumn.SizesForMultiColumnAutoCompleteSuggestionDropDownWindowColumns = null;
            this.binaryTextComboBoxSingleColumn.TabIndex = 9;
            this.binaryTextComboBoxSingleColumn.TableToLoad = null;
            this.binaryTextComboBoxSingleColumn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxSingleColumn.ValueMember = "CustomerID";
            // 
            // customersBindingSource1
            // 
            this.customersBindingSource1.DataMember = "Customers";
            this.customersBindingSource1.DataSource = this.customersTestDataSet1;
            // 
            // customersTestDataSet1
            // 
            this.customersTestDataSet1.DataSetName = "CustomersTestDataSet1";
            this.customersTestDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 234);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(309, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "BinaryCombobox in Single column mode  (Databound)";
            // 
            // chkBoxReadOnly2
            // 
            this.chkBoxReadOnly2.AutoSize = true;
            this.chkBoxReadOnly2.Location = new System.Drawing.Point(16, 53);
            this.chkBoxReadOnly2.Name = "chkBoxReadOnly2";
            this.chkBoxReadOnly2.Size = new System.Drawing.Size(166, 17);
            this.chkBoxReadOnly2.TabIndex = 12;
            this.chkBoxReadOnly2.Text = "BinaryCombobox is Read-only";
            this.chkBoxReadOnly2.UseVisualStyleBackColor = true;
            this.chkBoxReadOnly2.CheckedChanged += new System.EventHandler(this.chkBoxReadOnly2_CheckedChanged);
            // 
            // chkAutoComplete2
            // 
            this.chkAutoComplete2.AutoSize = true;
            this.chkAutoComplete2.Location = new System.Drawing.Point(16, 86);
            this.chkAutoComplete2.Name = "chkAutoComplete2";
            this.chkAutoComplete2.Size = new System.Drawing.Size(92, 17);
            this.chkAutoComplete2.TabIndex = 11;
            this.chkAutoComplete2.Text = "AutoComplete";
            this.chkAutoComplete2.UseVisualStyleBackColor = true;
            this.chkAutoComplete2.CheckedChanged += new System.EventHandler(this.chkAutoComplete2_CheckedChanged);
            // 
            // customersTableAdapter1
            // 
            this.customersTableAdapter1.ClearBeforeFill = true;
            // 
            // cmbBxAutoCompleteMode2
            // 
            this.cmbBxAutoCompleteMode2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBxAutoCompleteMode2.Enabled = false;
            this.cmbBxAutoCompleteMode2.FormattingEnabled = true;
            this.cmbBxAutoCompleteMode2.Items.AddRange(new object[] {
            "None",
            "Suggest",
            "Append",
            "SuggestAppend"});
            this.cmbBxAutoCompleteMode2.Location = new System.Drawing.Point(127, 106);
            this.cmbBxAutoCompleteMode2.Name = "cmbBxAutoCompleteMode2";
            this.cmbBxAutoCompleteMode2.Size = new System.Drawing.Size(124, 21);
            this.cmbBxAutoCompleteMode2.TabIndex = 15;
            this.cmbBxAutoCompleteMode2.SelectedIndexChanged += new System.EventHandler(this.cmbBxAutoCompleteMode2_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Enabled = false;
            this.label4.Location = new System.Drawing.Point(16, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "AutoComplete Mode";
            // 
            // cmbBxAutoCompleteMode3
            // 
            this.cmbBxAutoCompleteMode3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBxAutoCompleteMode3.Enabled = false;
            this.cmbBxAutoCompleteMode3.FormattingEnabled = true;
            this.cmbBxAutoCompleteMode3.Items.AddRange(new object[] {
            "None",
            "Suggest",
            "Append",
            "SuggestAppend"});
            this.cmbBxAutoCompleteMode3.Location = new System.Drawing.Point(127, 108);
            this.cmbBxAutoCompleteMode3.Name = "cmbBxAutoCompleteMode3";
            this.cmbBxAutoCompleteMode3.Size = new System.Drawing.Size(124, 21);
            this.cmbBxAutoCompleteMode3.TabIndex = 21;
            this.cmbBxAutoCompleteMode3.SelectedIndexChanged += new System.EventHandler(this.cmbBxAutoCompleteMode3_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Enabled = false;
            this.label5.Location = new System.Drawing.Point(15, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "AutoComplete Mode";
            // 
            // chkBoxReadOnly3
            // 
            this.chkBoxReadOnly3.AutoSize = true;
            this.chkBoxReadOnly3.Location = new System.Drawing.Point(15, 55);
            this.chkBoxReadOnly3.Name = "chkBoxReadOnly3";
            this.chkBoxReadOnly3.Size = new System.Drawing.Size(166, 17);
            this.chkBoxReadOnly3.TabIndex = 19;
            this.chkBoxReadOnly3.Text = "BinaryCombobox is Read-only";
            this.chkBoxReadOnly3.UseVisualStyleBackColor = true;
            this.chkBoxReadOnly3.CheckedChanged += new System.EventHandler(this.chkBoxReadOnly3_CheckedChanged);
            // 
            // chkAutoComplete3
            // 
            this.chkAutoComplete3.AutoSize = true;
            this.chkAutoComplete3.Location = new System.Drawing.Point(15, 88);
            this.chkAutoComplete3.Name = "chkAutoComplete3";
            this.chkAutoComplete3.Size = new System.Drawing.Size(92, 17);
            this.chkAutoComplete3.TabIndex = 18;
            this.chkAutoComplete3.Text = "AutoComplete";
            this.chkAutoComplete3.UseVisualStyleBackColor = true;
            this.chkAutoComplete3.CheckedChanged += new System.EventHandler(this.chkAutoComplete3_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 412);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(334, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "BinaryCombobox in Single column mode  (un-bound mode)";
            // 
            // binaryTextComboBoxSingleColumnUnbound
            // 
            this.binaryTextComboBoxSingleColumnUnbound.AlphaBlendFactorForControlPainting = 100;
            this.binaryTextComboBoxSingleColumnUnbound.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryTextComboBoxSingleColumnUnbound.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryTextComboBoxSingleColumnUnbound.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.binaryTextComboBoxSingleColumnUnbound.AutoComplete = false;
            this.binaryTextComboBoxSingleColumnUnbound.AutoCompleteBasedOnCompleteMatchWithAnItemInTheList = false;
            this.binaryTextComboBoxSingleColumnUnbound.AutoCompleteIsCaseSensitive = false;
            this.binaryTextComboBoxSingleColumnUnbound.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.binaryTextComboBoxSingleColumnUnbound.AutoCompleteStyleForMultiColumnModeIsMultiColumn = false;
            this.binaryTextComboBoxSingleColumnUnbound.BackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSingleColumnUnbound.BuiltinFilterOnNonStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxSingleColumnUnbound.BuiltinFilterOnStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxSingleColumnUnbound.BusyIndicatorText = "Processing...";
            this.binaryTextComboBoxSingleColumnUnbound.ColumnDataTypeFormatInfoContainers = null;
            this.binaryTextComboBoxSingleColumnUnbound.ColumnsToDisplay = null;
            this.binaryTextComboBoxSingleColumnUnbound.ColumnWidths = null;
            this.binaryTextComboBoxSingleColumnUnbound.ComboBoxIsReadOnly = false;
            this.binaryTextComboBoxSingleColumnUnbound.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumnUnbound.CSVFileSaveAs = "MultiColumnDataViewExport.csv";
            this.binaryTextComboBoxSingleColumnUnbound.CustomColumnNameForAutomaticRowSelection = null;
            this.binaryTextComboBoxSingleColumnUnbound.CustomComparerImplementor = null;
            this.binaryTextComboBoxSingleColumnUnbound.CustomControlBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryTextComboBoxSingleColumnUnbound.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSingleColumnUnbound.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSingleColumnUnbound.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this.binaryTextComboBoxSingleColumnUnbound.CustomPaintingColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryTextComboBoxSingleColumnUnbound.DataMember = null;
            this.binaryTextComboBoxSingleColumnUnbound.DataSourceViewCustomSortingExpression = null;
            this.binaryTextComboBoxSingleColumnUnbound.DesiredFilterColumn = 0;
            this.binaryTextComboBoxSingleColumnUnbound.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryTextComboBoxSingleColumnUnbound.DrawTheControlBasedOnWindowsOS = true;
            this.binaryTextComboBoxSingleColumnUnbound.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSingleColumnUnbound.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxSingleColumnUnbound.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSingleColumnUnbound.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxSingleColumnUnbound.DropDownWindowBorderThickness = 1F;
            this.binaryTextComboBoxSingleColumnUnbound.DropDownWindowDisplayOrientation = Binarymission.WinForms.Controls.ListControls.DropDownWindowDisplayOrientation.Default;
            this.binaryTextComboBoxSingleColumnUnbound.DropStyleIsMultiColumn = false;
            this.binaryTextComboBoxSingleColumnUnbound.EnableAlphaBlendingForFilterAndGroupingPanelBackColor = true;
            this.binaryTextComboBoxSingleColumnUnbound.EnableDrawingHeaderFooterWhenInMultiColumnMode = false;
            this.binaryTextComboBoxSingleColumnUnbound.ExtendedDropdownButtonImage = null;
            this.binaryTextComboBoxSingleColumnUnbound.ExtendedDropdownButtonInternalImage = null;
            this.binaryTextComboBoxSingleColumnUnbound.FilterAndGroupingPanelBackColor = System.Drawing.Color.Empty;
            this.binaryTextComboBoxSingleColumnUnbound.FilteringIsON = false;
            this.binaryTextComboBoxSingleColumnUnbound.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryTextComboBoxSingleColumnUnbound.GroupItemsWhenInMultiColumnDisplayMode = false;
            this.binaryTextComboBoxSingleColumnUnbound.GroupMultiColumnDisplayModeDataBasedOnThisColumn = 0;
            this.binaryTextComboBoxSingleColumnUnbound.HeadersToDisplay = null;
            this.binaryTextComboBoxSingleColumnUnbound.IsAutoCompleteModeAppendSuggestInMultiColumnMode = false;
            this.binaryTextComboBoxSingleColumnUnbound.IsCustomisationOfColumnDisplayEnabledInMultiColumnAutoSuggestMode = false;
            this.binaryTextComboBoxSingleColumnUnbound.IsFilterSearchResultBasedOnColumnDataType = true;
            this.binaryTextComboBoxSingleColumnUnbound.IsInExtendedReadOnlyMode = false;
            this.binaryTextComboBoxSingleColumnUnbound.Items.AddRange(new object[] {
            "Five",
            "Five, second entry",
            "Five, third entry",
            "Four",
            "Four, second entry",
            "Four, third entry",
            "One-First entry",
            "One more",
            "One more and more",
            "Three",
            "Three, second enty",
            "Three, third entry",
            "Tow more, and more",
            "Two - second entry",
            "Two more"});
            this.binaryTextComboBoxSingleColumnUnbound.KeepBindingContextInSyncWithParent = false;
            this.binaryTextComboBoxSingleColumnUnbound.KeepTheFilterAndGroupingViewsCollapsedAtStartUp = true;
            this.binaryTextComboBoxSingleColumnUnbound.KeepTheFilterAndGroupingViewsPaneFullyCollapsedAtStartup = false;
            this.binaryTextComboBoxSingleColumnUnbound.Location = new System.Drawing.Point(15, 17);
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownSize = new System.Drawing.Size(500, 250);
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.ColumnHeaderFont = new System.Drawing.Font("Arial", 12F);
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.ColumnHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.DrawFooter = true;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.FooterCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.FooterSurfaceHeight = 20;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.FooterText = "";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = null;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderIcon = null;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderImageType = Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Icon;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderSurfaceHeight = 20;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.HeaderText = "";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropDownWindowConfigurationData.NoDataToDisplayMessageText = "There are no items to display.";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropListBackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropListFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropListForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropListGridLines = true;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropListHoverSelection = false;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDroplistWindowAnimationStyle = Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnDropListWindowIsResizable = true;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewBusyProcessingText = "Processing the query... please wait...";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewNoDataFoundText = "There is no data to display.";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewSortingGlyphColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableDataGroupingText = "Enable data grouping";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableFilterOptionsText = "Enable filter options";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.ContextMenuItemExportDataToCSV = "Export data to CSV";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.ContextMenuItemShowCommandBarText = "Show command bar";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemBuiltInFilter = "Built-in filter";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemCustomExpression = "Custom expression";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemFilterOnThisColumn = "Filter on this column:";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemEnableGrouping = "Enable \"grouping\"";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemFilterDataWhileTheUserTypesExpression = "Filter data while the user types expression?";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpression = "Filter expression:";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionType = "Filter expression type:";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionTypeComboBoxTooltip = resources.GetString("resource.WindowItemFilterExpressionTypeComboBoxTooltip2");
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemFilteringStatusPart = "Filter status: Filtering is currently using";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemGroupOnThisColumn = "Group on this column:";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemHideFilterAndGroupingOptions = "Hide filter and grouping options";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemShowFilterAndGroupingOptions = "Show filter and grouping options";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowItemUseFilterToRetrieveData = "Use filter to retrieve data";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowStatusBarCustomExpressionErrorMessage = "Invalid custom expression. Please correct.";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnViewUIElementsTextProvider.WindowTaskStatusMessageForCSVExportSuccessful = "                Command result: CSV export successful.";
            this.binaryTextComboBoxSingleColumnUnbound.MultiColumnWindowColumnsHorizontalAlignments = ((System.Collections.Generic.IList<System.Windows.Forms.HorizontalAlignment>)(resources.GetObject("binaryTextComboBoxSingleColumnUnbound.MultiColumnWindowColumnsHorizontalAlignment" +
        "s")));
            this.binaryTextComboBoxSingleColumnUnbound.Name = "binaryTextComboBoxSingleColumnUnbound";
            this.binaryTextComboBoxSingleColumnUnbound.SelectedIndexFromDropList = -1;
            this.binaryTextComboBoxSingleColumnUnbound.ShareCustomMultiColumnSizeAcrossDataListAndFilterGroupingOptionsPane = true;
            this.binaryTextComboBoxSingleColumnUnbound.ShouldAllowUserInputWhileProcessingMultiColumnAutoCompleDropDownView = true;
            this.binaryTextComboBoxSingleColumnUnbound.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryTextComboBoxSingleColumnUnbound.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryTextComboBoxSingleColumnUnbound.ShouldDrawExtendedDropdownButton = false;
            this.binaryTextComboBoxSingleColumnUnbound.ShouldPersistUserSetColumnWidthsAcrossFilterSessions = false;
            this.binaryTextComboBoxSingleColumnUnbound.ShowBorderAlways = true;
            this.binaryTextComboBoxSingleColumnUnbound.ShowDropDownMultiColumnWindowAfterAdjustingForVirtualAvaliableScreenSpace = false;
            this.binaryTextComboBoxSingleColumnUnbound.ShowEmptyDropListViewWhenThereAreNoData = true;
            this.binaryTextComboBoxSingleColumnUnbound.ShowFilterOptionsInMultiColumnMode = false;
            this.binaryTextComboBoxSingleColumnUnbound.Size = new System.Drawing.Size(187, 21);
            this.binaryTextComboBoxSingleColumnUnbound.SizeForMultiColumnAutoCompleteSuggestionDropDownWindow = new System.Drawing.Size(0, 0);
            this.binaryTextComboBoxSingleColumnUnbound.SizesForMultiColumnAutoCompleteSuggestionDropDownWindowColumns = null;
            this.binaryTextComboBoxSingleColumnUnbound.TabIndex = 16;
            this.binaryTextComboBoxSingleColumnUnbound.TableToLoad = null;
            this.binaryTextComboBoxSingleColumnUnbound.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.chkIsAutoCompletionInMultiColumnDisplay);
            this.panel1.Controls.Add(this.binaryTextComboBoxMultiColumn);
            this.panel1.Controls.Add(this.chkAutoComplete1);
            this.panel1.Controls.Add(this.chkBoxReadOnly1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cmbBxAutoCompleteMode1);
            this.panel1.Location = new System.Drawing.Point(15, 34);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(331, 179);
            this.panel1.TabIndex = 22;
            // 
            // chkIsAutoCompletionInMultiColumnDisplay
            // 
            this.chkIsAutoCompletionInMultiColumnDisplay.AutoSize = true;
            this.chkIsAutoCompletionInMultiColumnDisplay.Location = new System.Drawing.Point(18, 143);
            this.chkIsAutoCompletionInMultiColumnDisplay.Name = "chkIsAutoCompletionInMultiColumnDisplay";
            this.chkIsAutoCompletionInMultiColumnDisplay.Size = new System.Drawing.Size(270, 17);
            this.chkIsAutoCompletionInMultiColumnDisplay.TabIndex = 8;
            this.chkIsAutoCompletionInMultiColumnDisplay.Text = "Is auto-completion window in multi-column mode too";
            this.chkIsAutoCompletionInMultiColumnDisplay.UseVisualStyleBackColor = true;
            this.chkIsAutoCompletionInMultiColumnDisplay.CheckedChanged += new System.EventHandler(this.chkIsAutoCompletionInMultiColumnDisplay_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.cmbBxAutoCompleteMode2);
            this.panel2.Controls.Add(this.binaryTextComboBoxSingleColumn);
            this.panel2.Controls.Add(this.chkAutoComplete2);
            this.panel2.Controls.Add(this.chkBoxReadOnly2);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(15, 250);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(331, 141);
            this.panel2.TabIndex = 23;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.binaryTextComboBoxSingleColumnUnbound);
            this.panel3.Controls.Add(this.chkAutoComplete3);
            this.panel3.Controls.Add(this.chkBoxReadOnly3);
            this.panel3.Controls.Add(this.cmbBxAutoCompleteMode3);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Location = new System.Drawing.Point(15, 431);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(331, 141);
            this.panel3.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(371, 649);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customersTestDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersTestDataSet1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CustomersTestDataSet customersTestDataSet;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private BinaryComboboxAutoCompleteSample.CustomersTestDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
        private Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox binaryTextComboBoxMultiColumn;
        private System.Windows.Forms.CheckBox chkAutoComplete1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbBxAutoCompleteMode1;
        private System.Windows.Forms.CheckBox chkBoxReadOnly1;
        private System.Windows.Forms.Button button1;
        private Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox binaryTextComboBoxSingleColumn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkBoxReadOnly2;
        private System.Windows.Forms.CheckBox chkAutoComplete2;
        private CustomersTestDataSet1 customersTestDataSet1;
        private System.Windows.Forms.BindingSource customersBindingSource1;
        private BinaryComboboxAutoCompleteSample.CustomersTestDataSet1TableAdapters.CustomersTableAdapter customersTableAdapter1;
        private System.Windows.Forms.ComboBox cmbBxAutoCompleteMode2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbBxAutoCompleteMode3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox chkBoxReadOnly3;
        private System.Windows.Forms.CheckBox chkAutoComplete3;
        private System.Windows.Forms.Label label6;
        private Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox binaryTextComboBoxSingleColumnUnbound;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.CheckBox chkIsAutoCompletionInMultiColumnDisplay;
    }
}

