using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryComboboxColorCustomisationSample
{
    public partial class Form1 : ModernChromeWindow
    {
        public Form1()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"Color Customisation Demo";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'customersTestDataSet.Customers' table. You can move, or remove it, as needed.
            this.customersTableAdapter.Fill(this.customersTestDataSet.Customers);
            RetrievePresets();

        }

        private void binaryColorPickerComboBoxBackcolor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumn.BackColor = 
                binaryColorPickerComboBoxBackcolor.SelectedColor;
        }

        private void binaryColorPickerComboBoxForecolor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumn.ForeColor = 
                binaryColorPickerComboBoxForecolor.SelectedColor;
        }

        private void binaryColorPickerComboBoxBorderColor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumn.CustomControlBorderColor = 
                binaryColorPickerComboBoxBorderColor.SelectedColor;
        }

        private void binaryColorPickerComboBoxPaintingColor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumn.CustomPaintingColor =
                binaryColorPickerComboBoxPaintingColor.SelectedColor;
        }

        private void binaryColorPickerComboBoxDropdownArrowColor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumn.ControlArrowColor =
                binaryColorPickerComboBoxDropdownArrowColor.SelectedColor;
        }

        private void binaryColorPickerComboBoxDropdownWindowBackcolor_SelectedColorChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumn.DropDownWindowBackgroundColor =
                binaryColorPickerComboBoxDropdownWindowBackcolor.SelectedColor;            
        }

        private void numericUpDownForPainting_ValueChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumn.AlphaBlendFactorForControlPainting = 
                Convert.ToInt32(numericUpDownForPainting.Value);
                
        }

        private void numericUpDownForDropdownPressed_ValueChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumn.AlphaBlendFactorForDropDownPressedColor =
                Convert.ToInt32(numericUpDownForDropdownPressed.Value);
        }

        private void numericUpDownForItemSelection_ValueChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxSingleColumn.AlphaBlendFactorForItemSelectionColor =
                Convert.ToInt32(numericUpDownForItemSelection.Value);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RetrievePresets()
        {
            binaryColorPickerComboBoxBackcolor.SelectedColor = binaryTextComboBoxSingleColumn.BackColor;
            binaryColorPickerComboBoxForecolor.SelectedColor = binaryTextComboBoxSingleColumn.ForeColor;
            binaryColorPickerComboBoxBorderColor.SelectedColor = binaryTextComboBoxSingleColumn.CustomControlBorderColor;
            binaryColorPickerComboBoxPaintingColor.SelectedColor = binaryTextComboBoxSingleColumn.CustomPaintingColor;
            binaryColorPickerComboBoxDropdownArrowColor.SelectedColor = binaryTextComboBoxSingleColumn.ControlArrowColor;
            binaryColorPickerComboBoxDropdownWindowBackcolor.SelectedColor = binaryTextComboBoxSingleColumn.DropDownWindowBackgroundColor;
        }
    }
}