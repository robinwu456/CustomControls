using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryComboboxDataExportfeatureSample
{
    public partial class Form1 : ModernChromeWindow
    {
        public Form1()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"Data export Demo";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'testDataSet.Salesdata' table. You can move, or remove it, as needed.
            this.salesdataTableAdapter.Fill(this.testDataSet.Salesdata);
            txtFileName.Text = binaryTextComboBoxMulticolumnMode.CSVFileSaveAs;

        }

        private void txtFileName_TextChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumnMode.CSVFileSaveAs = txtFileName.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClearFileName_Click(object sender, EventArgs e)
        {
            txtFileName.Text = null;
        }

        private void btnFilePath_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "CSV Files (*.csv)|*.csv";
            if (DialogResult.Cancel != saveFileDialog.ShowDialog())
            {
                binaryTextComboBoxMulticolumnMode.CSVFileSaveAs = saveFileDialog.FileName;
                txtFileName.Text = saveFileDialog.FileName;
            }

        }

 
    }
}