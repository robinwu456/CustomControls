namespace BinaryComboboxSortingGroupingFiltering
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.salesdataBindingSource = new System.Windows.Forms.BindingSource();
            this.testDataSet = new BinaryComboboxSortingGroupingFiltering.TestDataSet();
            this.salesdataTableAdapter = new BinaryComboboxSortingGroupingFiltering.TestDataSetTableAdapters.SalesdataTableAdapter();
            this.chkFilterGrouping = new System.Windows.Forms.CheckBox();
            this.chkColumnSorting = new System.Windows.Forms.CheckBox();
            this.chkGrouping = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkCollapsedView = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.binaryTextComboBoxMulticolumnMode = new Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.salesdataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testDataSet)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(277, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "BinaryCombobox instance (multi-column mode)";
            // 
            // salesdataBindingSource
            // 
            this.salesdataBindingSource.DataMember = "Salesdata";
            this.salesdataBindingSource.DataSource = this.testDataSet;
            // 
            // testDataSet
            // 
            this.testDataSet.DataSetName = "TestDataSet";
            this.testDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // salesdataTableAdapter
            // 
            this.salesdataTableAdapter.ClearBeforeFill = true;
            // 
            // chkFilterGrouping
            // 
            this.chkFilterGrouping.AutoSize = true;
            this.chkFilterGrouping.Location = new System.Drawing.Point(5, 35);
            this.chkFilterGrouping.Name = "chkFilterGrouping";
            this.chkFilterGrouping.Size = new System.Drawing.Size(207, 17);
            this.chkFilterGrouping.TabIndex = 0;
            this.chkFilterGrouping.Text = "Show data-filter and grouping options";
            this.chkFilterGrouping.UseVisualStyleBackColor = true;
            this.chkFilterGrouping.CheckedChanged += new System.EventHandler(this.chkFilterGrouping_CheckedChanged);
            // 
            // chkColumnSorting
            // 
            this.chkColumnSorting.AutoSize = true;
            this.chkColumnSorting.Location = new System.Drawing.Point(5, 12);
            this.chkColumnSorting.Name = "chkColumnSorting";
            this.chkColumnSorting.Size = new System.Drawing.Size(130, 17);
            this.chkColumnSorting.TabIndex = 4;
            this.chkColumnSorting.Text = "Enable column sorting";
            this.chkColumnSorting.UseVisualStyleBackColor = true;
            this.chkColumnSorting.CheckedChanged += new System.EventHandler(this.chkColumnSorting_CheckedChanged);
            // 
            // chkGrouping
            // 
            this.chkGrouping.AutoSize = true;
            this.chkGrouping.Location = new System.Drawing.Point(5, 81);
            this.chkGrouping.Name = "chkGrouping";
            this.chkGrouping.Size = new System.Drawing.Size(164, 17);
            this.chkGrouping.TabIndex = 1;
            this.chkGrouping.Text = "View data in \"grouped\" mode";
            this.chkGrouping.UseVisualStyleBackColor = true;
            this.chkGrouping.CheckedChanged += new System.EventHandler(this.chkGrouping_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.chkCollapsedView);
            this.panel1.Controls.Add(this.chkFilterGrouping);
            this.panel1.Controls.Add(this.chkColumnSorting);
            this.panel1.Controls.Add(this.chkGrouping);
            this.panel1.Location = new System.Drawing.Point(20, 135);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(306, 114);
            this.panel1.TabIndex = 5;
            // 
            // chkCollapsedView
            // 
            this.chkCollapsedView.AutoSize = true;
            this.chkCollapsedView.Location = new System.Drawing.Point(5, 58);
            this.chkCollapsedView.Name = "chkCollapsedView";
            this.chkCollapsedView.Size = new System.Drawing.Size(291, 17);
            this.chkCollapsedView.TabIndex = 6;
            this.chkCollapsedView.Text = "Keep the filter and grouping views collapsed at start up";
            this.chkCollapsedView.UseVisualStyleBackColor = true;
            this.chkCollapsedView.CheckedChanged += new System.EventHandler(this.chkCollapsedView_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(191, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Sorting, Filtering and Grouping options";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(268, 267);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(58, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // binaryTextComboBoxMulticolumnMode
            // 
            this.binaryTextComboBoxMulticolumnMode.AlphaBlendFactorForControlPainting = 100;
            this.binaryTextComboBoxMulticolumnMode.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryTextComboBoxMulticolumnMode.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryTextComboBoxMulticolumnMode.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.binaryTextComboBoxMulticolumnMode.AutoComplete = true;
            this.binaryTextComboBoxMulticolumnMode.AutoCompleteBasedOnCompleteMatchWithAnItemInTheList = false;
            this.binaryTextComboBoxMulticolumnMode.AutoCompleteIsCaseSensitive = true;
            this.binaryTextComboBoxMulticolumnMode.AutoCompleteStyleForMultiColumnModeIsMultiColumn = false;
            this.binaryTextComboBoxMulticolumnMode.BackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumnMode.BuiltinFilterOnNonStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxMulticolumnMode.BuiltinFilterOnStringTypeColumnFilterMode = Binarymission.WinForms.Controls.ListControls.BuiltinFilterOnNonStringTypeColumnFilterResultsMode.MatchIsExact;
            this.binaryTextComboBoxMulticolumnMode.BusyIndicatorText = "Processing...";
            this.binaryTextComboBoxMulticolumnMode.ColumnDataTypeFormatInfoContainers = null;
            this.binaryTextComboBoxMulticolumnMode.ColumnsToDisplay = null;
            this.binaryTextComboBoxMulticolumnMode.ColumnWidths = null;
            this.binaryTextComboBoxMulticolumnMode.ComboBoxIsReadOnly = false;
            this.binaryTextComboBoxMulticolumnMode.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumnMode.CSVFileSaveAs = "MultiColumnDataViewExport.csv";
            this.binaryTextComboBoxMulticolumnMode.CustomColumnNameForAutomaticRowSelection = null;
            this.binaryTextComboBoxMulticolumnMode.CustomComparerImplementor = null;
            this.binaryTextComboBoxMulticolumnMode.CustomControlBorderColor = System.Drawing.Color.Black;
            this.binaryTextComboBoxMulticolumnMode.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumnMode.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumnMode.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this.binaryTextComboBoxMulticolumnMode.CustomPaintingColor = System.Drawing.Color.Silver;
            this.binaryTextComboBoxMulticolumnMode.DataMember = null;
            this.binaryTextComboBoxMulticolumnMode.DataSource = this.salesdataBindingSource;
            this.binaryTextComboBoxMulticolumnMode.DataSourceViewCustomSortingExpression = null;
            this.binaryTextComboBoxMulticolumnMode.DesiredFilterColumn = 0;
            this.binaryTextComboBoxMulticolumnMode.DisplayMember = "CompanyName";
            this.binaryTextComboBoxMulticolumnMode.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryTextComboBoxMulticolumnMode.DrawTheControlBasedOnWindowsOS = true;
            this.binaryTextComboBoxMulticolumnMode.DropDownItemBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumnMode.DropDownItemTextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxMulticolumnMode.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumnMode.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.binaryTextComboBoxMulticolumnMode.DropDownWindowBorderThickness = 1F;
            this.binaryTextComboBoxMulticolumnMode.DropDownWindowDisplayOrientation = Binarymission.WinForms.Controls.ListControls.DropDownWindowDisplayOrientation.Default;
            this.binaryTextComboBoxMulticolumnMode.DropStyleIsMultiColumn = true;
            this.binaryTextComboBoxMulticolumnMode.EnableAlphaBlendingForFilterAndGroupingPanelBackColor = true;
            this.binaryTextComboBoxMulticolumnMode.EnableColumnSorting = false;
            this.binaryTextComboBoxMulticolumnMode.EnableDrawingHeaderFooterWhenInMultiColumnMode = false;
            this.binaryTextComboBoxMulticolumnMode.ExtendedDropdownButtonImage = null;
            this.binaryTextComboBoxMulticolumnMode.ExtendedDropdownButtonInternalImage = null;
            this.binaryTextComboBoxMulticolumnMode.FilterAndGroupingPanelBackColor = System.Drawing.Color.Empty;
            this.binaryTextComboBoxMulticolumnMode.FilteringIsON = false;
            this.binaryTextComboBoxMulticolumnMode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryTextComboBoxMulticolumnMode.GroupItemsWhenInMultiColumnDisplayMode = false;
            this.binaryTextComboBoxMulticolumnMode.GroupMultiColumnDisplayModeDataBasedOnThisColumn = 0;
            this.binaryTextComboBoxMulticolumnMode.HeadersToDisplay = null;
            this.binaryTextComboBoxMulticolumnMode.IsAutoCompleteModeAppendSuggestInMultiColumnMode = false;
            this.binaryTextComboBoxMulticolumnMode.IsCustomisationOfColumnDisplayEnabledInMultiColumnAutoSuggestMode = false;
            this.binaryTextComboBoxMulticolumnMode.IsFilterSearchResultBasedOnColumnDataType = true;
            this.binaryTextComboBoxMulticolumnMode.IsInExtendedReadOnlyMode = false;
            this.binaryTextComboBoxMulticolumnMode.KeepBindingContextInSyncWithParent = false;
            this.binaryTextComboBoxMulticolumnMode.KeepTheFilterAndGroupingViewsCollapsedAtStartUp = false;
            this.binaryTextComboBoxMulticolumnMode.KeepTheFilterAndGroupingViewsPaneFullyCollapsedAtStartup = false;
            this.binaryTextComboBoxMulticolumnMode.Location = new System.Drawing.Point(20, 52);
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownSize = new System.Drawing.Size(500, 250);
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowBorderThickness = 0F;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.ColumnHeaderFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.ColumnHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.DrawFooter = true;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.FooterCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.FooterSurfaceHeight = 20;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.FooterText = "";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.HeaderAndFooterTextForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.HeaderBitmap = null;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.HeaderCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingEndColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.HeaderControlRenderingStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(169)))), ((int)(((byte)(225)))));
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.HeaderIcon = null;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.HeaderImageType = Binarymission.WinForms.Controls.ListControls.HeaderImageStyle.Icon;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.HeaderSurfaceHeight = 20;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.HeaderText = "";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropDownWindowConfigurationData.NoDataToDisplayMessageText = "There are no items to display.";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropListBackColor = System.Drawing.SystemColors.Window;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropListFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropListForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropListGridLines = true;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropListHoverSelection = false;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDroplistWindowAnimationStyle = Binarymission.WinForms.Controls.ListControls.MultiColumnDroplistWindowAnimationStyle.None;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnDropListWindowIsResizable = true;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewBusyProcessingText = "Processing the query... please wait...";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewNoDataFoundText = "There is no data to display.";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewSortingGlyphColor = System.Drawing.SystemColors.WindowText;
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableDataGroupingText = "Enable data grouping";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.ContextMenuItemEnableFilterOptionsText = "Enable filter options";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.ContextMenuItemExportDataToCSV = "Export data to CSV";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.ContextMenuItemShowCommandBarText = "Show command bar";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemBuiltInFilter = "Built-in filter";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemCustomExpression = "Custom expression";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowComboBoxItemFilterOnThisColumn = "Filter on this column:";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowItemEnableGrouping = "Enable \"grouping\"";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowItemFilterDataWhileTheUserTypesExpression = "Filter data while the user types expression?";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpression = "Filter expression:";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionType = "Filter expression type:";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowItemFilterExpressionTypeComboBoxTooltip = resources.GetString("resource.WindowItemFilterExpressionTypeComboBoxTooltip");
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowItemFilteringStatusPart = "Filter status: Filtering is currently using";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowItemGroupOnThisColumn = "Group on this column:";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowItemHideFilterAndGroupingOptions = "Hide filter and grouping options";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowItemShowFilterAndGroupingOptions = "Show filter and grouping options";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowItemUseFilterToRetrieveData = "Use filter to retrieve data";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowStatusBarCustomExpressionErrorMessage = "Invalid custom expression. Please correct.";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnViewUIElementsTextProvider.WindowTaskStatusMessageForCSVExportSuccessful = "                Command result: CSV export successful.";
            this.binaryTextComboBoxMulticolumnMode.MultiColumnWindowColumnsHorizontalAlignments = ((System.Collections.Generic.IList<System.Windows.Forms.HorizontalAlignment>)(resources.GetObject("binaryTextComboBoxMulticolumnMode.MultiColumnWindowColumnsHorizontalAlignments")));
            this.binaryTextComboBoxMulticolumnMode.Name = "binaryTextComboBoxMulticolumnMode";
            this.binaryTextComboBoxMulticolumnMode.SelectedIndexFromDropList = -1;
            this.binaryTextComboBoxMulticolumnMode.ShareCustomMultiColumnSizeAcrossDataListAndFilterGroupingOptionsPane = true;
            this.binaryTextComboBoxMulticolumnMode.ShouldAllowUserInputWhileProcessingMultiColumnAutoCompleDropDownView = true;
            this.binaryTextComboBoxMulticolumnMode.ShouldApplyMultiColumnWindowColumnsAlignmentsToAutoCompleteDropDown = false;
            this.binaryTextComboBoxMulticolumnMode.ShouldDisplayColumnHeadersWhenInMultiColumnMode = true;
            this.binaryTextComboBoxMulticolumnMode.ShouldDrawExtendedDropdownButton = false;
            this.binaryTextComboBoxMulticolumnMode.ShouldPersistUserSetColumnWidthsAcrossFilterSessions = false;
            this.binaryTextComboBoxMulticolumnMode.ShowBorderAlways = true;
            this.binaryTextComboBoxMulticolumnMode.ShowDropDownMultiColumnWindowAfterAdjustingForVirtualAvaliableScreenSpace = false;
            this.binaryTextComboBoxMulticolumnMode.ShowEmptyDropListViewWhenThereAreNoData = true;
            this.binaryTextComboBoxMulticolumnMode.ShowFilterOptionsInMultiColumnMode = false;
            this.binaryTextComboBoxMulticolumnMode.Size = new System.Drawing.Size(223, 22);
            this.binaryTextComboBoxMulticolumnMode.SizeForMultiColumnAutoCompleteSuggestionDropDownWindow = new System.Drawing.Size(0, 0);
            this.binaryTextComboBoxMulticolumnMode.SizesForMultiColumnAutoCompleteSuggestionDropDownWindowColumns = null;
            this.binaryTextComboBoxMulticolumnMode.TabIndex = 8;
            this.binaryTextComboBoxMulticolumnMode.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.binaryTextComboBoxMulticolumnMode.ValueMember = "ID";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(355, 339);
            this.Controls.Add(this.binaryTextComboBoxMulticolumnMode);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.salesdataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testDataSet)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private TestDataSet testDataSet;
        private System.Windows.Forms.BindingSource salesdataBindingSource;
        private BinaryComboboxSortingGroupingFiltering.TestDataSetTableAdapters.SalesdataTableAdapter salesdataTableAdapter;
        private System.Windows.Forms.CheckBox chkFilterGrouping;
        private System.Windows.Forms.CheckBox chkColumnSorting;
        private System.Windows.Forms.CheckBox chkGrouping;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private Binarymission.WinForms.Controls.ListControls.BinaryTextComboBox binaryTextComboBoxMulticolumnMode;
        private System.Windows.Forms.CheckBox chkCollapsedView;
    }
}

