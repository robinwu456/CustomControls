using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace BinaryComboboxSortingGroupingFiltering
{
    public partial class Form1 : ModernChromeWindow
    {
        public Form1()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"Sort, Group & Filter Demo";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'testDataSet.Salesdata' table. You can move, or remove it, as needed.
            this.salesdataTableAdapter.Fill(this.testDataSet.Salesdata);

        }

        private void chkColumnSorting_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumnMode.EnableColumnSorting = chkColumnSorting.Checked;
        }

        private void chkFilterGrouping_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumnMode.ShowFilterOptionsInMultiColumnMode =
                chkFilterGrouping.Checked;

        }

        private void chkGrouping_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumnMode.GroupItemsWhenInMultiColumnDisplayMode =
                chkGrouping.Checked;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void chkCollapsedView_CheckedChanged(object sender, EventArgs e)
        {
            binaryTextComboBoxMulticolumnMode.KeepTheFilterAndGroupingViewsCollapsedAtStartUp =
                chkCollapsedView.Checked;
        }

    }
}