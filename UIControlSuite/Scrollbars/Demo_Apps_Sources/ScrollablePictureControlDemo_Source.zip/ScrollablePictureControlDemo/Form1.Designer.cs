﻿using Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite;

namespace ScrollablePictureControlDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.scrollablePicture1 = new Binarymission.WinForms.Controls.ScrollablePicture();
            this.scrollablePicture2 = new Binarymission.WinForms.Controls.ScrollablePicture();
            this.scrollablePicture3 = new Binarymission.WinForms.Controls.ScrollablePicture();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this.label5 = new System.Windows.Forms.Label();
            this.scrollablePicture4 = new Binarymission.WinForms.Controls.ScrollablePicture();
            this.label6 = new System.Windows.Forms.Label();
            this.scrollablePicture5 = new Binarymission.WinForms.Controls.ScrollablePicture();
            this.SuspendLayout();
            // 
            // scrollablePicture1
            // 
            // 
            // 
            // 
            this.scrollablePicture1.HorizontalScrollBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.scrollablePicture1.HorizontalScrollBar.HorizontalScrollBarHeight = 22;
            this.scrollablePicture1.HorizontalScrollBar.IsDefaultScrollContextMenuEnabled = false;
            this.scrollablePicture1.HorizontalScrollBar.LargeChange = 397;
            this.scrollablePicture1.HorizontalScrollBar.Location = new System.Drawing.Point(0, 198);
            this.scrollablePicture1.HorizontalScrollBar.MaximumScrollRange = 1024;
            this.scrollablePicture1.HorizontalScrollBar.Name = "";
            this.scrollablePicture1.HorizontalScrollBar.PaddingGap = 0;
            this.scrollablePicture1.HorizontalScrollBar.Position = 0D;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarNavigationButtonRenderer = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.BorderColor = System.Drawing.Color.Brown;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.BuiltInNavigationButtonImageDimension = new System.Drawing.Size(0, 0);
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ColorTheme = Binarymission.WinForms.Controls.ScrollBars.Enums.ColorTheme.OrangeRed;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlOnHoverBorderHighlightColor = System.Drawing.Color.White;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = System.Drawing.Color.OrangeRed;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStatePressedColor = System.Drawing.Color.DarkOrange;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndNavigationButtonBackgroundColor = System.Drawing.Color.Brown;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndThumbFillColor = System.Drawing.Color.OrangeRed;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndTrackFillColor = System.Drawing.Color.OrangeRed;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartNavigationButtonBackgroundColor = System.Drawing.Color.White;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartThumbFillColor = System.Drawing.Color.White;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartTrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GripperColor1 = System.Drawing.Color.Brown;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GripperColor2 = System.Drawing.Color.White;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalGripperImage = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftHot = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftNormal = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftPressed = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightHot = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightNormal = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightPressed = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageHot = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageNormal = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImagePressed = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.IsDrawingNavigationButtonArrowsEnabled = true;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonArrowColor = System.Drawing.Color.Brown;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonsColor = System.Drawing.Color.Empty;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ShouldDrawGripperArtefact = true;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMajorColor = System.Drawing.Color.LightSalmon;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMinorColor = System.Drawing.Color.Orange;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.TrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalGripperImage = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownHot = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownNormal = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownPressed = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpHot = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpNormal = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpPressed = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageHot = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageNormal = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImagePressed = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarThumbGripperRenderer = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarThumbRenderer = null;
            this.scrollablePicture1.HorizontalScrollBar.ScrollBarTrackRenderer = null;
            this.scrollablePicture1.HorizontalScrollBar.ShouldAutomaticallyPositionScroller = true;
            this.scrollablePicture1.HorizontalScrollBar.ShouldUseExtendedMenuControlForContextMenu = false;
            this.scrollablePicture1.HorizontalScrollBar.Size = new System.Drawing.Size(397, 22);
            this.scrollablePicture1.HorizontalScrollBar.SmallChange = 8;
            this.scrollablePicture1.HorizontalScrollBar.TabIndex = 1;
            this.scrollablePicture1.HorizontalScrollBar.VerticalScrollBarWidth = 22;
            this.scrollablePicture1.Image = ((System.Drawing.Bitmap)(resources.GetObject("scrollablePicture1.Image")));
            this.scrollablePicture1.Location = new System.Drawing.Point(535, 342);
            this.scrollablePicture1.Name = "scrollablePicture1";
            this.scrollablePicture1.ScrollSize = new System.Drawing.Size(8, 8);
            this.scrollablePicture1.Size = new System.Drawing.Size(419, 220);
            this.scrollablePicture1.TabIndex = 0;
            this.scrollablePicture1.Text = "scrollablePicture1";
            // 
            // 
            // 
            this.scrollablePicture1.VerticalScrollBar.Dock = System.Windows.Forms.DockStyle.Right;
            this.scrollablePicture1.VerticalScrollBar.HorizontalScrollBarHeight = 22;
            this.scrollablePicture1.VerticalScrollBar.IsDefaultScrollContextMenuEnabled = false;
            this.scrollablePicture1.VerticalScrollBar.LargeChange = 198;
            this.scrollablePicture1.VerticalScrollBar.Location = new System.Drawing.Point(397, 0);
            this.scrollablePicture1.VerticalScrollBar.MaximumScrollRange = 768;
            this.scrollablePicture1.VerticalScrollBar.Name = "";
            this.scrollablePicture1.VerticalScrollBar.PaddingGap = 0;
            this.scrollablePicture1.VerticalScrollBar.Position = 0D;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarNavigationButtonRenderer = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.BorderColor = System.Drawing.Color.Brown;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.BuiltInNavigationButtonImageDimension = new System.Drawing.Size(0, 0);
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.ColorTheme = Binarymission.WinForms.Controls.ScrollBars.Enums.ColorTheme.OrangeRed;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlOnHoverBorderHighlightColor = System.Drawing.Color.White;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = System.Drawing.Color.OrangeRed;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStatePressedColor = System.Drawing.Color.DarkOrange;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndNavigationButtonBackgroundColor = System.Drawing.Color.Brown;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndThumbFillColor = System.Drawing.Color.OrangeRed;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndTrackFillColor = System.Drawing.Color.OrangeRed;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartNavigationButtonBackgroundColor = System.Drawing.Color.White;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartThumbFillColor = System.Drawing.Color.White;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartTrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.GripperColor1 = System.Drawing.Color.Brown;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.GripperColor2 = System.Drawing.Color.White;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalGripperImage = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftHot = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftNormal = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftPressed = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightHot = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightNormal = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightPressed = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageHot = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageNormal = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImagePressed = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.IsDrawingNavigationButtonArrowsEnabled = true;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonArrowColor = System.Drawing.Color.Brown;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonsColor = System.Drawing.Color.Empty;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.ShouldDrawGripperArtefact = true;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMajorColor = System.Drawing.Color.LightSalmon;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMinorColor = System.Drawing.Color.Orange;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.TrackFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalGripperImage = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownHot = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownNormal = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownPressed = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpHot = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpNormal = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpPressed = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageHot = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageNormal = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImagePressed = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarThumbGripperRenderer = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarThumbRenderer = null;
            this.scrollablePicture1.VerticalScrollBar.ScrollBarTrackRenderer = null;
            this.scrollablePicture1.VerticalScrollBar.ShouldAutomaticallyPositionScroller = true;
            this.scrollablePicture1.VerticalScrollBar.ShouldUseExtendedMenuControlForContextMenu = false;
            this.scrollablePicture1.VerticalScrollBar.Size = new System.Drawing.Size(22, 198);
            this.scrollablePicture1.VerticalScrollBar.SmallChange = 8;
            this.scrollablePicture1.VerticalScrollBar.TabIndex = 0;
            this.scrollablePicture1.VerticalScrollBar.VerticalScrollBarWidth = 22;
            // 
            // scrollablePicture2
            // 
            // 
            // 
            // 
            this.scrollablePicture2.HorizontalScrollBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.scrollablePicture2.HorizontalScrollBar.HorizontalScrollBarHeight = 30;
            this.scrollablePicture2.HorizontalScrollBar.IsDefaultScrollContextMenuEnabled = false;
            this.scrollablePicture2.HorizontalScrollBar.LargeChange = 392;
            this.scrollablePicture2.HorizontalScrollBar.Location = new System.Drawing.Point(0, 190);
            this.scrollablePicture2.HorizontalScrollBar.MaximumScrollRange = 1024;
            this.scrollablePicture2.HorizontalScrollBar.Name = "";
            this.scrollablePicture2.HorizontalScrollBar.PaddingGap = 0;
            this.scrollablePicture2.HorizontalScrollBar.Position = 0D;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarNavigationButtonRenderer = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.BorderColor = System.Drawing.Color.Green;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.BuiltInNavigationButtonImageDimension = new System.Drawing.Size(0, 0);
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.ColorTheme = Binarymission.WinForms.Controls.ScrollBars.Enums.ColorTheme.CyanGreen;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlOnHoverBorderHighlightColor = System.Drawing.Color.White;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = System.Drawing.Color.LightSeaGreen;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStatePressedColor = System.Drawing.Color.DarkCyan;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndNavigationButtonBackgroundColor = System.Drawing.Color.Green;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndThumbFillColor = System.Drawing.Color.Teal;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndTrackFillColor = System.Drawing.Color.YellowGreen;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartNavigationButtonBackgroundColor = System.Drawing.Color.White;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartThumbFillColor = System.Drawing.Color.White;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartTrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.GripperColor1 = System.Drawing.Color.Black;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.GripperColor2 = System.Drawing.Color.White;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalGripperImage = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftHot = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftNormal = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftPressed = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightHot = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightNormal = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightPressed = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageHot = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageNormal = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImagePressed = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.IsDrawingNavigationButtonArrowsEnabled = true;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonArrowColor = System.Drawing.Color.Green;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonsColor = System.Drawing.Color.Empty;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.ShouldDrawGripperArtefact = true;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMajorColor = System.Drawing.Color.White;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMinorColor = System.Drawing.Color.White;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.TrackFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalGripperImage = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownHot = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownNormal = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownPressed = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpHot = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpNormal = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpPressed = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageHot = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageNormal = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImagePressed = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarThumbGripperRenderer = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarThumbRenderer = null;
            this.scrollablePicture2.HorizontalScrollBar.ScrollBarTrackRenderer = null;
            this.scrollablePicture2.HorizontalScrollBar.ShouldAutomaticallyPositionScroller = true;
            this.scrollablePicture2.HorizontalScrollBar.ShouldUseExtendedMenuControlForContextMenu = false;
            this.scrollablePicture2.HorizontalScrollBar.Size = new System.Drawing.Size(392, 30);
            this.scrollablePicture2.HorizontalScrollBar.SmallChange = 8;
            this.scrollablePicture2.HorizontalScrollBar.TabIndex = 1;
            this.scrollablePicture2.HorizontalScrollBar.VerticalScrollBarWidth = 30;
            this.scrollablePicture2.Image = ((System.Drawing.Bitmap)(resources.GetObject("scrollablePicture2.Image")));
            this.scrollablePicture2.Location = new System.Drawing.Point(532, 75);
            this.scrollablePicture2.Name = "scrollablePicture2";
            this.scrollablePicture2.ScrollSize = new System.Drawing.Size(8, 8);
            this.scrollablePicture2.Size = new System.Drawing.Size(422, 220);
            this.scrollablePicture2.TabIndex = 1;
            this.scrollablePicture2.Text = "scrollablePicture2";
            // 
            // 
            // 
            this.scrollablePicture2.VerticalScrollBar.Dock = System.Windows.Forms.DockStyle.Right;
            this.scrollablePicture2.VerticalScrollBar.HorizontalScrollBarHeight = 30;
            this.scrollablePicture2.VerticalScrollBar.IsDefaultScrollContextMenuEnabled = false;
            this.scrollablePicture2.VerticalScrollBar.LargeChange = 190;
            this.scrollablePicture2.VerticalScrollBar.Location = new System.Drawing.Point(392, 0);
            this.scrollablePicture2.VerticalScrollBar.MaximumScrollRange = 768;
            this.scrollablePicture2.VerticalScrollBar.Name = "";
            this.scrollablePicture2.VerticalScrollBar.PaddingGap = 0;
            this.scrollablePicture2.VerticalScrollBar.Position = 0D;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarNavigationButtonRenderer = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.BorderColor = System.Drawing.Color.Green;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.BuiltInNavigationButtonImageDimension = new System.Drawing.Size(0, 0);
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.ColorTheme = Binarymission.WinForms.Controls.ScrollBars.Enums.ColorTheme.CyanGreen;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlOnHoverBorderHighlightColor = System.Drawing.Color.White;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = System.Drawing.Color.LightSeaGreen;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStatePressedColor = System.Drawing.Color.DarkCyan;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndNavigationButtonBackgroundColor = System.Drawing.Color.Green;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndThumbFillColor = System.Drawing.Color.Teal;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndTrackFillColor = System.Drawing.Color.YellowGreen;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartNavigationButtonBackgroundColor = System.Drawing.Color.White;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartThumbFillColor = System.Drawing.Color.White;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartTrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.GripperColor1 = System.Drawing.Color.Black;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.GripperColor2 = System.Drawing.Color.White;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalGripperImage = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftHot = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftNormal = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftPressed = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightHot = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightNormal = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightPressed = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageHot = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageNormal = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImagePressed = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.IsDrawingNavigationButtonArrowsEnabled = true;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonArrowColor = System.Drawing.Color.Green;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonsColor = System.Drawing.Color.Empty;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.ShouldDrawGripperArtefact = true;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMajorColor = System.Drawing.Color.White;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMinorColor = System.Drawing.Color.White;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.TrackFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalGripperImage = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownHot = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownNormal = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownPressed = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpHot = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpNormal = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpPressed = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageHot = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageNormal = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImagePressed = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarThumbGripperRenderer = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarThumbRenderer = null;
            this.scrollablePicture2.VerticalScrollBar.ScrollBarTrackRenderer = null;
            this.scrollablePicture2.VerticalScrollBar.ShouldAutomaticallyPositionScroller = true;
            this.scrollablePicture2.VerticalScrollBar.ShouldUseExtendedMenuControlForContextMenu = false;
            this.scrollablePicture2.VerticalScrollBar.Size = new System.Drawing.Size(30, 190);
            this.scrollablePicture2.VerticalScrollBar.SmallChange = 8;
            this.scrollablePicture2.VerticalScrollBar.TabIndex = 0;
            this.scrollablePicture2.VerticalScrollBar.VerticalScrollBarWidth = 30;
            // 
            // scrollablePicture3
            // 
            // 
            // 
            // 
            this.scrollablePicture3.HorizontalScrollBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.scrollablePicture3.HorizontalScrollBar.HorizontalScrollBarHeight = 36;
            this.scrollablePicture3.HorizontalScrollBar.IsDefaultScrollContextMenuEnabled = false;
            this.scrollablePicture3.HorizontalScrollBar.LargeChange = 450;
            this.scrollablePicture3.HorizontalScrollBar.Location = new System.Drawing.Point(0, 184);
            this.scrollablePicture3.HorizontalScrollBar.MaximumScrollRange = 1024;
            this.scrollablePicture3.HorizontalScrollBar.Name = "";
            this.scrollablePicture3.HorizontalScrollBar.PaddingGap = 0;
            this.scrollablePicture3.HorizontalScrollBar.Position = 0D;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarNavigationButtonRenderer = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.BorderColor = System.Drawing.Color.White;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.BuiltInNavigationButtonImageDimension = new System.Drawing.Size(0, 0);
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.ColorTheme = Binarymission.WinForms.Controls.ScrollBars.Enums.ColorTheme.Custom;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlOnHoverBorderHighlightColor = System.Drawing.Color.Black;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStatePressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndNavigationButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndThumbFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndTrackFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartNavigationButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartThumbFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartTrackFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.GripperColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.GripperColor2 = System.Drawing.Color.White;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalGripperImage = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftHot = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftNormal = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftPressed = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightHot = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightNormal = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightPressed = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageHot = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageNormal = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImagePressed = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.IsDrawingNavigationButtonArrowsEnabled = true;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonArrowColor = System.Drawing.Color.Black;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonsColor = System.Drawing.Color.Empty;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.ShouldDrawGripperArtefact = true;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMajorColor = System.Drawing.Color.Black;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMinorColor = System.Drawing.Color.White;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.TrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalGripperImage = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownHot = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownNormal = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownPressed = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpHot = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpNormal = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpPressed = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageHot = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageNormal = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImagePressed = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarThumbGripperRenderer = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarThumbRenderer = null;
            this.scrollablePicture3.HorizontalScrollBar.ScrollBarTrackRenderer = null;
            this.scrollablePicture3.HorizontalScrollBar.ShouldAutomaticallyPositionScroller = true;
            this.scrollablePicture3.HorizontalScrollBar.ShouldUseExtendedMenuControlForContextMenu = false;
            this.scrollablePicture3.HorizontalScrollBar.Size = new System.Drawing.Size(450, 36);
            this.scrollablePicture3.HorizontalScrollBar.SmallChange = 8;
            this.scrollablePicture3.HorizontalScrollBar.TabIndex = 1;
            this.scrollablePicture3.HorizontalScrollBar.VerticalScrollBarWidth = 36;
            this.scrollablePicture3.Image = ((System.Drawing.Bitmap)(resources.GetObject("scrollablePicture3.Image")));
            this.scrollablePicture3.Location = new System.Drawing.Point(25, 75);
            this.scrollablePicture3.Name = "scrollablePicture3";
            this.scrollablePicture3.ScrollSize = new System.Drawing.Size(8, 8);
            this.scrollablePicture3.Size = new System.Drawing.Size(486, 220);
            this.scrollablePicture3.TabIndex = 2;
            this.scrollablePicture3.Text = "scrollablePicture3";
            // 
            // 
            // 
            this.scrollablePicture3.VerticalScrollBar.Dock = System.Windows.Forms.DockStyle.Right;
            this.scrollablePicture3.VerticalScrollBar.HorizontalScrollBarHeight = 36;
            this.scrollablePicture3.VerticalScrollBar.IsDefaultScrollContextMenuEnabled = false;
            this.scrollablePicture3.VerticalScrollBar.LargeChange = 184;
            this.scrollablePicture3.VerticalScrollBar.Location = new System.Drawing.Point(450, 0);
            this.scrollablePicture3.VerticalScrollBar.MaximumScrollRange = 768;
            this.scrollablePicture3.VerticalScrollBar.Name = "";
            this.scrollablePicture3.VerticalScrollBar.PaddingGap = 0;
            this.scrollablePicture3.VerticalScrollBar.Position = 0D;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarNavigationButtonRenderer = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.BorderColor = System.Drawing.Color.White;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.BuiltInNavigationButtonImageDimension = new System.Drawing.Size(0, 0);
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.ColorTheme = Binarymission.WinForms.Controls.ScrollBars.Enums.ColorTheme.Custom;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlOnHoverBorderHighlightColor = System.Drawing.Color.Black;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStatePressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndNavigationButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndThumbFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndTrackFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartNavigationButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartThumbFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartTrackFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.GripperColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.GripperColor2 = System.Drawing.Color.White;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalGripperImage = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftHot = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftNormal = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftPressed = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightHot = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightNormal = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightPressed = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageHot = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageNormal = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImagePressed = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.IsDrawingNavigationButtonArrowsEnabled = true;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonArrowColor = System.Drawing.Color.Maroon;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonsColor = System.Drawing.Color.Empty;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.ShouldDrawGripperArtefact = true;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMajorColor = System.Drawing.Color.Black;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMinorColor = System.Drawing.Color.White;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.TrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalGripperImage = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownHot = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownNormal = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownPressed = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpHot = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpNormal = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpPressed = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageHot = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageNormal = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImagePressed = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarThumbGripperRenderer = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarThumbRenderer = null;
            this.scrollablePicture3.VerticalScrollBar.ScrollBarTrackRenderer = null;
            this.scrollablePicture3.VerticalScrollBar.ShouldAutomaticallyPositionScroller = true;
            this.scrollablePicture3.VerticalScrollBar.ShouldUseExtendedMenuControlForContextMenu = false;
            this.scrollablePicture3.VerticalScrollBar.Size = new System.Drawing.Size(36, 184);
            this.scrollablePicture3.VerticalScrollBar.SmallChange = 8;
            this.scrollablePicture3.VerticalScrollBar.TabIndex = 0;
            this.scrollablePicture3.VerticalScrollBar.VerticalScrollBarWidth = 36;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(532, 317);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Color: OrangeRed, Size 22";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(529, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Color: CyanGreen, Size: 30";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(198, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Color: custom colors, Size: 36";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(22, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(642, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Scrollable Picture Control with built-in custom scrollbars and customised on vari" +
    "ous aspects:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button1.BorderColor = System.Drawing.Color.Black;
            this.button1.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this.button1.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this.button1.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this.button1.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this.button1.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this.button1.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this.button1.ContextMenuProperties.UseGradientPainting = true;
            this.button1.DefaultTheme = true;
            this.button1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.button1.DrawMenuButtonSeparator = true;
            this.button1.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this.button1.DropDownMenuItems = null;
            this.button1.EndColor = System.Drawing.Color.Silver;
            this.button1.IsRenderingTheme = false;
            this.button1.LinearGradientRenderingAngle = 90F;
            this.button1.Location = new System.Drawing.Point(1361, 536);
            this.button1.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this.button1.MenuButtonSeparatorLineHeight = -1;
            this.button1.Name = "button1";
            this.button1.PushedEndColor = System.Drawing.Color.White;
            this.button1.PushedStartColor = System.Drawing.Color.Silver;
            this.button1.Size = new System.Drawing.Size(104, 33);
            this.button1.StartColor = System.Drawing.Color.White;
            this.button1.TabIndex = 7;
            this.button1.Text = "E&xit";
            this.button1.TextStringFormat = null;
            this.button1.TransparentColor = System.Drawing.Color.Empty;
            this.button1.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this.button1.UseCustomTextStringFormat = false;
            this.button1.UseUserDefinedColorForArrowMark = true;
            this.button1.UseUserDefinedColorForMenuButtonSeparator = true;
            this.button1.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(22, 314);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(171, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "Color: OfficeBlue, Size 22";
            // 
            // scrollablePicture4
            // 
            // 
            // 
            // 
            this.scrollablePicture4.HorizontalScrollBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.scrollablePicture4.HorizontalScrollBar.HorizontalScrollBarHeight = 22;
            this.scrollablePicture4.HorizontalScrollBar.IsDefaultScrollContextMenuEnabled = false;
            this.scrollablePicture4.HorizontalScrollBar.LargeChange = 464;
            this.scrollablePicture4.HorizontalScrollBar.Location = new System.Drawing.Point(0, 198);
            this.scrollablePicture4.HorizontalScrollBar.MaximumScrollRange = 1024;
            this.scrollablePicture4.HorizontalScrollBar.Name = "";
            this.scrollablePicture4.HorizontalScrollBar.PaddingGap = 0;
            this.scrollablePicture4.HorizontalScrollBar.Position = 0D;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarNavigationButtonRenderer = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.BorderColor = System.Drawing.Color.PowderBlue;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.BuiltInNavigationButtonImageDimension = new System.Drawing.Size(0, 0);
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.ColorTheme = Binarymission.WinForms.Controls.ScrollBars.Enums.ColorTheme.OfficeBlue;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlOnHoverBorderHighlightColor = System.Drawing.Color.DodgerBlue;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = System.Drawing.Color.PowderBlue;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStatePressedColor = System.Drawing.Color.DodgerBlue;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndNavigationButtonBackgroundColor = System.Drawing.Color.CornflowerBlue;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndThumbFillColor = System.Drawing.Color.CornflowerBlue;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndTrackFillColor = System.Drawing.Color.LightBlue;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartNavigationButtonBackgroundColor = System.Drawing.Color.LightBlue;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartThumbFillColor = System.Drawing.Color.PowderBlue;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartTrackFillColor = System.Drawing.Color.PowderBlue;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.GripperColor1 = System.Drawing.Color.White;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.GripperColor2 = System.Drawing.Color.Gray;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalGripperImage = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftHot = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftNormal = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftPressed = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightHot = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightNormal = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightPressed = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageHot = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageNormal = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImagePressed = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.IsDrawingNavigationButtonArrowsEnabled = true;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonArrowColor = System.Drawing.Color.Black;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonsColor = System.Drawing.Color.Empty;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.ShouldDrawGripperArtefact = true;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMajorColor = System.Drawing.Color.White;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMinorColor = System.Drawing.Color.Gray;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.TrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalGripperImage = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownHot = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownNormal = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownPressed = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpHot = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpNormal = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpPressed = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageHot = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageNormal = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImagePressed = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarThumbGripperRenderer = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarThumbRenderer = null;
            this.scrollablePicture4.HorizontalScrollBar.ScrollBarTrackRenderer = null;
            this.scrollablePicture4.HorizontalScrollBar.ShouldAutomaticallyPositionScroller = true;
            this.scrollablePicture4.HorizontalScrollBar.ShouldUseExtendedMenuControlForContextMenu = false;
            this.scrollablePicture4.HorizontalScrollBar.Size = new System.Drawing.Size(464, 22);
            this.scrollablePicture4.HorizontalScrollBar.SmallChange = 8;
            this.scrollablePicture4.HorizontalScrollBar.TabIndex = 1;
            this.scrollablePicture4.HorizontalScrollBar.VerticalScrollBarWidth = 22;
            this.scrollablePicture4.Image = ((System.Drawing.Bitmap)(resources.GetObject("scrollablePicture4.Image")));
            this.scrollablePicture4.Location = new System.Drawing.Point(25, 342);
            this.scrollablePicture4.Name = "scrollablePicture4";
            this.scrollablePicture4.ScrollSize = new System.Drawing.Size(8, 8);
            this.scrollablePicture4.Size = new System.Drawing.Size(486, 220);
            this.scrollablePicture4.TabIndex = 8;
            this.scrollablePicture4.Text = "scrollablePicture4";
            // 
            // 
            // 
            this.scrollablePicture4.VerticalScrollBar.Dock = System.Windows.Forms.DockStyle.Right;
            this.scrollablePicture4.VerticalScrollBar.HorizontalScrollBarHeight = 22;
            this.scrollablePicture4.VerticalScrollBar.IsDefaultScrollContextMenuEnabled = false;
            this.scrollablePicture4.VerticalScrollBar.LargeChange = 198;
            this.scrollablePicture4.VerticalScrollBar.Location = new System.Drawing.Point(464, 0);
            this.scrollablePicture4.VerticalScrollBar.MaximumScrollRange = 768;
            this.scrollablePicture4.VerticalScrollBar.Name = "";
            this.scrollablePicture4.VerticalScrollBar.PaddingGap = 0;
            this.scrollablePicture4.VerticalScrollBar.Position = 0D;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarNavigationButtonRenderer = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.BorderColor = System.Drawing.Color.PowderBlue;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.BuiltInNavigationButtonImageDimension = new System.Drawing.Size(0, 0);
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.ColorTheme = Binarymission.WinForms.Controls.ScrollBars.Enums.ColorTheme.OfficeBlue;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlOnHoverBorderHighlightColor = System.Drawing.Color.DodgerBlue;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = System.Drawing.Color.PowderBlue;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStatePressedColor = System.Drawing.Color.DodgerBlue;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndNavigationButtonBackgroundColor = System.Drawing.Color.CornflowerBlue;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndThumbFillColor = System.Drawing.Color.CornflowerBlue;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndTrackFillColor = System.Drawing.Color.LightBlue;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartNavigationButtonBackgroundColor = System.Drawing.Color.LightBlue;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartThumbFillColor = System.Drawing.Color.PowderBlue;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartTrackFillColor = System.Drawing.Color.PowderBlue;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.GripperColor1 = System.Drawing.Color.White;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.GripperColor2 = System.Drawing.Color.Gray;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalGripperImage = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftHot = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftNormal = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftPressed = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightHot = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightNormal = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightPressed = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageHot = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageNormal = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImagePressed = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.IsDrawingNavigationButtonArrowsEnabled = true;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonArrowColor = System.Drawing.Color.Black;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonsColor = System.Drawing.Color.Empty;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.ShouldDrawGripperArtefact = true;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMajorColor = System.Drawing.Color.White;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMinorColor = System.Drawing.Color.Gray;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.TrackFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalGripperImage = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownHot = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownNormal = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownPressed = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpHot = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpNormal = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpPressed = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageHot = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageNormal = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImagePressed = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarThumbGripperRenderer = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarThumbRenderer = null;
            this.scrollablePicture4.VerticalScrollBar.ScrollBarTrackRenderer = null;
            this.scrollablePicture4.VerticalScrollBar.ShouldAutomaticallyPositionScroller = true;
            this.scrollablePicture4.VerticalScrollBar.ShouldUseExtendedMenuControlForContextMenu = false;
            this.scrollablePicture4.VerticalScrollBar.Size = new System.Drawing.Size(22, 198);
            this.scrollablePicture4.VerticalScrollBar.SmallChange = 8;
            this.scrollablePicture4.VerticalScrollBar.TabIndex = 0;
            this.scrollablePicture4.VerticalScrollBar.VerticalScrollBarWidth = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(972, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 15);
            this.label6.TabIndex = 11;
            this.label6.Text = "Color: Win8, Size: 36";
            // 
            // scrollablePicture5
            // 
            // 
            // 
            // 
            this.scrollablePicture5.HorizontalScrollBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.scrollablePicture5.HorizontalScrollBar.HorizontalScrollBarHeight = 36;
            this.scrollablePicture5.HorizontalScrollBar.IsDefaultScrollContextMenuEnabled = false;
            this.scrollablePicture5.HorizontalScrollBar.LargeChange = 450;
            this.scrollablePicture5.HorizontalScrollBar.Location = new System.Drawing.Point(0, 184);
            this.scrollablePicture5.HorizontalScrollBar.MaximumScrollRange = 1024;
            this.scrollablePicture5.HorizontalScrollBar.Name = "";
            this.scrollablePicture5.HorizontalScrollBar.PaddingGap = 0;
            this.scrollablePicture5.HorizontalScrollBar.Position = 0D;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarNavigationButtonRenderer = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.BorderColor = System.Drawing.Color.White;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.BuiltInNavigationButtonImageDimension = new System.Drawing.Size(0, 0);
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.ColorTheme = Binarymission.WinForms.Controls.ScrollBars.Enums.ColorTheme.Win8;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlOnHoverBorderHighlightColor = System.Drawing.Color.LightSteelBlue;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = System.Drawing.Color.LightSteelBlue;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStatePressedColor = System.Drawing.Color.LightSlateGray;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndNavigationButtonBackgroundColor = System.Drawing.Color.Silver;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndThumbFillColor = System.Drawing.Color.LightSteelBlue;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndTrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartNavigationButtonBackgroundColor = System.Drawing.Color.Silver;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartThumbFillColor = System.Drawing.Color.LightSteelBlue;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartTrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.GripperColor1 = System.Drawing.Color.Black;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.GripperColor2 = System.Drawing.Color.White;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalGripperImage = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftHot = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftNormal = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftPressed = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightHot = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightNormal = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightPressed = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageHot = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageNormal = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImagePressed = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.IsDrawingNavigationButtonArrowsEnabled = true;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonArrowColor = System.Drawing.Color.Black;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonsColor = System.Drawing.Color.Empty;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.ShouldDrawGripperArtefact = false;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMajorColor = System.Drawing.Color.White;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMinorColor = System.Drawing.Color.White;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.TrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalGripperImage = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownHot = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownNormal = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownPressed = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpHot = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpNormal = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpPressed = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageHot = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageNormal = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImagePressed = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarThumbGripperRenderer = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarThumbRenderer = null;
            this.scrollablePicture5.HorizontalScrollBar.ScrollBarTrackRenderer = null;
            this.scrollablePicture5.HorizontalScrollBar.ShouldAutomaticallyPositionScroller = true;
            this.scrollablePicture5.HorizontalScrollBar.ShouldUseExtendedMenuControlForContextMenu = false;
            this.scrollablePicture5.HorizontalScrollBar.Size = new System.Drawing.Size(450, 36);
            this.scrollablePicture5.HorizontalScrollBar.SmallChange = 8;
            this.scrollablePicture5.HorizontalScrollBar.TabIndex = 1;
            this.scrollablePicture5.HorizontalScrollBar.VerticalScrollBarWidth = 36;
            this.scrollablePicture5.Image = ((System.Drawing.Bitmap)(resources.GetObject("scrollablePicture5.Image")));
            this.scrollablePicture5.Location = new System.Drawing.Point(975, 75);
            this.scrollablePicture5.Name = "scrollablePicture5";
            this.scrollablePicture5.ScrollSize = new System.Drawing.Size(8, 8);
            this.scrollablePicture5.Size = new System.Drawing.Size(486, 220);
            this.scrollablePicture5.TabIndex = 10;
            this.scrollablePicture5.Text = "scrollablePicture5";
            // 
            // 
            // 
            this.scrollablePicture5.VerticalScrollBar.Dock = System.Windows.Forms.DockStyle.Right;
            this.scrollablePicture5.VerticalScrollBar.HorizontalScrollBarHeight = 36;
            this.scrollablePicture5.VerticalScrollBar.IsDefaultScrollContextMenuEnabled = false;
            this.scrollablePicture5.VerticalScrollBar.LargeChange = 184;
            this.scrollablePicture5.VerticalScrollBar.Location = new System.Drawing.Point(450, 0);
            this.scrollablePicture5.VerticalScrollBar.MaximumScrollRange = 768;
            this.scrollablePicture5.VerticalScrollBar.Name = "";
            this.scrollablePicture5.VerticalScrollBar.PaddingGap = 0;
            this.scrollablePicture5.VerticalScrollBar.Position = 0D;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarNavigationButtonRenderer = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.BorderColor = System.Drawing.Color.White;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.BuiltInNavigationButtonImageDimension = new System.Drawing.Size(0, 0);
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.ColorTheme = Binarymission.WinForms.Controls.ScrollBars.Enums.ColorTheme.Win8;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlOnHoverBorderHighlightColor = System.Drawing.Color.LightSteelBlue;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = System.Drawing.Color.LightSteelBlue;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStatePressedColor = System.Drawing.Color.LightSlateGray;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndNavigationButtonBackgroundColor = System.Drawing.Color.Silver;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndThumbFillColor = System.Drawing.Color.LightSteelBlue;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndTrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartNavigationButtonBackgroundColor = System.Drawing.Color.Silver;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartThumbFillColor = System.Drawing.Color.LightSteelBlue;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartTrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.GripperColor1 = System.Drawing.Color.Black;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.GripperColor2 = System.Drawing.Color.White;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalGripperImage = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftHot = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftNormal = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftPressed = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightHot = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightNormal = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightPressed = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageHot = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageNormal = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImagePressed = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.IsDrawingNavigationButtonArrowsEnabled = true;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonArrowColor = System.Drawing.Color.Black;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonsColor = System.Drawing.Color.Empty;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.ShouldDrawGripperArtefact = false;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbFillColor = System.Drawing.Color.Empty;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMajorColor = System.Drawing.Color.White;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMinorColor = System.Drawing.Color.White;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.TrackFillColor = System.Drawing.Color.White;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalGripperImage = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownHot = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownNormal = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownPressed = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpHot = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpNormal = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpPressed = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageHot = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageNormal = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImagePressed = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarThumbGripperRenderer = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarThumbRenderer = null;
            this.scrollablePicture5.VerticalScrollBar.ScrollBarTrackRenderer = null;
            this.scrollablePicture5.VerticalScrollBar.ShouldAutomaticallyPositionScroller = true;
            this.scrollablePicture5.VerticalScrollBar.ShouldUseExtendedMenuControlForContextMenu = false;
            this.scrollablePicture5.VerticalScrollBar.Size = new System.Drawing.Size(36, 184);
            this.scrollablePicture5.VerticalScrollBar.SmallChange = 8;
            this.scrollablePicture5.VerticalScrollBar.TabIndex = 0;
            this.scrollablePicture5.VerticalScrollBar.VerticalScrollBarWidth = 36;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.LightGray;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(1488, 618);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.scrollablePicture5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.scrollablePicture4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.scrollablePicture3);
            this.Controls.Add(this.scrollablePicture2);
            this.Controls.Add(this.scrollablePicture1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.TitlebarText = "Binarymission ScrollablePictureBox .NET control demo";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Binarymission.WinForms.Controls.ScrollablePicture scrollablePicture1;
        private Binarymission.WinForms.Controls.ScrollablePicture scrollablePicture2;
        private Binarymission.WinForms.Controls.ScrollablePicture scrollablePicture3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private SmartButton button1;
        private System.Windows.Forms.Label label5;
        private Binarymission.WinForms.Controls.ScrollablePicture scrollablePicture4;
        private System.Windows.Forms.Label label6;
        private Binarymission.WinForms.Controls.ScrollablePicture scrollablePicture5;
    }
}

