﻿using System;
using System.Drawing;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.TabControls;

namespace TabControlMoreAdvancedFeaturesDemo
{
    public partial class AdvancedFeaturesDemoForm : ModernChromeWindow
    {
        public AdvancedFeaturesDemoForm()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
        }

        private void orientationChangeCmbBx_SelectedIndexChanged(object sender, EventArgs e)
        {
            binaryPowerTabStrip1.TabPagesRenderingLocation = (TabPagesRenderingLocation)Enum.Parse(typeof(TabPagesRenderingLocation),
                orientationChangeCmbBx.SelectedItem.ToString());
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            orientationChangeCmbBx.SelectedIndex = 0;
            closeButtonPositionCmbBx.SelectedIndex = 0;

            binaryPowerTabStrip1.TabPagesRenderingLocation = TabPagesRenderingLocation.Top;

            binaryPowerTabStrip1.HeaderTextCloseButtonExtraGap = 16;

            var sf = new StringFormat
            {
                Alignment = StringAlignment.Center, 
                LineAlignment = StringAlignment.Center
            };

            binaryPowerTabStrip1.TabHeaderStringFormat = sf;
        }

        private void closeButtonPositionCmbBx_SelectedIndexChanged(object sender, EventArgs e)
        {
            binaryPowerTabStrip1.TabBottomOrientationCloseButtonPosition = (CloseButtonPosition)Enum.Parse(typeof(CloseButtonPosition),
                closeButtonPositionCmbBx.SelectedItem.ToString());
        }
    }
}
