﻿using Binarymission.WinForms.Controls.TabControls;

namespace TabControlMoreAdvancedFeaturesDemo
{
    partial class AdvancedFeaturesDemoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            var stringFormat1 = new System.Drawing.StringFormat();
            var resources = new System.ComponentModel.ComponentResourceManager(typeof(AdvancedFeaturesDemoForm));
            this.orientationChangeCmbBx = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.closeButtonPositionCmbBx = new System.Windows.Forms.ComboBox();
            this.binaryPowerTabStrip1 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip();
            this.binaryPowerTabPage1 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage2 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage3 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage4 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage5 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage6 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage7 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage8 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage9 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.binaryPowerTabStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // orientationChangeCmbBx
            // 
            this.orientationChangeCmbBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.orientationChangeCmbBx.FormattingEnabled = true;
            this.orientationChangeCmbBx.Items.AddRange(new object[] {
            "Top",
            "Bottom"});
            this.orientationChangeCmbBx.Location = new System.Drawing.Point(13, 34);
            this.orientationChangeCmbBx.Name = "orientationChangeCmbBx";
            this.orientationChangeCmbBx.Size = new System.Drawing.Size(129, 21);
            this.orientationChangeCmbBx.TabIndex = 1;
            this.orientationChangeCmbBx.SelectedIndexChanged += new System.EventHandler(this.orientationChangeCmbBx_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Orientation:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.closeButtonPositionCmbBx);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.orientationChangeCmbBx);
            this.panel1.Location = new System.Drawing.Point(699, 55);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(153, 445);
            this.panel1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 389);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "(Relevant for Bottom mode)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 373);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Close button position:";
            // 
            // closeButtonPositionCmbBx
            // 
            this.closeButtonPositionCmbBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.closeButtonPositionCmbBx.FormattingEnabled = true;
            this.closeButtonPositionCmbBx.Items.AddRange(new object[] {
            "Top",
            "Bottom"});
            this.closeButtonPositionCmbBx.Location = new System.Drawing.Point(13, 413);
            this.closeButtonPositionCmbBx.Name = "closeButtonPositionCmbBx";
            this.closeButtonPositionCmbBx.Size = new System.Drawing.Size(129, 21);
            this.closeButtonPositionCmbBx.TabIndex = 3;
            this.closeButtonPositionCmbBx.SelectedIndexChanged += new System.EventHandler(this.closeButtonPositionCmbBx_SelectedIndexChanged);
            // 
            // binaryPowerTabStrip1
            // 
            this.binaryPowerTabStrip1.Cursor = System.Windows.Forms.Cursors.Default;
            this.binaryPowerTabStrip1.CustomEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip1.CustomStartColor = System.Drawing.Color.Green;
            this.binaryPowerTabStrip1.DrawBorderAroundTabStrip = false;
            this.binaryPowerTabStrip1.DrawTabPageOnTopOfEachOther = true;
            this.binaryPowerTabStrip1.EmptySpaceLengthBeforeTheFirstTabPage = 8;
            this.binaryPowerTabStrip1.EnableAutomaticUpdateOfTabPagesHeaderSize = false;
            this.binaryPowerTabStrip1.EnableControlledLayoutRendering = false;
            this.binaryPowerTabStrip1.EnableDragAndDropOfTabPages = false;
            this.binaryPowerTabStrip1.EnableTabPageLevelCloseButtonRendering = true;
            this.binaryPowerTabStrip1.ExtendedWindowsXPRenderingFirstColor = System.Drawing.Color.Blue;
            this.binaryPowerTabStrip1.ExtendedWindowsXPRenderingSecondColor = System.Drawing.Color.LightBlue;
            this.binaryPowerTabStrip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabStrip1.HeaderFont = null;
            this.binaryPowerTabStrip1.HeaderTextCloseButtonExtraGap = 30;
            this.binaryPowerTabStrip1.IsBackgroundTransparent = false;
            this.binaryPowerTabStrip1.KeepShowingTooltipEvenWhenMousePointerIsMoving = false;
            this.binaryPowerTabStrip1.Location = new System.Drawing.Point(12, 52);
            this.binaryPowerTabStrip1.Name = "binaryPowerTabStrip1";
            this.binaryPowerTabStrip1.NewlyAddedPagesAreLocatedAtLeftCorner = false;
            this.binaryPowerTabStrip1.PreventInvalidation = false;
            this.binaryPowerTabStrip1.RenderFullTextForTabPageHeader = false;
            this.binaryPowerTabStrip1.SelectedPageHeaderTextIsRenderedBold = true;
            this.binaryPowerTabStrip1.ShouldAutoSizeTabs = true;
            this.binaryPowerTabStrip1.ShouldDrawTabPageHeaderInMultiLines = false;
            this.binaryPowerTabStrip1.ShouldUpdateUponParentMove = false;
            this.binaryPowerTabStrip1.ShouldUpdateUponParentResize = false;
            this.binaryPowerTabStrip1.ShowToolTip = true;
            this.binaryPowerTabStrip1.Size = new System.Drawing.Size(668, 449);
            this.binaryPowerTabStrip1.TabBottomOrientationCloseButtonPosition = Binarymission.WinForms.Controls.TabControls.CloseButtonPosition.Bottom;
            stringFormat1.Alignment = System.Drawing.StringAlignment.Center;
            stringFormat1.FormatFlags = System.Drawing.StringFormatFlags.NoWrap;
            stringFormat1.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat1.LineAlignment = System.Drawing.StringAlignment.Near;
            stringFormat1.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
            this.binaryPowerTabStrip1.TabHeaderStringFormat = stringFormat1;
            this.binaryPowerTabStrip1.TabIndex = 0;
            this.binaryPowerTabStrip1.TabPageBorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabStrip1.TabPageCloseButtonMouseEnterColor = System.Drawing.Color.Red;
            this.binaryPowerTabStrip1.TabPageCloseButtonRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPageCloseButtonRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPageCurrentSelectionIndicatorEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip1.TabPageCurrentSelectionIndicatorStartColor = System.Drawing.Color.Orange;
            this.binaryPowerTabStrip1.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.binaryPowerTabStrip1.TabPageHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPageHeaderHeight = 36;
            this.binaryPowerTabStrip1.TabPageHeaderShowsSideBar = false;
            this.binaryPowerTabStrip1.TabPageHeaderTextFontOverridesControlDefault = false;
            this.binaryPowerTabStrip1.TabPageHeaderWidth = 200;
            this.binaryPowerTabStrip1.TabPages.AddRange(new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage[] {
            this.binaryPowerTabPage1,
            this.binaryPowerTabPage2,
            this.binaryPowerTabPage3,
            this.binaryPowerTabPage4,
            this.binaryPowerTabPage5,
            this.binaryPowerTabPage6,
            this.binaryPowerTabPage7,
            this.binaryPowerTabPage8,
            this.binaryPowerTabPage9});
            this.binaryPowerTabStrip1.TabPagesCloseButtonColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPagesHaveGapBetweenThem = true;
            this.binaryPowerTabStrip1.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabStrip1.TabPagesOverflowCalculationStrategy = Binarymission.WinForms.Controls.TabControls.TabPagesOverflowCalculationStrategy.Pessimistic;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuDropDownColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuGlyphActiveRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPagesRenderingLocation = Binarymission.WinForms.Controls.TabControls.TabPagesRenderingLocation.Top;
            this.binaryPowerTabStrip1.TabRenderingStyle = Binarymission.WinForms.Controls.TabControls.RenderingStyle.ExtendedWindowsXP;
            this.binaryPowerTabStrip1.TabsOverflowMode = Binarymission.WinForms.Controls.TabControls.OverflowMode.MultiLine;
            this.binaryPowerTabStrip1.Text = "binaryPowerTabStrip1";
            this.binaryPowerTabStrip1.ThemeBorderColorCanBeOverridden = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.AutomaticDelay = 500;
            this.binaryPowerTabStrip1.ToolTipConfiguration.AutoPopDelay = 5000;
            this.binaryPowerTabStrip1.ToolTipConfiguration.BackColor = System.Drawing.SystemColors.Info;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.ToolTipConfiguration.InitialDelay = 500;
            this.binaryPowerTabStrip1.ToolTipConfiguration.IsBalloon = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ReshowDelay = 100;
            this.binaryPowerTabStrip1.ToolTipConfiguration.StripAmpersands = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ToolTipIcon = System.Windows.Forms.ToolTipIcon.None;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ToolTipTitle = "";
            this.binaryPowerTabStrip1.ToolTipConfiguration.UseAnimation = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.UseFading = false;
            this.binaryPowerTabStrip1.UseTabCurrentSelectionIndicatorColor = true;
            // 
            // binaryPowerTabPage1
            // 
            this.binaryPowerTabPage1.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(155)))), ((int)(((byte)(156)))));
            this.binaryPowerTabPage1.BorderSize = 1;
            this.binaryPowerTabPage1.CurrentlySelected = true;
            this.binaryPowerTabPage1.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage1.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage1.Image")));
            this.binaryPowerTabPage1.IsBackgroundTransparent = false;
            this.binaryPowerTabPage1.IsHeaderEnabled = true;
            this.binaryPowerTabPage1.Name = "binaryPowerTabPage1";
            this.binaryPowerTabPage1.Size = new System.Drawing.Size(666, 268);
            this.binaryPowerTabPage1.TabIndex = 0;
            this.binaryPowerTabPage1.TabPageContentIsDirty = false;
            this.binaryPowerTabPage1.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.Text = "Reports";
            this.binaryPowerTabPage1.ToolTipText = "";
            // 
            // binaryPowerTabPage2
            // 
            this.binaryPowerTabPage2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(155)))), ((int)(((byte)(156)))));
            this.binaryPowerTabPage2.BorderSize = 1;
            this.binaryPowerTabPage2.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage2.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage2.Image")));
            this.binaryPowerTabPage2.IsBackgroundTransparent = false;
            this.binaryPowerTabPage2.IsHeaderEnabled = true;
            this.binaryPowerTabPage2.Name = "binaryPowerTabPage2";
            this.binaryPowerTabPage2.Size = new System.Drawing.Size(666, 268);
            this.binaryPowerTabPage2.TabIndex = 1;
            this.binaryPowerTabPage2.TabPageContentIsDirty = false;
            this.binaryPowerTabPage2.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.Text = "Archive";
            this.binaryPowerTabPage2.ToolTipText = "";
            // 
            // binaryPowerTabPage3
            // 
            this.binaryPowerTabPage3.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(155)))), ((int)(((byte)(156)))));
            this.binaryPowerTabPage3.BorderSize = 1;
            this.binaryPowerTabPage3.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage3.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage3.Image")));
            this.binaryPowerTabPage3.IsBackgroundTransparent = false;
            this.binaryPowerTabPage3.IsHeaderEnabled = true;
            this.binaryPowerTabPage3.Name = "binaryPowerTabPage3";
            this.binaryPowerTabPage3.Size = new System.Drawing.Size(617, 374);
            this.binaryPowerTabPage3.TabIndex = 2;
            this.binaryPowerTabPage3.TabPageContentIsDirty = false;
            this.binaryPowerTabPage3.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.Text = "Sales";
            this.binaryPowerTabPage3.ToolTipText = "";
            // 
            // binaryPowerTabPage4
            // 
            this.binaryPowerTabPage4.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(155)))), ((int)(((byte)(156)))));
            this.binaryPowerTabPage4.BorderSize = 1;
            this.binaryPowerTabPage4.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage4.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage4.Image")));
            this.binaryPowerTabPage4.IsBackgroundTransparent = false;
            this.binaryPowerTabPage4.IsHeaderEnabled = true;
            this.binaryPowerTabPage4.Name = "binaryPowerTabPage4";
            this.binaryPowerTabPage4.Size = new System.Drawing.Size(666, 338);
            this.binaryPowerTabPage4.TabIndex = 3;
            this.binaryPowerTabPage4.TabPageContentIsDirty = false;
            this.binaryPowerTabPage4.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.Text = "Queries";
            this.binaryPowerTabPage4.ToolTipText = "";
            // 
            // binaryPowerTabPage5
            // 
            this.binaryPowerTabPage5.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(155)))), ((int)(((byte)(156)))));
            this.binaryPowerTabPage5.BorderSize = 1;
            this.binaryPowerTabPage5.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage5.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage5.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage5.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage5.Image")));
            this.binaryPowerTabPage5.IsBackgroundTransparent = false;
            this.binaryPowerTabPage5.IsHeaderEnabled = true;
            this.binaryPowerTabPage5.Name = "binaryPowerTabPage5";
            this.binaryPowerTabPage5.Size = new System.Drawing.Size(628, 374);
            this.binaryPowerTabPage5.TabIndex = 4;
            this.binaryPowerTabPage5.TabPageContentIsDirty = false;
            this.binaryPowerTabPage5.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage5.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage5.Text = "Reviews";
            this.binaryPowerTabPage5.ToolTipText = "";
            // 
            // binaryPowerTabPage6
            // 
            this.binaryPowerTabPage6.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(155)))), ((int)(((byte)(156)))));
            this.binaryPowerTabPage6.BorderSize = 1;
            this.binaryPowerTabPage6.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage6.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage6.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage6.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage6.Image")));
            this.binaryPowerTabPage6.IsBackgroundTransparent = false;
            this.binaryPowerTabPage6.IsHeaderEnabled = true;
            this.binaryPowerTabPage6.Name = "binaryPowerTabPage6";
            this.binaryPowerTabPage6.Size = new System.Drawing.Size(628, 374);
            this.binaryPowerTabPage6.TabIndex = 5;
            this.binaryPowerTabPage6.TabPageContentIsDirty = false;
            this.binaryPowerTabPage6.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage6.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage6.Text = "Old documents";
            this.binaryPowerTabPage6.ToolTipText = "";
            // 
            // binaryPowerTabPage7
            // 
            this.binaryPowerTabPage7.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(155)))), ((int)(((byte)(156)))));
            this.binaryPowerTabPage7.BorderSize = 1;
            this.binaryPowerTabPage7.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage7.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage7.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage7.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage7.Image")));
            this.binaryPowerTabPage7.IsBackgroundTransparent = false;
            this.binaryPowerTabPage7.IsHeaderEnabled = true;
            this.binaryPowerTabPage7.Name = "binaryPowerTabPage7";
            this.binaryPowerTabPage7.Size = new System.Drawing.Size(628, 374);
            this.binaryPowerTabPage7.TabIndex = 6;
            this.binaryPowerTabPage7.TabPageContentIsDirty = false;
            this.binaryPowerTabPage7.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage7.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage7.Text = "Work-in-progress";
            this.binaryPowerTabPage7.ToolTipText = "";
            // 
            // binaryPowerTabPage8
            // 
            this.binaryPowerTabPage8.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(155)))), ((int)(((byte)(156)))));
            this.binaryPowerTabPage8.BorderSize = 1;
            this.binaryPowerTabPage8.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage8.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage8.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage8.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage8.Image")));
            this.binaryPowerTabPage8.IsBackgroundTransparent = false;
            this.binaryPowerTabPage8.IsHeaderEnabled = true;
            this.binaryPowerTabPage8.Name = "binaryPowerTabPage8";
            this.binaryPowerTabPage8.Size = new System.Drawing.Size(628, 374);
            this.binaryPowerTabPage8.TabIndex = 7;
            this.binaryPowerTabPage8.TabPageContentIsDirty = false;
            this.binaryPowerTabPage8.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage8.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage8.Text = "Charts";
            this.binaryPowerTabPage8.ToolTipText = "";
            // 
            // binaryPowerTabPage9
            // 
            this.binaryPowerTabPage9.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(155)))), ((int)(((byte)(156)))));
            this.binaryPowerTabPage9.BorderSize = 1;
            this.binaryPowerTabPage9.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage9.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage9.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage9.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage9.Image")));
            this.binaryPowerTabPage9.IsBackgroundTransparent = false;
            this.binaryPowerTabPage9.IsHeaderEnabled = true;
            this.binaryPowerTabPage9.Name = "binaryPowerTabPage9";
            this.binaryPowerTabPage9.Size = new System.Drawing.Size(628, 398);
            this.binaryPowerTabPage9.TabIndex = 8;
            this.binaryPowerTabPage9.TabPageContentIsDirty = false;
            this.binaryPowerTabPage9.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage9.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage9.Text = "Misc.";
            this.binaryPowerTabPage9.ToolTipText = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(354, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Tab control instance in multi-line mode with more customisations  possible:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(880, 555);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.binaryPowerTabStrip1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.TitlebarText = "Binarymission TabControl rendering customisations Demo";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.binaryPowerTabStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip binaryPowerTabStrip1;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage1;
        private System.Windows.Forms.ComboBox orientationChangeCmbBx;
        private System.Windows.Forms.Label label1;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage2;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage3;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage4;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage5;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage6;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage7;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage8;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox closeButtonPositionCmbBx;
        private System.Windows.Forms.Label label4;
    }
}

