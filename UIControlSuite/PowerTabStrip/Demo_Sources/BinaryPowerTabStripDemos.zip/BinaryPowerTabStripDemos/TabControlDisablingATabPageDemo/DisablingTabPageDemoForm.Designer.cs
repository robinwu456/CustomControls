﻿using Binarymission.WinForms.Controls.TabControls;

namespace TabControlDisablingATabPageDemo
{
    partial class DisablingTabPageDemoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            var stringFormat1 = new System.Drawing.StringFormat();
            var resources = new System.ComponentModel.ComponentResourceManager(typeof(DisablingTabPageDemoForm));
            this.binaryPowerTabStrip1 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip();
            this.binaryPowerTabPage1 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage2 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage3 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage4 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.chkShouldAutoSizeTabPageHeaders = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkOverflowStrategyIsMenu = new System.Windows.Forms.CheckBox();
            this.binaryPowerTabStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // binaryPowerTabStrip1
            // 
            this.binaryPowerTabStrip1.Cursor = System.Windows.Forms.Cursors.Default;
            this.binaryPowerTabStrip1.CustomEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip1.CustomStartColor = System.Drawing.Color.Green;
            this.binaryPowerTabStrip1.DrawBorderAroundTabStrip = false;
            this.binaryPowerTabStrip1.DrawTabPageOnTopOfEachOther = false;
            this.binaryPowerTabStrip1.EmptySpaceLengthBeforeTheFirstTabPage = 8;
            this.binaryPowerTabStrip1.EnableAutomaticUpdateOfTabPagesHeaderSize = true;
            this.binaryPowerTabStrip1.EnableControlledLayoutRendering = false;
            this.binaryPowerTabStrip1.EnableDragAndDropOfTabPages = false;
            this.binaryPowerTabStrip1.EnableTabPageLevelCloseButtonRendering = true;
            this.binaryPowerTabStrip1.ExtendedWindowsXPRenderingFirstColor = System.Drawing.Color.Blue;
            this.binaryPowerTabStrip1.ExtendedWindowsXPRenderingSecondColor = System.Drawing.Color.LightBlue;
            this.binaryPowerTabStrip1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabStrip1.HeaderFont = null;
            this.binaryPowerTabStrip1.HeaderTextCloseButtonExtraGap = 8;
            this.binaryPowerTabStrip1.IsBackgroundTransparent = false;
            this.binaryPowerTabStrip1.KeepShowingTooltipEvenWhenMousePointerIsMoving = false;
            this.binaryPowerTabStrip1.Location = new System.Drawing.Point(12, 52);
            this.binaryPowerTabStrip1.Name = "binaryPowerTabStrip1";
            this.binaryPowerTabStrip1.NewlyAddedPagesAreLocatedAtLeftCorner = false;
            this.binaryPowerTabStrip1.PreventInvalidation = false;
            this.binaryPowerTabStrip1.RenderFullTextForTabPageHeader = false;
            this.binaryPowerTabStrip1.SelectedPageHeaderTextIsRenderedBold = true;
            this.binaryPowerTabStrip1.ShouldAutoSizeTabs = false;
            this.binaryPowerTabStrip1.ShouldDrawTabPageHeaderInMultiLines = false;
            this.binaryPowerTabStrip1.ShouldUpdateUponParentMove = false;
            this.binaryPowerTabStrip1.ShouldUpdateUponParentResize = false;
            this.binaryPowerTabStrip1.ShowToolTip = true;
            this.binaryPowerTabStrip1.Size = new System.Drawing.Size(1013, 283);
            this.binaryPowerTabStrip1.TabBottomOrientationCloseButtonPosition = Binarymission.WinForms.Controls.TabControls.CloseButtonPosition.Bottom;
            stringFormat1.Alignment = System.Drawing.StringAlignment.Center;
            stringFormat1.FormatFlags = System.Drawing.StringFormatFlags.NoWrap;
            stringFormat1.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat1.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat1.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
            this.binaryPowerTabStrip1.TabHeaderStringFormat = stringFormat1;
            this.binaryPowerTabStrip1.TabIndex = 0;
            this.binaryPowerTabStrip1.TabPageBorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabStrip1.TabPageCloseButtonMouseEnterColor = System.Drawing.Color.Red;
            this.binaryPowerTabStrip1.TabPageCloseButtonRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPageCloseButtonRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPageCurrentSelectionIndicatorEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip1.TabPageCurrentSelectionIndicatorStartColor = System.Drawing.Color.Orange;
            this.binaryPowerTabStrip1.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.binaryPowerTabStrip1.TabPageHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPageHeaderHeight = 40;
            this.binaryPowerTabStrip1.TabPageHeaderShowsSideBar = false;
            this.binaryPowerTabStrip1.TabPageHeaderTextFontOverridesControlDefault = false;
            this.binaryPowerTabStrip1.TabPageHeaderWidth = 240;
            this.binaryPowerTabStrip1.TabPages.AddRange(new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage[] {
            this.binaryPowerTabPage1,
            this.binaryPowerTabPage2,
            this.binaryPowerTabPage3,
            this.binaryPowerTabPage4});
            this.binaryPowerTabStrip1.TabPagesCloseButtonColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPagesHaveGapBetweenThem = false;
            this.binaryPowerTabStrip1.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabStrip1.TabPagesOverflowCalculationStrategy = Binarymission.WinForms.Controls.TabControls.TabPagesOverflowCalculationStrategy.Pessimistic;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuDropDownColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuGlyphActiveRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPagesRenderingLocation = Binarymission.WinForms.Controls.TabControls.TabPagesRenderingLocation.Top;
            this.binaryPowerTabStrip1.TabRenderingStyle = Binarymission.WinForms.Controls.TabControls.RenderingStyle.VisualStudio2008;
            this.binaryPowerTabStrip1.TabsOverflowMode = Binarymission.WinForms.Controls.TabControls.OverflowMode.MultiLine;
            this.binaryPowerTabStrip1.Text = "binaryPowerTabStrip1";
            this.binaryPowerTabStrip1.ThemeBorderColorCanBeOverridden = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.AutomaticDelay = 500;
            this.binaryPowerTabStrip1.ToolTipConfiguration.AutoPopDelay = 5000;
            this.binaryPowerTabStrip1.ToolTipConfiguration.BackColor = System.Drawing.SystemColors.Info;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.ToolTipConfiguration.InitialDelay = 500;
            this.binaryPowerTabStrip1.ToolTipConfiguration.IsBalloon = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ReshowDelay = 100;
            this.binaryPowerTabStrip1.ToolTipConfiguration.StripAmpersands = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ToolTipIcon = System.Windows.Forms.ToolTipIcon.None;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ToolTipTitle = "";
            this.binaryPowerTabStrip1.ToolTipConfiguration.UseAnimation = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.UseFading = false;
            this.binaryPowerTabStrip1.UseTabCurrentSelectionIndicatorColor = true;
            // 
            // binaryPowerTabPage1
            // 
            this.binaryPowerTabPage1.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(181)))), ((int)(((byte)(226)))));
            this.binaryPowerTabPage1.BorderSize = 1;
            this.binaryPowerTabPage1.CurrentlySelected = true;
            this.binaryPowerTabPage1.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.HeaderTextFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage1.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage1.Image")));
            this.binaryPowerTabPage1.IsBackgroundTransparent = false;
            this.binaryPowerTabPage1.IsHeaderEnabled = true;
            this.binaryPowerTabPage1.Name = "binaryPowerTabPage1";
            this.binaryPowerTabPage1.Size = new System.Drawing.Size(1011, 242);
            this.binaryPowerTabPage1.TabIndex = 0;
            this.binaryPowerTabPage1.TabPageContentIsDirty = false;
            this.binaryPowerTabPage1.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.Text = " History";
            this.binaryPowerTabPage1.ToolTipText = "";
            // 
            // binaryPowerTabPage2
            // 
            this.binaryPowerTabPage2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage2.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage2.BorderSize = 1;
            this.binaryPowerTabPage2.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.HeaderTextFont = new System.Drawing.Font("Verdana", 9.75F);
            this.binaryPowerTabPage2.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage2.Image")));
            this.binaryPowerTabPage2.IsBackgroundTransparent = false;
            this.binaryPowerTabPage2.IsHeaderEnabled = false;
            this.binaryPowerTabPage2.Name = "binaryPowerTabPage2";
            this.binaryPowerTabPage2.Size = new System.Drawing.Size(822, 157);
            this.binaryPowerTabPage2.TabIndex = 1;
            this.binaryPowerTabPage2.TabPageContentIsDirty = false;
            this.binaryPowerTabPage2.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.Text = " Printed reports (Unavailable)";
            this.binaryPowerTabPage2.ToolTipText = "";
            // 
            // binaryPowerTabPage3
            // 
            this.binaryPowerTabPage3.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage3.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage3.BorderSize = 1;
            this.binaryPowerTabPage3.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.HeaderTextFont = new System.Drawing.Font("Verdana", 9.75F);
            this.binaryPowerTabPage3.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage3.Image")));
            this.binaryPowerTabPage3.IsBackgroundTransparent = false;
            this.binaryPowerTabPage3.IsHeaderEnabled = true;
            this.binaryPowerTabPage3.Name = "binaryPowerTabPage3";
            this.binaryPowerTabPage3.Size = new System.Drawing.Size(1011, 242);
            this.binaryPowerTabPage3.TabIndex = 2;
            this.binaryPowerTabPage3.TabPageContentIsDirty = false;
            this.binaryPowerTabPage3.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.Text = " Legal";
            this.binaryPowerTabPage3.ToolTipText = "";
            // 
            // binaryPowerTabPage4
            // 
            this.binaryPowerTabPage4.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage4.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage4.BorderSize = 1;
            this.binaryPowerTabPage4.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage4.IsBackgroundTransparent = false;
            this.binaryPowerTabPage4.IsHeaderEnabled = false;
            this.binaryPowerTabPage4.Name = "binaryPowerTabPage4";
            this.binaryPowerTabPage4.Size = new System.Drawing.Size(1011, 241);
            this.binaryPowerTabPage4.TabIndex = 3;
            this.binaryPowerTabPage4.TabPageContentIsDirty = false;
            this.binaryPowerTabPage4.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.Text = " Print (Unavailable)";
            this.binaryPowerTabPage4.ToolTipText = "";
            // 
            // chkShouldAutoSizeTabPageHeaders
            // 
            this.chkShouldAutoSizeTabPageHeaders.AutoSize = true;
            this.chkShouldAutoSizeTabPageHeaders.Location = new System.Drawing.Point(15, 353);
            this.chkShouldAutoSizeTabPageHeaders.Name = "chkShouldAutoSizeTabPageHeaders";
            this.chkShouldAutoSizeTabPageHeaders.Size = new System.Drawing.Size(243, 17);
            this.chkShouldAutoSizeTabPageHeaders.TabIndex = 1;
            this.chkShouldAutoSizeTabPageHeaders.Text = "Should autosize all page headers to same size";
            this.chkShouldAutoSizeTabPageHeaders.UseVisualStyleBackColor = true;
            this.chkShouldAutoSizeTabPageHeaders.CheckedChanged += new System.EventHandler(this.ShouldAutoSizeTabPageHeadersCheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(569, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "TabControl demonstrating that you can set some or all of the tab pages to be in d" +
    "isabled mode:";
            // 
            // chkOverflowStrategyIsMenu
            // 
            this.chkOverflowStrategyIsMenu.AutoSize = true;
            this.chkOverflowStrategyIsMenu.Location = new System.Drawing.Point(335, 355);
            this.chkOverflowStrategyIsMenu.Name = "chkOverflowStrategyIsMenu";
            this.chkOverflowStrategyIsMenu.Size = new System.Drawing.Size(148, 17);
            this.chkOverflowStrategyIsMenu.TabIndex = 3;
            this.chkOverflowStrategyIsMenu.Text = "Overflow strategy is Menu";
            this.chkOverflowStrategyIsMenu.UseVisualStyleBackColor = true;
            this.chkOverflowStrategyIsMenu.CheckedChanged += new System.EventHandler(this.ShouldOverflowStrategyMenuCheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(1049, 425);
            this.Controls.Add(this.chkOverflowStrategyIsMenu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chkShouldAutoSizeTabPageHeaders);
            this.Controls.Add(this.binaryPowerTabStrip1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.TitlebarText = "Binarymission TabControl Demo: Disabling some of the tab pages/headers";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.binaryPowerTabStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip binaryPowerTabStrip1;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage1;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage2;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage3;
        private BinaryPowerTabPage binaryPowerTabPage4;
        private System.Windows.Forms.CheckBox chkShouldAutoSizeTabPageHeaders;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkOverflowStrategyIsMenu;
    }
}

