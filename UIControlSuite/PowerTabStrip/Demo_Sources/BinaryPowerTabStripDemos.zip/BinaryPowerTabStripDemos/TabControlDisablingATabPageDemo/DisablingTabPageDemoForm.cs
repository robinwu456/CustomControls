﻿using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.TabControls;

namespace TabControlDisablingATabPageDemo
{
    public partial class DisablingTabPageDemoForm : ModernChromeWindow
    {
        public DisablingTabPageDemoForm()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
        }

        private void ShouldAutoSizeTabPageHeadersCheckedChanged(object sender, System.EventArgs e)
        {
            binaryPowerTabStrip1.ShouldAutoSizeTabs = chkShouldAutoSizeTabPageHeaders.Checked;
        }

        private void ShouldOverflowStrategyMenuCheckedChanged(object sender, System.EventArgs e)
        {
            binaryPowerTabStrip1.TabsOverflowMode = chkOverflowStrategyIsMenu.Checked
                ? OverflowMode.Menu
                : OverflowMode.MultiLine;
        }
    }
}
