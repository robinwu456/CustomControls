﻿using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace MultiLineTabControlDemo
{
    public partial class MultiLineTabControlDemoForm : ModernChromeWindow
    {
        public MultiLineTabControlDemoForm()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
        }
    }
}
