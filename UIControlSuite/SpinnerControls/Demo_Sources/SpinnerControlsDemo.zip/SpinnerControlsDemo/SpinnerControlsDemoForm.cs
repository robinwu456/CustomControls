using System;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.AdvancedInputControls;
using System.ComponentModel;

namespace SpinnerControlsDemo
{
    /// <summary>
    /// Summary description for SpinnerControlsDemoForm.
    /// </summary>
    public class SpinnerControlsDemoForm : Form
	{
        private void HandleSpinnerControlsShowBorderAlwaysSetupChanged(object sender, EventArgs e)
		{
			if(_chkShowBorderAlways.Checked)
			{
				_numericSpinner.ShowBorderAlways = _domainSpinner.ShowBorderAlways = true;
			}
			else
			{
				_numericSpinner.ShowBorderAlways = _domainSpinner.ShowBorderAlways = false;
			}
		}

		private void HandleSpinnerControlsDrawStyleSetupChanged(object sender, EventArgs e)
		{
			if(_chkDrawStyleIsFlat.Checked)
			{
				_chkShowBorderAlways.Enabled = !false;
				_numericSpinner.DrawStyleIsFlat = _domainSpinner.DrawStyleIsFlat = true;
			}
			else
			{
				_chkShowBorderAlways.Enabled = false;
				_numericSpinner.DrawStyleIsFlat = _domainSpinner.DrawStyleIsFlat = false;
			}
		}

        private void HandleEnableDisableSpinnerControlsCheckedChanged(object sender, EventArgs e)
        {
            _numericSpinner.Enabled = _domainSpinner.Enabled = _chkEnableDisableSpinnerControls.Checked;
        }

        private void HandleApplicationExitRequested(object sender, EventArgs e)
		{
			Close();
		}

        private void HandleBorderColorInvoker(object sender, EventArgs e)
        {
            if (_colorDialog1.ShowDialog(this) == DialogResult.OK)
            {
                _numericSpinner.BorderColor = _domainSpinner.BorderColor = _colorDialog1.Color;
                UpdateSpinnerControls();
            }
        }

        private void HandleBackColorInvoker(object sender, EventArgs e)
        {
            if (_colorDialog1.ShowDialog(this) == DialogResult.OK)
            {
                _numericSpinner.BackColor = _domainSpinner.BackColor = _colorDialog1.Color;
                UpdateSpinnerControls();
            }
        }

        private void HandleInternalButtonColorInvoker(object sender, EventArgs e)
        {
            if (_colorDialog1.ShowDialog(this) == DialogResult.OK)
            {
                _numericSpinner.UpDownButtonOnFocusBackColor = _domainSpinner.UpDownButtonOnFocusBackColor = _colorDialog1.Color;
                UpdateSpinnerControls();
            }
        }

        private void HandleArrowPressedColorInvoker(object sender, EventArgs e)
        {
            if (_colorDialog1.ShowDialog(this) == DialogResult.OK)
            {
                _numericSpinner.UpDownArrowPressedBackColor = _domainSpinner.UpDownArrowPressedBackColor = _colorDialog1.Color;
                UpdateSpinnerControls();
            }
        }

        private void HandleArrowNormalColorInvoker(object sender, EventArgs e)
        {
            if (_colorDialog1.ShowDialog(this) == DialogResult.OK)
            {
                _numericSpinner.UpDownArrowsColor = _domainSpinner.UpDownArrowsColor = _colorDialog1.Color;
                UpdateSpinnerControls();
            }
        }

        private void UpdateSpinnerControls()
        {
            _numericSpinner.Refresh();
            _domainSpinner.Refresh();
        }

        #region Infrastructure bits

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private readonly Container _components = null;

        public SpinnerControlsDemoForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_components != null)
                {
                    _components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SpinnerControlsDemoForm));
            this._groupBox1 = new System.Windows.Forms.GroupBox();
            this._chkEnableDisableSpinnerControls = new System.Windows.Forms.CheckBox();
            this._label2 = new System.Windows.Forms.Label();
            this._label1 = new System.Windows.Forms.Label();
            this._domainSpinner = new Binarymission.WinForms.Controls.AdvancedInputControls.BinaryDomainUpDown();
            this._numericSpinner = new Binarymission.WinForms.Controls.AdvancedInputControls.BinaryNumericUpDown();
            this._groupBox2 = new System.Windows.Forms.GroupBox();
            this._btnBorderColorInvoker = new System.Windows.Forms.Button();
            this._btnBackColorInvoker = new System.Windows.Forms.Button();
            this._btnArrowNormalColorrInvoker = new System.Windows.Forms.Button();
            this._btnArrowPressedColorrInvoker = new System.Windows.Forms.Button();
            this._btnInternalButtonColorrInvoker = new System.Windows.Forms.Button();
            this._chkDrawStyleIsFlat = new System.Windows.Forms.CheckBox();
            this._chkShowBorderAlways = new System.Windows.Forms.CheckBox();
            this._appExitCommandVisual = new System.Windows.Forms.Button();
            this._statusStrip1 = new System.Windows.Forms.StatusStrip();
            this._toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this._colorDialog1 = new System.Windows.Forms.ColorDialog();
            this._groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._numericSpinner)).BeginInit();
            this._groupBox2.SuspendLayout();
            this._statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // _groupBox1
            // 
            this._groupBox1.Controls.Add(this._chkEnableDisableSpinnerControls);
            this._groupBox1.Controls.Add(this._label2);
            this._groupBox1.Controls.Add(this._label1);
            this._groupBox1.Controls.Add(this._domainSpinner);
            this._groupBox1.Controls.Add(this._numericSpinner);
            this._groupBox1.Location = new System.Drawing.Point(8, 8);
            this._groupBox1.Name = "_groupBox1";
            this._groupBox1.Size = new System.Drawing.Size(464, 123);
            this._groupBox1.TabIndex = 0;
            this._groupBox1.TabStop = false;
            this._groupBox1.Text = "BinaryUpDown .NET controls";
            // 
            // _chkEnableDisableSpinnerControls
            // 
            this._chkEnableDisableSpinnerControls.Checked = true;
            this._chkEnableDisableSpinnerControls.CheckState = System.Windows.Forms.CheckState.Checked;
            this._chkEnableDisableSpinnerControls.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._chkEnableDisableSpinnerControls.Location = new System.Drawing.Point(9, 95);
            this._chkEnableDisableSpinnerControls.Name = "_chkEnableDisableSpinnerControls";
            this._chkEnableDisableSpinnerControls.Size = new System.Drawing.Size(184, 16);
            this._chkEnableDisableSpinnerControls.TabIndex = 6;
            this._chkEnableDisableSpinnerControls.Text = "Enable spinner controls?";
            this._chkEnableDisableSpinnerControls.CheckedChanged += new System.EventHandler(this.HandleEnableDisableSpinnerControlsCheckedChanged);
            // 
            // _label2
            // 
            this._label2.Location = new System.Drawing.Point(232, 24);
            this._label2.Name = "_label2";
            this._label2.Size = new System.Drawing.Size(208, 16);
            this._label2.TabIndex = 3;
            this._label2.Text = "BinaryDomainUpDown .NET";
            // 
            // _label1
            // 
            this._label1.Location = new System.Drawing.Point(8, 24);
            this._label1.Name = "_label1";
            this._label1.Size = new System.Drawing.Size(208, 16);
            this._label1.TabIndex = 2;
            this._label1.Text = "BinaryNumericUpDown .NET";
            // 
            // _domainSpinner
            // 
            this._domainSpinner.BorderColor = System.Drawing.Color.Green;
            this._domainSpinner.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._domainSpinner.Items.Add("Sample Item 1");
            this._domainSpinner.Items.Add("Sample Item 2");
            this._domainSpinner.Items.Add("Sample Item 3");
            this._domainSpinner.Items.Add("Sample Item 4");
            this._domainSpinner.Items.Add("Sample Item 5");
            this._domainSpinner.Items.Add("Sample Item 6");
            this._domainSpinner.Items.Add("Sample Item 7");
            this._domainSpinner.Items.Add("Sample Item 8");
            this._domainSpinner.Items.Add("");
            this._domainSpinner.Location = new System.Drawing.Point(232, 48);
            this._domainSpinner.Name = "_domainSpinner";
            this._domainSpinner.ShowBorderAlways = true;
            this._domainSpinner.Size = new System.Drawing.Size(224, 22);
            this._domainSpinner.TabIndex = 1;
            this._domainSpinner.Text = "binaryDomainUpDown1";
            this._domainSpinner.UpDownArrowPressedBackColor = System.Drawing.Color.Green;
            this._domainSpinner.UpDownArrowsColor = System.Drawing.Color.Black;
            this._domainSpinner.UpDownButtonNormalBackColor = System.Drawing.Color.White;
            this._domainSpinner.UpDownButtonOnFocusBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(255)))), ((int)(((byte)(204)))));
            // 
            // _numericSpinner
            // 
            this._numericSpinner.BorderColor = System.Drawing.Color.Green;
            this._numericSpinner.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._numericSpinner.Location = new System.Drawing.Point(8, 48);
            this._numericSpinner.Name = "_numericSpinner";
            this._numericSpinner.ShowBorderAlways = true;
            this._numericSpinner.Size = new System.Drawing.Size(208, 22);
            this._numericSpinner.TabIndex = 0;
            this._numericSpinner.UpDownArrowPressedBackColor = System.Drawing.Color.Green;
            this._numericSpinner.UpDownArrowsColor = System.Drawing.Color.Black;
            this._numericSpinner.UpDownButtonNormalBackColor = System.Drawing.Color.White;
            this._numericSpinner.UpDownButtonOnFocusBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(255)))), ((int)(((byte)(204)))));
            // 
            // _groupBox2
            // 
            this._groupBox2.Controls.Add(this._btnBorderColorInvoker);
            this._groupBox2.Controls.Add(this._btnBackColorInvoker);
            this._groupBox2.Controls.Add(this._btnArrowNormalColorrInvoker);
            this._groupBox2.Controls.Add(this._btnArrowPressedColorrInvoker);
            this._groupBox2.Controls.Add(this._btnInternalButtonColorrInvoker);
            this._groupBox2.Controls.Add(this._chkDrawStyleIsFlat);
            this._groupBox2.Controls.Add(this._chkShowBorderAlways);
            this._groupBox2.Location = new System.Drawing.Point(8, 149);
            this._groupBox2.Name = "_groupBox2";
            this._groupBox2.Size = new System.Drawing.Size(464, 152);
            this._groupBox2.TabIndex = 1;
            this._groupBox2.TabStop = false;
            this._groupBox2.Text = "Special properties";
            // 
            // btnBorderColorInvoker
            // 
            this._btnBorderColorInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnBorderColorInvoker.Location = new System.Drawing.Point(169, 104);
            this._btnBorderColorInvoker.Name = "_btnBorderColorInvoker";
            this._btnBorderColorInvoker.Size = new System.Drawing.Size(132, 32);
            this._btnBorderColorInvoker.TabIndex = 9;
            this._btnBorderColorInvoker.Text = "Border color...";
            this._btnBorderColorInvoker.Click += new System.EventHandler(this.HandleBorderColorInvoker);
            // 
            // btnBackColorInvoker
            // 
            this._btnBackColorInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnBackColorInvoker.Location = new System.Drawing.Point(13, 104);
            this._btnBackColorInvoker.Name = "_btnBackColorInvoker";
            this._btnBackColorInvoker.Size = new System.Drawing.Size(132, 32);
            this._btnBackColorInvoker.TabIndex = 8;
            this._btnBackColorInvoker.Text = "Backcolor...";
            this._btnBackColorInvoker.Click += new System.EventHandler(this.HandleBackColorInvoker);
            // 
            // btnArrowNormalColorrInvoker
            // 
            this._btnArrowNormalColorrInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnArrowNormalColorrInvoker.Location = new System.Drawing.Point(324, 57);
            this._btnArrowNormalColorrInvoker.Name = "_btnArrowNormalColorrInvoker";
            this._btnArrowNormalColorrInvoker.Size = new System.Drawing.Size(132, 32);
            this._btnArrowNormalColorrInvoker.TabIndex = 7;
            this._btnArrowNormalColorrInvoker.Text = "Arrow normal color...";
            this._btnArrowNormalColorrInvoker.Click += new System.EventHandler(this.HandleArrowNormalColorInvoker);
            // 
            // btnArrowPressedColorrInvoker
            // 
            this._btnArrowPressedColorrInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnArrowPressedColorrInvoker.Location = new System.Drawing.Point(168, 57);
            this._btnArrowPressedColorrInvoker.Name = "_btnArrowPressedColorrInvoker";
            this._btnArrowPressedColorrInvoker.Size = new System.Drawing.Size(132, 32);
            this._btnArrowPressedColorrInvoker.TabIndex = 6;
            this._btnArrowPressedColorrInvoker.Text = "Arrow pressed color...";
            this._btnArrowPressedColorrInvoker.Click += new System.EventHandler(this.HandleArrowPressedColorInvoker);
            // 
            // btnInternalButtonColorrInvoker
            // 
            this._btnInternalButtonColorrInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnInternalButtonColorrInvoker.Location = new System.Drawing.Point(12, 57);
            this._btnInternalButtonColorrInvoker.Name = "_btnInternalButtonColorrInvoker";
            this._btnInternalButtonColorrInvoker.Size = new System.Drawing.Size(132, 32);
            this._btnInternalButtonColorrInvoker.TabIndex = 5;
            this._btnInternalButtonColorrInvoker.Text = "Internal Button Color...";
            this._btnInternalButtonColorrInvoker.Click += new System.EventHandler(this.HandleInternalButtonColorInvoker);
            // 
            // _chkDrawStyleIsFlat
            // 
            this._chkDrawStyleIsFlat.Checked = true;
            this._chkDrawStyleIsFlat.CheckState = System.Windows.Forms.CheckState.Checked;
            this._chkDrawStyleIsFlat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._chkDrawStyleIsFlat.Location = new System.Drawing.Point(168, 24);
            this._chkDrawStyleIsFlat.Name = "_chkDrawStyleIsFlat";
            this._chkDrawStyleIsFlat.Size = new System.Drawing.Size(184, 16);
            this._chkDrawStyleIsFlat.TabIndex = 1;
            this._chkDrawStyleIsFlat.Text = "DrawStyleIsFlat";
            this._chkDrawStyleIsFlat.CheckedChanged += new System.EventHandler(this.HandleSpinnerControlsDrawStyleSetupChanged);
            // 
            // _chkShowBorderAlways
            // 
            this._chkShowBorderAlways.Checked = true;
            this._chkShowBorderAlways.CheckState = System.Windows.Forms.CheckState.Checked;
            this._chkShowBorderAlways.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._chkShowBorderAlways.Location = new System.Drawing.Point(8, 24);
            this._chkShowBorderAlways.Name = "_chkShowBorderAlways";
            this._chkShowBorderAlways.Size = new System.Drawing.Size(136, 16);
            this._chkShowBorderAlways.TabIndex = 0;
            this._chkShowBorderAlways.Text = "ShowBorderAlways";
            this._chkShowBorderAlways.CheckedChanged += new System.EventHandler(this.HandleSpinnerControlsShowBorderAlwaysSetupChanged);
            // 
            // _appExitCommandVisual
            // 
            this._appExitCommandVisual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._appExitCommandVisual.Location = new System.Drawing.Point(356, 327);
            this._appExitCommandVisual.Name = "_appExitCommandVisual";
            this._appExitCommandVisual.Size = new System.Drawing.Size(112, 32);
            this._appExitCommandVisual.TabIndex = 4;
            this._appExitCommandVisual.Text = "E&xit";
            this._appExitCommandVisual.Click += new System.EventHandler(this.HandleApplicationExitRequested);
            // 
            // _statusStrip1
            // 
            this._statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._toolStripStatusLabel1});
            this._statusStrip1.Location = new System.Drawing.Point(0, 371);
            this._statusStrip1.Name = "_statusStrip1";
            this._statusStrip1.Size = new System.Drawing.Size(480, 22);
            this._statusStrip1.TabIndex = 5;
            this._statusStrip1.Text = "statusStrip1";
            // 
            // _toolStripStatusLabel1
            // 
            this._toolStripStatusLabel1.Name = "_toolStripStatusLabel1";
            this._toolStripStatusLabel1.Size = new System.Drawing.Size(354, 17);
            this._toolStripStatusLabel1.Text = "Copyright (C) Binarymission, UK. http://www.binarymission.co.uk";
            // 
            // SpinnerControlsDemoForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(480, 393);
            this.Controls.Add(this._statusStrip1);
            this.Controls.Add(this._appExitCommandVisual);
            this.Controls.Add(this._groupBox2);
            this.Controls.Add(this._groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "SpinnerControlsDemoForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BinaryUpDown .NET Demo App!";
            this._groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._numericSpinner)).EndInit();
            this._groupBox2.ResumeLayout(false);
            this._statusStrip1.ResumeLayout(false);
            this._statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.Run(new SpinnerControlsDemoForm());
        }

        private GroupBox _groupBox1;
        private BinaryNumericUpDown _numericSpinner;
        private BinaryDomainUpDown _domainSpinner;
        private Label _label1;
        private Label _label2;
        private GroupBox _groupBox2;
        private CheckBox _chkShowBorderAlways;
        private Button _appExitCommandVisual;
        private CheckBox _chkDrawStyleIsFlat;
        private StatusStrip _statusStrip1;
        private ToolStripStatusLabel _toolStripStatusLabel1;
        private CheckBox _chkEnableDisableSpinnerControls;
        private Button _btnInternalButtonColorrInvoker;
        private Button _btnBorderColorInvoker;
        private Button _btnBackColorInvoker;
        private Button _btnArrowNormalColorrInvoker;
        private Button _btnArrowPressedColorrInvoker;
        private ColorDialog _colorDialog1;

        #endregion Infrastructure bits
    }
}
