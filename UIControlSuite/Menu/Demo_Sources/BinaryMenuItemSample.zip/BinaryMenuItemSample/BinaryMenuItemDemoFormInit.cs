﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Resources;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.MenuControls.MenuClasses;
using Binarymission.WinForms.Controls.MenuControls.UsableUtilities;

namespace BinaryMenuItemSample
{
    public partial class BinaryMenuItemDemoForm
    {
        private readonly System.ComponentModel.Container _components = null;
        private CheckBox _chkBoxUseOfficeStyleRendering;
        private GroupBox _grpBoxMenuRenderingOptions;
        private Button _btnChkBoxRadioBtnColor;
        private Button _btnBorderColor;
        private Button _btnSelectionColor;
        private Label _label1;
        private Label _label2;
        private Label _label3;
        private Label _label4;
        private Button _btnExit;
        private Button _btnAbout;
        private StatusStrip _statusStrip1;
        private ToolStripStatusLabel _toolStripStatusLabel1;
        private Button _btnMenuItemSidebarColor;
        private CheckBox _chkBxUseGradientStyle;
        private ComboBox _cmbBoxMenuRenderingStyles;
        private Button _button10;
        private Button _button9;
        private Button _button8;
        private CheckBox _checkBox1;
        public static ResourceManager ResMgr;

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _components?.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BinaryMenuItemDemoForm));
            _chkBoxUseOfficeStyleRendering = new CheckBox();
            _grpBoxMenuRenderingOptions = new System.Windows.Forms.GroupBox();
            _checkBox1 = new CheckBox();
            _button10 = new System.Windows.Forms.Button();
            _button9 = new System.Windows.Forms.Button();
            _button8 = new System.Windows.Forms.Button();
            _cmbBoxMenuRenderingStyles = new System.Windows.Forms.ComboBox();
            _chkBxUseGradientStyle = new CheckBox();
            _btnMenuItemSidebarColor = new System.Windows.Forms.Button();
            _btnChkBoxRadioBtnColor = new System.Windows.Forms.Button();
            _btnBorderColor = new System.Windows.Forms.Button();
            _btnSelectionColor = new System.Windows.Forms.Button();
            _label1 = new System.Windows.Forms.Label();
            _label2 = new System.Windows.Forms.Label();
            _label3 = new System.Windows.Forms.Label();
            _label4 = new System.Windows.Forms.Label();
            _btnExit = new System.Windows.Forms.Button();
            _btnAbout = new System.Windows.Forms.Button();
            _statusStrip1 = new System.Windows.Forms.StatusStrip();
            _toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            _grpBoxMenuRenderingOptions.SuspendLayout();
            _statusStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // _chkBoxUseOfficeStyleRendering
            // 
            _chkBoxUseOfficeStyleRendering.Checked = true;
            _chkBoxUseOfficeStyleRendering.CheckState = System.Windows.Forms.CheckState.Checked;
            _chkBoxUseOfficeStyleRendering.Location = new System.Drawing.Point(12, 239);
            _chkBoxUseOfficeStyleRendering.Name = "_chkBoxUseOfficeStyleRendering";
            _chkBoxUseOfficeStyleRendering.Size = new System.Drawing.Size(308, 19);
            _chkBoxUseOfficeStyleRendering.TabIndex = 0;
            _chkBoxUseOfficeStyleRendering.Text = "Use MSOffice style rendering for menu item selection.";
            _chkBoxUseOfficeStyleRendering.CheckedChanged += new System.EventHandler(MenuItemSelectionColorRenderingStyleCheckedChanged);
            // 
            // _grpBoxMenuRenderingOptions
            // 
            _grpBoxMenuRenderingOptions.Controls.Add(_checkBox1);
            _grpBoxMenuRenderingOptions.Controls.Add(_button10);
            _grpBoxMenuRenderingOptions.Controls.Add(_button9);
            _grpBoxMenuRenderingOptions.Controls.Add(_button8);
            _grpBoxMenuRenderingOptions.Controls.Add(_cmbBoxMenuRenderingStyles);
            _grpBoxMenuRenderingOptions.Controls.Add(_chkBxUseGradientStyle);
            _grpBoxMenuRenderingOptions.Controls.Add(_btnMenuItemSidebarColor);
            _grpBoxMenuRenderingOptions.Controls.Add(_btnChkBoxRadioBtnColor);
            _grpBoxMenuRenderingOptions.Controls.Add(_btnBorderColor);
            _grpBoxMenuRenderingOptions.Controls.Add(_btnSelectionColor);
            _grpBoxMenuRenderingOptions.Controls.Add(_chkBoxUseOfficeStyleRendering);
            _grpBoxMenuRenderingOptions.Location = new System.Drawing.Point(12, 40);
            _grpBoxMenuRenderingOptions.Name = "_grpBoxMenuRenderingOptions";
            _grpBoxMenuRenderingOptions.Size = new System.Drawing.Size(425, 266);
            _grpBoxMenuRenderingOptions.TabIndex = 1;
            _grpBoxMenuRenderingOptions.TabStop = false;
            _grpBoxMenuRenderingOptions.Text = "Set menu rendering options";
            // 
            // _checkBox1
            // 
            _checkBox1.Checked = true;
            _checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            _checkBox1.Location = new System.Drawing.Point(205, 141);
            _checkBox1.Name = "_checkBox1";
            _checkBox1.Size = new System.Drawing.Size(214, 19);
            _checkBox1.TabIndex = 16;
            _checkBox1.Text = "Group header item border is dotted";
            _checkBox1.CheckedChanged += new System.EventHandler(GroupHeaderBorderDrawnAsDotsCheckedChanged);
            // 
            // _button10
            // 
            _button10.FlatStyle = System.Windows.Forms.FlatStyle.System;
            _button10.Location = new System.Drawing.Point(12, 136);
            _button10.Name = "_button10";
            _button10.Size = new System.Drawing.Size(187, 26);
            _button10.TabIndex = 15;
            _button10.Text = "Change Group forecolor...";
            _button10.Click += new System.EventHandler(UpdateGroupHeaderForeColor);
            // 
            // _button9
            // 
            _button9.FlatStyle = System.Windows.Forms.FlatStyle.System;
            _button9.Location = new System.Drawing.Point(205, 101);
            _button9.Name = "_button9";
            _button9.Size = new System.Drawing.Size(200, 29);
            _button9.TabIndex = 14;
            _button9.Text = "Change Group border color...";
            _button9.Click += new System.EventHandler(UpdateGroupHeaderBorderColor);
            // 
            // _button8
            // 
            _button8.FlatStyle = System.Windows.Forms.FlatStyle.System;
            _button8.Location = new System.Drawing.Point(12, 101);
            _button8.Name = "_button8";
            _button8.Size = new System.Drawing.Size(187, 29);
            _button8.TabIndex = 13;
            _button8.Text = "Change Group header color...";
            _button8.Click += new System.EventHandler(UpdateGroupHeaderBackColor);
            // 
            // _cmbBoxMenuRenderingStyles
            // 
            _cmbBoxMenuRenderingStyles.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            _cmbBoxMenuRenderingStyles.FormattingEnabled = true;
            _cmbBoxMenuRenderingStyles.Location = new System.Drawing.Point(15, 174);
            _cmbBoxMenuRenderingStyles.Name = "_cmbBoxMenuRenderingStyles";
            _cmbBoxMenuRenderingStyles.Size = new System.Drawing.Size(269, 21);
            _cmbBoxMenuRenderingStyles.TabIndex = 6;
            _cmbBoxMenuRenderingStyles.SelectedIndexChanged += new System.EventHandler(MenuRenderingStylesSelectedIndexChanged);
            // 
            // _chkBxUseGradientStyle
            // 
            _chkBxUseGradientStyle.Checked = true;
            _chkBxUseGradientStyle.CheckState = System.Windows.Forms.CheckState.Checked;
            _chkBxUseGradientStyle.Location = new System.Drawing.Point(12, 214);
            _chkBxUseGradientStyle.Name = "_chkBxUseGradientStyle";
            _chkBxUseGradientStyle.Size = new System.Drawing.Size(407, 19);
            _chkBxUseGradientStyle.TabIndex = 5;
            _chkBxUseGradientStyle.Text = "Render side bar using gradient brush style (otherwise it will use solid brush)";
            _chkBxUseGradientStyle.CheckedChanged += new System.EventHandler(DrawMenuSideBarUsingThisStyleCheckedChanged);
            // 
            // _btnMenuItemSidebarColor
            // 
            _btnMenuItemSidebarColor.Location = new System.Drawing.Point(12, 67);
            _btnMenuItemSidebarColor.Name = "_btnMenuItemSidebarColor";
            _btnMenuItemSidebarColor.Size = new System.Drawing.Size(187, 28);
            _btnMenuItemSidebarColor.TabIndex = 4;
            _btnMenuItemSidebarColor.Text = "Menu item side bar color...";
            _btnMenuItemSidebarColor.UseVisualStyleBackColor = true;
            _btnMenuItemSidebarColor.Click += new System.EventHandler(UpdateMenuItemControlColor);
            // 
            // _btnChkBoxRadioBtnColor
            // 
            _btnChkBoxRadioBtnColor.Location = new System.Drawing.Point(205, 67);
            _btnChkBoxRadioBtnColor.Name = "_btnChkBoxRadioBtnColor";
            _btnChkBoxRadioBtnColor.Size = new System.Drawing.Size(200, 28);
            _btnChkBoxRadioBtnColor.TabIndex = 3;
            _btnChkBoxRadioBtnColor.Text = "Check mark / Radio button color...";
            _btnChkBoxRadioBtnColor.UseVisualStyleBackColor = true;
            _btnChkBoxRadioBtnColor.Click += new System.EventHandler(UpdateCheckMarkAndRadioButtonColor);
            // 
            // _btnBorderColor
            // 
            _btnBorderColor.Location = new System.Drawing.Point(205, 33);
            _btnBorderColor.Name = "_btnBorderColor";
            _btnBorderColor.Size = new System.Drawing.Size(200, 28);
            _btnBorderColor.TabIndex = 2;
            _btnBorderColor.Text = "Menu item border color...";
            _btnBorderColor.UseVisualStyleBackColor = true;
            _btnBorderColor.Click += new System.EventHandler(UpdateMenuItemBorderColor);
            // 
            // _btnSelectionColor
            // 
            _btnSelectionColor.Location = new System.Drawing.Point(12, 33);
            _btnSelectionColor.Name = "_btnSelectionColor";
            _btnSelectionColor.Size = new System.Drawing.Size(187, 28);
            _btnSelectionColor.TabIndex = 1;
            _btnSelectionColor.Text = "Menu item Selection color...";
            _btnSelectionColor.UseVisualStyleBackColor = true;
            _btnSelectionColor.Click += new System.EventHandler(UpdateMenuItemSelectionColor);
            // 
            // _label1
            // 
            _label1.AutoSize = true;
            _label1.Location = new System.Drawing.Point(19, 16);
            _label1.Name = "_label1";
            _label1.Size = new System.Drawing.Size(183, 13);
            _label1.TabIndex = 2;
            _label1.Text = "BinaryMenuItem .NET demonstration:";
            // 
            // _label2
            // 
            _label2.AutoSize = true;
            _label2.Location = new System.Drawing.Point(15, 312);
            _label2.Name = "_label2";
            _label2.Size = new System.Drawing.Size(38, 13);
            _label2.TabIndex = 3;
            _label2.Text = "Notes:";
            // 
            // _label3
            // 
            _label3.Location = new System.Drawing.Point(15, 333);
            _label3.Name = "_label3";
            _label3.Size = new System.Drawing.Size(422, 27);
            _label3.TabIndex = 4;
            _label3.Text = "1. The Application\'s menu system is rendered using BInaryMenuItem .NET, which wil" +
    "l be visible at run-time.";
            // 
            // _label4
            // 
            _label4.Location = new System.Drawing.Point(15, 370);
            _label4.Name = "_label4";
            _label4.Size = new System.Drawing.Size(422, 32);
            _label4.TabIndex = 5;
            _label4.Text = "2. Right-click anywhere in this form, to see the context menu for this form rende" +
    "red using BInaryMenuItem .NET.";
            // 
            // _btnExit
            // 
            _btnExit.Location = new System.Drawing.Point(370, 408);
            _btnExit.Name = "_btnExit";
            _btnExit.Size = new System.Drawing.Size(91, 32);
            _btnExit.TabIndex = 6;
            _btnExit.Text = "Exit";
            _btnExit.UseVisualStyleBackColor = true;
            _btnExit.Click += new System.EventHandler(AppExitClicked);
            // 
            // _btnAbout
            // 
            _btnAbout.Location = new System.Drawing.Point(273, 408);
            _btnAbout.Name = "_btnAbout";
            _btnAbout.Size = new System.Drawing.Size(91, 32);
            _btnAbout.TabIndex = 7;
            _btnAbout.Text = "About";
            _btnAbout.UseVisualStyleBackColor = true;
            _btnAbout.Click += new System.EventHandler(AboutClicked);
            // 
            // _statusStrip1
            // 
            _statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            _toolStripStatusLabel1});
            _statusStrip1.Location = new System.Drawing.Point(0, 483);
            _statusStrip1.Name = "_statusStrip1";
            _statusStrip1.Size = new System.Drawing.Size(481, 22);
            _statusStrip1.TabIndex = 8;
            _statusStrip1.Text = "statusStrip1";
            // 
            // _toolStripStatusLabel1
            // 
            _toolStripStatusLabel1.Name = "_toolStripStatusLabel1";
            _toolStripStatusLabel1.Size = new System.Drawing.Size(335, 17);
            _toolStripStatusLabel1.Text = "Copyright Binarymission, UK. http://www.binarymission.co.uk";
            // 
            // Form1
            // 
            AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            ClientSize = new System.Drawing.Size(481, 505);
            Controls.Add(_statusStrip1);
            Controls.Add(_btnAbout);
            Controls.Add(_btnExit);
            Controls.Add(_label4);
            Controls.Add(_label3);
            Controls.Add(_label2);
            Controls.Add(_label1);
            Controls.Add(_grpBoxMenuRenderingOptions);
            DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            MaximizeBox = false;
            Name = "Form1";
            WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            Load += new System.EventHandler(FormLoaded);
            _grpBoxMenuRenderingOptions.ResumeLayout(false);
            _statusStrip1.ResumeLayout(false);
            _statusStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            var thisForm = new BinaryMenuItemDemoForm
            {
                ContextMenu = new ContextMenu(GenerateBinaryMenuItems())
            };

            // Create MenuItems using BinaryMenuItem objects

            // Use the BinaryMenuItemManager to set the Colors and other properties, including its alpha-blending factors...

            BinaryMenuItemManager.MenuItemControlColor = SystemColors.ControlDark;
            BinaryMenuItemManager.MenuItemSelectionColor = Color.Orange;
            BinaryMenuItemManager.MenuItemBorderColor = Color.DarkOrange;
            BinaryMenuItemManager.CheckMarkAndRadioButtonColor = Color.DarkOrange;

            // Associate the form instance with the BinaryMenuItemManager object so that it can repaint with changed colors whenever
            // you change the color and other properties to BinaryMenuItems.
            BinaryMenuItemManager.PerformPaint(thisForm);

            // Now choose a rendering style.
            BinaryMenuItemManager.MenuItemSelectionColorRenderingStyle = MenuItemSelectionColorRenderingStyle.Default;

            // Subscribe the BinaryMenuItemManager's Color change handler to the Form's SystemColorsChanged event...
            // to automatically repaint the menu items whenever the system colors change.
            thisForm.SystemColorsChanged += BinaryMenuItemManager.PerformPaintHandler;

            Application.EnableVisualStyles();
            Application.DoEvents();
            Application.Run(thisForm);
        }
    }
}
