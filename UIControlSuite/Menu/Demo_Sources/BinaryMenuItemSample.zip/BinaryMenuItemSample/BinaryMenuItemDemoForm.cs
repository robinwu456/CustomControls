using System;
using System.Drawing;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;
using System.Collections.Generic;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.MenuControls.MenuClasses;
using Binarymission.WinForms.Controls.MenuControls.UsableUtilities;

namespace BinaryMenuItemSample
{
	public partial class BinaryMenuItemDemoForm : ModernChromeWindow
	{
		public BinaryMenuItemDemoForm()
		{
			ResMgr = new ResourceManager("BinaryMenuItemSample.BinaryMenuItemRes", Assembly.GetCallingAssembly());
			InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
        }
        
		public static Bitmap ItemIcon(string iconName)
		{
			var icon = (Bitmap)ResMgr.GetObject(iconName);
			return icon;
		}

		public static MenuItem [] GenerateBinaryMenuItems()
		{
			// Lets create a sample Menu structure like :
			// File
			//	   New
			//     Open...
			//     ---- (Separator)
			//     Exit
			// Edit
			//     Undo
			//     Redo
			//     ---- (Separator)
			//     Cut
			//          Always ask before Cutting (Checked item)
			//     Copy
			//     Paste


            // Just create each instance of the Menuitem using BinaryMenuItem object. That's it!
			
			var mFile = new BinaryMenuItem("&File", null, false);
			var mFile1 = new BinaryMenuItem("&New", new EventHandler(FileNewClickHandler), Shortcut.CtrlN, null, null, -1, false);
            var mFile2 = new BinaryMenuItem("&Open", new EventHandler(FileOpenClickHandler), Shortcut.CtrlO, null, null, -1, false);
            var mFile3 = new BinaryMenuItem("-", null, false);
            var mFile4 = new BinaryMenuItem("E&xit", new EventHandler(FileExitClickHandler), Shortcut.CtrlX, null, null, -1, false);

			var mFileItems = new MenuItem [4];
			mFileItems[0] = mFile1;
			mFileItems[1] = mFile2;
			mFileItems[2] = mFile3;
			mFileItems[3] = mFile4;

            var mEdit = new BinaryMenuItem("&Edit", null, false);
            var mEdit1 = new BinaryMenuItem("&Undo", new EventHandler(EditUndoClickHandler), Shortcut.CtrlU, null, null, -1, false);
            var mEdit2 = new BinaryMenuItem("&Redo", new EventHandler(EditRedoClickHandler), Shortcut.CtrlR, null, null, -1, false);

            // We will set this item as "Group header"
            var mEdit3 = new BinaryMenuItem("More options", null, true);

            var mEdit4 = new BinaryMenuItem("Cu&t", new EventHandler(EditCutClickHandler), false);
            var mEdit4SubItem1 = new BinaryMenuItem("&Always ask before Cutting", new EventHandler(EditCutConfirmClickHandler), false);
			mEdit4SubItem1.Checked = true;
			mEdit4.MenuItems.Add(mEdit4SubItem1);

            var mEdit5 = new BinaryMenuItem("&Copy", new EventHandler(EditCopyClickHandler), Shortcut.CtrlY, null, null, -1, false);
            var mEdit6 = new BinaryMenuItem("&Paste", new EventHandler(EditPasteClickHandler), Shortcut.CtrlP, null, null, -1, false);

            var mEditItems = new MenuItem [6];
			mEditItems[0] = mEdit1;
			mEditItems[1] = mEdit2;
			mEditItems[2] = mEdit3;
			mEditItems[3] = mEdit4;
			mEditItems[4] = mEdit5;
			mEditItems[5] = mEdit6;
		
			// set images to each of the BinaryMenuItem...

			mFile1.MenuItemImage = ItemIcon("Binarymission.File.New");
			mFile2.MenuItemImage = ItemIcon("Binarymission.File.Open");
			mFile4.MenuItemImage = ItemIcon("Binarymission.File.Exit");
            
			mEdit1.MenuItemImage = ItemIcon("Binarymission.Edit.Undo");
			mEdit2.MenuItemImage = ItemIcon("Binarymission.Edit.Redo");
			mEdit4.MenuItemImage = ItemIcon("Binarymission.Edit.Cut");
			mEdit5.MenuItemImage = ItemIcon("Binarymission.Edit.Copy");
			mEdit6.MenuItemImage = ItemIcon("Binarymission.Edit.Paste");
            
			mFile.MenuItems.AddRange(mFileItems);
			mEdit.MenuItems.AddRange(mEditItems);

            var finalCollection = new MenuItem[2];
			finalCollection[0] = (MenuItem)(mFile);
			finalCollection[1] = (MenuItem)(mEdit);

			return finalCollection;
		}
		
		public static void FileNewClickHandler(object sender, EventArgs e)
		{
		}

		public static void FileOpenClickHandler(object sender, EventArgs e)
		{
		}

		public static void FileExitClickHandler(object sender, EventArgs e)
		{
		}

		public static void EditUndoClickHandler(object sender, EventArgs e)
		{
		}

		public static void EditRedoClickHandler(object sender, EventArgs e)
		{
		}

		public static void EditCutClickHandler(object sender, EventArgs e)
		{
		}

		public static void EditCopyClickHandler(object sender, EventArgs e)
		{
		}

		public static void EditPasteClickHandler(object sender, EventArgs e)
		{
		}

		public static void EditCutConfirmClickHandler(object sender, EventArgs e)
		{
		}

		private void MenuItemSelectionColorRenderingStyleCheckedChanged(object sender, System.EventArgs e)
		{
		    BinaryMenuItemManager.MenuItemSelectionColorRenderingStyle = 
                _chkBoxUseOfficeStyleRendering.Checked ? MenuItemSelectionColorRenderingStyle.Office : MenuItemSelectionColorRenderingStyle.Default;
		}

	    private void AppExitClicked(object sender, EventArgs e)
        {
            Close();
        }

        private void AboutClicked(object sender, EventArgs e)
        {
            var contentString = "BinaryMenuItem .NET demonstration sample." +
                Environment.NewLine + Environment.NewLine +
                "Copyright (C) Binarymission Technologies Limited, UK" +
                Environment.NewLine +
                "Web home: http://www.binarymission.co.uk";
            const string titleString = "About BinaryMenuItem. NET";

            MessageBox.Show(this, contentString, titleString);
        }

        private void UpdateMenuItemSelectionColor(object sender, EventArgs e)
        {
            var cDialog = new ColorDialog();

            if(cDialog.ShowDialog() != DialogResult.Cancel)
            {
                BinaryMenuItemManager.MenuItemSelectionColor = cDialog.Color;
                
                // Associate the form instance with the BinaryMenuItemManager object so that it can repaint with changed colors whenever
                // you change the color and other properties to BinaryMenuItems.
                BinaryMenuItemManager.PerformPaint(this);
            }
        }

        private void UpdateMenuItemBorderColor(object sender, EventArgs e)
        {
            var cDialog = new ColorDialog();

            if (cDialog.ShowDialog() != DialogResult.Cancel)
            {
                BinaryMenuItemManager.MenuItemBorderColor = cDialog.Color;
                			
                // Associate the form instance with the BinaryMenuItemManager object so that it can repaint with changed colors whenever
                // you change the color and other properties to BinaryMenuItems.
                BinaryMenuItemManager.PerformPaint(this);
            }
        }

        private void UpdateCheckMarkAndRadioButtonColor(object sender, EventArgs e)
        {
            var cDialog = new ColorDialog();

            if (cDialog.ShowDialog() == DialogResult.Cancel) return;

            BinaryMenuItemManager.CheckMarkAndRadioButtonColor = cDialog.Color;
			
            // Associate the form instance with the BinaryMenuItemManager object so that it can repaint with changed colors whenever
            // you change the color and other properties to BinaryMenuItems.
            BinaryMenuItemManager.PerformPaint(this);
        }

        private void UpdateMenuItemControlColor(object sender, EventArgs e)
        {
            var cDialog = new ColorDialog();

            if (cDialog.ShowDialog() == DialogResult.Cancel) return;

            // Set up the menu item's side bar color.
            BinaryMenuItemManager.MenuItemControlColor = cDialog.Color;
               
            // Associate the form instance with the BinaryMenuItemManager object so that it can repaint with changed colors whenever
            // you change the color and other properties to BinaryMenuItems.
            BinaryMenuItemManager.PerformPaint(this);
        }

        private void DrawMenuSideBarUsingThisStyleCheckedChanged(object sender, EventArgs e)
        {
            BinaryMenuItemManager.DrawMenuSideBarUsingThisStyle =
                (_chkBxUseGradientStyle.Checked) ? MenuSideBarRenderingStyle.GradientBrushStyle : MenuSideBarRenderingStyle.SolidBrush;
            BinaryMenuItemManager.PerformPaint(this);
        }

        private void FormLoaded(object sender, EventArgs e)
        {
            BinaryMenuItemManager.MenuItemSelectionColorRenderingStyle = MenuItemSelectionColorRenderingStyle.Office;
            _cmbBoxMenuRenderingStyles.Items.AddRange(Enum.GetNames(typeof(MenuRenderingStyle)));
            _cmbBoxMenuRenderingStyles.SelectedIndex = 3; // Custom style to start with.
        }

        private void MenuRenderingStylesSelectedIndexChanged(object sender, EventArgs e)
        {
            BinaryMenuItemManager.MenuRenderingStyle = (MenuRenderingStyle)Enum.Parse(
                typeof(MenuRenderingStyle),
                _cmbBoxMenuRenderingStyles.SelectedItem.ToString(), true);
        }

        private void UpdateGroupHeaderBackColor(object sender, EventArgs e)
        {
            var colorDialog1 = new ColorDialog();

            if (colorDialog1.ShowDialog() != DialogResult.Cancel)
            {
                var items = GetGroupHeaderStyleMenuItems();

                foreach (var menuObject in items)
                {
                    menuObject.GroupHeaderBackColor = colorDialog1.Color;
                }
            }
        }
                
        private void UpdateGroupHeaderBorderColor(object sender, EventArgs e)
        {
            var colorDialog1 = new ColorDialog();

            if (colorDialog1.ShowDialog() != DialogResult.Cancel)
            {
                var items = GetGroupHeaderStyleMenuItems();

                foreach (var menuObject in items)
                {
                    menuObject.GroupHeaderBorderColor = colorDialog1.Color;
                }
            }
        }

        private void UpdateGroupHeaderForeColor(object sender, EventArgs e)
        {
            var colorDialog1 = new ColorDialog();

            if (colorDialog1.ShowDialog() == DialogResult.Cancel) return;
            var items = GetGroupHeaderStyleMenuItems();

            foreach (var menuObject in items)
            {
                menuObject.GroupHeaderForeColor = colorDialog1.Color;
            }
        }

        private IEnumerable<BinaryMenuItem> GetGroupHeaderStyleMenuItems()
        {
            var items = new List<BinaryMenuItem>();

            if (Menu != null)
            {
                foreach (BinaryMenuItem item in Menu.MenuItems)
                    GetGroupHeaderStyleMenuItems(items, item);
            }

            if (ContextMenu == null) return items;
            {
                foreach (BinaryMenuItem item in ContextMenu.MenuItems)
                    GetGroupHeaderStyleMenuItems(items, item);
            }

            return items;
        }

        private static void GetGroupHeaderStyleMenuItems(ICollection<BinaryMenuItem> items, BinaryMenuItem parentItem)
        {
            foreach (BinaryMenuItem item in parentItem.MenuItems)
            {
                items.Add(item);
                GetGroupHeaderStyleMenuItems(items, item);
            }
        }

        private void GroupHeaderBorderDrawnAsDotsCheckedChanged(object sender, EventArgs e)
        {
            var items = GetGroupHeaderStyleMenuItems();

            foreach (var menuObject in items)
            {
                menuObject.IsGroupHeaderBorderDrawnAsDots = _checkBox1.Checked;
            }
        }
    }
}
