﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.TimeControls;
using Binarymission.WinForms.Controls.TimeControls.Core.Data;

namespace ClockControlDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            InitialiseDefaults();
        }

        private void InitialiseDefaults()
        {
            dtpTimeSource.Enabled = btnClearStaticTime.Enabled = chkSetStaticTime.Checked;

            clock1.HourIndicatorLookupDictionary = new Dictionary<int, string>
            {
                {1, "B".ToUpper()},
                {2, "C".ToUpper()},
                {3, "D".ToUpper()},
                {4, "E".ToUpper()},
                {5, "F".ToUpper()},
                {6, "G".ToUpper()},
                {7, "H".ToUpper()},
                {8, "I".ToUpper()},
                {9, "J".ToUpper()},
                {10, "K".ToUpper()},
                {11, "L".ToUpper()},
                {12, "A".ToUpper()}
            };
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void spinnerBorderThickness_ValueChanged(object sender, EventArgs e)
        {
            clock1.BorderThickness = (int)spinnerBorderThickness.Value;
        }

        private void chkDropShadowEnabled_CheckedChanged(object sender, EventArgs e)
        {
            clock1.ShouldDropShadowBeEnabled = chkDropShadowEnabled.Checked;
        }

        private void dtpTimeSource_ValueChanged(object sender, EventArgs e)
        {
            clock1.StaticTime = dtpTimeSource.Value;
        }

        private void chkSetStaticTime_CheckedChanged(object sender, EventArgs e)
        {
            dtpTimeSource.Enabled = btnClearStaticTime.Enabled = chkSetStaticTime.Checked;

            if (!chkSetStaticTime.Checked)
            {
                clock1.StaticTime = null;
            }
        }

        private void btnClearStaticTime_Click(object sender, EventArgs e)
        {
            clock1.StaticTime = null;
        }

        private void spinnerTimeRefreshInterval_ValueChanged(object sender, EventArgs e)
        {
            clock1.RefreshInterval = (int)spinnerTimeRefreshInterval.Value;
        }

        private void chkShouldDrawBorder_CheckedChanged(object sender, EventArgs e)
        {
            clock1.ShouldDrawBorder = chkShouldDrawBorder.Checked;
            chkDrawGlassOnBorder.Enabled = chkShouldDrawBorder.Checked;
        }

        private void chkShouldDrawGlassArtefacts_CheckedChanged(object sender, EventArgs e)
        {
            clock1.ShouldDrawGlassEffect = chkShouldDrawGlassArtefacts.Checked;
        }

        private void chkShouldDrawInnerRing_CheckedChanged(object sender, EventArgs e)
        {
            clock1.ShouldDrawInnerRing = chkShouldDrawInnerRing.Checked;
        }

        private void chkDrawGlassOnBorder_CheckedChanged(object sender, EventArgs e)
        {
            clock1.ShouldDrawGlassEffectOnBorder = chkDrawGlassOnBorder.Checked;
        }

        private void chkDisplayTimeNumerals_CheckedChanged(object sender, EventArgs e)
        {
            clock1.ShouldDrawNumerals = chkDisplayTimeNumerals.Checked;
            chkShouldDrawMinuteIndicatorVisuals.Enabled = chkDisplayTimeNumerals.Checked;
        }

        private void optionDisplayNumbers_CheckedChanged(object sender, EventArgs e)
        {
            clock1.TimeRepresentationMode = TimeRepresentationMode.Number;
        }

        private void optionDisplayRomanNumerals_CheckedChanged(object sender, EventArgs e)
        {
            clock1.TimeRepresentationMode = TimeRepresentationMode.RomanNumeral;
        }

        private void optionsDisplayCustomTimeArtefacts_CheckedChanged(object sender, EventArgs e)
        {
            clock1.TimeRepresentationMode = TimeRepresentationMode.Custom;
        }

        private void chkShouldDrawMinuteIndicatorVisuals_CheckedChanged(object sender, EventArgs e)
        {
            clock1.ShouldDrawMinuteIndicatorVisual = chkShouldDrawMinuteIndicatorVisuals.Checked;
        }

        private void spinnerGlassAlphaFactor_ValueChanged(object sender, EventArgs e)
        {
            clock1.GlassRenderingAlphaComponent = (int)spinnerGlassAlphaFactor.Value;
        }

        private void spinnerBorderGlassAlphaFactor_ValueChanged(object sender, EventArgs e)
        {
            clock1.BorderGlassRenderingAlphaComponent = (int)spinnerBorderGlassAlphaFactor.Value;
        }

        private void chkShouldDrawShadowForTImeHandles_CheckedChanged(object sender, EventArgs e)
        {
            clock1.ShouldDrawDropShadowForTimeHandles = chkShouldDrawShadowForTImeHandles.Checked;
        }
    }
}
