﻿using Binarymission.WinForms.Controls.TimeControls.Core.Data;

namespace ClockControlDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkShouldDrawShadowForTImeHandles = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.spinnerBorderGlassAlphaFactor = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.spinnerGlassAlphaFactor = new System.Windows.Forms.NumericUpDown();
            this.chkShouldDrawMinuteIndicatorVisuals = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.optionsDisplayCustomTimeArtefacts = new System.Windows.Forms.RadioButton();
            this.optionDisplayNumbers = new System.Windows.Forms.RadioButton();
            this.optionDisplayRomanNumerals = new System.Windows.Forms.RadioButton();
            this.chkDisplayTimeNumerals = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.chkDrawGlassOnBorder = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.chkShouldDrawBorder = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.chkShouldDrawGlassArtefacts = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.chkShouldDrawInnerRing = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.spinnerTimeRefreshInterval = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnClearStaticTime = new System.Windows.Forms.Button();
            this.chkSetStaticTime = new System.Windows.Forms.CheckBox();
            this.lblStaticTime = new System.Windows.Forms.Label();
            this.dtpTimeSource = new System.Windows.Forms.DateTimePicker();
            this.chkDropShadowEnabled = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.spinnerBorderThickness = new System.Windows.Forms.NumericUpDown();
            this.btnExit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.clock1 = new Binarymission.WinForms.Controls.TimeControls.Clock();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spinnerBorderGlassAlphaFactor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinnerGlassAlphaFactor)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spinnerTimeRefreshInterval)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spinnerBorderThickness)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkShouldDrawShadowForTImeHandles);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.spinnerBorderGlassAlphaFactor);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.spinnerGlassAlphaFactor);
            this.groupBox1.Controls.Add(this.chkShouldDrawMinuteIndicatorVisuals);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.chkDisplayTimeNumerals);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.chkDrawGlassOnBorder);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.chkShouldDrawBorder);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.chkShouldDrawGlassArtefacts);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.chkShouldDrawInnerRing);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.spinnerTimeRefreshInterval);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.chkDropShadowEnabled);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.spinnerBorderThickness);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(534, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(667, 698);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Options";
            // 
            // chkShouldDrawShadowForTImeHandles
            // 
            this.chkShouldDrawShadowForTImeHandles.AutoSize = true;
            this.chkShouldDrawShadowForTImeHandles.Location = new System.Drawing.Point(407, 297);
            this.chkShouldDrawShadowForTImeHandles.Name = "chkShouldDrawShadowForTImeHandles";
            this.chkShouldDrawShadowForTImeHandles.Size = new System.Drawing.Size(15, 14);
            this.chkShouldDrawShadowForTImeHandles.TabIndex = 33;
            this.chkShouldDrawShadowForTImeHandles.UseVisualStyleBackColor = true;
            this.chkShouldDrawShadowForTImeHandles.CheckedChanged += new System.EventHandler(this.chkShouldDrawShadowForTImeHandles_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(31, 293);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(263, 18);
            this.label13.TabIndex = 32;
            this.label13.Text = "Should draw shadow for time handles?";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(31, 352);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(173, 18);
            this.label12.TabIndex = 31;
            this.label12.Text = "Border glass alpha factor";
            // 
            // spinnerBorderGlassAlphaFactor
            // 
            this.spinnerBorderGlassAlphaFactor.Location = new System.Drawing.Point(405, 352);
            this.spinnerBorderGlassAlphaFactor.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.spinnerBorderGlassAlphaFactor.Minimum = new decimal(new int[] {
            28,
            0,
            0,
            0});
            this.spinnerBorderGlassAlphaFactor.Name = "spinnerBorderGlassAlphaFactor";
            this.spinnerBorderGlassAlphaFactor.Size = new System.Drawing.Size(190, 24);
            this.spinnerBorderGlassAlphaFactor.TabIndex = 30;
            this.spinnerBorderGlassAlphaFactor.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.spinnerBorderGlassAlphaFactor.ValueChanged += new System.EventHandler(this.spinnerBorderGlassAlphaFactor_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(31, 323);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(128, 18);
            this.label11.TabIndex = 29;
            this.label11.Text = "Glass alpha factor";
            // 
            // spinnerGlassAlphaFactor
            // 
            this.spinnerGlassAlphaFactor.Location = new System.Drawing.Point(405, 321);
            this.spinnerGlassAlphaFactor.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.spinnerGlassAlphaFactor.Minimum = new decimal(new int[] {
            28,
            0,
            0,
            0});
            this.spinnerGlassAlphaFactor.Name = "spinnerGlassAlphaFactor";
            this.spinnerGlassAlphaFactor.Size = new System.Drawing.Size(190, 24);
            this.spinnerGlassAlphaFactor.TabIndex = 28;
            this.spinnerGlassAlphaFactor.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.spinnerGlassAlphaFactor.ValueChanged += new System.EventHandler(this.spinnerGlassAlphaFactor_ValueChanged);
            // 
            // chkShouldDrawMinuteIndicatorVisuals
            // 
            this.chkShouldDrawMinuteIndicatorVisuals.AutoSize = true;
            this.chkShouldDrawMinuteIndicatorVisuals.Checked = true;
            this.chkShouldDrawMinuteIndicatorVisuals.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShouldDrawMinuteIndicatorVisuals.Location = new System.Drawing.Point(406, 270);
            this.chkShouldDrawMinuteIndicatorVisuals.Name = "chkShouldDrawMinuteIndicatorVisuals";
            this.chkShouldDrawMinuteIndicatorVisuals.Size = new System.Drawing.Size(15, 14);
            this.chkShouldDrawMinuteIndicatorVisuals.TabIndex = 27;
            this.chkShouldDrawMinuteIndicatorVisuals.UseVisualStyleBackColor = true;
            this.chkShouldDrawMinuteIndicatorVisuals.CheckedChanged += new System.EventHandler(this.chkShouldDrawMinuteIndicatorVisuals_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(30, 266);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(255, 18);
            this.label10.TabIndex = 26;
            this.label10.Text = "Should draw minute indicator visuals?";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.optionsDisplayCustomTimeArtefacts);
            this.groupBox3.Controls.Add(this.optionDisplayNumbers);
            this.groupBox3.Controls.Add(this.optionDisplayRomanNumerals);
            this.groupBox3.Location = new System.Drawing.Point(37, 392);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(190, 121);
            this.groupBox3.TabIndex = 25;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Time display Mode";
            // 
            // optionsDisplayCustomTimeArtefacts
            // 
            this.optionsDisplayCustomTimeArtefacts.AutoSize = true;
            this.optionsDisplayCustomTimeArtefacts.Location = new System.Drawing.Point(17, 90);
            this.optionsDisplayCustomTimeArtefacts.Name = "optionsDisplayCustomTimeArtefacts";
            this.optionsDisplayCustomTimeArtefacts.Size = new System.Drawing.Size(79, 22);
            this.optionsDisplayCustomTimeArtefacts.TabIndex = 24;
            this.optionsDisplayCustomTimeArtefacts.Text = "Custom";
            this.optionsDisplayCustomTimeArtefacts.UseVisualStyleBackColor = true;
            this.optionsDisplayCustomTimeArtefacts.CheckedChanged += new System.EventHandler(this.optionsDisplayCustomTimeArtefacts_CheckedChanged);
            // 
            // optionDisplayNumbers
            // 
            this.optionDisplayNumbers.AutoSize = true;
            this.optionDisplayNumbers.Checked = true;
            this.optionDisplayNumbers.Location = new System.Drawing.Point(17, 34);
            this.optionDisplayNumbers.Name = "optionDisplayNumbers";
            this.optionDisplayNumbers.Size = new System.Drawing.Size(87, 22);
            this.optionDisplayNumbers.TabIndex = 22;
            this.optionDisplayNumbers.TabStop = true;
            this.optionDisplayNumbers.Text = "Numbers";
            this.optionDisplayNumbers.UseVisualStyleBackColor = true;
            this.optionDisplayNumbers.CheckedChanged += new System.EventHandler(this.optionDisplayNumbers_CheckedChanged);
            // 
            // optionDisplayRomanNumerals
            // 
            this.optionDisplayRomanNumerals.AutoSize = true;
            this.optionDisplayRomanNumerals.Location = new System.Drawing.Point(17, 62);
            this.optionDisplayRomanNumerals.Name = "optionDisplayRomanNumerals";
            this.optionDisplayRomanNumerals.Size = new System.Drawing.Size(140, 22);
            this.optionDisplayRomanNumerals.TabIndex = 23;
            this.optionDisplayRomanNumerals.Text = "Roman Numbers";
            this.optionDisplayRomanNumerals.UseVisualStyleBackColor = true;
            this.optionDisplayRomanNumerals.CheckedChanged += new System.EventHandler(this.optionDisplayRomanNumerals_CheckedChanged);
            // 
            // chkDisplayTimeNumerals
            // 
            this.chkDisplayTimeNumerals.AutoSize = true;
            this.chkDisplayTimeNumerals.Checked = true;
            this.chkDisplayTimeNumerals.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDisplayTimeNumerals.Location = new System.Drawing.Point(406, 241);
            this.chkDisplayTimeNumerals.Name = "chkDisplayTimeNumerals";
            this.chkDisplayTimeNumerals.Size = new System.Drawing.Size(15, 14);
            this.chkDisplayTimeNumerals.TabIndex = 20;
            this.chkDisplayTimeNumerals.UseVisualStyleBackColor = true;
            this.chkDisplayTimeNumerals.CheckedChanged += new System.EventHandler(this.chkDisplayTimeNumerals_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(30, 237);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(161, 18);
            this.label9.TabIndex = 19;
            this.label9.Text = "Display time numerals?";
            // 
            // chkDrawGlassOnBorder
            // 
            this.chkDrawGlassOnBorder.AutoSize = true;
            this.chkDrawGlassOnBorder.Checked = true;
            this.chkDrawGlassOnBorder.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDrawGlassOnBorder.Location = new System.Drawing.Point(406, 212);
            this.chkDrawGlassOnBorder.Name = "chkDrawGlassOnBorder";
            this.chkDrawGlassOnBorder.Size = new System.Drawing.Size(15, 14);
            this.chkDrawGlassOnBorder.TabIndex = 18;
            this.chkDrawGlassOnBorder.UseVisualStyleBackColor = true;
            this.chkDrawGlassOnBorder.CheckedChanged += new System.EventHandler(this.chkDrawGlassOnBorder_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 208);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(222, 18);
            this.label8.TabIndex = 17;
            this.label8.Text = "Draw glass effect on the border?";
            // 
            // chkShouldDrawBorder
            // 
            this.chkShouldDrawBorder.AutoSize = true;
            this.chkShouldDrawBorder.Checked = true;
            this.chkShouldDrawBorder.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShouldDrawBorder.Location = new System.Drawing.Point(406, 183);
            this.chkShouldDrawBorder.Name = "chkShouldDrawBorder";
            this.chkShouldDrawBorder.Size = new System.Drawing.Size(15, 14);
            this.chkShouldDrawBorder.TabIndex = 16;
            this.chkShouldDrawBorder.UseVisualStyleBackColor = true;
            this.chkShouldDrawBorder.CheckedChanged += new System.EventHandler(this.chkShouldDrawBorder_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(30, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(147, 18);
            this.label7.TabIndex = 15;
            this.label7.Text = "Should draw Border?";
            // 
            // chkShouldDrawGlassArtefacts
            // 
            this.chkShouldDrawGlassArtefacts.AutoSize = true;
            this.chkShouldDrawGlassArtefacts.Checked = true;
            this.chkShouldDrawGlassArtefacts.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShouldDrawGlassArtefacts.Location = new System.Drawing.Point(406, 157);
            this.chkShouldDrawGlassArtefacts.Name = "chkShouldDrawGlassArtefacts";
            this.chkShouldDrawGlassArtefacts.Size = new System.Drawing.Size(15, 14);
            this.chkShouldDrawGlassArtefacts.TabIndex = 14;
            this.chkShouldDrawGlassArtefacts.UseVisualStyleBackColor = true;
            this.chkShouldDrawGlassArtefacts.CheckedChanged += new System.EventHandler(this.chkShouldDrawGlassArtefacts_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 153);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(238, 18);
            this.label6.TabIndex = 13;
            this.label6.Text = "Should draw glass artefacts/effect?";
            // 
            // chkShouldDrawInnerRing
            // 
            this.chkShouldDrawInnerRing.AutoSize = true;
            this.chkShouldDrawInnerRing.Location = new System.Drawing.Point(406, 130);
            this.chkShouldDrawInnerRing.Name = "chkShouldDrawInnerRing";
            this.chkShouldDrawInnerRing.Size = new System.Drawing.Size(15, 14);
            this.chkShouldDrawInnerRing.TabIndex = 12;
            this.chkShouldDrawInnerRing.UseVisualStyleBackColor = true;
            this.chkShouldDrawInnerRing.CheckedChanged += new System.EventHandler(this.chkShouldDrawInnerRing_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(225, 18);
            this.label5.TabIndex = 11;
            this.label5.Text = "Should draw the inner disk / ring?";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(254, 18);
            this.label4.TabIndex = 10;
            this.label4.Text = "Clock time refresh interval (seconds):";
            // 
            // spinnerTimeRefreshInterval
            // 
            this.spinnerTimeRefreshInterval.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.spinnerTimeRefreshInterval.Location = new System.Drawing.Point(405, 66);
            this.spinnerTimeRefreshInterval.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.spinnerTimeRefreshInterval.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.spinnerTimeRefreshInterval.Name = "spinnerTimeRefreshInterval";
            this.spinnerTimeRefreshInterval.Size = new System.Drawing.Size(190, 24);
            this.spinnerTimeRefreshInterval.TabIndex = 9;
            this.spinnerTimeRefreshInterval.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.spinnerTimeRefreshInterval.ValueChanged += new System.EventHandler(this.spinnerTimeRefreshInterval_ValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnClearStaticTime);
            this.groupBox2.Controls.Add(this.chkSetStaticTime);
            this.groupBox2.Controls.Add(this.lblStaticTime);
            this.groupBox2.Controls.Add(this.dtpTimeSource);
            this.groupBox2.Location = new System.Drawing.Point(33, 534);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(616, 150);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Static (fixed) time setup for the clock to display";
            // 
            // btnClearStaticTime
            // 
            this.btnClearStaticTime.Location = new System.Drawing.Point(385, 99);
            this.btnClearStaticTime.Name = "btnClearStaticTime";
            this.btnClearStaticTime.Size = new System.Drawing.Size(212, 32);
            this.btnClearStaticTime.TabIndex = 10;
            this.btnClearStaticTime.Text = "Clear the static/fixed time?";
            this.btnClearStaticTime.UseVisualStyleBackColor = true;
            this.btnClearStaticTime.Click += new System.EventHandler(this.btnClearStaticTime_Click);
            // 
            // chkSetStaticTime
            // 
            this.chkSetStaticTime.AutoSize = true;
            this.chkSetStaticTime.Location = new System.Drawing.Point(18, 33);
            this.chkSetStaticTime.Name = "chkSetStaticTime";
            this.chkSetStaticTime.Size = new System.Drawing.Size(404, 22);
            this.chkSetStaticTime.TabIndex = 9;
            this.chkSetStaticTime.Text = "Enable setting a static / fixed time for the clock to display?";
            this.chkSetStaticTime.UseVisualStyleBackColor = true;
            this.chkSetStaticTime.CheckedChanged += new System.EventHandler(this.chkSetStaticTime_CheckedChanged);
            // 
            // lblStaticTime
            // 
            this.lblStaticTime.AutoSize = true;
            this.lblStaticTime.Location = new System.Drawing.Point(48, 69);
            this.lblStaticTime.Name = "lblStaticTime";
            this.lblStaticTime.Size = new System.Drawing.Size(77, 18);
            this.lblStaticTime.TabIndex = 4;
            this.lblStaticTime.Text = "Static time";
            // 
            // dtpTimeSource
            // 
            this.dtpTimeSource.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpTimeSource.Location = new System.Drawing.Point(385, 69);
            this.dtpTimeSource.Name = "dtpTimeSource";
            this.dtpTimeSource.ShowUpDown = true;
            this.dtpTimeSource.Size = new System.Drawing.Size(212, 24);
            this.dtpTimeSource.TabIndex = 5;
            this.dtpTimeSource.ValueChanged += new System.EventHandler(this.dtpTimeSource_ValueChanged);
            // 
            // chkDropShadowEnabled
            // 
            this.chkDropShadowEnabled.AutoSize = true;
            this.chkDropShadowEnabled.Checked = true;
            this.chkDropShadowEnabled.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDropShadowEnabled.Location = new System.Drawing.Point(405, 102);
            this.chkDropShadowEnabled.Name = "chkDropShadowEnabled";
            this.chkDropShadowEnabled.Size = new System.Drawing.Size(15, 14);
            this.chkDropShadowEnabled.TabIndex = 3;
            this.chkDropShadowEnabled.UseVisualStyleBackColor = true;
            this.chkDropShadowEnabled.CheckedChanged += new System.EventHandler(this.chkDropShadowEnabled_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Is drop-shadow enabled?";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Border thickness:";
            // 
            // spinnerBorderThickness
            // 
            this.spinnerBorderThickness.Location = new System.Drawing.Point(405, 36);
            this.spinnerBorderThickness.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.spinnerBorderThickness.Name = "spinnerBorderThickness";
            this.spinnerBorderThickness.Size = new System.Drawing.Size(190, 24);
            this.spinnerBorderThickness.TabIndex = 0;
            this.spinnerBorderThickness.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.spinnerBorderThickness.ValueChanged += new System.EventHandler(this.spinnerBorderThickness_ValueChanged);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(1080, 745);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(121, 32);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(190, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Clock control instance:";
            // 
            // clock1
            // 
            this.clock1.BackgroundEndColor = System.Drawing.Color.RosyBrown;
            this.clock1.BackgroundStartColor = System.Drawing.Color.Brown;
            this.clock1.BorderEndColor = System.Drawing.Color.Black;
            this.clock1.BorderGlassEndColor = System.Drawing.Color.Transparent;
            this.clock1.BorderGlassRenderingAlphaComponent = 60;
            this.clock1.BorderGlassStartColor = System.Drawing.Color.White;
            this.clock1.BorderStartColor = System.Drawing.Color.Black;
            this.clock1.BorderThickness = 16;
            this.clock1.DropShadowColor = System.Drawing.Color.Gray;
            this.clock1.GlassEndColor = System.Drawing.Color.Transparent;
            this.clock1.GlassRenderingAlphaComponent = 72;
            this.clock1.GlassStartColor = System.Drawing.Color.Wheat;
            this.clock1.GradientDrawingAngleForCircularArtefacts = 45F;
            this.clock1.GradientDrawingAngleForTimeNeedles = 90F;
            this.clock1.HourHandEndColor = System.Drawing.Color.Black;
            this.clock1.HourHandStartColor = System.Drawing.Color.Black;
            this.clock1.HourIndicatorLookupDictionary = null;
            this.clock1.HourNeedleWidth = 16;
            this.clock1.InnerRingEndColor = System.Drawing.Color.Black;
            this.clock1.InnerRingShapeBounds = new System.Drawing.Rectangle(-25, -25, 50, 50);
            this.clock1.InnerRingStartColor = System.Drawing.Color.Black;
            this.clock1.Location = new System.Drawing.Point(23, 130);
            this.clock1.MaxBorderThickness = 32;
            this.clock1.MinimumSize = new System.Drawing.Size(128, 128);
            this.clock1.MinuteHandEndColor = System.Drawing.Color.Black;
            this.clock1.MinuteHandStartColor = System.Drawing.Color.Black;
            this.clock1.MinuteIndicatorVisual = ".";
            this.clock1.MinuteIndicatorVisualColor = System.Drawing.Color.White;
            this.clock1.MinuteIndicatorVisualFont = null;
            this.clock1.MinuteNeedleWidth = 6;
            this.clock1.Name = "clock1";
            this.clock1.NumeralsColor = System.Drawing.Color.White;
            this.clock1.NumeralsFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clock1.RefreshInterval = 1000;
            this.clock1.SecondHandEndColor = System.Drawing.Color.DarkRed;
            this.clock1.SecondHandStartColor = System.Drawing.Color.DarkRed;
            this.clock1.SecondNeedleWidth = 2;
            this.clock1.ShouldDrawBorder = true;
            this.clock1.ShouldDrawDropShadowForTimeHandles = false;
            this.clock1.ShouldDrawGlassEffect = true;
            this.clock1.ShouldDrawGlassEffectOnBorder = true;
            this.clock1.ShouldDrawInnerRing = false;
            this.clock1.ShouldDrawMinuteIndicatorVisual = true;
            this.clock1.ShouldDrawNumerals = true;
            this.clock1.ShouldDropShadowBeEnabled = true;
            this.clock1.Size = new System.Drawing.Size(480, 480);
            this.clock1.StaticTime = null;
            this.clock1.TabIndex = 4;
            this.clock1.Text = "clock1";
            this.clock1.TimeRepresentationMode = Binarymission.WinForms.Controls.TimeControls.Core.Data.TimeRepresentationMode.Number;
            // 
            // Form1
            // 
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1214, 789);
            this.Controls.Add(this.clock1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Binarymission Clock .NET Control Demo.";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spinnerBorderGlassAlphaFactor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinnerGlassAlphaFactor)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spinnerTimeRefreshInterval)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spinnerBorderThickness)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown spinnerBorderThickness;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkDropShadowEnabled;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblStaticTime;
        private System.Windows.Forms.DateTimePicker dtpTimeSource;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkSetStaticTime;
        private System.Windows.Forms.Button btnClearStaticTime;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown spinnerTimeRefreshInterval;
        private System.Windows.Forms.CheckBox chkShouldDrawInnerRing;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox chkShouldDrawGlassArtefacts;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox chkShouldDrawBorder;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox chkDrawGlassOnBorder;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox chkDisplayTimeNumerals;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton optionDisplayRomanNumerals;
        private System.Windows.Forms.RadioButton optionDisplayNumbers;
        private System.Windows.Forms.RadioButton optionsDisplayCustomTimeArtefacts;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox chkShouldDrawMinuteIndicatorVisuals;
        private System.Windows.Forms.Label label10;
        private Binarymission.WinForms.Controls.TimeControls.Clock clock1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown spinnerGlassAlphaFactor;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown spinnerBorderGlassAlphaFactor;
        private System.Windows.Forms.CheckBox chkShouldDrawShadowForTImeHandles;
        private System.Windows.Forms.Label label13;
    }
}

