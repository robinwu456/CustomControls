﻿namespace ClocksConfigured
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.clock1 = new Binarymission.WinForms.Controls.TimeControls.Clock();
            this.clock2 = new Binarymission.WinForms.Controls.TimeControls.Clock();
            this.clock3 = new Binarymission.WinForms.Controls.TimeControls.Clock();
            this.clock4 = new Binarymission.WinForms.Controls.TimeControls.Clock();
            this.SuspendLayout();
            // 
            // clock1
            // 
            this.clock1.BackgroundEndColor = System.Drawing.Color.RosyBrown;
            this.clock1.BackgroundStartColor = System.Drawing.Color.Brown;
            this.clock1.BorderEndColor = System.Drawing.Color.Black;
            this.clock1.BorderGlassEndColor = System.Drawing.Color.Transparent;
            this.clock1.BorderGlassRenderingAlphaComponent = 0;
            this.clock1.BorderGlassStartColor = System.Drawing.Color.White;
            this.clock1.BorderStartColor = System.Drawing.Color.Black;
            this.clock1.BorderThickness = 16;
            this.clock1.DropShadowColor = System.Drawing.Color.Gray;
            this.clock1.GlassEndColor = System.Drawing.Color.Transparent;
            this.clock1.GlassRenderingAlphaComponent = 72;
            this.clock1.GlassStartColor = System.Drawing.Color.White;
            this.clock1.GradientDrawingAngleForCircularArtefacts = 45F;
            this.clock1.GradientDrawingAngleForTimeNeedles = 90F;
            this.clock1.HourHandEndColor = System.Drawing.Color.Black;
            this.clock1.HourHandStartColor = System.Drawing.Color.Black;
            this.clock1.HourIndicatorLookupDictionary = null;
            this.clock1.HourNeedleWidth = 10;
            this.clock1.InnerRingEndColor = System.Drawing.Color.Black;
            this.clock1.InnerRingShapeBounds = new System.Drawing.Rectangle(-25, -25, 50, 50);
            this.clock1.InnerRingStartColor = System.Drawing.Color.Black;
            this.clock1.Location = new System.Drawing.Point(24, 17);
            this.clock1.MaxBorderThickness = 32;
            this.clock1.MinimumSize = new System.Drawing.Size(128, 128);
            this.clock1.MinuteHandEndColor = System.Drawing.Color.Black;
            this.clock1.MinuteHandStartColor = System.Drawing.Color.Black;
            this.clock1.MinuteIndicatorVisual = ".";
            this.clock1.MinuteIndicatorVisualColor = System.Drawing.Color.White;
            this.clock1.MinuteIndicatorVisualFont = null;
            this.clock1.MinuteNeedleWidth = 3;
            this.clock1.Name = "clock1";
            this.clock1.NumeralsColor = System.Drawing.Color.White;
            this.clock1.NumeralsFont = null;
            this.clock1.RefreshInterval = 1000;
            this.clock1.SecondHandEndColor = System.Drawing.Color.DarkRed;
            this.clock1.SecondHandStartColor = System.Drawing.Color.DarkRed;
            this.clock1.SecondNeedleWidth = 2;
            this.clock1.ShouldDrawBorder = true;
            this.clock1.ShouldDrawDropShadowForTimeHandles = false;
            this.clock1.ShouldDrawGlassEffect = true;
            this.clock1.ShouldDrawGlassEffectOnBorder = false;
            this.clock1.ShouldDrawInnerRing = false;
            this.clock1.ShouldDrawMinuteIndicatorVisual = true;
            this.clock1.ShouldDrawNumerals = true;
            this.clock1.ShouldDropShadowBeEnabled = true;
            this.clock1.Size = new System.Drawing.Size(295, 282);
            this.clock1.StaticTime = null;
            this.clock1.TabIndex = 0;
            this.clock1.Text = "clock1";
            this.clock1.TimeRepresentationMode = Binarymission.WinForms.Controls.TimeControls.Core.Data.TimeRepresentationMode.Number;
            // 
            // clock2
            // 
            this.clock2.BackgroundEndColor = System.Drawing.Color.DarkSalmon;
            this.clock2.BackgroundStartColor = System.Drawing.Color.DarkSalmon;
            this.clock2.BorderEndColor = System.Drawing.Color.Brown;
            this.clock2.BorderGlassEndColor = System.Drawing.Color.Transparent;
            this.clock2.BorderGlassRenderingAlphaComponent = 60;
            this.clock2.BorderGlassStartColor = System.Drawing.Color.White;
            this.clock2.BorderStartColor = System.Drawing.Color.Brown;
            this.clock2.BorderThickness = 16;
            this.clock2.DropShadowColor = System.Drawing.Color.Gray;
            this.clock2.GlassEndColor = System.Drawing.Color.Transparent;
            this.clock2.GlassRenderingAlphaComponent = 72;
            this.clock2.GlassStartColor = System.Drawing.Color.White;
            this.clock2.GradientDrawingAngleForCircularArtefacts = 45F;
            this.clock2.GradientDrawingAngleForTimeNeedles = 90F;
            this.clock2.HourHandEndColor = System.Drawing.Color.Black;
            this.clock2.HourHandStartColor = System.Drawing.Color.Black;
            this.clock2.HourIndicatorLookupDictionary = null;
            this.clock2.HourNeedleWidth = 10;
            this.clock2.InnerRingEndColor = System.Drawing.Color.Black;
            this.clock2.InnerRingShapeBounds = new System.Drawing.Rectangle(-25, -25, 50, 50);
            this.clock2.InnerRingStartColor = System.Drawing.Color.Black;
            this.clock2.Location = new System.Drawing.Point(212, 428);
            this.clock2.MaxBorderThickness = 32;
            this.clock2.MinimumSize = new System.Drawing.Size(128, 128);
            this.clock2.MinuteHandEndColor = System.Drawing.Color.Black;
            this.clock2.MinuteHandStartColor = System.Drawing.Color.Black;
            this.clock2.MinuteIndicatorVisual = ".";
            this.clock2.MinuteIndicatorVisualColor = System.Drawing.Color.White;
            this.clock2.MinuteIndicatorVisualFont = null;
            this.clock2.MinuteNeedleWidth = 3;
            this.clock2.Name = "clock2";
            this.clock2.NumeralsColor = System.Drawing.Color.White;
            this.clock2.NumeralsFont = null;
            this.clock2.RefreshInterval = 1000;
            this.clock2.SecondHandEndColor = System.Drawing.Color.DarkRed;
            this.clock2.SecondHandStartColor = System.Drawing.Color.DarkRed;
            this.clock2.SecondNeedleWidth = 2;
            this.clock2.ShouldDrawBorder = true;
            this.clock2.ShouldDrawDropShadowForTimeHandles = false;
            this.clock2.ShouldDrawGlassEffect = true;
            this.clock2.ShouldDrawGlassEffectOnBorder = false;
            this.clock2.ShouldDrawInnerRing = false;
            this.clock2.ShouldDrawMinuteIndicatorVisual = true;
            this.clock2.ShouldDrawNumerals = false;
            this.clock2.ShouldDropShadowBeEnabled = true;
            this.clock2.Size = new System.Drawing.Size(657, 351);
            this.clock2.StaticTime = null;
            this.clock2.TabIndex = 1;
            this.clock2.Text = "clock2";
            this.clock2.TimeRepresentationMode = Binarymission.WinForms.Controls.TimeControls.Core.Data.TimeRepresentationMode.Number;
            // 
            // clock3
            // 
            this.clock3.BackgroundEndColor = System.Drawing.Color.LightSlateGray;
            this.clock3.BackgroundStartColor = System.Drawing.Color.LightSlateGray;
            this.clock3.BorderEndColor = System.Drawing.Color.Black;
            this.clock3.BorderGlassEndColor = System.Drawing.Color.Transparent;
            this.clock3.BorderGlassRenderingAlphaComponent = 60;
            this.clock3.BorderGlassStartColor = System.Drawing.Color.White;
            this.clock3.BorderStartColor = System.Drawing.Color.Black;
            this.clock3.BorderThickness = 16;
            this.clock3.DropShadowColor = System.Drawing.Color.Gray;
            this.clock3.GlassEndColor = System.Drawing.Color.Transparent;
            this.clock3.GlassRenderingAlphaComponent = 72;
            this.clock3.GlassStartColor = System.Drawing.Color.White;
            this.clock3.GradientDrawingAngleForCircularArtefacts = 45F;
            this.clock3.GradientDrawingAngleForTimeNeedles = 90F;
            this.clock3.HourHandEndColor = System.Drawing.Color.Black;
            this.clock3.HourHandStartColor = System.Drawing.Color.Black;
            this.clock3.HourIndicatorLookupDictionary = null;
            this.clock3.HourNeedleWidth = 10;
            this.clock3.InnerRingEndColor = System.Drawing.Color.Black;
            this.clock3.InnerRingShapeBounds = new System.Drawing.Rectangle(-25, -25, 50, 50);
            this.clock3.InnerRingStartColor = System.Drawing.Color.Black;
            this.clock3.Location = new System.Drawing.Point(336, 17);
            this.clock3.MaxBorderThickness = 32;
            this.clock3.MinimumSize = new System.Drawing.Size(128, 128);
            this.clock3.MinuteHandEndColor = System.Drawing.Color.Black;
            this.clock3.MinuteHandStartColor = System.Drawing.Color.Black;
            this.clock3.MinuteIndicatorVisual = ".";
            this.clock3.MinuteIndicatorVisualColor = System.Drawing.Color.White;
            this.clock3.MinuteIndicatorVisualFont = null;
            this.clock3.MinuteNeedleWidth = 3;
            this.clock3.Name = "clock3";
            this.clock3.NumeralsColor = System.Drawing.Color.White;
            this.clock3.NumeralsFont = null;
            this.clock3.RefreshInterval = 1000;
            this.clock3.SecondHandEndColor = System.Drawing.Color.DarkRed;
            this.clock3.SecondHandStartColor = System.Drawing.Color.DarkRed;
            this.clock3.SecondNeedleWidth = 2;
            this.clock3.ShouldDrawBorder = true;
            this.clock3.ShouldDrawDropShadowForTimeHandles = false;
            this.clock3.ShouldDrawGlassEffect = true;
            this.clock3.ShouldDrawGlassEffectOnBorder = false;
            this.clock3.ShouldDrawInnerRing = false;
            this.clock3.ShouldDrawMinuteIndicatorVisual = true;
            this.clock3.ShouldDrawNumerals = true;
            this.clock3.ShouldDropShadowBeEnabled = true;
            this.clock3.Size = new System.Drawing.Size(409, 394);
            this.clock3.StaticTime = null;
            this.clock3.TabIndex = 2;
            this.clock3.Text = "clock3";
            this.clock3.TimeRepresentationMode = Binarymission.WinForms.Controls.TimeControls.Core.Data.TimeRepresentationMode.RomanNumeral;
            // 
            // clock4
            // 
            this.clock4.BackgroundEndColor = System.Drawing.Color.White;
            this.clock4.BackgroundStartColor = System.Drawing.Color.Black;
            this.clock4.BorderEndColor = System.Drawing.Color.DimGray;
            this.clock4.BorderGlassEndColor = System.Drawing.Color.Transparent;
            this.clock4.BorderGlassRenderingAlphaComponent = 60;
            this.clock4.BorderGlassStartColor = System.Drawing.Color.White;
            this.clock4.BorderStartColor = System.Drawing.Color.DimGray;
            this.clock4.BorderThickness = 1;
            this.clock4.DropShadowColor = System.Drawing.Color.Gray;
            this.clock4.GlassEndColor = System.Drawing.Color.Transparent;
            this.clock4.GlassRenderingAlphaComponent = 72;
            this.clock4.GlassStartColor = System.Drawing.Color.White;
            this.clock4.GradientDrawingAngleForCircularArtefacts = 45F;
            this.clock4.GradientDrawingAngleForTimeNeedles = 90F;
            this.clock4.HourHandEndColor = System.Drawing.Color.Black;
            this.clock4.HourHandStartColor = System.Drawing.Color.Black;
            this.clock4.HourIndicatorLookupDictionary = null;
            this.clock4.HourNeedleWidth = 10;
            this.clock4.InnerRingEndColor = System.Drawing.Color.Black;
            this.clock4.InnerRingShapeBounds = new System.Drawing.Rectangle(-15, -15, 30, 30);
            this.clock4.InnerRingStartColor = System.Drawing.Color.Black;
            this.clock4.Location = new System.Drawing.Point(757, 17);
            this.clock4.MaxBorderThickness = 32;
            this.clock4.MinimumSize = new System.Drawing.Size(128, 128);
            this.clock4.MinuteHandEndColor = System.Drawing.Color.Black;
            this.clock4.MinuteHandStartColor = System.Drawing.Color.Black;
            this.clock4.MinuteIndicatorVisual = ".";
            this.clock4.MinuteIndicatorVisualColor = System.Drawing.Color.White;
            this.clock4.MinuteIndicatorVisualFont = null;
            this.clock4.MinuteNeedleWidth = 3;
            this.clock4.Name = "clock4";
            this.clock4.NumeralsColor = System.Drawing.Color.White;
            this.clock4.NumeralsFont = null;
            this.clock4.RefreshInterval = 1000;
            this.clock4.SecondHandEndColor = System.Drawing.Color.DarkRed;
            this.clock4.SecondHandStartColor = System.Drawing.Color.DarkRed;
            this.clock4.SecondNeedleWidth = 2;
            this.clock4.ShouldDrawBorder = true;
            this.clock4.ShouldDrawDropShadowForTimeHandles = false;
            this.clock4.ShouldDrawGlassEffect = false;
            this.clock4.ShouldDrawGlassEffectOnBorder = false;
            this.clock4.ShouldDrawInnerRing = true;
            this.clock4.ShouldDrawMinuteIndicatorVisual = false;
            this.clock4.ShouldDrawNumerals = false;
            this.clock4.ShouldDropShadowBeEnabled = true;
            this.clock4.Size = new System.Drawing.Size(295, 282);
            this.clock4.StaticTime = null;
            this.clock4.TabIndex = 3;
            this.clock4.Text = "clock4";
            this.clock4.TimeRepresentationMode = Binarymission.WinForms.Controls.TimeControls.Core.Data.TimeRepresentationMode.Number;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1087, 798);
            this.Controls.Add(this.clock4);
            this.Controls.Add(this.clock3);
            this.Controls.Add(this.clock2);
            this.Controls.Add(this.clock1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Clocks configured with various properties";
            this.ResumeLayout(false);

        }

        #endregion

        private Binarymission.WinForms.Controls.TimeControls.Clock clock1;
        private Binarymission.WinForms.Controls.TimeControls.Clock clock2;
        private Binarymission.WinForms.Controls.TimeControls.Clock clock3;
        private Binarymission.WinForms.Controls.TimeControls.Clock clock4;
    }
}

