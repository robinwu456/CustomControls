﻿Imports Binarymission.Winforms.Controls
Imports Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums
Imports Binarymission.Winforms.Controls.ContainerControls.Windows
Imports Binarymission.Winforms.Controls.ContainerControls.Windows.Enums

Public Class CoreFeaturesDemoForm
    Inherits ModernChromeWindow
    Private Sub rounderCornerAngleSpinner_ValueChanged(sender As Object, e As EventArgs) Handles rounderCornerAngleSpinner.ValueChanged
        binarymissionAdvancedGroupBoxInstance.RoundedCornersAngle = rounderCornerAngleSpinner.Value
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        WindowChromeTheme = WindowChromeTheme.OfficeBlack
        BackColor = Color.White
        rounderCornerAngleSpinner.Value = binarymissionAdvancedGroupBoxInstance.RoundedCornersAngle
        Label1.Enabled = chkShouldDrawWithRounderCorners.Checked
        rounderCornerAngleSpinner.Enabled = chkShouldDrawWithRounderCorners.Checked
        Panel1.Enabled = chkShouldDrawWithRounderCorners.Checked
        spinnerHeaderAlignCustomFactor.Enabled = optDrawRoundedCornersForBottomRight.Checked
        spinnerHeaderAlignCustomFactor.Maximum = 1000
        binarymissionAdvancedGroupBoxInstance.Padding = New Padding(spinnerHeaderAlignCustomFactor.Value, 0, 0, 0)
    End Sub

    Private Sub optDrawRoundedCornersForTopLeft_CheckedChanged(sender As Object, e As EventArgs) Handles optDrawRoundedCornersForTopLeft.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.RoundedCornerTargets = AdvancedGroupBox.CornerTargets.TopLeft
    End Sub

    Private Sub optDrawRoundedCornersForTopRight_CheckedChanged(sender As Object, e As EventArgs) Handles optDrawRoundedCornersForTopRight.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.RoundedCornerTargets = AdvancedGroupBox.CornerTargets.TopRight
    End Sub

    Private Sub optDrawRoundedCornersForBottomLeft_CheckedChanged(sender As Object, e As EventArgs) Handles optDrawRoundedCornersForBottomLeft.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.RoundedCornerTargets = AdvancedGroupBox.CornerTargets.BottomLeft
    End Sub

    Private Sub optDrawRoundedCornersForBottomRight_CheckedChanged(sender As Object, e As EventArgs) Handles optDrawRoundedCornersForBottomRight.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.RoundedCornerTargets = AdvancedGroupBox.CornerTargets.BottomRight
    End Sub

    Private Sub optDrawRoundedCornersForTopLeftTopRight_CheckedChanged(sender As Object, e As EventArgs) Handles optDrawRoundedCornersForTopLeftTopRight.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.RoundedCornerTargets = AdvancedGroupBox.CornerTargets.TopLeft Or AdvancedGroupBox.CornerTargets.TopRight
    End Sub

    Private Sub optDrawRoundedCornersForTopLeftBottomRight_CheckedChanged(sender As Object, e As EventArgs) Handles optDrawRoundedCornersForTopLeftBottomRight.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.RoundedCornerTargets = AdvancedGroupBox.CornerTargets.TopLeft Or AdvancedGroupBox.CornerTargets.BottomRight
    End Sub

    Private Sub optDrawRoundedCornersForTopRightBottomLeft_CheckedChanged(sender As Object, e As EventArgs) Handles optDrawRoundedCornersForTopRightBottomLeft.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.RoundedCornerTargets = AdvancedGroupBox.CornerTargets.TopRight Or AdvancedGroupBox.CornerTargets.BottomLeft
    End Sub

    Private Sub optDrawRoundedCornersForTopRightBottomRight_CheckedChanged(sender As Object, e As EventArgs) Handles optDrawRoundedCornersForTopRightBottomRight.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.RoundedCornerTargets = AdvancedGroupBox.CornerTargets.TopRight Or AdvancedGroupBox.CornerTargets.BottomRight
    End Sub

    Private Sub chkShouldDrawWithRounderCorners_CheckedChanged_1(sender As Object, e As EventArgs) Handles chkShouldDrawWithRounderCorners.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.ShouldDrawRoundedCorners = chkShouldDrawWithRounderCorners.Checked
        Panel1.Enabled = chkShouldDrawWithRounderCorners.Checked
        Label1.Enabled = chkShouldDrawWithRounderCorners.Checked
        rounderCornerAngleSpinner.Enabled = chkShouldDrawWithRounderCorners.Checked
    End Sub

    Private Sub optDrawRoundCornersForAll_CheckedChanged(sender As Object, e As EventArgs) Handles optDrawRoundCornersForAll.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.RoundedCornerTargets = AdvancedGroupBox.CornerTargets.All
    End Sub

    Private Sub optHeaderAlignTopLeft_CheckedChanged(sender As Object, e As EventArgs) Handles optHeaderAlignTopLeft.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.HeaderAlignment = HeaderAlignment.TopLeft
    End Sub

    Private Sub optHeaderAlignTopCenter_CheckedChanged(sender As Object, e As EventArgs) Handles optHeaderAlignTopCenter.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.HeaderAlignment = HeaderAlignment.TopCenter
    End Sub

    Private Sub optHeaderAlignTopRight_CheckedChanged(sender As Object, e As EventArgs) Handles optHeaderAlignTopRight.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.HeaderAlignment = HeaderAlignment.TopRight
    End Sub

    Private Sub optDrawRoundedCornersForTopLeftBottomLeft_CheckedChanged(sender As Object, e As EventArgs) Handles optDrawRoundedCornersForTopLeftBottomLeft.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.RoundedCornerTargets = AdvancedGroupBox.CornerTargets.TopLeft Or AdvancedGroupBox.CornerTargets.BottomLeft
    End Sub

    Private Sub optDrawRoundedCornersForBottomLeftBottomRight_CheckedChanged(sender As Object, e As EventArgs) Handles optDrawRoundedCornersForBottomLeftBottomRight.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.RoundedCornerTargets = AdvancedGroupBox.CornerTargets.BottomLeft Or AdvancedGroupBox.CornerTargets.BottomRight
    End Sub

    Private Sub optHeaderAlignCustom_CheckedChanged(sender As Object, e As EventArgs) Handles optHeaderAlignCustom.CheckedChanged
        binarymissionAdvancedGroupBoxInstance.HeaderAlignment = HeaderAlignment.Custom
        spinnerHeaderAlignCustomFactor.Enabled = optHeaderAlignCustom.Checked
    End Sub

    Private Sub spinnerHeaderAlignCustomFactor_ValueChanged(sender As Object, e As EventArgs) Handles spinnerHeaderAlignCustomFactor.ValueChanged
        binarymissionAdvancedGroupBoxInstance.Padding = New Padding(spinnerHeaderAlignCustomFactor.Value, 0, 0, 0)
    End Sub
End Class
