﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CoreFeaturesDemoForm
    Inherits Binarymission.Winforms.Controls.ContainerControls.Windows.ModernChromeWindow

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CoreFeaturesDemoForm))
        Me.rounderCornerAngleSpinner = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.binarymissionAdvancedGroupBoxInstance = New Binarymission.Winforms.Controls.AdvancedGroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.chkShouldDrawWithRounderCorners = New System.Windows.Forms.CheckBox()
        Me.optDrawRoundCornersForAll = New System.Windows.Forms.RadioButton()
        Me.optDrawRoundedCornersForTopLeft = New System.Windows.Forms.RadioButton()
        Me.optDrawRoundedCornersForTopRight = New System.Windows.Forms.RadioButton()
        Me.optDrawRoundedCornersForBottomLeft = New System.Windows.Forms.RadioButton()
        Me.optDrawRoundedCornersForBottomRight = New System.Windows.Forms.RadioButton()
        Me.optDrawRoundedCornersForTopRightBottomRight = New System.Windows.Forms.RadioButton()
        Me.optDrawRoundedCornersForTopRightBottomLeft = New System.Windows.Forms.RadioButton()
        Me.optDrawRoundedCornersForTopLeftBottomRight = New System.Windows.Forms.RadioButton()
        Me.optDrawRoundedCornersForTopLeftTopRight = New System.Windows.Forms.RadioButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.optDrawRoundedCornersForTopLeftBottomLeft = New System.Windows.Forms.RadioButton()
        Me.optDrawRoundedCornersForBottomLeftBottomRight = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.optHeaderAlignTopLeft = New System.Windows.Forms.RadioButton()
        Me.optHeaderAlignTopRight = New System.Windows.Forms.RadioButton()
        Me.optHeaderAlignTopCenter = New System.Windows.Forms.RadioButton()
        Me.optHeaderAlignCustom = New System.Windows.Forms.RadioButton()
        Me.spinnerHeaderAlignCustomFactor = New System.Windows.Forms.NumericUpDown()
        CType(Me.rounderCornerAngleSpinner, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.spinnerHeaderAlignCustomFactor, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'rounderCornerAngleSpinner
        '
        Me.rounderCornerAngleSpinner.Location = New System.Drawing.Point(440, 54)
        Me.rounderCornerAngleSpinner.Maximum = New Decimal(New Integer() {360, 0, 0, 0})
        Me.rounderCornerAngleSpinner.Name = "rounderCornerAngleSpinner"
        Me.rounderCornerAngleSpinner.Size = New System.Drawing.Size(50, 20)
        Me.rounderCornerAngleSpinner.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(318, 55)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(116, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Rounded corner angle:"
        '
        'binarymissionAdvancedGroupBoxInstance
        '
        Me.binarymissionAdvancedGroupBoxInstance.BackgroundBrushColor1 = System.Drawing.Color.White
        Me.binarymissionAdvancedGroupBoxInstance.BackgroundBrushColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.binarymissionAdvancedGroupBoxInstance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.binarymissionAdvancedGroupBoxInstance.BorderThickness = 1.0!
        Me.binarymissionAdvancedGroupBoxInstance.ControlBorderStyle = Binarymission.WinForms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal
        Me.binarymissionAdvancedGroupBoxInstance.DottedBorderDepth = 4
        Me.binarymissionAdvancedGroupBoxInstance.DottedBorderGap = 2
        Me.binarymissionAdvancedGroupBoxInstance.HeaderAlignment = Binarymission.WinForms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.Custom
        Me.binarymissionAdvancedGroupBoxInstance.HeaderBackgroundColor1 = System.Drawing.Color.White
        Me.binarymissionAdvancedGroupBoxInstance.HeaderBackgroundColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.binarymissionAdvancedGroupBoxInstance.HeaderBackgroundLeftMargin = 6
        Me.binarymissionAdvancedGroupBoxInstance.HeaderBackgroundLinearGradientBrushGradientAngle = 90.0!
        Me.binarymissionAdvancedGroupBoxInstance.HeaderBackgroundRightMargin = 6
        Me.binarymissionAdvancedGroupBoxInstance.HeaderBorderColor = System.Drawing.Color.Black
        Me.binarymissionAdvancedGroupBoxInstance.HeaderBorderThickness = 1
        Me.binarymissionAdvancedGroupBoxInstance.HeaderExtraHeightFactor = 8
        Me.binarymissionAdvancedGroupBoxInstance.HeaderFont = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.binarymissionAdvancedGroupBoxInstance.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.binarymissionAdvancedGroupBoxInstance.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty
        Me.binarymissionAdvancedGroupBoxInstance.IsBackgroundDrawingUsingLinerGradientBrush = True
        Me.binarymissionAdvancedGroupBoxInstance.IsHeaderBackgroundDrawingEnabled = True
        Me.binarymissionAdvancedGroupBoxInstance.IsHeaderBackgroundGradient = True
        Me.binarymissionAdvancedGroupBoxInstance.IsHeaderBorderDrawingEnabled = True
        Me.binarymissionAdvancedGroupBoxInstance.LinearGradientBrushGradientAngle = 90.0!
        Me.binarymissionAdvancedGroupBoxInstance.Location = New System.Drawing.Point(12, 378)
        Me.binarymissionAdvancedGroupBoxInstance.Name = "binarymissionAdvancedGroupBoxInstance"
        Me.binarymissionAdvancedGroupBoxInstance.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.binarymissionAdvancedGroupBoxInstance.RoundedCornersAngle = 60.0!
        Me.binarymissionAdvancedGroupBoxInstance.RoundedCornerTargets = Binarymission.WinForms.Controls.AdvancedGroupBox.CornerTargets.TopRight
        Me.binarymissionAdvancedGroupBoxInstance.ShouldDrawRoundedCorners = False
        Me.binarymissionAdvancedGroupBoxInstance.ShouldUpdateChildrenUponParentFormMoveSize = False
        Me.binarymissionAdvancedGroupBoxInstance.Size = New System.Drawing.Size(479, 409)
        Me.binarymissionAdvancedGroupBoxInstance.TabIndex = 4
        Me.binarymissionAdvancedGroupBoxInstance.TabStop = False
        Me.binarymissionAdvancedGroupBoxInstance.Text = "Options"
        Me.binarymissionAdvancedGroupBoxInstance.TextLeftMargin = 3
        Me.binarymissionAdvancedGroupBoxInstance.TextRightMargin = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(130, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Draw rounded corners for:"
        '
        'chkShouldDrawWithRounderCorners
        '
        Me.chkShouldDrawWithRounderCorners.AutoSize = True
        Me.chkShouldDrawWithRounderCorners.Location = New System.Drawing.Point(15, 54)
        Me.chkShouldDrawWithRounderCorners.Name = "chkShouldDrawWithRounderCorners"
        Me.chkShouldDrawWithRounderCorners.Size = New System.Drawing.Size(198, 17)
        Me.chkShouldDrawWithRounderCorners.TabIndex = 14
        Me.chkShouldDrawWithRounderCorners.Text = "Should draw with Rounded corners?"
        Me.chkShouldDrawWithRounderCorners.UseVisualStyleBackColor = True
        '
        'optDrawRoundCornersForAll
        '
        Me.optDrawRoundCornersForAll.AutoSize = True
        Me.optDrawRoundCornersForAll.Checked = True
        Me.optDrawRoundCornersForAll.Location = New System.Drawing.Point(22, 33)
        Me.optDrawRoundCornersForAll.Name = "optDrawRoundCornersForAll"
        Me.optDrawRoundCornersForAll.Size = New System.Drawing.Size(74, 17)
        Me.optDrawRoundCornersForAll.TabIndex = 15
        Me.optDrawRoundCornersForAll.TabStop = True
        Me.optDrawRoundCornersForAll.Text = "All corners"
        Me.optDrawRoundCornersForAll.UseVisualStyleBackColor = True
        '
        'optDrawRoundedCornersForTopLeft
        '
        Me.optDrawRoundedCornersForTopLeft.AutoSize = True
        Me.optDrawRoundedCornersForTopLeft.Location = New System.Drawing.Point(22, 56)
        Me.optDrawRoundedCornersForTopLeft.Name = "optDrawRoundedCornersForTopLeft"
        Me.optDrawRoundedCornersForTopLeft.Size = New System.Drawing.Size(84, 17)
        Me.optDrawRoundedCornersForTopLeft.TabIndex = 5
        Me.optDrawRoundedCornersForTopLeft.Text = "TopLeft only"
        Me.optDrawRoundedCornersForTopLeft.UseVisualStyleBackColor = True
        '
        'optDrawRoundedCornersForTopRight
        '
        Me.optDrawRoundedCornersForTopRight.AutoSize = True
        Me.optDrawRoundedCornersForTopRight.Location = New System.Drawing.Point(288, 56)
        Me.optDrawRoundedCornersForTopRight.Name = "optDrawRoundedCornersForTopRight"
        Me.optDrawRoundedCornersForTopRight.Size = New System.Drawing.Size(91, 17)
        Me.optDrawRoundedCornersForTopRight.TabIndex = 7
        Me.optDrawRoundedCornersForTopRight.Text = "TopRight only"
        Me.optDrawRoundedCornersForTopRight.UseVisualStyleBackColor = True
        '
        'optDrawRoundedCornersForBottomLeft
        '
        Me.optDrawRoundedCornersForBottomLeft.AutoSize = True
        Me.optDrawRoundedCornersForBottomLeft.Location = New System.Drawing.Point(21, 79)
        Me.optDrawRoundedCornersForBottomLeft.Name = "optDrawRoundedCornersForBottomLeft"
        Me.optDrawRoundedCornersForBottomLeft.Size = New System.Drawing.Size(98, 17)
        Me.optDrawRoundedCornersForBottomLeft.TabIndex = 8
        Me.optDrawRoundedCornersForBottomLeft.Text = "BottomLeft only"
        Me.optDrawRoundedCornersForBottomLeft.UseVisualStyleBackColor = True
        '
        'optDrawRoundedCornersForBottomRight
        '
        Me.optDrawRoundedCornersForBottomRight.AutoSize = True
        Me.optDrawRoundedCornersForBottomRight.Location = New System.Drawing.Point(288, 79)
        Me.optDrawRoundedCornersForBottomRight.Name = "optDrawRoundedCornersForBottomRight"
        Me.optDrawRoundedCornersForBottomRight.Size = New System.Drawing.Size(105, 17)
        Me.optDrawRoundedCornersForBottomRight.TabIndex = 9
        Me.optDrawRoundedCornersForBottomRight.Text = "BottomRight only"
        Me.optDrawRoundedCornersForBottomRight.UseVisualStyleBackColor = True
        '
        'optDrawRoundedCornersForTopRightBottomRight
        '
        Me.optDrawRoundedCornersForTopRightBottomRight.AutoSize = True
        Me.optDrawRoundedCornersForTopRightBottomRight.Location = New System.Drawing.Point(288, 125)
        Me.optDrawRoundedCornersForTopRightBottomRight.Name = "optDrawRoundedCornersForTopRightBottomRight"
        Me.optDrawRoundedCornersForTopRightBottomRight.Size = New System.Drawing.Size(173, 17)
        Me.optDrawRoundedCornersForTopRightBottomRight.TabIndex = 13
        Me.optDrawRoundedCornersForTopRightBottomRight.Text = "TopRight and BottomRight only"
        Me.optDrawRoundedCornersForTopRightBottomRight.UseVisualStyleBackColor = True
        '
        'optDrawRoundedCornersForTopRightBottomLeft
        '
        Me.optDrawRoundedCornersForTopRightBottomLeft.AutoSize = True
        Me.optDrawRoundedCornersForTopRightBottomLeft.Location = New System.Drawing.Point(21, 125)
        Me.optDrawRoundedCornersForTopRightBottomLeft.Name = "optDrawRoundedCornersForTopRightBottomLeft"
        Me.optDrawRoundedCornersForTopRightBottomLeft.Size = New System.Drawing.Size(166, 17)
        Me.optDrawRoundedCornersForTopRightBottomLeft.TabIndex = 12
        Me.optDrawRoundedCornersForTopRightBottomLeft.Text = "TopRight and BottomLeft only"
        Me.optDrawRoundedCornersForTopRightBottomLeft.UseVisualStyleBackColor = True
        '
        'optDrawRoundedCornersForTopLeftBottomRight
        '
        Me.optDrawRoundedCornersForTopLeftBottomRight.AutoSize = True
        Me.optDrawRoundedCornersForTopLeftBottomRight.Location = New System.Drawing.Point(288, 102)
        Me.optDrawRoundedCornersForTopLeftBottomRight.Name = "optDrawRoundedCornersForTopLeftBottomRight"
        Me.optDrawRoundedCornersForTopLeftBottomRight.Size = New System.Drawing.Size(166, 17)
        Me.optDrawRoundedCornersForTopLeftBottomRight.TabIndex = 11
        Me.optDrawRoundedCornersForTopLeftBottomRight.Text = "TopLeft and BottomRight only"
        Me.optDrawRoundedCornersForTopLeftBottomRight.UseVisualStyleBackColor = True
        '
        'optDrawRoundedCornersForTopLeftTopRight
        '
        Me.optDrawRoundedCornersForTopLeftTopRight.AutoSize = True
        Me.optDrawRoundedCornersForTopLeftTopRight.Location = New System.Drawing.Point(22, 102)
        Me.optDrawRoundedCornersForTopLeftTopRight.Name = "optDrawRoundedCornersForTopLeftTopRight"
        Me.optDrawRoundedCornersForTopLeftTopRight.Size = New System.Drawing.Size(152, 17)
        Me.optDrawRoundedCornersForTopLeftTopRight.TabIndex = 10
        Me.optDrawRoundedCornersForTopLeftTopRight.Text = "TopLeft and TopRight only"
        Me.optDrawRoundedCornersForTopLeftTopRight.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.optDrawRoundedCornersForTopLeftBottomLeft)
        Me.Panel1.Controls.Add(Me.optDrawRoundedCornersForBottomLeftBottomRight)
        Me.Panel1.Controls.Add(Me.optDrawRoundedCornersForTopLeftTopRight)
        Me.Panel1.Controls.Add(Me.optDrawRoundCornersForAll)
        Me.Panel1.Controls.Add(Me.optDrawRoundedCornersForTopLeftBottomRight)
        Me.Panel1.Controls.Add(Me.optDrawRoundedCornersForTopRightBottomLeft)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.optDrawRoundedCornersForTopRightBottomRight)
        Me.Panel1.Controls.Add(Me.optDrawRoundedCornersForBottomRight)
        Me.Panel1.Controls.Add(Me.optDrawRoundedCornersForBottomLeft)
        Me.Panel1.Controls.Add(Me.optDrawRoundedCornersForTopRight)
        Me.Panel1.Controls.Add(Me.optDrawRoundedCornersForTopLeft)
        Me.Panel1.Location = New System.Drawing.Point(14, 82)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(479, 181)
        Me.Panel1.TabIndex = 16
        '
        'optDrawRoundedCornersForTopLeftBottomLeft
        '
        Me.optDrawRoundedCornersForTopLeftBottomLeft.AutoSize = True
        Me.optDrawRoundedCornersForTopLeftBottomLeft.Location = New System.Drawing.Point(22, 150)
        Me.optDrawRoundedCornersForTopLeftBottomLeft.Name = "optDrawRoundedCornersForTopLeftBottomLeft"
        Me.optDrawRoundedCornersForTopLeftBottomLeft.Size = New System.Drawing.Size(159, 17)
        Me.optDrawRoundedCornersForTopLeftBottomLeft.TabIndex = 16
        Me.optDrawRoundedCornersForTopLeftBottomLeft.Text = "TopLeft and BottomLeft only"
        Me.optDrawRoundedCornersForTopLeftBottomLeft.UseVisualStyleBackColor = True
        '
        'optDrawRoundedCornersForBottomLeftBottomRight
        '
        Me.optDrawRoundedCornersForBottomLeftBottomRight.AutoSize = True
        Me.optDrawRoundedCornersForBottomLeftBottomRight.Location = New System.Drawing.Point(289, 150)
        Me.optDrawRoundedCornersForBottomLeftBottomRight.Name = "optDrawRoundedCornersForBottomLeftBottomRight"
        Me.optDrawRoundedCornersForBottomLeftBottomRight.Size = New System.Drawing.Size(180, 17)
        Me.optDrawRoundedCornersForBottomLeftBottomRight.TabIndex = 17
        Me.optDrawRoundedCornersForBottomLeftBottomRight.Text = "BottomLeft and BottomRight only"
        Me.optDrawRoundedCornersForBottomLeftBottomRight.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 21)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(309, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Advanced GroupBox Header and Corner drawing customization:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 288)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(93, 13)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "Header alignment:"
        '
        'optHeaderAlignTopLeft
        '
        Me.optHeaderAlignTopLeft.AutoSize = True
        Me.optHeaderAlignTopLeft.Checked = True
        Me.optHeaderAlignTopLeft.Location = New System.Drawing.Point(176, 288)
        Me.optHeaderAlignTopLeft.Name = "optHeaderAlignTopLeft"
        Me.optHeaderAlignTopLeft.Size = New System.Drawing.Size(62, 17)
        Me.optHeaderAlignTopLeft.TabIndex = 21
        Me.optHeaderAlignTopLeft.TabStop = True
        Me.optHeaderAlignTopLeft.Text = "TopLeft"
        Me.optHeaderAlignTopLeft.UseVisualStyleBackColor = True
        '
        'optHeaderAlignTopRight
        '
        Me.optHeaderAlignTopRight.AutoSize = True
        Me.optHeaderAlignTopRight.Location = New System.Drawing.Point(424, 288)
        Me.optHeaderAlignTopRight.Name = "optHeaderAlignTopRight"
        Me.optHeaderAlignTopRight.Size = New System.Drawing.Size(69, 17)
        Me.optHeaderAlignTopRight.TabIndex = 20
        Me.optHeaderAlignTopRight.Text = "TopRight"
        Me.optHeaderAlignTopRight.UseVisualStyleBackColor = True
        '
        'optHeaderAlignTopCenter
        '
        Me.optHeaderAlignTopCenter.AutoSize = True
        Me.optHeaderAlignTopCenter.Location = New System.Drawing.Point(302, 288)
        Me.optHeaderAlignTopCenter.Name = "optHeaderAlignTopCenter"
        Me.optHeaderAlignTopCenter.Size = New System.Drawing.Size(75, 17)
        Me.optHeaderAlignTopCenter.TabIndex = 19
        Me.optHeaderAlignTopCenter.Text = "TopCenter"
        Me.optHeaderAlignTopCenter.UseVisualStyleBackColor = True
        '
        'optHeaderAlignCustom
        '
        Me.optHeaderAlignCustom.AutoSize = True
        Me.optHeaderAlignCustom.Location = New System.Drawing.Point(177, 317)
        Me.optHeaderAlignCustom.Name = "optHeaderAlignCustom"
        Me.optHeaderAlignCustom.Size = New System.Drawing.Size(60, 17)
        Me.optHeaderAlignCustom.TabIndex = 22
        Me.optHeaderAlignCustom.TabStop = True
        Me.optHeaderAlignCustom.Text = "Custom"
        Me.optHeaderAlignCustom.UseVisualStyleBackColor = True
        '
        'spinnerHeaderAlignCustomFactor
        '
        Me.spinnerHeaderAlignCustomFactor.Location = New System.Drawing.Point(252, 316)
        Me.spinnerHeaderAlignCustomFactor.Name = "spinnerHeaderAlignCustomFactor"
        Me.spinnerHeaderAlignCustomFactor.Size = New System.Drawing.Size(71, 20)
        Me.spinnerHeaderAlignCustomFactor.TabIndex = 23
        '
        'CoreFeaturesDemoForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray
        Me.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray
        Me.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray
        Me.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray
        Me.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray
        Me.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray
        Me.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray
        Me.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray
        Me.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray
        Me.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray
        Me.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray
        Me.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray
        Me.ClientSize = New System.Drawing.Size(515, 843)
        Me.Controls.Add(Me.spinnerHeaderAlignCustomFactor)
        Me.Controls.Add(Me.optHeaderAlignCustom)
        Me.Controls.Add(Me.optHeaderAlignTopLeft)
        Me.Controls.Add(Me.optHeaderAlignTopRight)
        Me.Controls.Add(Me.optHeaderAlignTopCenter)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.chkShouldDrawWithRounderCorners)
        Me.Controls.Add(Me.binarymissionAdvancedGroupBoxInstance)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.rounderCornerAngleSpinner)
        Me.DefaultNormalWindowSize = New System.Drawing.Size(300, 300)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "CoreFeaturesDemoForm"
        Me.TitlebarText = "Advanced GroupBox Header & Corner customization"
        Me.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray
        Me.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray
        CType(Me.rounderCornerAngleSpinner, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.spinnerHeaderAlignCustomFactor, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents rounderCornerAngleSpinner As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents binarymissionAdvancedGroupBoxInstance As Binarymission.Winforms.Controls.AdvancedGroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents chkShouldDrawWithRounderCorners As System.Windows.Forms.CheckBox
    Friend WithEvents optDrawRoundCornersForAll As System.Windows.Forms.RadioButton
    Friend WithEvents optDrawRoundedCornersForTopLeft As System.Windows.Forms.RadioButton
    Friend WithEvents optDrawRoundedCornersForTopRight As System.Windows.Forms.RadioButton
    Friend WithEvents optDrawRoundedCornersForBottomLeft As System.Windows.Forms.RadioButton
    Friend WithEvents optDrawRoundedCornersForBottomRight As System.Windows.Forms.RadioButton
    Friend WithEvents optDrawRoundedCornersForTopRightBottomRight As System.Windows.Forms.RadioButton
    Friend WithEvents optDrawRoundedCornersForTopRightBottomLeft As System.Windows.Forms.RadioButton
    Friend WithEvents optDrawRoundedCornersForTopLeftBottomRight As System.Windows.Forms.RadioButton
    Friend WithEvents optDrawRoundedCornersForTopLeftTopRight As System.Windows.Forms.RadioButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents optHeaderAlignTopLeft As System.Windows.Forms.RadioButton
    Friend WithEvents optHeaderAlignTopRight As System.Windows.Forms.RadioButton
    Friend WithEvents optHeaderAlignTopCenter As System.Windows.Forms.RadioButton
    Friend WithEvents optDrawRoundedCornersForTopLeftBottomLeft As System.Windows.Forms.RadioButton
    Friend WithEvents optDrawRoundedCornersForBottomLeftBottomRight As System.Windows.Forms.RadioButton
    Friend WithEvents optHeaderAlignCustom As System.Windows.Forms.RadioButton
    Friend WithEvents spinnerHeaderAlignCustomFactor As System.Windows.Forms.NumericUpDown

End Class
