﻿namespace AdvancedGroupBoxDemo
{
    partial class AdvancedGroupBoxDemoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdvancedGroupBoxDemoForm));
            this.advancedGroupBox9 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.advancedGroupBox8 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.advancedGroupBox7 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.advancedGroupBox2 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.advancedGroupBox5 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.advancedGroupBox6 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.advancedGroupBox3 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.advancedGroupBox4 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.advancedGroupBox1 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // advancedGroupBox9
            // 
            this.advancedGroupBox9.BackgroundBrushColor1 = System.Drawing.SystemColors.Control;
            this.advancedGroupBox9.BackgroundBrushColor2 = System.Drawing.SystemColors.Control;
            this.advancedGroupBox9.BorderColor = System.Drawing.Color.DarkGray;
            this.advancedGroupBox9.BorderThickness = 4F;
            this.advancedGroupBox9.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal;
            this.advancedGroupBox9.DottedBorderDepth = 3;
            this.advancedGroupBox9.DottedBorderGap = 4;
            this.advancedGroupBox9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.advancedGroupBox9.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopLeft;
            this.advancedGroupBox9.HeaderBackgroundColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.advancedGroupBox9.HeaderBackgroundColor2 = System.Drawing.Color.DarkGray;
            this.advancedGroupBox9.HeaderBackgroundLeftMargin = 4;
            this.advancedGroupBox9.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox9.HeaderBackgroundRightMargin = 4;
            this.advancedGroupBox9.HeaderBorderColor = System.Drawing.Color.DarkGray;
            this.advancedGroupBox9.HeaderBorderThickness = 2;
            this.advancedGroupBox9.HeaderExtraHeightFactor = 8;
            this.advancedGroupBox9.HeaderFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advancedGroupBox9.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.advancedGroupBox9.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.advancedGroupBox9.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.advancedGroupBox9.IsHeaderBackgroundDrawingEnabled = false;
            this.advancedGroupBox9.IsHeaderBackgroundGradient = true;
            this.advancedGroupBox9.IsHeaderBorderDrawingEnabled = true;
            this.advancedGroupBox9.LinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox9.Location = new System.Drawing.Point(15, 399);
            this.advancedGroupBox9.Margin = new System.Windows.Forms.Padding(4);
            this.advancedGroupBox9.Name = "advancedGroupBox9";
            this.advancedGroupBox9.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.advancedGroupBox9.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.advancedGroupBox9.Size = new System.Drawing.Size(475, 144);
            this.advancedGroupBox9.TabIndex = 24;
            this.advancedGroupBox9.TabStop = false;
            this.advancedGroupBox9.Text = "Customization options";
            this.advancedGroupBox9.TextLeftMargin = 3;
            this.advancedGroupBox9.TextRightMargin = 3;
            // 
            // advancedGroupBox8
            // 
            this.advancedGroupBox8.BackgroundBrushColor1 = System.Drawing.SystemColors.Control;
            this.advancedGroupBox8.BackgroundBrushColor2 = System.Drawing.SystemColors.Control;
            this.advancedGroupBox8.BorderColor = System.Drawing.Color.DarkGray;
            this.advancedGroupBox8.BorderThickness = 2F;
            this.advancedGroupBox8.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal;
            this.advancedGroupBox8.DottedBorderDepth = 4;
            this.advancedGroupBox8.DottedBorderGap = 2;
            this.advancedGroupBox8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.advancedGroupBox8.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopLeft;
            this.advancedGroupBox8.HeaderBackgroundColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.advancedGroupBox8.HeaderBackgroundColor2 = System.Drawing.Color.DarkGray;
            this.advancedGroupBox8.HeaderBackgroundLeftMargin = 4;
            this.advancedGroupBox8.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox8.HeaderBackgroundRightMargin = 4;
            this.advancedGroupBox8.HeaderBorderColor = System.Drawing.Color.Empty;
            this.advancedGroupBox8.HeaderBorderThickness = 0;
            this.advancedGroupBox8.HeaderExtraHeightFactor = 8;
            this.advancedGroupBox8.HeaderFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advancedGroupBox8.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.advancedGroupBox8.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.advancedGroupBox8.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.advancedGroupBox8.IsHeaderBackgroundDrawingEnabled = true;
            this.advancedGroupBox8.IsHeaderBackgroundGradient = true;
            this.advancedGroupBox8.IsHeaderBorderDrawingEnabled = false;
            this.advancedGroupBox8.LinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox8.Location = new System.Drawing.Point(15, 233);
            this.advancedGroupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.advancedGroupBox8.Name = "advancedGroupBox8";
            this.advancedGroupBox8.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.advancedGroupBox8.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.advancedGroupBox8.Size = new System.Drawing.Size(475, 144);
            this.advancedGroupBox8.TabIndex = 23;
            this.advancedGroupBox8.TabStop = false;
            this.advancedGroupBox8.Text = "Customization options";
            this.advancedGroupBox8.TextLeftMargin = 3;
            this.advancedGroupBox8.TextRightMargin = 3;
            // 
            // advancedGroupBox7
            // 
            this.advancedGroupBox7.BackgroundBrushColor1 = System.Drawing.Color.White;
            this.advancedGroupBox7.BackgroundBrushColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.advancedGroupBox7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.advancedGroupBox7.BorderThickness = 3F;
            this.advancedGroupBox7.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal;
            this.advancedGroupBox7.DottedBorderDepth = 4;
            this.advancedGroupBox7.DottedBorderGap = 2;
            this.advancedGroupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.advancedGroupBox7.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopCenter;
            this.advancedGroupBox7.HeaderBackgroundColor1 = System.Drawing.Color.White;
            this.advancedGroupBox7.HeaderBackgroundColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.advancedGroupBox7.HeaderBackgroundLeftMargin = 8;
            this.advancedGroupBox7.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox7.HeaderBackgroundRightMargin = 8;
            this.advancedGroupBox7.HeaderBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.advancedGroupBox7.HeaderBorderThickness = 3;
            this.advancedGroupBox7.HeaderExtraHeightFactor = 8;
            this.advancedGroupBox7.HeaderFont = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advancedGroupBox7.HeaderForeColor = System.Drawing.Color.Maroon;
            this.advancedGroupBox7.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.advancedGroupBox7.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.advancedGroupBox7.IsHeaderBackgroundDrawingEnabled = true;
            this.advancedGroupBox7.IsHeaderBackgroundGradient = true;
            this.advancedGroupBox7.IsHeaderBorderDrawingEnabled = true;
            this.advancedGroupBox7.LinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox7.Location = new System.Drawing.Point(15, 567);
            this.advancedGroupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.advancedGroupBox7.Name = "advancedGroupBox7";
            this.advancedGroupBox7.Padding = new System.Windows.Forms.Padding(0);
            this.advancedGroupBox7.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.advancedGroupBox7.Size = new System.Drawing.Size(475, 162);
            this.advancedGroupBox7.TabIndex = 22;
            this.advancedGroupBox7.TabStop = false;
            this.advancedGroupBox7.Text = "Customization options";
            this.advancedGroupBox7.TextLeftMargin = 0;
            this.advancedGroupBox7.TextRightMargin = 0;
            this.advancedGroupBox7.UseCompatibleTextRendering = true;
            // 
            // advancedGroupBox2
            // 
            this.advancedGroupBox2.BackgroundBrushColor1 = System.Drawing.Color.White;
            this.advancedGroupBox2.BackgroundBrushColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.advancedGroupBox2.BorderColor = System.Drawing.Color.Goldenrod;
            this.advancedGroupBox2.BorderThickness = 1F;
            this.advancedGroupBox2.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal;
            this.advancedGroupBox2.DottedBorderDepth = 4;
            this.advancedGroupBox2.DottedBorderGap = 2;
            this.advancedGroupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.advancedGroupBox2.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopCenter;
            this.advancedGroupBox2.HeaderBackgroundColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.advancedGroupBox2.HeaderBackgroundColor2 = System.Drawing.Color.DarkSalmon;
            this.advancedGroupBox2.HeaderBackgroundLeftMargin = 6;
            this.advancedGroupBox2.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox2.HeaderBackgroundRightMargin = 5;
            this.advancedGroupBox2.HeaderBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.advancedGroupBox2.HeaderBorderThickness = 1;
            this.advancedGroupBox2.HeaderExtraHeightFactor = 8;
            this.advancedGroupBox2.HeaderFont = new System.Drawing.Font("Britannic Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advancedGroupBox2.HeaderForeColor = System.Drawing.Color.Maroon;
            this.advancedGroupBox2.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.advancedGroupBox2.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.advancedGroupBox2.IsHeaderBackgroundDrawingEnabled = false;
            this.advancedGroupBox2.IsHeaderBackgroundGradient = true;
            this.advancedGroupBox2.IsHeaderBorderDrawingEnabled = true;
            this.advancedGroupBox2.LinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox2.Location = new System.Drawing.Point(335, 52);
            this.advancedGroupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.advancedGroupBox2.Name = "advancedGroupBox2";
            this.advancedGroupBox2.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.advancedGroupBox2.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.advancedGroupBox2.Size = new System.Drawing.Size(393, 162);
            this.advancedGroupBox2.TabIndex = 17;
            this.advancedGroupBox2.TabStop = false;
            this.advancedGroupBox2.Text = "Customization options";
            this.advancedGroupBox2.TextLeftMargin = 2;
            this.advancedGroupBox2.TextRightMargin = 0;
            // 
            // advancedGroupBox5
            // 
            this.advancedGroupBox5.BackgroundBrushColor1 = System.Drawing.Color.White;
            this.advancedGroupBox5.BackgroundBrushColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(203)))), ((int)(((byte)(165)))));
            this.advancedGroupBox5.BorderColor = System.Drawing.Color.Olive;
            this.advancedGroupBox5.BorderThickness = 3F;
            this.advancedGroupBox5.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Dotted;
            this.advancedGroupBox5.DottedBorderDepth = 4;
            this.advancedGroupBox5.DottedBorderGap = 5;
            this.advancedGroupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.advancedGroupBox5.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopLeft;
            this.advancedGroupBox5.HeaderBackgroundColor1 = System.Drawing.Color.White;
            this.advancedGroupBox5.HeaderBackgroundColor2 = System.Drawing.Color.Olive;
            this.advancedGroupBox5.HeaderBackgroundLeftMargin = 0;
            this.advancedGroupBox5.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox5.HeaderBackgroundRightMargin = 0;
            this.advancedGroupBox5.HeaderBorderColor = System.Drawing.Color.Empty;
            this.advancedGroupBox5.HeaderBorderThickness = 0;
            this.advancedGroupBox5.HeaderExtraHeightFactor = 8;
            this.advancedGroupBox5.HeaderFont = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advancedGroupBox5.HeaderForeColor = System.Drawing.Color.Black;
            this.advancedGroupBox5.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.advancedGroupBox5.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.advancedGroupBox5.IsHeaderBackgroundDrawingEnabled = true;
            this.advancedGroupBox5.IsHeaderBackgroundGradient = true;
            this.advancedGroupBox5.IsHeaderBorderDrawingEnabled = false;
            this.advancedGroupBox5.LinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox5.Location = new System.Drawing.Point(844, 385);
            this.advancedGroupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.advancedGroupBox5.Name = "advancedGroupBox5";
            this.advancedGroupBox5.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.advancedGroupBox5.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.advancedGroupBox5.Size = new System.Drawing.Size(296, 158);
            this.advancedGroupBox5.TabIndex = 21;
            this.advancedGroupBox5.TabStop = false;
            this.advancedGroupBox5.Text = "Customization options";
            this.advancedGroupBox5.TextLeftMargin = 2;
            this.advancedGroupBox5.TextRightMargin = 2;
            // 
            // advancedGroupBox6
            // 
            this.advancedGroupBox6.BackgroundBrushColor1 = System.Drawing.Color.White;
            this.advancedGroupBox6.BackgroundBrushColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.advancedGroupBox6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.advancedGroupBox6.BorderThickness = 3F;
            this.advancedGroupBox6.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Dotted;
            this.advancedGroupBox6.DottedBorderDepth = 4;
            this.advancedGroupBox6.DottedBorderGap = 5;
            this.advancedGroupBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.advancedGroupBox6.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopLeft;
            this.advancedGroupBox6.HeaderBackgroundColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(235)))), ((int)(((byte)(209)))));
            this.advancedGroupBox6.HeaderBackgroundColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.advancedGroupBox6.HeaderBackgroundLeftMargin = 6;
            this.advancedGroupBox6.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox6.HeaderBackgroundRightMargin = 6;
            this.advancedGroupBox6.HeaderBorderColor = System.Drawing.Color.Empty;
            this.advancedGroupBox6.HeaderBorderThickness = 0;
            this.advancedGroupBox6.HeaderExtraHeightFactor = 8;
            this.advancedGroupBox6.HeaderFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advancedGroupBox6.HeaderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.advancedGroupBox6.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.advancedGroupBox6.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.advancedGroupBox6.IsHeaderBackgroundDrawingEnabled = true;
            this.advancedGroupBox6.IsHeaderBackgroundGradient = true;
            this.advancedGroupBox6.IsHeaderBorderDrawingEnabled = false;
            this.advancedGroupBox6.LinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox6.Location = new System.Drawing.Point(844, 233);
            this.advancedGroupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.advancedGroupBox6.Name = "advancedGroupBox6";
            this.advancedGroupBox6.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.advancedGroupBox6.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.advancedGroupBox6.Size = new System.Drawing.Size(296, 144);
            this.advancedGroupBox6.TabIndex = 20;
            this.advancedGroupBox6.TabStop = false;
            this.advancedGroupBox6.Text = "Customization options";
            this.advancedGroupBox6.TextLeftMargin = 2;
            this.advancedGroupBox6.TextRightMargin = 2;
            // 
            // advancedGroupBox3
            // 
            this.advancedGroupBox3.BackgroundBrushColor1 = System.Drawing.Color.White;
            this.advancedGroupBox3.BackgroundBrushColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(203)))), ((int)(((byte)(165)))));
            this.advancedGroupBox3.BorderColor = System.Drawing.Color.Olive;
            this.advancedGroupBox3.BorderThickness = 3F;
            this.advancedGroupBox3.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Dotted;
            this.advancedGroupBox3.DottedBorderDepth = 2;
            this.advancedGroupBox3.DottedBorderGap = 3;
            this.advancedGroupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.advancedGroupBox3.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopCenter;
            this.advancedGroupBox3.HeaderBackgroundColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.advancedGroupBox3.HeaderBackgroundColor2 = System.Drawing.Color.Red;
            this.advancedGroupBox3.HeaderBackgroundLeftMargin = 0;
            this.advancedGroupBox3.HeaderBackgroundLinearGradientBrushGradientAngle = 120F;
            this.advancedGroupBox3.HeaderBackgroundRightMargin = 2;
            this.advancedGroupBox3.HeaderBorderColor = System.Drawing.Color.Empty;
            this.advancedGroupBox3.HeaderBorderThickness = 0;
            this.advancedGroupBox3.HeaderExtraHeightFactor = 8;
            this.advancedGroupBox3.HeaderFont = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advancedGroupBox3.HeaderForeColor = System.Drawing.Color.Black;
            this.advancedGroupBox3.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.advancedGroupBox3.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.advancedGroupBox3.IsHeaderBackgroundDrawingEnabled = false;
            this.advancedGroupBox3.IsHeaderBackgroundGradient = true;
            this.advancedGroupBox3.IsHeaderBorderDrawingEnabled = false;
            this.advancedGroupBox3.LinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox3.Location = new System.Drawing.Point(756, 52);
            this.advancedGroupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.advancedGroupBox3.Name = "advancedGroupBox3";
            this.advancedGroupBox3.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.advancedGroupBox3.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.advancedGroupBox3.Size = new System.Drawing.Size(384, 162);
            this.advancedGroupBox3.TabIndex = 19;
            this.advancedGroupBox3.TabStop = false;
            this.advancedGroupBox3.Text = "Customization options";
            this.advancedGroupBox3.TextLeftMargin = 2;
            this.advancedGroupBox3.TextRightMargin = 2;
            // 
            // advancedGroupBox4
            // 
            this.advancedGroupBox4.BackgroundBrushColor1 = System.Drawing.Color.White;
            this.advancedGroupBox4.BackgroundBrushColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.advancedGroupBox4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.advancedGroupBox4.BorderThickness = 3F;
            this.advancedGroupBox4.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Dotted;
            this.advancedGroupBox4.DottedBorderDepth = 2;
            this.advancedGroupBox4.DottedBorderGap = 3;
            this.advancedGroupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.advancedGroupBox4.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopLeft;
            this.advancedGroupBox4.HeaderBackgroundColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.advancedGroupBox4.HeaderBackgroundColor2 = System.Drawing.Color.Red;
            this.advancedGroupBox4.HeaderBackgroundLeftMargin = 4;
            this.advancedGroupBox4.HeaderBackgroundLinearGradientBrushGradientAngle = 75F;
            this.advancedGroupBox4.HeaderBackgroundRightMargin = 4;
            this.advancedGroupBox4.HeaderBorderColor = System.Drawing.Color.Empty;
            this.advancedGroupBox4.HeaderBorderThickness = 0;
            this.advancedGroupBox4.HeaderExtraHeightFactor = 8;
            this.advancedGroupBox4.HeaderFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advancedGroupBox4.HeaderForeColor = System.Drawing.Color.White;
            this.advancedGroupBox4.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.advancedGroupBox4.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.advancedGroupBox4.IsHeaderBackgroundDrawingEnabled = true;
            this.advancedGroupBox4.IsHeaderBackgroundGradient = true;
            this.advancedGroupBox4.IsHeaderBorderDrawingEnabled = false;
            this.advancedGroupBox4.LinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox4.Location = new System.Drawing.Point(517, 233);
            this.advancedGroupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.advancedGroupBox4.Name = "advancedGroupBox4";
            this.advancedGroupBox4.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.advancedGroupBox4.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.advancedGroupBox4.Size = new System.Drawing.Size(296, 309);
            this.advancedGroupBox4.TabIndex = 18;
            this.advancedGroupBox4.TabStop = false;
            this.advancedGroupBox4.Text = "Customization options";
            this.advancedGroupBox4.TextLeftMargin = 2;
            this.advancedGroupBox4.TextRightMargin = 2;
            // 
            // advancedGroupBox1
            // 
            this.advancedGroupBox1.BackgroundBrushColor1 = System.Drawing.Color.White;
            this.advancedGroupBox1.BackgroundBrushColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.advancedGroupBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.advancedGroupBox1.BorderThickness = 3F;
            this.advancedGroupBox1.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal;
            this.advancedGroupBox1.DottedBorderDepth = 4;
            this.advancedGroupBox1.DottedBorderGap = 2;
            this.advancedGroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.advancedGroupBox1.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopLeft;
            this.advancedGroupBox1.HeaderBackgroundColor1 = System.Drawing.Color.White;
            this.advancedGroupBox1.HeaderBackgroundColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.advancedGroupBox1.HeaderBackgroundLeftMargin = 10;
            this.advancedGroupBox1.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox1.HeaderBackgroundRightMargin = 10;
            this.advancedGroupBox1.HeaderBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.advancedGroupBox1.HeaderBorderThickness = 3;
            this.advancedGroupBox1.HeaderExtraHeightFactor = 8;
            this.advancedGroupBox1.HeaderFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advancedGroupBox1.HeaderForeColor = System.Drawing.Color.Maroon;
            this.advancedGroupBox1.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.advancedGroupBox1.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.advancedGroupBox1.IsHeaderBackgroundDrawingEnabled = true;
            this.advancedGroupBox1.IsHeaderBackgroundGradient = true;
            this.advancedGroupBox1.IsHeaderBorderDrawingEnabled = true;
            this.advancedGroupBox1.LinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox1.Location = new System.Drawing.Point(15, 52);
            this.advancedGroupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.advancedGroupBox1.Name = "advancedGroupBox1";
            this.advancedGroupBox1.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.advancedGroupBox1.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.advancedGroupBox1.Size = new System.Drawing.Size(296, 162);
            this.advancedGroupBox1.TabIndex = 16;
            this.advancedGroupBox1.TabStop = false;
            this.advancedGroupBox1.Text = "Customization options";
            this.advancedGroupBox1.TextLeftMargin = 2;
            this.advancedGroupBox1.TextRightMargin = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(519, 15);
            this.label1.TabIndex = 25;
            this.label1.Text = "A number of AdvancedGroupBox control instances, configured with a variety of cust" +
    "om settings:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1047, 693);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 36);
            this.button1.TabIndex = 26;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 778);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.advancedGroupBox9);
            this.Controls.Add(this.advancedGroupBox8);
            this.Controls.Add(this.advancedGroupBox7);
            this.Controls.Add(this.advancedGroupBox2);
            this.Controls.Add(this.advancedGroupBox5);
            this.Controls.Add(this.advancedGroupBox6);
            this.Controls.Add(this.advancedGroupBox3);
            this.Controls.Add(this.advancedGroupBox4);
            this.Controls.Add(this.advancedGroupBox1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.TitlebarText = "Binarymission Advanced GroupBox .NET Control Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Binarymission.Winforms.Controls.AdvancedGroupBox advancedGroupBox9;
        private Binarymission.Winforms.Controls.AdvancedGroupBox advancedGroupBox8;
        private Binarymission.Winforms.Controls.AdvancedGroupBox advancedGroupBox7;
        private Binarymission.Winforms.Controls.AdvancedGroupBox advancedGroupBox2;
        private Binarymission.Winforms.Controls.AdvancedGroupBox advancedGroupBox5;
        private Binarymission.Winforms.Controls.AdvancedGroupBox advancedGroupBox6;
        private Binarymission.Winforms.Controls.AdvancedGroupBox advancedGroupBox3;
        private Binarymission.Winforms.Controls.AdvancedGroupBox advancedGroupBox4;
        private Binarymission.Winforms.Controls.AdvancedGroupBox advancedGroupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;

    }
}

