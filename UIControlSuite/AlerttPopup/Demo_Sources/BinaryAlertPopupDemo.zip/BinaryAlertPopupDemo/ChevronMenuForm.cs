using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace BinaryAlertPopupDemo
{
	/// <summary>
	/// Summary description for ChevronMenuForm.
	/// </summary>
	public class ChevronMenuForm : Form
	{
		public static Color StartColor = Color.Empty;
		public static Color EndColor = Color.Empty;
        public static Color SingleColor = Color.Empty;
		public static Color ChevronButtonColor = Color.Empty;
		public static float OrientationAngle = (float)90.0;
		public static bool DrawUsingGradientColors;
		private static Color _chevronButtonBorderColor = Color.Empty;
        
		private GroupBox _groupBox1;
		private Button _button1;
		private Button _button2;
		private RadioButton _radioButton1;
		private RadioButton _radioButton2;
		private GroupBox _groupBox2;
		private Button _button3;
		private Button _button4;
		private NumericUpDown _numericUpDown1;
		private Label _label1;
		private Button _button5;
		private Label _label2;
		private GroupBox _groupBox3;
		private Button _button6;
		private Button _button7;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private readonly Container _components = null;

		public ChevronMenuForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
			    _components?.Dispose();
			}
		    base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            _groupBox1 = new GroupBox();
            _label2 = new System.Windows.Forms.Label();
            _button5 = new System.Windows.Forms.Button();
            _groupBox2 = new GroupBox();
            _label1 = new System.Windows.Forms.Label();
            _numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            _button4 = new System.Windows.Forms.Button();
            _button3 = new System.Windows.Forms.Button();
            _radioButton2 = new System.Windows.Forms.RadioButton();
            _radioButton1 = new System.Windows.Forms.RadioButton();
            _button1 = new System.Windows.Forms.Button();
            _button2 = new System.Windows.Forms.Button();
            _groupBox3 = new GroupBox();
            _button6 = new System.Windows.Forms.Button();
            _button7 = new System.Windows.Forms.Button();
            _groupBox1.SuspendLayout();
            _groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(_numericUpDown1)).BeginInit();
            _groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            _groupBox1.Controls.Add(_button7);
            _groupBox1.Controls.Add(_label2);
            _groupBox1.Controls.Add(_button5);
            _groupBox1.Controls.Add(_groupBox2);
            _groupBox1.Controls.Add(_radioButton2);
            _groupBox1.Controls.Add(_radioButton1);
            _groupBox1.Location = new System.Drawing.Point(16, 80);
            _groupBox1.Name = "_groupBox1";
            _groupBox1.Size = new System.Drawing.Size(344, 256);
            _groupBox1.TabIndex = 0;
            _groupBox1.TabStop = false;
            _groupBox1.Text = "ChevronMenu Drop-down menu button rectangle settings";
            // 
            // label2
            // 
            _label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            _label2.Location = new System.Drawing.Point(144, 160);
            _label2.Name = "_label2";
            _label2.Size = new System.Drawing.Size(192, 48);
            _label2.TabIndex = 4;
            _label2.Text = "(This button is relevant only when using single color to draw the chevron menu bu" +
				"tton)";
            // 
            // button5
            // 
            _button5.Location = new System.Drawing.Point(16, 160);
            _button5.Name = "_button5";
            _button5.Size = new System.Drawing.Size(120, 32);
            _button5.TabIndex = 3;
            _button5.Text = "Single color...";
            _button5.Click += new System.EventHandler(SingleColorUpdateRequested);
            // 
            // groupBox2
            // 
            _groupBox2.Controls.Add(_label1);
            _groupBox2.Controls.Add(_numericUpDown1);
            _groupBox2.Controls.Add(_button4);
            _groupBox2.Controls.Add(_button3);
            _groupBox2.Location = new System.Drawing.Point(16, 48);
            _groupBox2.Name = "_groupBox2";
            _groupBox2.Size = new System.Drawing.Size(320, 104);
            _groupBox2.TabIndex = 2;
            _groupBox2.TabStop = false;
            _groupBox2.Text = "Applicable only if using gradient colors";
            // 
            // label1
            // 
            _label1.Location = new System.Drawing.Point(16, 72);
            _label1.Name = "_label1";
            _label1.Size = new System.Drawing.Size(144, 16);
            _label1.TabIndex = 3;
            _label1.Text = "Gradient orientation angle:";
            // 
            // numericUpDown1
            // 
            _numericUpDown1.Location = new System.Drawing.Point(176, 72);
            _numericUpDown1.Maximum = new System.Decimal(new int[] {
																		   360,
																		   0,
																		   0,
																		   0});
            _numericUpDown1.Name = "_numericUpDown1";
            _numericUpDown1.Size = new System.Drawing.Size(72, 20);
            _numericUpDown1.TabIndex = 2;
            _numericUpDown1.Value = new System.Decimal(new int[] {
																		 90,
																		 0,
																		 0,
																		 0});
            _numericUpDown1.ValueChanged += new System.EventHandler(OrientationAngleChanged);
            // 
            // button4
            // 
            _button4.Location = new System.Drawing.Point(176, 24);
            _button4.Name = "_button4";
            _button4.Size = new System.Drawing.Size(128, 32);
            _button4.TabIndex = 1;
            _button4.Text = "End color...";
            _button4.Click += new System.EventHandler(EndColorChanged);
            // 
            // button3
            // 
            _button3.Location = new System.Drawing.Point(16, 24);
            _button3.Name = "_button3";
            _button3.Size = new System.Drawing.Size(128, 32);
            _button3.TabIndex = 0;
            _button3.Text = "Start color...";
            _button3.Click += new System.EventHandler(StartColorChanged);
            // 
            // radioButton2
            // 
            _radioButton2.Location = new System.Drawing.Point(184, 24);
            _radioButton2.Name = "_radioButton2";
            _radioButton2.Size = new System.Drawing.Size(136, 16);
            _radioButton2.TabIndex = 1;
            _radioButton2.Text = "Use single color";
            _radioButton2.CheckedChanged += new System.EventHandler(DrawUsingGradientColorsChangeRemoved);
            // 
            // radioButton1
            // 
            _radioButton1.Checked = true;
            _radioButton1.Location = new System.Drawing.Point(16, 24);
            _radioButton1.Name = "_radioButton1";
            _radioButton1.Size = new System.Drawing.Size(136, 16);
            _radioButton1.TabIndex = 0;
            _radioButton1.TabStop = true;
            _radioButton1.Text = "Use Gradient colors";
            _radioButton1.CheckedChanged += new System.EventHandler(DrawUsingGradientColorsRequested);
            // 
            // button1
            // 
            _button1.Location = new System.Drawing.Point(192, 344);
            _button1.Name = "_button1";
            _button1.Size = new System.Drawing.Size(80, 32);
            _button1.TabIndex = 1;
            _button1.Text = "&OK";
            _button1.Click += new System.EventHandler(CloseForm);
            // 
            // button2
            // 
            _button2.Location = new System.Drawing.Point(280, 344);
            _button2.Name = "_button2";
            _button2.Size = new System.Drawing.Size(80, 32);
            _button2.TabIndex = 2;
            _button2.Text = "E&xit";
            _button2.Click += new System.EventHandler(CloseRequested);
            // 
            // groupBox3
            // 
            _groupBox3.Controls.Add(_button6);
            _groupBox3.Location = new System.Drawing.Point(16, 8);
            _groupBox3.Name = "_groupBox3";
            _groupBox3.Size = new System.Drawing.Size(344, 64);
            _groupBox3.TabIndex = 3;
            _groupBox3.TabStop = false;
            _groupBox3.Text = "Chevron menu drop-down button settings";
            // 
            // button6
            // 
            _button6.Location = new System.Drawing.Point(24, 24);
            _button6.Name = "_button6";
            _button6.Size = new System.Drawing.Size(304, 32);
            _button6.TabIndex = 1;
            _button6.Text = "Chevron menu drop-down button color...";
            _button6.Click += new System.EventHandler(ChevronButtonColorUpdateRequested);
            // 
            // button7
            // 
            _button7.Location = new System.Drawing.Point(16, 208);
            _button7.Name = "_button7";
            _button7.Size = new System.Drawing.Size(320, 32);
            _button7.TabIndex = 5;
            _button7.Text = "Chevron menu button border color...";
            _button7.Click += new System.EventHandler(ChevronButtonBorderColorChanged);
            // 
            // ChevronMenuForm
            // 
            AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            ClientSize = new System.Drawing.Size(368, 382);
            ControlBox = false;
            Controls.Add(_groupBox3);
            Controls.Add(_button2);
            Controls.Add(_button1);
            Controls.Add(_groupBox1);
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "ChevronMenuForm";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            Text = "Chevron menu button settings";
            Load += new System.EventHandler(ChevronMenuFormLoad);
            _groupBox1.ResumeLayout(false);
            _groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(_numericUpDown1)).EndInit();
            _groupBox3.ResumeLayout(false);
            ResumeLayout(false);

		}
		#endregion

		private void DrawUsingGradientColorsRequested(object sender, EventArgs e)
		{
			_groupBox2.Enabled = _radioButton1.Checked;
			_button5.Enabled = !_radioButton1.Checked;
			DrawUsingGradientColors = true;
		}

		private void DrawUsingGradientColorsChangeRemoved(object sender, EventArgs e)
		{
			_groupBox2.Enabled = !_radioButton2.Checked;
			_button5.Enabled = _radioButton2.Checked;
			DrawUsingGradientColors = false;
		}

		private void StartColorChanged(object sender, EventArgs e)
		{
		    ColorDialog clrDialog = new ColorDialog {Color = StartColor};

		    if(DialogResult.Cancel != clrDialog.ShowDialog(this))
			{
				StartColor = clrDialog.Color;
			}
		}

		private void EndColorChanged(object sender, EventArgs e)
		{
		    ColorDialog clrDialog = new ColorDialog {Color = EndColor};

		    if(DialogResult.Cancel != clrDialog.ShowDialog(this))
			{
				EndColor = clrDialog.Color;
			}
		}

		private void OrientationAngleChanged(object sender, EventArgs e)
		{
            OrientationAngle = (float)Convert.ToDouble(_numericUpDown1.Value);
		}

		private void CloseRequested(object sender, EventArgs e)
		{
			Close();
		}

		private void ChevronButtonColorUpdateRequested(object sender, EventArgs e)
		{
			ColorDialog clrDialog = new ColorDialog();
			clrDialog.Color = ChevronButtonColor;

			if(DialogResult.Cancel != clrDialog.ShowDialog(this))
			{
				ChevronButtonColor = clrDialog.Color;
			}
		}

		private void SingleColorUpdateRequested(object sender, EventArgs e)
		{
			ColorDialog clrDialog = new ColorDialog();
			clrDialog.Color = SingleColor;

			if(DialogResult.Cancel != clrDialog.ShowDialog(this))
			{
				SingleColor = clrDialog.Color;
			}
		}

		private void ChevronMenuFormLoad(object sender, EventArgs e)
		{
			_numericUpDown1.Value = Convert.ToDecimal(OrientationAngle);
			_radioButton1.Checked = DrawUsingGradientColors;
			_button5.Enabled = !_radioButton1.Checked;
		}

		private void ChevronButtonBorderColorChanged(object sender, EventArgs e)
		{
		    ColorDialog clrDialog = new ColorDialog {Color = _chevronButtonBorderColor};

		    if(DialogResult.Cancel != clrDialog.ShowDialog(this))
			{
				_chevronButtonBorderColor = clrDialog.Color;
			}
		}

		private void CloseForm(object sender, EventArgs e)
		{
			Close();
		}
	}
}
