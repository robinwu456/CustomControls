﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.PopupControls;

namespace BinaryAlertPopupDemo
{
    partial class BinaryAlertPopupDemoForm : ModernChromeWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;
        private AlertPopup _bAlertPopup;
        private GroupBox _groupBox1;
        private Label _label1;
        private Label _label2;
        private GroupBox _groupBox2;
        private Label _label3;
        private Label _label4;
        private GroupBox _groupBox3;
        private Label _label5;
        private Label _label6;
        private GroupBox _groupBox4;
        private Label _label7;
        private Label _label9;
        private GroupBox _groupBox7;
        private GroupBox _groupBox8;
        private Label _label11;
        private Label _label12;
        private Label _label13;
        private ComboBox _popupWindowStyles;
        private ComboBox _popupWindowDisappearingStyles;
        private NumericUpDown _animationWhileStarting;
        private NumericUpDown _animationWhileClosing;
        private NumericUpDown _durationToShowAlertPopup;
        private CheckBox _showAlertPopupWhenMouseIsOver;
        private CheckBox _showAlertPopupWhenMouseIsOverAndWindowIsClosing;
        private CheckBox _displayExitIcon;
        private SmartButton _customPopupTitleIcon;
        private SmartButton _customExitIcon;
        private SmartButton _alertTextSelectionRectangleColor;
        private SmartButton _titleTextFontOnNormal;
        private SmartButton _bodyTextFontOnNormal;
        private SmartButton _bodyTextFontOnHover;
        private SmartButton _titleTextFontOnHover;
        private SmartButton _titleTextColorOnHover;
        private SmartButton _titleTextColorOnNormal;
        private SmartButton _bodyTextColorOnHover;
        private SmartButton _bodyTextColorOnNormal;
        private TextBox _alertPopupTitleText;
        private TextBox _alertPopupBodyText;
        private SmartButton _about;
        private SmartButton _exit;
        private StatusBar _statusBar;
        private SmartButton _showAlertPopupNow;
        private GroupBox _groupBox5;
        private GroupBox _groupBox6;
        private SmartButton _useThisSpecifiColor;
        private GroupBox _groupBox9;
        private SmartButton _endColor;
        private SmartButton _startColor;
        private ComboBox _customColorStyles;
        private Label _label10;
        private RadioButton _useCustomColors;
        private RadioButton _useBuiltInColors;
        private ComboBox _themeColors;
        private Label _label8;
        private Label _label14;
        private TextBox _textBox1;
        private SmartButton _button1;
        private Label _label15;
        private NumericUpDown _numericUpDown1;
        private CheckBox _alertTextClickable;
        private CheckBox _alertTitleIsClickable;
        private CheckBox _exitButtonClickable;
        private CheckBox _showTextAreaRectangle;
        private CheckBox _checkBox1;
        private GroupBox _groupBox10;
        private CheckBox _checkBox2;
        private Label _label16;
        private Label _label17;
        private NumericUpDown _numericUpDown2;
        private NumericUpDown _numericUpDown3;
        private GroupBox _groupBox11;
        private CheckBox _checkBox3;
        private SmartButton _button2;
        private TextBox _textBox2;
        private SmartButton _button3;
        private CheckBox _checkBox5;
        private ContextMenuStrip _contextMenuStrip1;
        private ToolStripMenuItem _callSupportTeamToolStripMenuItem;
        private ToolStripSeparator _toolStripSeparator1;
        private ToolStripMenuItem _toolStripMenuItem1;
        private ToolStripMenuItem _toolStripMenuItem2;
        private ToolStripSeparator _toolStripSeparator2;
        private ToolStripMenuItem _toolStripMenuItem3;
        private ToolStripMenuItem _toolStripMenuItem4;
        private SmartButton _button4;
        private CheckBox _checkBox4;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        [STAThread]
        static void Main()
        {
            var form = new BinaryAlertPopupDemoForm();
            Application.EnableVisualStyles();
            Application.DoEvents();
            Application.Run(form);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BinaryAlertPopupDemoForm));
            this._groupBox1 = new System.Windows.Forms.GroupBox();
            this._alertPopupBodyText = new System.Windows.Forms.TextBox();
            this._alertPopupTitleText = new System.Windows.Forms.TextBox();
            this._label2 = new System.Windows.Forms.Label();
            this._label1 = new System.Windows.Forms.Label();
            this._groupBox2 = new System.Windows.Forms.GroupBox();
            this._button3 = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._label5 = new System.Windows.Forms.Label();
            this._bodyTextColorOnHover = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._titleTextColorOnHover = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._label6 = new System.Windows.Forms.Label();
            this._bodyTextColorOnNormal = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._titleTextColorOnNormal = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._label4 = new System.Windows.Forms.Label();
            this._bodyTextFontOnHover = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._titleTextFontOnHover = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._label3 = new System.Windows.Forms.Label();
            this._bodyTextFontOnNormal = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._titleTextFontOnNormal = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._alertTextSelectionRectangleColor = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._groupBox3 = new System.Windows.Forms.GroupBox();
            this._checkBox5 = new System.Windows.Forms.CheckBox();
            this._checkBox1 = new System.Windows.Forms.CheckBox();
            this._showTextAreaRectangle = new System.Windows.Forms.CheckBox();
            this._exitButtonClickable = new System.Windows.Forms.CheckBox();
            this._alertTitleIsClickable = new System.Windows.Forms.CheckBox();
            this._alertTextClickable = new System.Windows.Forms.CheckBox();
            this._button1 = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._textBox1 = new System.Windows.Forms.TextBox();
            this._label14 = new System.Windows.Forms.Label();
            this._groupBox7 = new System.Windows.Forms.GroupBox();
            this._customPopupTitleIcon = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._customExitIcon = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._displayExitIcon = new System.Windows.Forms.CheckBox();
            this._showAlertPopupWhenMouseIsOverAndWindowIsClosing = new System.Windows.Forms.CheckBox();
            this._showAlertPopupWhenMouseIsOver = new System.Windows.Forms.CheckBox();
            this._groupBox4 = new System.Windows.Forms.GroupBox();
            this._groupBox5 = new System.Windows.Forms.GroupBox();
            this._groupBox6 = new System.Windows.Forms.GroupBox();
            this._useThisSpecifiColor = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._groupBox9 = new System.Windows.Forms.GroupBox();
            this._numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this._label15 = new System.Windows.Forms.Label();
            this._endColor = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._startColor = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._customColorStyles = new System.Windows.Forms.ComboBox();
            this._label10 = new System.Windows.Forms.Label();
            this._useCustomColors = new System.Windows.Forms.RadioButton();
            this._useBuiltInColors = new System.Windows.Forms.RadioButton();
            this._themeColors = new System.Windows.Forms.ComboBox();
            this._label8 = new System.Windows.Forms.Label();
            this._popupWindowDisappearingStyles = new System.Windows.Forms.ComboBox();
            this._label9 = new System.Windows.Forms.Label();
            this._popupWindowStyles = new System.Windows.Forms.ComboBox();
            this._label7 = new System.Windows.Forms.Label();
            this._groupBox8 = new System.Windows.Forms.GroupBox();
            this._durationToShowAlertPopup = new System.Windows.Forms.NumericUpDown();
            this._animationWhileClosing = new System.Windows.Forms.NumericUpDown();
            this._animationWhileStarting = new System.Windows.Forms.NumericUpDown();
            this._checkBox4 = new System.Windows.Forms.CheckBox();
            this._label13 = new System.Windows.Forms.Label();
            this._label12 = new System.Windows.Forms.Label();
            this._label11 = new System.Windows.Forms.Label();
            this._about = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._exit = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._statusBar = new System.Windows.Forms.StatusBar();
            this._showAlertPopupNow = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._groupBox10 = new System.Windows.Forms.GroupBox();
            this._numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this._numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this._label17 = new System.Windows.Forms.Label();
            this._label16 = new System.Windows.Forms.Label();
            this._checkBox2 = new System.Windows.Forms.CheckBox();
            this._groupBox11 = new System.Windows.Forms.GroupBox();
            this._button2 = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._textBox2 = new System.Windows.Forms.TextBox();
            this._checkBox3 = new System.Windows.Forms.CheckBox();
            this._contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this._callSupportTeamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this._toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this._toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this._toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this._toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this._toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this._button4 = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._groupBox1.SuspendLayout();
            this._groupBox2.SuspendLayout();
            this._groupBox3.SuspendLayout();
            this._groupBox7.SuspendLayout();
            this._groupBox4.SuspendLayout();
            this._groupBox5.SuspendLayout();
            this._groupBox6.SuspendLayout();
            this._groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._numericUpDown1)).BeginInit();
            this._groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._durationToShowAlertPopup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._animationWhileClosing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._animationWhileStarting)).BeginInit();
            this._groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._numericUpDown2)).BeginInit();
            this._groupBox11.SuspendLayout();
            this._contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // _groupBox1
            // 
            this._groupBox1.Controls.Add(this._alertPopupBodyText);
            this._groupBox1.Controls.Add(this._alertPopupTitleText);
            this._groupBox1.Controls.Add(this._label2);
            this._groupBox1.Controls.Add(this._label1);
            this._groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox1.Location = new System.Drawing.Point(16, 8);
            this._groupBox1.Name = "_groupBox1";
            this._groupBox1.Size = new System.Drawing.Size(408, 88);
            this._groupBox1.TabIndex = 1;
            this._groupBox1.TabStop = false;
            this._groupBox1.Text = "Alert text properties";
            // 
            // _alertPopupBodyText
            // 
            this._alertPopupBodyText.Location = new System.Drawing.Point(112, 56);
            this._alertPopupBodyText.Name = "_alertPopupBodyText";
            this._alertPopupBodyText.Size = new System.Drawing.Size(280, 20);
            this._alertPopupBodyText.TabIndex = 3;
            this._alertPopupBodyText.Text = "A new message from your friend :-)";
            this._alertPopupBodyText.TextChanged += new System.EventHandler(this.AlertPopupBodyTextTextChanged);
            // 
            // _alertPopupTitleText
            // 
            this._alertPopupTitleText.Location = new System.Drawing.Point(112, 32);
            this._alertPopupTitleText.Name = "_alertPopupTitleText";
            this._alertPopupTitleText.Size = new System.Drawing.Size(280, 20);
            this._alertPopupTitleText.TabIndex = 2;
            this._alertPopupTitleText.Text = "Sample Title";
            this._alertPopupTitleText.TextChanged += new System.EventHandler(this.AlertPopupTitleTextTextChanged);
            // 
            // _label2
            // 
            this._label2.Location = new System.Drawing.Point(16, 56);
            this._label2.Name = "_label2";
            this._label2.Size = new System.Drawing.Size(88, 16);
            this._label2.TabIndex = 1;
            this._label2.Text = "Alert Body text:";
            // 
            // _label1
            // 
            this._label1.Location = new System.Drawing.Point(16, 32);
            this._label1.Name = "_label1";
            this._label1.Size = new System.Drawing.Size(88, 16);
            this._label1.TabIndex = 0;
            this._label1.Text = "Alert Title text:";
            // 
            // _groupBox2
            // 
            this._groupBox2.Controls.Add(this._button3);
            this._groupBox2.Controls.Add(this._label5);
            this._groupBox2.Controls.Add(this._bodyTextColorOnHover);
            this._groupBox2.Controls.Add(this._titleTextColorOnHover);
            this._groupBox2.Controls.Add(this._label6);
            this._groupBox2.Controls.Add(this._bodyTextColorOnNormal);
            this._groupBox2.Controls.Add(this._titleTextColorOnNormal);
            this._groupBox2.Controls.Add(this._label4);
            this._groupBox2.Controls.Add(this._bodyTextFontOnHover);
            this._groupBox2.Controls.Add(this._titleTextFontOnHover);
            this._groupBox2.Controls.Add(this._label3);
            this._groupBox2.Controls.Add(this._bodyTextFontOnNormal);
            this._groupBox2.Controls.Add(this._titleTextFontOnNormal);
            this._groupBox2.Controls.Add(this._alertTextSelectionRectangleColor);
            this._groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox2.Location = new System.Drawing.Point(16, 104);
            this._groupBox2.Name = "_groupBox2";
            this._groupBox2.Size = new System.Drawing.Size(408, 184);
            this._groupBox2.TabIndex = 1;
            this._groupBox2.TabStop = false;
            this._groupBox2.Text = "Alert font / color properties";
            // 
            // _button3
            // 
            this._button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._button3.BorderColor = System.Drawing.Color.Black;
            this._button3.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._button3.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._button3.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._button3.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._button3.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._button3.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._button3.ContextMenuProperties.UseGradientPainting = true;
            this._button3.DefaultTheme = true;
            this._button3.DialogResult = System.Windows.Forms.DialogResult.None;
            this._button3.DrawMenuButtonSeparator = true;
            this._button3.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._button3.DropDownMenuItems = null;
            this._button3.EndColor = System.Drawing.Color.White;
            this._button3.IsRenderingTheme = true;
            this._button3.LinearGradientRenderingAngle = 90F;
            this._button3.Location = new System.Drawing.Point(208, 152);
            this._button3.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._button3.MenuButtonSeparatorLineHeight = -1;
            this._button3.Name = "_button3";
            this._button3.PushedEndColor = System.Drawing.Color.Silver;
            this._button3.PushedStartColor = System.Drawing.Color.White;
            this._button3.Size = new System.Drawing.Size(192, 24);
            this._button3.StartColor = System.Drawing.Color.Silver;
            this._button3.TabIndex = 12;
            this._button3.Text = "Chevron drop-down menu settings...";
            this._button3.TextStringFormat = null;
            this._button3.TransparentColor = System.Drawing.Color.Empty;
            this._button3.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._button3.UseCustomTextStringFormat = false;
            this._button3.UseUserDefinedColorForArrowMark = true;
            this._button3.UseUserDefinedColorForMenuButtonSeparator = true;
            this._button3.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._button3.Click += new System.EventHandler(this.AlertChevronMenuFormDisplayed);
            // 
            // _label5
            // 
            this._label5.Location = new System.Drawing.Point(8, 128);
            this._label5.Name = "_label5";
            this._label5.Size = new System.Drawing.Size(88, 16);
            this._label5.TabIndex = 11;
            this._label5.Text = "On Hover:";
            // 
            // _bodyTextColorOnHover
            // 
            this._bodyTextColorOnHover.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._bodyTextColorOnHover.BorderColor = System.Drawing.Color.Black;
            this._bodyTextColorOnHover.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._bodyTextColorOnHover.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._bodyTextColorOnHover.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._bodyTextColorOnHover.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._bodyTextColorOnHover.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._bodyTextColorOnHover.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._bodyTextColorOnHover.ContextMenuProperties.UseGradientPainting = true;
            this._bodyTextColorOnHover.DefaultTheme = true;
            this._bodyTextColorOnHover.DialogResult = System.Windows.Forms.DialogResult.None;
            this._bodyTextColorOnHover.DrawMenuButtonSeparator = true;
            this._bodyTextColorOnHover.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._bodyTextColorOnHover.DropDownMenuItems = null;
            this._bodyTextColorOnHover.EndColor = System.Drawing.Color.White;
            this._bodyTextColorOnHover.IsRenderingTheme = true;
            this._bodyTextColorOnHover.LinearGradientRenderingAngle = 90F;
            this._bodyTextColorOnHover.Location = new System.Drawing.Point(240, 120);
            this._bodyTextColorOnHover.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._bodyTextColorOnHover.MenuButtonSeparatorLineHeight = -1;
            this._bodyTextColorOnHover.Name = "_bodyTextColorOnHover";
            this._bodyTextColorOnHover.PushedEndColor = System.Drawing.Color.Silver;
            this._bodyTextColorOnHover.PushedStartColor = System.Drawing.Color.White;
            this._bodyTextColorOnHover.Size = new System.Drawing.Size(120, 24);
            this._bodyTextColorOnHover.StartColor = System.Drawing.Color.Silver;
            this._bodyTextColorOnHover.TabIndex = 10;
            this._bodyTextColorOnHover.Text = "Body Text color...";
            this._bodyTextColorOnHover.TextStringFormat = null;
            this._bodyTextColorOnHover.TransparentColor = System.Drawing.Color.Empty;
            this._bodyTextColorOnHover.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._bodyTextColorOnHover.UseCustomTextStringFormat = false;
            this._bodyTextColorOnHover.UseUserDefinedColorForArrowMark = true;
            this._bodyTextColorOnHover.UseUserDefinedColorForMenuButtonSeparator = true;
            this._bodyTextColorOnHover.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._bodyTextColorOnHover.Click += new System.EventHandler(this.BodyTextColorOnHoverClick);
            // 
            // _titleTextColorOnHover
            // 
            this._titleTextColorOnHover.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._titleTextColorOnHover.BorderColor = System.Drawing.Color.Black;
            this._titleTextColorOnHover.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._titleTextColorOnHover.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._titleTextColorOnHover.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._titleTextColorOnHover.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._titleTextColorOnHover.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._titleTextColorOnHover.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._titleTextColorOnHover.ContextMenuProperties.UseGradientPainting = true;
            this._titleTextColorOnHover.DefaultTheme = true;
            this._titleTextColorOnHover.DialogResult = System.Windows.Forms.DialogResult.None;
            this._titleTextColorOnHover.DrawMenuButtonSeparator = true;
            this._titleTextColorOnHover.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._titleTextColorOnHover.DropDownMenuItems = null;
            this._titleTextColorOnHover.EndColor = System.Drawing.Color.White;
            this._titleTextColorOnHover.IsRenderingTheme = true;
            this._titleTextColorOnHover.LinearGradientRenderingAngle = 90F;
            this._titleTextColorOnHover.Location = new System.Drawing.Point(112, 120);
            this._titleTextColorOnHover.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._titleTextColorOnHover.MenuButtonSeparatorLineHeight = -1;
            this._titleTextColorOnHover.Name = "_titleTextColorOnHover";
            this._titleTextColorOnHover.PushedEndColor = System.Drawing.Color.Silver;
            this._titleTextColorOnHover.PushedStartColor = System.Drawing.Color.White;
            this._titleTextColorOnHover.Size = new System.Drawing.Size(120, 24);
            this._titleTextColorOnHover.StartColor = System.Drawing.Color.Silver;
            this._titleTextColorOnHover.TabIndex = 9;
            this._titleTextColorOnHover.Text = "Title Text color...";
            this._titleTextColorOnHover.TextStringFormat = null;
            this._titleTextColorOnHover.TransparentColor = System.Drawing.Color.Empty;
            this._titleTextColorOnHover.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._titleTextColorOnHover.UseCustomTextStringFormat = false;
            this._titleTextColorOnHover.UseUserDefinedColorForArrowMark = true;
            this._titleTextColorOnHover.UseUserDefinedColorForMenuButtonSeparator = true;
            this._titleTextColorOnHover.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._titleTextColorOnHover.Click += new System.EventHandler(this.titleTextColorOnHover_Click);
            // 
            // _label6
            // 
            this._label6.Location = new System.Drawing.Point(8, 96);
            this._label6.Name = "_label6";
            this._label6.Size = new System.Drawing.Size(88, 16);
            this._label6.TabIndex = 8;
            this._label6.Text = "On Normal:";
            // 
            // _bodyTextColorOnNormal
            // 
            this._bodyTextColorOnNormal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._bodyTextColorOnNormal.BorderColor = System.Drawing.Color.Black;
            this._bodyTextColorOnNormal.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._bodyTextColorOnNormal.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._bodyTextColorOnNormal.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._bodyTextColorOnNormal.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._bodyTextColorOnNormal.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._bodyTextColorOnNormal.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._bodyTextColorOnNormal.ContextMenuProperties.UseGradientPainting = true;
            this._bodyTextColorOnNormal.DefaultTheme = true;
            this._bodyTextColorOnNormal.DialogResult = System.Windows.Forms.DialogResult.None;
            this._bodyTextColorOnNormal.DrawMenuButtonSeparator = true;
            this._bodyTextColorOnNormal.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._bodyTextColorOnNormal.DropDownMenuItems = null;
            this._bodyTextColorOnNormal.EndColor = System.Drawing.Color.White;
            this._bodyTextColorOnNormal.IsRenderingTheme = true;
            this._bodyTextColorOnNormal.LinearGradientRenderingAngle = 90F;
            this._bodyTextColorOnNormal.Location = new System.Drawing.Point(240, 88);
            this._bodyTextColorOnNormal.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._bodyTextColorOnNormal.MenuButtonSeparatorLineHeight = -1;
            this._bodyTextColorOnNormal.Name = "_bodyTextColorOnNormal";
            this._bodyTextColorOnNormal.PushedEndColor = System.Drawing.Color.Silver;
            this._bodyTextColorOnNormal.PushedStartColor = System.Drawing.Color.White;
            this._bodyTextColorOnNormal.Size = new System.Drawing.Size(120, 24);
            this._bodyTextColorOnNormal.StartColor = System.Drawing.Color.Silver;
            this._bodyTextColorOnNormal.TabIndex = 7;
            this._bodyTextColorOnNormal.Text = "Body Text color...";
            this._bodyTextColorOnNormal.TextStringFormat = null;
            this._bodyTextColorOnNormal.TransparentColor = System.Drawing.Color.Empty;
            this._bodyTextColorOnNormal.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._bodyTextColorOnNormal.UseCustomTextStringFormat = false;
            this._bodyTextColorOnNormal.UseUserDefinedColorForArrowMark = true;
            this._bodyTextColorOnNormal.UseUserDefinedColorForMenuButtonSeparator = true;
            this._bodyTextColorOnNormal.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._bodyTextColorOnNormal.Click += new System.EventHandler(this.ChangeAlertNormalBodyTextColor);
            // 
            // _titleTextColorOnNormal
            // 
            this._titleTextColorOnNormal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._titleTextColorOnNormal.BorderColor = System.Drawing.Color.Black;
            this._titleTextColorOnNormal.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._titleTextColorOnNormal.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._titleTextColorOnNormal.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._titleTextColorOnNormal.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._titleTextColorOnNormal.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._titleTextColorOnNormal.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._titleTextColorOnNormal.ContextMenuProperties.UseGradientPainting = true;
            this._titleTextColorOnNormal.DefaultTheme = true;
            this._titleTextColorOnNormal.DialogResult = System.Windows.Forms.DialogResult.None;
            this._titleTextColorOnNormal.DrawMenuButtonSeparator = true;
            this._titleTextColorOnNormal.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._titleTextColorOnNormal.DropDownMenuItems = null;
            this._titleTextColorOnNormal.EndColor = System.Drawing.Color.White;
            this._titleTextColorOnNormal.IsRenderingTheme = true;
            this._titleTextColorOnNormal.LinearGradientRenderingAngle = 90F;
            this._titleTextColorOnNormal.Location = new System.Drawing.Point(112, 88);
            this._titleTextColorOnNormal.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._titleTextColorOnNormal.MenuButtonSeparatorLineHeight = -1;
            this._titleTextColorOnNormal.Name = "_titleTextColorOnNormal";
            this._titleTextColorOnNormal.PushedEndColor = System.Drawing.Color.Silver;
            this._titleTextColorOnNormal.PushedStartColor = System.Drawing.Color.White;
            this._titleTextColorOnNormal.Size = new System.Drawing.Size(120, 24);
            this._titleTextColorOnNormal.StartColor = System.Drawing.Color.Silver;
            this._titleTextColorOnNormal.TabIndex = 6;
            this._titleTextColorOnNormal.Text = "Title Text color...";
            this._titleTextColorOnNormal.TextStringFormat = null;
            this._titleTextColorOnNormal.TransparentColor = System.Drawing.Color.Empty;
            this._titleTextColorOnNormal.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._titleTextColorOnNormal.UseCustomTextStringFormat = false;
            this._titleTextColorOnNormal.UseUserDefinedColorForArrowMark = true;
            this._titleTextColorOnNormal.UseUserDefinedColorForMenuButtonSeparator = true;
            this._titleTextColorOnNormal.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._titleTextColorOnNormal.Click += new System.EventHandler(this.TitleTextColorOnNormalClick);
            // 
            // _label4
            // 
            this._label4.Location = new System.Drawing.Point(8, 64);
            this._label4.Name = "_label4";
            this._label4.Size = new System.Drawing.Size(88, 16);
            this._label4.TabIndex = 5;
            this._label4.Text = "On Hover:";
            // 
            // _bodyTextFontOnHover
            // 
            this._bodyTextFontOnHover.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._bodyTextFontOnHover.BorderColor = System.Drawing.Color.Black;
            this._bodyTextFontOnHover.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._bodyTextFontOnHover.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._bodyTextFontOnHover.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._bodyTextFontOnHover.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._bodyTextFontOnHover.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._bodyTextFontOnHover.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._bodyTextFontOnHover.ContextMenuProperties.UseGradientPainting = true;
            this._bodyTextFontOnHover.DefaultTheme = true;
            this._bodyTextFontOnHover.DialogResult = System.Windows.Forms.DialogResult.None;
            this._bodyTextFontOnHover.DrawMenuButtonSeparator = true;
            this._bodyTextFontOnHover.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._bodyTextFontOnHover.DropDownMenuItems = null;
            this._bodyTextFontOnHover.EndColor = System.Drawing.Color.White;
            this._bodyTextFontOnHover.IsRenderingTheme = true;
            this._bodyTextFontOnHover.LinearGradientRenderingAngle = 90F;
            this._bodyTextFontOnHover.Location = new System.Drawing.Point(240, 56);
            this._bodyTextFontOnHover.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._bodyTextFontOnHover.MenuButtonSeparatorLineHeight = -1;
            this._bodyTextFontOnHover.Name = "_bodyTextFontOnHover";
            this._bodyTextFontOnHover.PushedEndColor = System.Drawing.Color.Silver;
            this._bodyTextFontOnHover.PushedStartColor = System.Drawing.Color.White;
            this._bodyTextFontOnHover.Size = new System.Drawing.Size(120, 24);
            this._bodyTextFontOnHover.StartColor = System.Drawing.Color.Silver;
            this._bodyTextFontOnHover.TabIndex = 4;
            this._bodyTextFontOnHover.Text = "Body Text font...";
            this._bodyTextFontOnHover.TextStringFormat = null;
            this._bodyTextFontOnHover.TransparentColor = System.Drawing.Color.Empty;
            this._bodyTextFontOnHover.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._bodyTextFontOnHover.UseCustomTextStringFormat = false;
            this._bodyTextFontOnHover.UseUserDefinedColorForArrowMark = true;
            this._bodyTextFontOnHover.UseUserDefinedColorForMenuButtonSeparator = true;
            this._bodyTextFontOnHover.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._bodyTextFontOnHover.Click += new System.EventHandler(this.BodyTextFontOnHoverClick);
            // 
            // _titleTextFontOnHover
            // 
            this._titleTextFontOnHover.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._titleTextFontOnHover.BorderColor = System.Drawing.Color.Black;
            this._titleTextFontOnHover.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._titleTextFontOnHover.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._titleTextFontOnHover.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._titleTextFontOnHover.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._titleTextFontOnHover.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._titleTextFontOnHover.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._titleTextFontOnHover.ContextMenuProperties.UseGradientPainting = true;
            this._titleTextFontOnHover.DefaultTheme = true;
            this._titleTextFontOnHover.DialogResult = System.Windows.Forms.DialogResult.None;
            this._titleTextFontOnHover.DrawMenuButtonSeparator = true;
            this._titleTextFontOnHover.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._titleTextFontOnHover.DropDownMenuItems = null;
            this._titleTextFontOnHover.EndColor = System.Drawing.Color.White;
            this._titleTextFontOnHover.IsRenderingTheme = true;
            this._titleTextFontOnHover.LinearGradientRenderingAngle = 90F;
            this._titleTextFontOnHover.Location = new System.Drawing.Point(112, 56);
            this._titleTextFontOnHover.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._titleTextFontOnHover.MenuButtonSeparatorLineHeight = -1;
            this._titleTextFontOnHover.Name = "_titleTextFontOnHover";
            this._titleTextFontOnHover.PushedEndColor = System.Drawing.Color.Silver;
            this._titleTextFontOnHover.PushedStartColor = System.Drawing.Color.White;
            this._titleTextFontOnHover.Size = new System.Drawing.Size(120, 24);
            this._titleTextFontOnHover.StartColor = System.Drawing.Color.Silver;
            this._titleTextFontOnHover.TabIndex = 3;
            this._titleTextFontOnHover.Text = "Title Text font...";
            this._titleTextFontOnHover.TextStringFormat = null;
            this._titleTextFontOnHover.TransparentColor = System.Drawing.Color.Empty;
            this._titleTextFontOnHover.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._titleTextFontOnHover.UseCustomTextStringFormat = false;
            this._titleTextFontOnHover.UseUserDefinedColorForArrowMark = true;
            this._titleTextFontOnHover.UseUserDefinedColorForMenuButtonSeparator = true;
            this._titleTextFontOnHover.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._titleTextFontOnHover.Click += new System.EventHandler(this.TitleTextFontOnHoverClick);
            // 
            // _label3
            // 
            this._label3.Location = new System.Drawing.Point(8, 32);
            this._label3.Name = "_label3";
            this._label3.Size = new System.Drawing.Size(88, 16);
            this._label3.TabIndex = 2;
            this._label3.Text = "On Normal:";
            // 
            // _bodyTextFontOnNormal
            // 
            this._bodyTextFontOnNormal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._bodyTextFontOnNormal.BorderColor = System.Drawing.Color.Black;
            this._bodyTextFontOnNormal.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._bodyTextFontOnNormal.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._bodyTextFontOnNormal.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._bodyTextFontOnNormal.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._bodyTextFontOnNormal.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._bodyTextFontOnNormal.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._bodyTextFontOnNormal.ContextMenuProperties.UseGradientPainting = true;
            this._bodyTextFontOnNormal.DefaultTheme = true;
            this._bodyTextFontOnNormal.DialogResult = System.Windows.Forms.DialogResult.None;
            this._bodyTextFontOnNormal.DrawMenuButtonSeparator = true;
            this._bodyTextFontOnNormal.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._bodyTextFontOnNormal.DropDownMenuItems = null;
            this._bodyTextFontOnNormal.EndColor = System.Drawing.Color.White;
            this._bodyTextFontOnNormal.IsRenderingTheme = true;
            this._bodyTextFontOnNormal.LinearGradientRenderingAngle = 90F;
            this._bodyTextFontOnNormal.Location = new System.Drawing.Point(240, 24);
            this._bodyTextFontOnNormal.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._bodyTextFontOnNormal.MenuButtonSeparatorLineHeight = -1;
            this._bodyTextFontOnNormal.Name = "_bodyTextFontOnNormal";
            this._bodyTextFontOnNormal.PushedEndColor = System.Drawing.Color.Silver;
            this._bodyTextFontOnNormal.PushedStartColor = System.Drawing.Color.White;
            this._bodyTextFontOnNormal.Size = new System.Drawing.Size(120, 24);
            this._bodyTextFontOnNormal.StartColor = System.Drawing.Color.Silver;
            this._bodyTextFontOnNormal.TabIndex = 1;
            this._bodyTextFontOnNormal.Text = "Body Text font...";
            this._bodyTextFontOnNormal.TextStringFormat = null;
            this._bodyTextFontOnNormal.TransparentColor = System.Drawing.Color.Empty;
            this._bodyTextFontOnNormal.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._bodyTextFontOnNormal.UseCustomTextStringFormat = false;
            this._bodyTextFontOnNormal.UseUserDefinedColorForArrowMark = true;
            this._bodyTextFontOnNormal.UseUserDefinedColorForMenuButtonSeparator = true;
            this._bodyTextFontOnNormal.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._bodyTextFontOnNormal.Click += new System.EventHandler(this.BodyTextFontOnNormalClick);
            // 
            // _titleTextFontOnNormal
            // 
            this._titleTextFontOnNormal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._titleTextFontOnNormal.BorderColor = System.Drawing.Color.Black;
            this._titleTextFontOnNormal.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._titleTextFontOnNormal.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._titleTextFontOnNormal.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._titleTextFontOnNormal.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._titleTextFontOnNormal.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._titleTextFontOnNormal.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._titleTextFontOnNormal.ContextMenuProperties.UseGradientPainting = true;
            this._titleTextFontOnNormal.DefaultTheme = true;
            this._titleTextFontOnNormal.DialogResult = System.Windows.Forms.DialogResult.None;
            this._titleTextFontOnNormal.DrawMenuButtonSeparator = true;
            this._titleTextFontOnNormal.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._titleTextFontOnNormal.DropDownMenuItems = null;
            this._titleTextFontOnNormal.EndColor = System.Drawing.Color.White;
            this._titleTextFontOnNormal.IsRenderingTheme = true;
            this._titleTextFontOnNormal.LinearGradientRenderingAngle = 90F;
            this._titleTextFontOnNormal.Location = new System.Drawing.Point(112, 24);
            this._titleTextFontOnNormal.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._titleTextFontOnNormal.MenuButtonSeparatorLineHeight = -1;
            this._titleTextFontOnNormal.Name = "_titleTextFontOnNormal";
            this._titleTextFontOnNormal.PushedEndColor = System.Drawing.Color.Silver;
            this._titleTextFontOnNormal.PushedStartColor = System.Drawing.Color.White;
            this._titleTextFontOnNormal.Size = new System.Drawing.Size(120, 24);
            this._titleTextFontOnNormal.StartColor = System.Drawing.Color.Silver;
            this._titleTextFontOnNormal.TabIndex = 0;
            this._titleTextFontOnNormal.Text = "Title Text font...";
            this._titleTextFontOnNormal.TextStringFormat = null;
            this._titleTextFontOnNormal.TransparentColor = System.Drawing.Color.Empty;
            this._titleTextFontOnNormal.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._titleTextFontOnNormal.UseCustomTextStringFormat = false;
            this._titleTextFontOnNormal.UseUserDefinedColorForArrowMark = true;
            this._titleTextFontOnNormal.UseUserDefinedColorForMenuButtonSeparator = true;
            this._titleTextFontOnNormal.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._titleTextFontOnNormal.Click += new System.EventHandler(this.TitleTextFontOnNormalClick);
            // 
            // _alertTextSelectionRectangleColor
            // 
            this._alertTextSelectionRectangleColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._alertTextSelectionRectangleColor.BorderColor = System.Drawing.Color.Black;
            this._alertTextSelectionRectangleColor.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._alertTextSelectionRectangleColor.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._alertTextSelectionRectangleColor.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._alertTextSelectionRectangleColor.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._alertTextSelectionRectangleColor.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._alertTextSelectionRectangleColor.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._alertTextSelectionRectangleColor.ContextMenuProperties.UseGradientPainting = true;
            this._alertTextSelectionRectangleColor.DefaultTheme = true;
            this._alertTextSelectionRectangleColor.DialogResult = System.Windows.Forms.DialogResult.None;
            this._alertTextSelectionRectangleColor.DrawMenuButtonSeparator = true;
            this._alertTextSelectionRectangleColor.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._alertTextSelectionRectangleColor.DropDownMenuItems = null;
            this._alertTextSelectionRectangleColor.EndColor = System.Drawing.Color.White;
            this._alertTextSelectionRectangleColor.IsRenderingTheme = true;
            this._alertTextSelectionRectangleColor.LinearGradientRenderingAngle = 90F;
            this._alertTextSelectionRectangleColor.Location = new System.Drawing.Point(8, 152);
            this._alertTextSelectionRectangleColor.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._alertTextSelectionRectangleColor.MenuButtonSeparatorLineHeight = -1;
            this._alertTextSelectionRectangleColor.Name = "_alertTextSelectionRectangleColor";
            this._alertTextSelectionRectangleColor.PushedEndColor = System.Drawing.Color.Silver;
            this._alertTextSelectionRectangleColor.PushedStartColor = System.Drawing.Color.White;
            this._alertTextSelectionRectangleColor.Size = new System.Drawing.Size(192, 24);
            this._alertTextSelectionRectangleColor.StartColor = System.Drawing.Color.Silver;
            this._alertTextSelectionRectangleColor.TabIndex = 7;
            this._alertTextSelectionRectangleColor.Text = "Alert text selection rectangle color...";
            this._alertTextSelectionRectangleColor.TextStringFormat = null;
            this._alertTextSelectionRectangleColor.TransparentColor = System.Drawing.Color.Empty;
            this._alertTextSelectionRectangleColor.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._alertTextSelectionRectangleColor.UseCustomTextStringFormat = false;
            this._alertTextSelectionRectangleColor.UseUserDefinedColorForArrowMark = true;
            this._alertTextSelectionRectangleColor.UseUserDefinedColorForMenuButtonSeparator = true;
            this._alertTextSelectionRectangleColor.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._alertTextSelectionRectangleColor.Click += new System.EventHandler(this.AlertTextSelectionRectangleColorClick);
            // 
            // _groupBox3
            // 
            this._groupBox3.Controls.Add(this._checkBox5);
            this._groupBox3.Controls.Add(this._checkBox1);
            this._groupBox3.Controls.Add(this._showTextAreaRectangle);
            this._groupBox3.Controls.Add(this._exitButtonClickable);
            this._groupBox3.Controls.Add(this._alertTitleIsClickable);
            this._groupBox3.Controls.Add(this._alertTextClickable);
            this._groupBox3.Controls.Add(this._button1);
            this._groupBox3.Controls.Add(this._textBox1);
            this._groupBox3.Controls.Add(this._label14);
            this._groupBox3.Controls.Add(this._groupBox7);
            this._groupBox3.Controls.Add(this._displayExitIcon);
            this._groupBox3.Controls.Add(this._showAlertPopupWhenMouseIsOverAndWindowIsClosing);
            this._groupBox3.Controls.Add(this._showAlertPopupWhenMouseIsOver);
            this._groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox3.Location = new System.Drawing.Point(16, 370);
            this._groupBox3.Name = "_groupBox3";
            this._groupBox3.Size = new System.Drawing.Size(408, 294);
            this._groupBox3.TabIndex = 2;
            this._groupBox3.TabStop = false;
            this._groupBox3.Text = "All other properties";
            // 
            // _checkBox5
            // 
            this._checkBox5.Checked = true;
            this._checkBox5.CheckState = System.Windows.Forms.CheckState.Checked;
            this._checkBox5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._checkBox5.Location = new System.Drawing.Point(8, 139);
            this._checkBox5.Name = "_checkBox5";
            this._checkBox5.Size = new System.Drawing.Size(384, 16);
            this._checkBox5.TabIndex = 15;
            this._checkBox5.Text = "Allow users to drag-and-drop (relocate) the popup window";
            this._checkBox5.CheckedChanged += new System.EventHandler(this.AllowUserToDragDropPopupWindowChanged);
            // 
            // _checkBox1
            // 
            this._checkBox1.Checked = true;
            this._checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this._checkBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._checkBox1.Location = new System.Drawing.Point(208, 90);
            this._checkBox1.Name = "_checkBox1";
            this._checkBox1.Size = new System.Drawing.Size(184, 16);
            this._checkBox1.TabIndex = 14;
            this._checkBox1.Text = "Play sound when popup is shown";
            this._checkBox1.CheckedChanged += new System.EventHandler(this.PlaySoundWhenPopupIsDisplayUpdated);
            // 
            // _showTextAreaRectangle
            // 
            this._showTextAreaRectangle.Checked = true;
            this._showTextAreaRectangle.CheckState = System.Windows.Forms.CheckState.Checked;
            this._showTextAreaRectangle.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._showTextAreaRectangle.Location = new System.Drawing.Point(208, 45);
            this._showTextAreaRectangle.Name = "_showTextAreaRectangle";
            this._showTextAreaRectangle.Size = new System.Drawing.Size(168, 16);
            this._showTextAreaRectangle.TabIndex = 13;
            this._showTextAreaRectangle.Text = "Show text area rectangle";
            this._showTextAreaRectangle.CheckedChanged += new System.EventHandler(this.ShowTextAreaRectangleUpdated);
            // 
            // _exitButtonClickable
            // 
            this._exitButtonClickable.Checked = true;
            this._exitButtonClickable.CheckState = System.Windows.Forms.CheckState.Checked;
            this._exitButtonClickable.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._exitButtonClickable.Location = new System.Drawing.Point(8, 45);
            this._exitButtonClickable.Name = "_exitButtonClickable";
            this._exitButtonClickable.Size = new System.Drawing.Size(168, 16);
            this._exitButtonClickable.TabIndex = 12;
            this._exitButtonClickable.Text = "Exit button can be clicked";
            this._exitButtonClickable.CheckedChanged += new System.EventHandler(this.ExitButtonClickableCheckedChanged);
            // 
            // _alertTitleIsClickable
            // 
            this._alertTitleIsClickable.Checked = true;
            this._alertTitleIsClickable.CheckState = System.Windows.Forms.CheckState.Checked;
            this._alertTitleIsClickable.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._alertTitleIsClickable.Location = new System.Drawing.Point(208, 23);
            this._alertTitleIsClickable.Name = "_alertTitleIsClickable";
            this._alertTitleIsClickable.Size = new System.Drawing.Size(160, 16);
            this._alertTitleIsClickable.TabIndex = 11;
            this._alertTitleIsClickable.Text = "Alert title text can be clicked";
            this._alertTitleIsClickable.CheckedChanged += new System.EventHandler(this.AlertTitleIsClickableCheckedChanged);
            // 
            // _alertTextClickable
            // 
            this._alertTextClickable.Checked = true;
            this._alertTextClickable.CheckState = System.Windows.Forms.CheckState.Checked;
            this._alertTextClickable.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._alertTextClickable.Location = new System.Drawing.Point(8, 23);
            this._alertTextClickable.Name = "_alertTextClickable";
            this._alertTextClickable.Size = new System.Drawing.Size(192, 16);
            this._alertTextClickable.TabIndex = 10;
            this._alertTextClickable.Text = "Alert Text can be clicked";
            this._alertTextClickable.CheckedChanged += new System.EventHandler(this.AlertTextClickableCheckedChanged);
            // 
            // _button1
            // 
            this._button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._button1.BorderColor = System.Drawing.Color.Black;
            this._button1.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._button1.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._button1.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._button1.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._button1.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._button1.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._button1.ContextMenuProperties.UseGradientPainting = true;
            this._button1.DefaultTheme = true;
            this._button1.DialogResult = System.Windows.Forms.DialogResult.None;
            this._button1.DrawMenuButtonSeparator = true;
            this._button1.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._button1.DropDownMenuItems = null;
            this._button1.EndColor = System.Drawing.Color.White;
            this._button1.IsRenderingTheme = true;
            this._button1.LinearGradientRenderingAngle = 90F;
            this._button1.Location = new System.Drawing.Point(285, 263);
            this._button1.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._button1.MenuButtonSeparatorLineHeight = -1;
            this._button1.Name = "_button1";
            this._button1.PushedEndColor = System.Drawing.Color.Silver;
            this._button1.PushedStartColor = System.Drawing.Color.White;
            this._button1.Size = new System.Drawing.Size(32, 20);
            this._button1.StartColor = System.Drawing.Color.Silver;
            this._button1.TabIndex = 9;
            this._button1.Text = "...";
            this._button1.TextStringFormat = null;
            this._button1.TransparentColor = System.Drawing.Color.Empty;
            this._button1.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._button1.UseCustomTextStringFormat = false;
            this._button1.UseUserDefinedColorForArrowMark = true;
            this._button1.UseUserDefinedColorForMenuButtonSeparator = true;
            this._button1.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._button1.Click += new System.EventHandler(this.SoundPlaybackFileUpdateRequested);
            // 
            // _textBox1
            // 
            this._textBox1.BackColor = System.Drawing.Color.White;
            this._textBox1.Location = new System.Drawing.Point(11, 263);
            this._textBox1.Name = "_textBox1";
            this._textBox1.ReadOnly = true;
            this._textBox1.Size = new System.Drawing.Size(272, 20);
            this._textBox1.TabIndex = 8;
            this._textBox1.Text = "notify.wav";
            this._textBox1.TextChanged += new System.EventHandler(this.SoundPlaybackFileChanged);
            // 
            // _label14
            // 
            this._label14.Location = new System.Drawing.Point(11, 247);
            this._label14.Name = "_label14";
            this._label14.Size = new System.Drawing.Size(272, 16);
            this._label14.TabIndex = 7;
            this._label14.Text = "Set a Sound to play when Alert window is displayed:";
            // 
            // _groupBox7
            // 
            this._groupBox7.Controls.Add(this._customPopupTitleIcon);
            this._groupBox7.Controls.Add(this._customExitIcon);
            this._groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox7.Location = new System.Drawing.Point(8, 168);
            this._groupBox7.Name = "_groupBox7";
            this._groupBox7.Size = new System.Drawing.Size(368, 64);
            this._groupBox7.TabIndex = 6;
            this._groupBox7.TabStop = false;
            this._groupBox7.Text = "Set custom icons:";
            // 
            // _customPopupTitleIcon
            // 
            this._customPopupTitleIcon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._customPopupTitleIcon.BorderColor = System.Drawing.Color.Black;
            this._customPopupTitleIcon.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._customPopupTitleIcon.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._customPopupTitleIcon.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._customPopupTitleIcon.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._customPopupTitleIcon.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._customPopupTitleIcon.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._customPopupTitleIcon.ContextMenuProperties.UseGradientPainting = true;
            this._customPopupTitleIcon.DefaultTheme = true;
            this._customPopupTitleIcon.DialogResult = System.Windows.Forms.DialogResult.None;
            this._customPopupTitleIcon.DrawMenuButtonSeparator = true;
            this._customPopupTitleIcon.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._customPopupTitleIcon.DropDownMenuItems = null;
            this._customPopupTitleIcon.EndColor = System.Drawing.Color.White;
            this._customPopupTitleIcon.IsRenderingTheme = true;
            this._customPopupTitleIcon.LinearGradientRenderingAngle = 90F;
            this._customPopupTitleIcon.Location = new System.Drawing.Point(64, 24);
            this._customPopupTitleIcon.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._customPopupTitleIcon.MenuButtonSeparatorLineHeight = -1;
            this._customPopupTitleIcon.Name = "_customPopupTitleIcon";
            this._customPopupTitleIcon.PushedEndColor = System.Drawing.Color.Silver;
            this._customPopupTitleIcon.PushedStartColor = System.Drawing.Color.White;
            this._customPopupTitleIcon.Size = new System.Drawing.Size(112, 32);
            this._customPopupTitleIcon.StartColor = System.Drawing.Color.Silver;
            this._customPopupTitleIcon.TabIndex = 4;
            this._customPopupTitleIcon.Text = "Popup title icon...";
            this._customPopupTitleIcon.TextStringFormat = null;
            this._customPopupTitleIcon.TransparentColor = System.Drawing.Color.Empty;
            this._customPopupTitleIcon.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._customPopupTitleIcon.UseCustomTextStringFormat = false;
            this._customPopupTitleIcon.UseUserDefinedColorForArrowMark = true;
            this._customPopupTitleIcon.UseUserDefinedColorForMenuButtonSeparator = true;
            this._customPopupTitleIcon.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._customPopupTitleIcon.Click += new System.EventHandler(this.CustomPopupTitleIconClick);
            // 
            // _customExitIcon
            // 
            this._customExitIcon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._customExitIcon.BorderColor = System.Drawing.Color.Black;
            this._customExitIcon.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._customExitIcon.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._customExitIcon.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._customExitIcon.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._customExitIcon.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._customExitIcon.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._customExitIcon.ContextMenuProperties.UseGradientPainting = true;
            this._customExitIcon.DefaultTheme = true;
            this._customExitIcon.DialogResult = System.Windows.Forms.DialogResult.None;
            this._customExitIcon.DrawMenuButtonSeparator = true;
            this._customExitIcon.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._customExitIcon.DropDownMenuItems = null;
            this._customExitIcon.EndColor = System.Drawing.Color.White;
            this._customExitIcon.IsRenderingTheme = true;
            this._customExitIcon.LinearGradientRenderingAngle = 90F;
            this._customExitIcon.Location = new System.Drawing.Point(192, 24);
            this._customExitIcon.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._customExitIcon.MenuButtonSeparatorLineHeight = -1;
            this._customExitIcon.Name = "_customExitIcon";
            this._customExitIcon.PushedEndColor = System.Drawing.Color.Silver;
            this._customExitIcon.PushedStartColor = System.Drawing.Color.White;
            this._customExitIcon.Size = new System.Drawing.Size(112, 32);
            this._customExitIcon.StartColor = System.Drawing.Color.Silver;
            this._customExitIcon.TabIndex = 5;
            this._customExitIcon.Text = "Popup exit icon...";
            this._customExitIcon.TextStringFormat = null;
            this._customExitIcon.TransparentColor = System.Drawing.Color.Empty;
            this._customExitIcon.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._customExitIcon.UseCustomTextStringFormat = false;
            this._customExitIcon.UseUserDefinedColorForArrowMark = true;
            this._customExitIcon.UseUserDefinedColorForMenuButtonSeparator = true;
            this._customExitIcon.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._customExitIcon.Click += new System.EventHandler(this.CustomExitIconClick);
            // 
            // _displayExitIcon
            // 
            this._displayExitIcon.Checked = true;
            this._displayExitIcon.CheckState = System.Windows.Forms.CheckState.Checked;
            this._displayExitIcon.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._displayExitIcon.Location = new System.Drawing.Point(8, 90);
            this._displayExitIcon.Name = "_displayExitIcon";
            this._displayExitIcon.Size = new System.Drawing.Size(112, 16);
            this._displayExitIcon.TabIndex = 2;
            this._displayExitIcon.Text = "Display exit button";
            this._displayExitIcon.CheckedChanged += new System.EventHandler(this.DisplayExitIconCheckedChanged);
            // 
            // _showAlertPopupWhenMouseIsOverAndWindowIsClosing
            // 
            this._showAlertPopupWhenMouseIsOverAndWindowIsClosing.Checked = true;
            this._showAlertPopupWhenMouseIsOverAndWindowIsClosing.CheckState = System.Windows.Forms.CheckState.Checked;
            this._showAlertPopupWhenMouseIsOverAndWindowIsClosing.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._showAlertPopupWhenMouseIsOverAndWindowIsClosing.Location = new System.Drawing.Point(8, 114);
            this._showAlertPopupWhenMouseIsOverAndWindowIsClosing.Name = "_showAlertPopupWhenMouseIsOverAndWindowIsClosing";
            this._showAlertPopupWhenMouseIsOverAndWindowIsClosing.Size = new System.Drawing.Size(384, 16);
            this._showAlertPopupWhenMouseIsOverAndWindowIsClosing.TabIndex = 1;
            this._showAlertPopupWhenMouseIsOverAndWindowIsClosing.Text = "Alert Popup is shown again when mouse is over it while the popup is closing";
            this._showAlertPopupWhenMouseIsOverAndWindowIsClosing.CheckedChanged += new System.EventHandler(this.ShowAlertPopupWhenMouseIsOverAndWindowIsClosingCheckedChanged);
            // 
            // _showAlertPopupWhenMouseIsOver
            // 
            this._showAlertPopupWhenMouseIsOver.Checked = true;
            this._showAlertPopupWhenMouseIsOver.CheckState = System.Windows.Forms.CheckState.Checked;
            this._showAlertPopupWhenMouseIsOver.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._showAlertPopupWhenMouseIsOver.Location = new System.Drawing.Point(8, 67);
            this._showAlertPopupWhenMouseIsOver.Name = "_showAlertPopupWhenMouseIsOver";
            this._showAlertPopupWhenMouseIsOver.Size = new System.Drawing.Size(296, 16);
            this._showAlertPopupWhenMouseIsOver.TabIndex = 0;
            this._showAlertPopupWhenMouseIsOver.Text = "Alert Popup continues to be  shown when mouse is over it";
            this._showAlertPopupWhenMouseIsOver.CheckedChanged += new System.EventHandler(this.ShowAlertPopupWhenMouseIsOverCheckedChanged);
            // 
            // _groupBox4
            // 
            this._groupBox4.Controls.Add(this._groupBox5);
            this._groupBox4.Controls.Add(this._popupWindowDisappearingStyles);
            this._groupBox4.Controls.Add(this._label9);
            this._groupBox4.Controls.Add(this._popupWindowStyles);
            this._groupBox4.Controls.Add(this._label7);
            this._groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox4.Location = new System.Drawing.Point(432, 8);
            this._groupBox4.Name = "_groupBox4";
            this._groupBox4.Size = new System.Drawing.Size(336, 401);
            this._groupBox4.TabIndex = 3;
            this._groupBox4.TabStop = false;
            this._groupBox4.Text = "Popup Styles";
            // 
            // _groupBox5
            // 
            this._groupBox5.Controls.Add(this._groupBox6);
            this._groupBox5.Controls.Add(this._groupBox9);
            this._groupBox5.Controls.Add(this._customColorStyles);
            this._groupBox5.Controls.Add(this._label10);
            this._groupBox5.Controls.Add(this._useCustomColors);
            this._groupBox5.Controls.Add(this._useBuiltInColors);
            this._groupBox5.Controls.Add(this._themeColors);
            this._groupBox5.Controls.Add(this._label8);
            this._groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox5.Location = new System.Drawing.Point(8, 95);
            this._groupBox5.Name = "_groupBox5";
            this._groupBox5.Size = new System.Drawing.Size(320, 293);
            this._groupBox5.TabIndex = 6;
            this._groupBox5.TabStop = false;
            // 
            // _groupBox6
            // 
            this._groupBox6.Controls.Add(this._useThisSpecifiColor);
            this._groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox6.Location = new System.Drawing.Point(22, 224);
            this._groupBox6.Name = "_groupBox6";
            this._groupBox6.Size = new System.Drawing.Size(280, 64);
            this._groupBox6.TabIndex = 19;
            this._groupBox6.TabStop = false;
            this._groupBox6.Text = "Applicable only when choosing the Specific color style";
            // 
            // _useThisSpecifiColor
            // 
            this._useThisSpecifiColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._useThisSpecifiColor.BorderColor = System.Drawing.Color.Black;
            this._useThisSpecifiColor.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._useThisSpecifiColor.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._useThisSpecifiColor.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._useThisSpecifiColor.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._useThisSpecifiColor.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._useThisSpecifiColor.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._useThisSpecifiColor.ContextMenuProperties.UseGradientPainting = true;
            this._useThisSpecifiColor.DefaultTheme = true;
            this._useThisSpecifiColor.DialogResult = System.Windows.Forms.DialogResult.None;
            this._useThisSpecifiColor.DrawMenuButtonSeparator = true;
            this._useThisSpecifiColor.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._useThisSpecifiColor.DropDownMenuItems = null;
            this._useThisSpecifiColor.EndColor = System.Drawing.Color.White;
            this._useThisSpecifiColor.IsRenderingTheme = true;
            this._useThisSpecifiColor.LinearGradientRenderingAngle = 90F;
            this._useThisSpecifiColor.Location = new System.Drawing.Point(24, 24);
            this._useThisSpecifiColor.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._useThisSpecifiColor.MenuButtonSeparatorLineHeight = -1;
            this._useThisSpecifiColor.Name = "_useThisSpecifiColor";
            this._useThisSpecifiColor.PushedEndColor = System.Drawing.Color.Silver;
            this._useThisSpecifiColor.PushedStartColor = System.Drawing.Color.White;
            this._useThisSpecifiColor.Size = new System.Drawing.Size(248, 32);
            this._useThisSpecifiColor.StartColor = System.Drawing.Color.Silver;
            this._useThisSpecifiColor.TabIndex = 0;
            this._useThisSpecifiColor.Text = "Use this specific color...";
            this._useThisSpecifiColor.TextStringFormat = null;
            this._useThisSpecifiColor.TransparentColor = System.Drawing.Color.Empty;
            this._useThisSpecifiColor.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._useThisSpecifiColor.UseCustomTextStringFormat = false;
            this._useThisSpecifiColor.UseUserDefinedColorForArrowMark = true;
            this._useThisSpecifiColor.UseUserDefinedColorForMenuButtonSeparator = true;
            this._useThisSpecifiColor.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._useThisSpecifiColor.Click += new System.EventHandler(this.UseThisSpecifiColorClick);
            // 
            // _groupBox9
            // 
            this._groupBox9.Controls.Add(this._numericUpDown1);
            this._groupBox9.Controls.Add(this._label15);
            this._groupBox9.Controls.Add(this._endColor);
            this._groupBox9.Controls.Add(this._startColor);
            this._groupBox9.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox9.Location = new System.Drawing.Point(22, 125);
            this._groupBox9.Name = "_groupBox9";
            this._groupBox9.Size = new System.Drawing.Size(280, 85);
            this._groupBox9.TabIndex = 18;
            this._groupBox9.TabStop = false;
            this._groupBox9.Text = "Applicable only when choosing the Gradient color style";
            // 
            // _numericUpDown1
            // 
            this._numericUpDown1.Location = new System.Drawing.Point(168, 56);
            this._numericUpDown1.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this._numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this._numericUpDown1.Name = "_numericUpDown1";
            this._numericUpDown1.Size = new System.Drawing.Size(72, 20);
            this._numericUpDown1.TabIndex = 4;
            this._numericUpDown1.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this._numericUpDown1.ValueChanged += new System.EventHandler(this.NumericUpDown1ValueChanged);
            // 
            // _label15
            // 
            this._label15.Location = new System.Drawing.Point(24, 56);
            this._label15.Name = "_label15";
            this._label15.Size = new System.Drawing.Size(152, 16);
            this._label15.TabIndex = 2;
            this._label15.Text = "Gradient orientation angle:";
            // 
            // _endColor
            // 
            this._endColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._endColor.BorderColor = System.Drawing.Color.Black;
            this._endColor.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._endColor.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._endColor.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._endColor.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._endColor.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._endColor.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._endColor.ContextMenuProperties.UseGradientPainting = true;
            this._endColor.DefaultTheme = true;
            this._endColor.DialogResult = System.Windows.Forms.DialogResult.None;
            this._endColor.DrawMenuButtonSeparator = true;
            this._endColor.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._endColor.DropDownMenuItems = null;
            this._endColor.EndColor = System.Drawing.Color.White;
            this._endColor.IsRenderingTheme = true;
            this._endColor.LinearGradientRenderingAngle = 90F;
            this._endColor.Location = new System.Drawing.Point(152, 24);
            this._endColor.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._endColor.MenuButtonSeparatorLineHeight = -1;
            this._endColor.Name = "_endColor";
            this._endColor.PushedEndColor = System.Drawing.Color.Silver;
            this._endColor.PushedStartColor = System.Drawing.Color.White;
            this._endColor.Size = new System.Drawing.Size(112, 24);
            this._endColor.StartColor = System.Drawing.Color.Silver;
            this._endColor.TabIndex = 1;
            this._endColor.Text = "End color...";
            this._endColor.TextStringFormat = null;
            this._endColor.TransparentColor = System.Drawing.Color.Empty;
            this._endColor.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._endColor.UseCustomTextStringFormat = false;
            this._endColor.UseUserDefinedColorForArrowMark = true;
            this._endColor.UseUserDefinedColorForMenuButtonSeparator = true;
            this._endColor.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._endColor.Click += new System.EventHandler(this.EndColorClick);
            // 
            // _startColor
            // 
            this._startColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._startColor.BorderColor = System.Drawing.Color.Black;
            this._startColor.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._startColor.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._startColor.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._startColor.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._startColor.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._startColor.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._startColor.ContextMenuProperties.UseGradientPainting = true;
            this._startColor.DefaultTheme = true;
            this._startColor.DialogResult = System.Windows.Forms.DialogResult.None;
            this._startColor.DrawMenuButtonSeparator = true;
            this._startColor.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._startColor.DropDownMenuItems = null;
            this._startColor.EndColor = System.Drawing.Color.White;
            this._startColor.IsRenderingTheme = true;
            this._startColor.LinearGradientRenderingAngle = 90F;
            this._startColor.Location = new System.Drawing.Point(24, 24);
            this._startColor.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._startColor.MenuButtonSeparatorLineHeight = -1;
            this._startColor.Name = "_startColor";
            this._startColor.PushedEndColor = System.Drawing.Color.Silver;
            this._startColor.PushedStartColor = System.Drawing.Color.White;
            this._startColor.Size = new System.Drawing.Size(112, 24);
            this._startColor.StartColor = System.Drawing.Color.Silver;
            this._startColor.TabIndex = 0;
            this._startColor.Text = "Start color...";
            this._startColor.TextStringFormat = null;
            this._startColor.TransparentColor = System.Drawing.Color.Empty;
            this._startColor.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._startColor.UseCustomTextStringFormat = false;
            this._startColor.UseUserDefinedColorForArrowMark = true;
            this._startColor.UseUserDefinedColorForMenuButtonSeparator = true;
            this._startColor.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._startColor.Click += new System.EventHandler(this.StartColorClick);
            // 
            // _customColorStyles
            // 
            this._customColorStyles.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._customColorStyles.Items.AddRange(new object[] {
            "SpecificColor",
            "GradientColors"});
            this._customColorStyles.Location = new System.Drawing.Point(134, 88);
            this._customColorStyles.Name = "_customColorStyles";
            this._customColorStyles.Size = new System.Drawing.Size(160, 21);
            this._customColorStyles.TabIndex = 17;
            this._customColorStyles.SelectedIndexChanged += new System.EventHandler(this.CustomColorStylesSelectedIndexChanged);
            // 
            // _label10
            // 
            this._label10.Location = new System.Drawing.Point(22, 91);
            this._label10.Name = "_label10";
            this._label10.Size = new System.Drawing.Size(72, 16);
            this._label10.TabIndex = 16;
            this._label10.Text = "Color style:";
            // 
            // _useCustomColors
            // 
            this._useCustomColors.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._useCustomColors.Location = new System.Drawing.Point(8, 64);
            this._useCustomColors.Name = "_useCustomColors";
            this._useCustomColors.Size = new System.Drawing.Size(120, 16);
            this._useCustomColors.TabIndex = 15;
            this._useCustomColors.Text = "Use custom colors";
            this._useCustomColors.CheckedChanged += new System.EventHandler(this.UseCustomColorsCheckedChanged);
            // 
            // _useBuiltInColors
            // 
            this._useBuiltInColors.Checked = true;
            this._useBuiltInColors.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._useBuiltInColors.Location = new System.Drawing.Point(8, 10);
            this._useBuiltInColors.Name = "_useBuiltInColors";
            this._useBuiltInColors.Size = new System.Drawing.Size(296, 16);
            this._useBuiltInColors.TabIndex = 14;
            this._useBuiltInColors.TabStop = true;
            this._useBuiltInColors.Text = "Use Built-in Styles/colors";
            this._useBuiltInColors.CheckedChanged += new System.EventHandler(this.UseBuiltInColorsCheckedChanged);
            // 
            // _themeColors
            // 
            this._themeColors.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._themeColors.Items.AddRange(new object[] {
            "Blue",
            "Olive",
            "Silver"});
            this._themeColors.Location = new System.Drawing.Point(160, 32);
            this._themeColors.Name = "_themeColors";
            this._themeColors.Size = new System.Drawing.Size(144, 21);
            this._themeColors.TabIndex = 13;
            this._themeColors.SelectedIndexChanged += new System.EventHandler(this.ThemeColorsSelectedIndexChanged);
            // 
            // _label8
            // 
            this._label8.Location = new System.Drawing.Point(24, 36);
            this._label8.Name = "_label8";
            this._label8.Size = new System.Drawing.Size(128, 16);
            this._label8.TabIndex = 12;
            this._label8.Text = "Built-in XP theme color:";
            // 
            // _popupWindowDisappearingStyles
            // 
            this._popupWindowDisappearingStyles.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._popupWindowDisappearingStyles.Items.AddRange(new object[] {
            "VanishOut",
            "SlideDown",
            "VanishOutWhileSlidingDown"});
            this._popupWindowDisappearingStyles.Location = new System.Drawing.Point(144, 62);
            this._popupWindowDisappearingStyles.Name = "_popupWindowDisappearingStyles";
            this._popupWindowDisappearingStyles.Size = new System.Drawing.Size(160, 21);
            this._popupWindowDisappearingStyles.TabIndex = 5;
            this._popupWindowDisappearingStyles.SelectedIndexChanged += new System.EventHandler(this.PopupWindowDisappearingStylesSelectedIndexChanged);
            // 
            // _label9
            // 
            this._label9.Location = new System.Drawing.Point(8, 55);
            this._label9.Name = "_label9";
            this._label9.Size = new System.Drawing.Size(112, 32);
            this._label9.TabIndex = 4;
            this._label9.Text = "Popup Window disappearing style:";
            // 
            // _popupWindowStyles
            // 
            this._popupWindowStyles.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._popupWindowStyles.Items.AddRange(new object[] {
            "Outlook",
            "MSNMessenger"});
            this._popupWindowStyles.Location = new System.Drawing.Point(144, 30);
            this._popupWindowStyles.Name = "_popupWindowStyles";
            this._popupWindowStyles.Size = new System.Drawing.Size(160, 21);
            this._popupWindowStyles.TabIndex = 1;
            this._popupWindowStyles.SelectedIndexChanged += new System.EventHandler(this.PopupWindowStylesSelectedIndexChanged);
            // 
            // _label7
            // 
            this._label7.Location = new System.Drawing.Point(8, 31);
            this._label7.Name = "_label7";
            this._label7.Size = new System.Drawing.Size(112, 16);
            this._label7.TabIndex = 0;
            this._label7.Text = "Popup window style:";
            // 
            // _groupBox8
            // 
            this._groupBox8.Controls.Add(this._durationToShowAlertPopup);
            this._groupBox8.Controls.Add(this._animationWhileClosing);
            this._groupBox8.Controls.Add(this._animationWhileStarting);
            this._groupBox8.Controls.Add(this._checkBox4);
            this._groupBox8.Controls.Add(this._label13);
            this._groupBox8.Controls.Add(this._label12);
            this._groupBox8.Controls.Add(this._label11);
            this._groupBox8.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox8.Location = new System.Drawing.Point(432, 427);
            this._groupBox8.Name = "_groupBox8";
            this._groupBox8.Size = new System.Drawing.Size(336, 130);
            this._groupBox8.TabIndex = 4;
            this._groupBox8.TabStop = false;
            this._groupBox8.Text = "Animation parameters (time duration in milliseconds)";
            // 
            // _durationToShowAlertPopup
            // 
            this._durationToShowAlertPopup.Location = new System.Drawing.Point(224, 72);
            this._durationToShowAlertPopup.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this._durationToShowAlertPopup.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this._durationToShowAlertPopup.Name = "_durationToShowAlertPopup";
            this._durationToShowAlertPopup.Size = new System.Drawing.Size(104, 20);
            this._durationToShowAlertPopup.TabIndex = 5;
            this._durationToShowAlertPopup.Value = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            this._durationToShowAlertPopup.ValueChanged += new System.EventHandler(this.DurationToShowAlertPopupValueChanged);
            // 
            // _animationWhileClosing
            // 
            this._animationWhileClosing.Location = new System.Drawing.Point(224, 48);
            this._animationWhileClosing.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this._animationWhileClosing.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this._animationWhileClosing.Name = "_animationWhileClosing";
            this._animationWhileClosing.Size = new System.Drawing.Size(104, 20);
            this._animationWhileClosing.TabIndex = 4;
            this._animationWhileClosing.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this._animationWhileClosing.ValueChanged += new System.EventHandler(this.AnimationWhileClosingValueChanged);
            // 
            // _animationWhileStarting
            // 
            this._animationWhileStarting.Location = new System.Drawing.Point(224, 24);
            this._animationWhileStarting.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this._animationWhileStarting.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this._animationWhileStarting.Name = "_animationWhileStarting";
            this._animationWhileStarting.Size = new System.Drawing.Size(104, 20);
            this._animationWhileStarting.TabIndex = 3;
            this._animationWhileStarting.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this._animationWhileStarting.ValueChanged += new System.EventHandler(this.AnimationWhileStartingValueChanged);
            // 
            // _checkBox4
            // 
            this._checkBox4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._checkBox4.Location = new System.Drawing.Point(11, 102);
            this._checkBox4.Name = "_checkBox4";
            this._checkBox4.Size = new System.Drawing.Size(317, 16);
            this._checkBox4.TabIndex = 20;
            this._checkBox4.Text = "Keep showing the alert popup until dismissed deterministically.";
            // 
            // _label13
            // 
            this._label13.Location = new System.Drawing.Point(8, 72);
            this._label13.Name = "_label13";
            this._label13.Size = new System.Drawing.Size(168, 16);
            this._label13.TabIndex = 2;
            this._label13.Text = "Time to show the alert window:";
            // 
            // _label12
            // 
            this._label12.Location = new System.Drawing.Point(8, 48);
            this._label12.Name = "_label12";
            this._label12.Size = new System.Drawing.Size(208, 16);
            this._label12.TabIndex = 1;
            this._label12.Text = "Animation (while disappearing) duration:";
            // 
            // _label11
            // 
            this._label11.Location = new System.Drawing.Point(8, 24);
            this._label11.Name = "_label11";
            this._label11.Size = new System.Drawing.Size(184, 16);
            this._label11.TabIndex = 0;
            this._label11.Text = "Animation (while starting) duration:";
            // 
            // _about
            // 
            this._about.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._about.BorderColor = System.Drawing.Color.Black;
            this._about.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._about.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._about.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._about.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._about.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._about.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._about.ContextMenuProperties.UseGradientPainting = true;
            this._about.DefaultTheme = false;
            this._about.DialogResult = System.Windows.Forms.DialogResult.None;
            this._about.DrawMenuButtonSeparator = true;
            this._about.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._about.DropDownMenuItems = null;
            this._about.EndColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this._about.IsRenderingTheme = false;
            this._about.LinearGradientRenderingAngle = 90F;
            this._about.Location = new System.Drawing.Point(568, 677);
            this._about.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._about.MenuButtonSeparatorLineHeight = -1;
            this._about.Name = "_about";
            this._about.PushedEndColor = System.Drawing.Color.White;
            this._about.PushedStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this._about.Size = new System.Drawing.Size(96, 32);
            this._about.StartColor = System.Drawing.Color.White;
            this._about.TabIndex = 5;
            this._about.Text = "&About";
            this._about.TextStringFormat = null;
            this._about.TransparentColor = System.Drawing.Color.Empty;
            this._about.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._about.UseCustomTextStringFormat = false;
            this._about.UseUserDefinedColorForArrowMark = true;
            this._about.UseUserDefinedColorForMenuButtonSeparator = true;
            this._about.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._about.Click += new System.EventHandler(this.AboutClick);
            // 
            // _exit
            // 
            this._exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._exit.BorderColor = System.Drawing.Color.Black;
            this._exit.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._exit.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._exit.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._exit.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._exit.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._exit.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._exit.ContextMenuProperties.UseGradientPainting = true;
            this._exit.DefaultTheme = true;
            this._exit.DialogResult = System.Windows.Forms.DialogResult.None;
            this._exit.DrawMenuButtonSeparator = true;
            this._exit.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._exit.DropDownMenuItems = null;
            this._exit.EndColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this._exit.IsRenderingTheme = false;
            this._exit.LinearGradientRenderingAngle = 90F;
            this._exit.Location = new System.Drawing.Point(672, 677);
            this._exit.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._exit.MenuButtonSeparatorLineHeight = -1;
            this._exit.Name = "_exit";
            this._exit.PushedEndColor = System.Drawing.Color.White;
            this._exit.PushedStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this._exit.Size = new System.Drawing.Size(96, 32);
            this._exit.StartColor = System.Drawing.Color.White;
            this._exit.TabIndex = 6;
            this._exit.Text = "E&xit";
            this._exit.TextStringFormat = null;
            this._exit.TransparentColor = System.Drawing.Color.Empty;
            this._exit.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._exit.UseCustomTextStringFormat = false;
            this._exit.UseUserDefinedColorForArrowMark = true;
            this._exit.UseUserDefinedColorForMenuButtonSeparator = true;
            this._exit.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._exit.Click += new System.EventHandler(this.ExitApplicationClicked);
            // 
            // _statusBar
            // 
            this._statusBar.Location = new System.Drawing.Point(0, 754);
            this._statusBar.Name = "_statusBar";
            this._statusBar.Size = new System.Drawing.Size(795, 22);
            this._statusBar.SizingGrip = false;
            this._statusBar.TabIndex = 7;
            this._statusBar.Text = "BinaryAlertPopup .NET control - Copyright (C) Binarymission Technologies Limited " +
    "(UK)! http://www.binarymission.co.uk";
            // 
            // _showAlertPopupNow
            // 
            this._showAlertPopupNow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._showAlertPopupNow.BorderColor = System.Drawing.Color.Black;
            this._showAlertPopupNow.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._showAlertPopupNow.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._showAlertPopupNow.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._showAlertPopupNow.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._showAlertPopupNow.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._showAlertPopupNow.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._showAlertPopupNow.ContextMenuProperties.UseGradientPainting = true;
            this._showAlertPopupNow.DefaultTheme = true;
            this._showAlertPopupNow.DialogResult = System.Windows.Forms.DialogResult.None;
            this._showAlertPopupNow.DrawMenuButtonSeparator = true;
            this._showAlertPopupNow.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._showAlertPopupNow.DropDownMenuItems = null;
            this._showAlertPopupNow.EndColor = System.Drawing.Color.White;
            this._showAlertPopupNow.IsRenderingTheme = true;
            this._showAlertPopupNow.LinearGradientRenderingAngle = 90F;
            this._showAlertPopupNow.Location = new System.Drawing.Point(16, 677);
            this._showAlertPopupNow.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._showAlertPopupNow.MenuButtonSeparatorLineHeight = -1;
            this._showAlertPopupNow.Name = "_showAlertPopupNow";
            this._showAlertPopupNow.PushedEndColor = System.Drawing.Color.Silver;
            this._showAlertPopupNow.PushedStartColor = System.Drawing.Color.White;
            this._showAlertPopupNow.Size = new System.Drawing.Size(141, 32);
            this._showAlertPopupNow.StartColor = System.Drawing.Color.Silver;
            this._showAlertPopupNow.TabIndex = 0;
            this._showAlertPopupNow.Text = "Display BinaryAlertPopup";
            this._showAlertPopupNow.TextStringFormat = null;
            this._showAlertPopupNow.TransparentColor = System.Drawing.Color.Empty;
            this._showAlertPopupNow.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._showAlertPopupNow.UseCustomTextStringFormat = false;
            this._showAlertPopupNow.UseUserDefinedColorForArrowMark = true;
            this._showAlertPopupNow.UseUserDefinedColorForMenuButtonSeparator = true;
            this._showAlertPopupNow.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._showAlertPopupNow.Click += new System.EventHandler(this.RunAlertPopupInMainUiThread);
            // 
            // _groupBox10
            // 
            this._groupBox10.Controls.Add(this._numericUpDown3);
            this._groupBox10.Controls.Add(this._numericUpDown2);
            this._groupBox10.Controls.Add(this._label17);
            this._groupBox10.Controls.Add(this._label16);
            this._groupBox10.Controls.Add(this._checkBox2);
            this._groupBox10.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox10.Location = new System.Drawing.Point(432, 588);
            this._groupBox10.Name = "_groupBox10";
            this._groupBox10.Size = new System.Drawing.Size(336, 56);
            this._groupBox10.TabIndex = 8;
            this._groupBox10.TabStop = false;
            // 
            // _numericUpDown3
            // 
            this._numericUpDown3.Location = new System.Drawing.Point(152, 24);
            this._numericUpDown3.Maximum = new decimal(new int[] {
            850,
            0,
            0,
            0});
            this._numericUpDown3.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this._numericUpDown3.Name = "_numericUpDown3";
            this._numericUpDown3.Size = new System.Drawing.Size(72, 20);
            this._numericUpDown3.TabIndex = 3;
            this._numericUpDown3.Value = new decimal(new int[] {
            350,
            0,
            0,
            0});
            this._numericUpDown3.ValueChanged += new System.EventHandler(this.numericUpDown3_ValueChanged);
            // 
            // _numericUpDown2
            // 
            this._numericUpDown2.Location = new System.Drawing.Point(40, 24);
            this._numericUpDown2.Maximum = new decimal(new int[] {
            700,
            0,
            0,
            0});
            this._numericUpDown2.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this._numericUpDown2.Name = "_numericUpDown2";
            this._numericUpDown2.Size = new System.Drawing.Size(72, 20);
            this._numericUpDown2.TabIndex = 2;
            this._numericUpDown2.Value = new decimal(new int[] {
            350,
            0,
            0,
            0});
            this._numericUpDown2.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // _label17
            // 
            this._label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._label17.Location = new System.Drawing.Point(128, 24);
            this._label17.Name = "_label17";
            this._label17.Size = new System.Drawing.Size(24, 16);
            this._label17.TabIndex = 1;
            this._label17.Text = "Y :";
            // 
            // _label16
            // 
            this._label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._label16.Location = new System.Drawing.Point(16, 24);
            this._label16.Name = "_label16";
            this._label16.Size = new System.Drawing.Size(24, 16);
            this._label16.TabIndex = 0;
            this._label16.Text = "X :";
            // 
            // _checkBox2
            // 
            this._checkBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._checkBox2.Location = new System.Drawing.Point(16, -1);
            this._checkBox2.Name = "_checkBox2";
            this._checkBox2.Size = new System.Drawing.Size(232, 16);
            this._checkBox2.TabIndex = 9;
            this._checkBox2.Text = "Display popup window at custom location";
            this._checkBox2.CheckedChanged += new System.EventHandler(this.FactorsUpdated);
            // 
            // _groupBox11
            // 
            this._groupBox11.Controls.Add(this._button2);
            this._groupBox11.Controls.Add(this._textBox2);
            this._groupBox11.Controls.Add(this._checkBox3);
            this._groupBox11.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox11.Location = new System.Drawing.Point(16, 296);
            this._groupBox11.Name = "_groupBox11";
            this._groupBox11.Size = new System.Drawing.Size(408, 56);
            this._groupBox11.TabIndex = 10;
            this._groupBox11.TabStop = false;
            // 
            // _button2
            // 
            this._button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._button2.BorderColor = System.Drawing.Color.Black;
            this._button2.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._button2.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._button2.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._button2.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._button2.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._button2.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._button2.ContextMenuProperties.UseGradientPainting = true;
            this._button2.DefaultTheme = true;
            this._button2.DialogResult = System.Windows.Forms.DialogResult.None;
            this._button2.DrawMenuButtonSeparator = true;
            this._button2.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._button2.DropDownMenuItems = null;
            this._button2.EndColor = System.Drawing.Color.White;
            this._button2.IsRenderingTheme = true;
            this._button2.LinearGradientRenderingAngle = 90F;
            this._button2.Location = new System.Drawing.Point(296, 24);
            this._button2.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._button2.MenuButtonSeparatorLineHeight = -1;
            this._button2.Name = "_button2";
            this._button2.PushedEndColor = System.Drawing.Color.Silver;
            this._button2.PushedStartColor = System.Drawing.Color.White;
            this._button2.Size = new System.Drawing.Size(32, 20);
            this._button2.StartColor = System.Drawing.Color.Silver;
            this._button2.TabIndex = 13;
            this._button2.Text = "...";
            this._button2.TextStringFormat = null;
            this._button2.TransparentColor = System.Drawing.Color.Empty;
            this._button2.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._button2.UseCustomTextStringFormat = false;
            this._button2.UseUserDefinedColorForArrowMark = true;
            this._button2.UseUserDefinedColorForMenuButtonSeparator = true;
            this._button2.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._button2.Click += new System.EventHandler(this.CustomAlertPopupWindowImageChanged);
            // 
            // _textBox2
            // 
            this._textBox2.BackColor = System.Drawing.Color.White;
            this._textBox2.Location = new System.Drawing.Point(16, 24);
            this._textBox2.Name = "_textBox2";
            this._textBox2.ReadOnly = true;
            this._textBox2.Size = new System.Drawing.Size(272, 20);
            this._textBox2.TabIndex = 12;
            this._textBox2.Text = "notify.wav";
            // 
            // _checkBox3
            // 
            this._checkBox3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._checkBox3.Location = new System.Drawing.Point(16, 0);
            this._checkBox3.Name = "_checkBox3";
            this._checkBox3.Size = new System.Drawing.Size(232, 16);
            this._checkBox3.TabIndex = 11;
            this._checkBox3.Text = "Use custom image to display as Popup Alert";
            this._checkBox3.CheckedChanged += new System.EventHandler(this.AlertStylesUpdated);
            // 
            // _contextMenuStrip1
            // 
            this._contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._callSupportTeamToolStripMenuItem,
            this._toolStripSeparator1,
            this._toolStripMenuItem1,
            this._toolStripMenuItem2,
            this._toolStripSeparator2,
            this._toolStripMenuItem3,
            this._toolStripMenuItem4});
            this._contextMenuStrip1.Name = "_contextMenuStrip1";
            this._contextMenuStrip1.Size = new System.Drawing.Size(198, 126);
            // 
            // _callSupportTeamToolStripMenuItem
            // 
            this._callSupportTeamToolStripMenuItem.Name = "_callSupportTeamToolStripMenuItem";
            this._callSupportTeamToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this._callSupportTeamToolStripMenuItem.Text = "Call support team...";
            this._callSupportTeamToolStripMenuItem.Click += new System.EventHandler(this.CallSupportTeamToolStripMenuItemClick);
            // 
            // _toolStripSeparator1
            // 
            this._toolStripSeparator1.Name = "_toolStripSeparator1";
            this._toolStripSeparator1.Size = new System.Drawing.Size(194, 6);
            // 
            // _toolStripMenuItem1
            // 
            this._toolStripMenuItem1.Name = "_toolStripMenuItem1";
            this._toolStripMenuItem1.Size = new System.Drawing.Size(197, 22);
            this._toolStripMenuItem1.Text = "Generate build scripts...";
            this._toolStripMenuItem1.Click += new System.EventHandler(this.CallSupportTeamToolStripMenuItemClick);
            // 
            // _toolStripMenuItem2
            // 
            this._toolStripMenuItem2.Name = "_toolStripMenuItem2";
            this._toolStripMenuItem2.Size = new System.Drawing.Size(197, 22);
            this._toolStripMenuItem2.Text = "Assemble scripts...";
            this._toolStripMenuItem2.Click += new System.EventHandler(this.CallSupportTeamToolStripMenuItemClick);
            // 
            // _toolStripSeparator2
            // 
            this._toolStripSeparator2.Name = "_toolStripSeparator2";
            this._toolStripSeparator2.Size = new System.Drawing.Size(194, 6);
            // 
            // _toolStripMenuItem3
            // 
            this._toolStripMenuItem3.Name = "_toolStripMenuItem3";
            this._toolStripMenuItem3.Size = new System.Drawing.Size(197, 22);
            this._toolStripMenuItem3.Text = "Run build!";
            this._toolStripMenuItem3.Click += new System.EventHandler(this.CallSupportTeamToolStripMenuItemClick);
            // 
            // _toolStripMenuItem4
            // 
            this._toolStripMenuItem4.Name = "_toolStripMenuItem4";
            this._toolStripMenuItem4.Size = new System.Drawing.Size(197, 22);
            this._toolStripMenuItem4.Text = "Re-run reports now!";
            this._toolStripMenuItem4.Click += new System.EventHandler(this.CallSupportTeamToolStripMenuItemClick);
            // 
            // _button4
            // 
            this._button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._button4.BorderColor = System.Drawing.Color.Black;
            this._button4.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._button4.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._button4.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._button4.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._button4.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._button4.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._button4.ContextMenuProperties.UseGradientPainting = true;
            this._button4.DefaultTheme = true;
            this._button4.DialogResult = System.Windows.Forms.DialogResult.None;
            this._button4.DrawMenuButtonSeparator = true;
            this._button4.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._button4.DropDownMenuItems = null;
            this._button4.EndColor = System.Drawing.Color.White;
            this._button4.IsRenderingTheme = true;
            this._button4.LinearGradientRenderingAngle = 90F;
            this._button4.Location = new System.Drawing.Point(163, 677);
            this._button4.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._button4.MenuButtonSeparatorLineHeight = -1;
            this._button4.Name = "_button4";
            this._button4.PushedEndColor = System.Drawing.Color.Silver;
            this._button4.PushedStartColor = System.Drawing.Color.White;
            this._button4.Size = new System.Drawing.Size(261, 32);
            this._button4.StartColor = System.Drawing.Color.Silver;
            this._button4.TabIndex = 21;
            this._button4.Text = "Display BinaryAlertPopup using a worker thread";
            this._button4.TextStringFormat = null;
            this._button4.TransparentColor = System.Drawing.Color.Empty;
            this._button4.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._button4.UseCustomTextStringFormat = false;
            this._button4.UseUserDefinedColorForArrowMark = true;
            this._button4.UseUserDefinedColorForMenuButtonSeparator = true;
            this._button4.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._button4.Click += new System.EventHandler(this.RunALertPopupInADedicatedThread);
            // 
            // BinaryAlertPopupDemoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(795, 776);
            this.Controls.Add(this._button4);
            this.Controls.Add(this._groupBox11);
            this.Controls.Add(this._showAlertPopupNow);
            this.Controls.Add(this._groupBox10);
            this.Controls.Add(this._statusBar);
            this.Controls.Add(this._exit);
            this.Controls.Add(this._about);
            this.Controls.Add(this._groupBox8);
            this.Controls.Add(this._groupBox4);
            this.Controls.Add(this._groupBox3);
            this.Controls.Add(this._groupBox2);
            this.Controls.Add(this._groupBox1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "BinaryAlertPopupDemoForm";
            this.TitlebarText = "Binarymission AlertPopup Demo";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.FormLoad);
            this.TextChanged += new System.EventHandler(this.FormTextChanged);
            this._groupBox1.ResumeLayout(false);
            this._groupBox1.PerformLayout();
            this._groupBox2.ResumeLayout(false);
            this._groupBox3.ResumeLayout(false);
            this._groupBox3.PerformLayout();
            this._groupBox7.ResumeLayout(false);
            this._groupBox4.ResumeLayout(false);
            this._groupBox5.ResumeLayout(false);
            this._groupBox6.ResumeLayout(false);
            this._groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._numericUpDown1)).EndInit();
            this._groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._durationToShowAlertPopup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._animationWhileClosing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._animationWhileStarting)).EndInit();
            this._groupBox10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._numericUpDown2)).EndInit();
            this._groupBox11.ResumeLayout(false);
            this._groupBox11.PerformLayout();
            this._contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        
        #endregion
    }
}