﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using BinaryAlertPopupDemo.Properties;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.PopupControls;

namespace BinaryAlertPopupDemo
{
    public partial class BinaryAlertPopupDemoForm : ModernChromeWindow
    {
        private ContextMenu _menu;
        private MenuItem _item1;
        private MenuItem _item2;
        private MenuItem _item3;
        private MenuItem _item4;
        private MenuItem _item5;
        private MenuItem _item6;
        private MenuItem _item7;
        private int _animationWhileStartingDuration;
        private int _animationWhileClosingDuration;
        private int _durationToShowAlertPopupValue;
        private delegate void RunAlertPopupHandler(string text);

        public BinaryAlertPopupDemoForm()
        {
            InitializeComponent();
            InitialiseForm();
        }

        private void InitialiseForm()
        {
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;

            _bAlertPopup = new AlertPopup();
            _bAlertPopup.PopupCustomImageClicked += PopupCustomImageClicked;
            _bAlertPopup.PopupMessageTextClicked += AlertTextClicked;
            _bAlertPopup.PopupTitleTextClicked += PopupTitleTextClicked;
            _bAlertPopup.PopupExitButtonClicked += PopupExitButtonClicked;

            _menu = new ContextMenu();
            _item1 = new MenuItem("Call Support team...");
            _item2 = new MenuItem("-");
            _item3 = new MenuItem("&Generate Build scripts...");
            _item4 = new MenuItem("&Assemble scripts");
            _item5 = new MenuItem("-");
            _item6 = new MenuItem("Run &Build...");
            _item7 = new MenuItem("Re-run re&ports now!");

            _menu.MenuItems.Add(_item1);
            _menu.MenuItems.Add(_item2);
            _menu.MenuItems.Add(_item3);
            _menu.MenuItems.Add(_item4);
            _menu.MenuItems.Add(_item5);
            _menu.MenuItems.Add(_item6);
            _menu.MenuItems.Add(_item7);

            _item1.Click += MenuItem1Clicked;
            _item2.Click += MenuItem2Clicked;
            _item3.Click += MenuItem3Clicked;
            _item4.Click += MenuItem4Clicked;
            _item5.Click += MenuItem5Clicked;
            _item6.Click += MenuItem6Clicked;
            _item7.Click += MenuItem7Clicked;

            _bAlertPopup.ContextMenu = _menu;
        }

        private void FormLoad(object sender, EventArgs e)
        {
            // load defaults as supported by the control.

            _animationWhileStartingDuration = 500; _animationWhileClosingDuration = 500; _durationToShowAlertPopupValue = 3000;
            _popupWindowStyles.SelectedIndex = 0;
            _popupWindowDisappearingStyles.SelectedIndex = 2;
            _themeColors.SelectedIndex = 0;

            _customColorStyles.SelectedIndex = 1;
            _customColorStyles.Enabled = false;

            _groupBox9.Enabled = false;
            _groupBox6.Enabled = false;

            _bAlertPopup.CustomExitIcon = null;
            _bAlertPopup.CustomTitleIcon = null;
            _bAlertPopup.CanClickTitle = _alertTitleIsClickable.Checked;

            _numericUpDown2.Enabled = _checkBox2.Checked;
            _numericUpDown3.Enabled = _checkBox2.Checked;

            _textBox2.Text = string.Empty;
            _textBox2.Enabled = false;
            _button2.Enabled = false;

            _bAlertPopup.AlertPopupIsShownWhenMouseIsOver = true;
            _bAlertPopup.AlertPopupIsShownAgainWhenMousePointerIsOver = true;
            _bAlertPopup.ContextMenuShown += ContextMenuShown;

            #region Additional properties you could set...

            // Sample of properties that you can set.

            //this.bAlertPopup.EnableCustomUserPaint = true;
            //this.bAlertPopup.Paint +=new PaintEventHandler(MyCustomDraw);
            //this.bAlertPopup.MouseMove += new MouseEventHandler(AlertPopupMouseMoved);
            //this.bAlertPopup.MouseUp +=new MouseEventHandler(bAlertPopup_MouseUp);
            //this.bAlertPopup.CustomTitleIconLocation = new Point(135,35);
            //this.bAlertPopup.CustomTitleTextArea = new Rectangle(8, 15, 85,10);
            //this.bAlertPopup.CustomAlertTextArea = new Rectangle(8, 40, 185, 10);
            //this.bAlertPopup.CustomTitleIconAlignment = ContentAlignment.TopLeft;
            //this.bAlertPopup.StretchTitleIconToCoverTheEntireControlArea = true;

            _bAlertPopup.ContextMenuStrip = _contextMenuStrip1;

            // If you want to paint the alert pop-up window yourself, just set the control's EnableCustomUserPaint property to true, and 
            // subscribe to the control's Paint event and write your paint code.
            // Note that you can also setup the size of the alert pop-up window, to draw into.

            // Example:

            // bAlertPopup.EnableCustomUserPaint = true;
            // bAlertPopup.CustomUserWindowPaintSize = new Size(500, 380);
            // bAlertPopup.Paint += new PaintEventHandler(MyCustomPaintRoutine);

            // The features list does not stop here.
            // Now, after setting up the above, you can also start to add your custom controls into the alert pop-up window,
            // by simply preparing the layout of your other windows Forms controls, and add these to the alert popup's "Controls" collection.
            // There you go, your own custom form type window is ready to pop-up as an alert pop-up window!

            // For example:

            // Panel panel = new Panel();
            // TreeView treeview = new TreeView();
            // Now prepare your treeview control.
            // TextBox textBox = new TextBox();
            // Now prepare your textBox control.
            // Create and layout some more Windows Forms / custom controls

            // Now add these to BinaryAlertPopup Control's control collection...

            // bAlertPopup.Controls.AddRange(new Control[] { treeview, textBox /*, <your other control instances>*/ });

            // That is all to it! 
            // The BinaryAlertPopup will now host and display your controls collection in the way you have laid it out on the window surface
            // and display the configured alert pop-up.
            #endregion
        }

        private void MyCustomPaintRoutine(object sender, PaintEventArgs pe)
        {
            var grp = pe.Graphics;
            var bitmap = new Bitmap(_bAlertPopup.Bounds.Width, _bAlertPopup.Bounds.Height);

            using (var g = Graphics.FromImage(bitmap))
            {
                g.Clear(Color.Green);
                g.DrawRectangle(new Pen(Color.Red), g.VisibleClipBounds.X, g.VisibleClipBounds.Y,
                    g.VisibleClipBounds.Width - 1, g.VisibleClipBounds.Height - 1);
                g.FillRectangle(new SolidBrush(Color.Red), g.VisibleClipBounds.X, g.VisibleClipBounds.Y,
                    g.VisibleClipBounds.Width - 1, g.VisibleClipBounds.Height - 1);
                g.DrawRectangle(new Pen(Color.Green), g.VisibleClipBounds.X + 10, g.VisibleClipBounds.Y + 10,
                    g.VisibleClipBounds.Width - 20, g.VisibleClipBounds.Height - 20);
                g.FillRectangle(new SolidBrush(Color.Green), g.VisibleClipBounds.X + 10, g.VisibleClipBounds.Y + 10,
                    g.VisibleClipBounds.Width - 20, g.VisibleClipBounds.Height - 20);

                g.DrawString("Hi! I am now custom drawn! :-)", Font, new SolidBrush(Color.Yellow), new RectangleF(
                    g.VisibleClipBounds.X + 15, g.VisibleClipBounds.Y + 20, g.VisibleClipBounds.Width - 10, g.VisibleClipBounds.Height));
            }

            grp.DrawImage(bitmap, grp.VisibleClipBounds);
            bitmap.Dispose();
        }

        private void ChangeAlertNormalBodyTextColor(object sender, EventArgs e)
        {
            var colorDialog = new ColorDialog();

            if (DialogResult.Cancel != colorDialog.ShowDialog(this))
            {
                _bAlertPopup.AlertNormalBodyTextColor = colorDialog.Color;
            }
        }

        private void RunAlertPopupInMainUiThread(object sender, EventArgs e)
        {
            // A simple way to work with BinaryAlertPopup instance from within the main UI thread.

            try
            {
                if (!_checkBox2.Checked)
                    _bAlertPopup.Show(_alertPopupTitleText.Text, _alertPopupBodyText.Text, _animationWhileStartingDuration, _durationToShowAlertPopupValue, _animationWhileClosingDuration);
                else
                    _bAlertPopup.Show(_alertPopupTitleText.Text, _alertPopupBodyText.Text, _animationWhileStartingDuration, _durationToShowAlertPopupValue, _animationWhileClosingDuration
                        , new Point(Convert.ToInt32(_numericUpDown2.Value), Convert.ToInt32(_numericUpDown3.Value)));

                // Use this line of code below, if you want to keep the alert pop up displayed, until you deterministically call Hide() on it.

                if (_checkBox4.Checked)
                    _bAlertPopup.KeepShowingUntilHiddenDeterministically();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void RunBinaryAlertPopupInstance()
        {
            var args = new object[1];
            args[0] = "New instance from thread";

            // A typical way to display the BinaryAlertPopup, if displaying it via worker threads.
            _bAlertPopup.BeginInvoke(new RunAlertPopupHandler(RunAlertPopup), args);
        }

        private void RunAlertPopup(string text)
        {
            _bAlertPopup.Show("Invoked from a thread!", text);

            // Use this line of code below, if you want to keep the alert pop up displayed, until you deterministically call Hide() on it.
            if (_checkBox4.Checked)
                _bAlertPopup.KeepShowingUntilHiddenDeterministically();
        }

        private void UseCustomColorsCheckedChanged(object sender, EventArgs e)
        {
            if (_useCustomColors.Checked)
            {
                if (_customColorStyles.SelectedIndex == 0)
                {
                    _groupBox9.Enabled = false;
                    _groupBox6.Enabled = true;
                }
                else
                {
                    _groupBox9.Enabled = true;
                    _groupBox6.Enabled = false;
                }

                _themeColors.Enabled = false;
                _customColorStyles.Enabled = true;
                _bAlertPopup.DrawUsingCustomColors = true;
            }
        }

        private void UseBuiltInColorsCheckedChanged(object sender, EventArgs e)
        {
            if (_useBuiltInColors.Checked)
            {
                _bAlertPopup.DrawUsingCustomColors = false;
                _groupBox9.Enabled = false;
                _groupBox6.Enabled = false;
                _themeColors.Enabled = true;
                _customColorStyles.Enabled = false;
            }
        }

        private void CustomColorStylesSelectedIndexChanged(object sender, EventArgs e)
        {
            if (_customColorStyles.SelectedIndex == 0)
            {
                _groupBox6.Enabled = true;
                _groupBox9.Enabled = false;
                _bAlertPopup.DrawUsingColorType = CustomColorType.SpecificColor;
            }
            else
            {
                _groupBox6.Enabled = !true;
                _groupBox9.Enabled = !false;
                _bAlertPopup.DrawUsingColorType = CustomColorType.GradientColors;
            }
        }

        private void PopupWindowStylesSelectedIndexChanged(object sender, EventArgs e)
        {
            if (_popupWindowStyles.SelectedIndex == 1)
            {
                _useCustomColors.Checked = true;
            }
            else
            {
                _useBuiltInColors.Enabled = true;
            }

            _bAlertPopup.AlertPopupStyle = _popupWindowStyles.SelectedIndex == 0 ? AlertPopupStyle.Outlook : AlertPopupStyle.MSNMessenger;
        }

        private void ExitApplicationClicked(object sender, EventArgs e)
        {
            Close();
        }

        private void AnimationWhileStartingValueChanged(object sender, EventArgs e)
        {
            _animationWhileStartingDuration = Convert.ToInt32(_animationWhileStarting.Value);
        }

        private void AnimationWhileClosingValueChanged(object sender, EventArgs e)
        {
            _animationWhileClosingDuration = Convert.ToInt32(_animationWhileClosing.Value);
        }

        private void DurationToShowAlertPopupValueChanged(object sender, EventArgs e)
        {
            _durationToShowAlertPopupValue = Convert.ToInt32(_durationToShowAlertPopup.Value);
        }

        private void ShowAlertPopupWhenMouseIsOverCheckedChanged(object sender, EventArgs e)
        {
            _bAlertPopup.AlertPopupIsShownWhenMouseIsOver = _showAlertPopupWhenMouseIsOver.Checked;
        }

        private void ShowAlertPopupWhenMouseIsOverAndWindowIsClosingCheckedChanged(object sender, EventArgs e)
        {
            _bAlertPopup.AlertPopupIsShownAgainWhenMousePointerIsOver = _showAlertPopupWhenMouseIsOverAndWindowIsClosing.Checked;
        }

        private void DisplayExitIconCheckedChanged(object sender, EventArgs e)
        {
            _bAlertPopup.DisplayExitButton = _displayExitIcon.Checked;
        }

        private void AlertPopupTitleTextTextChanged(object sender, EventArgs e)
        {
            _bAlertPopup.AlertTitleText = _alertPopupTitleText.Text;
        }

        private void AlertPopupBodyTextTextChanged(object sender, EventArgs e)
        {
            _bAlertPopup.AlertBodyText = _alertPopupBodyText.Text;
        }

        private void PopupWindowDisappearingStylesSelectedIndexChanged(object sender, EventArgs e)
        {
            switch (_popupWindowDisappearingStyles.SelectedIndex)
            {
                case 0: _bAlertPopup.ControlDisappearingStyle = DisappearingStyle.VanishOut; break;
                case 1: _bAlertPopup.ControlDisappearingStyle = DisappearingStyle.SlideDown; break;
                case 2: _bAlertPopup.ControlDisappearingStyle = DisappearingStyle.VanishOutWhileSlidingDown; break;
            }
        }

        private void FormTextChanged(object sender, EventArgs e)
        {
            // Handle form text changed event.
        }

        private void SoundPlaybackFileChanged(object sender, EventArgs e)
        {
            _bAlertPopup.SoundPlayBackFile = _textBox1.Text;
        }

        private void TitleTextFontOnNormalClick(object sender, EventArgs e)
        {
            var fontDialog = new FontDialog();

            if (DialogResult.Cancel != fontDialog.ShowDialog(this))
            {
                _bAlertPopup.AlertNormalTitleFont = fontDialog.Font;
            }
        }

        private void TitleTextFontOnHoverClick(object sender, EventArgs e)
        {
            var fontDialog = new FontDialog();

            if (DialogResult.Cancel != fontDialog.ShowDialog(this))
            {
                _bAlertPopup.AlertOnHoverTitleFont = fontDialog.Font;
            }
        }

        private void TitleTextColorOnNormalClick(object sender, EventArgs e)
        {
            var colorDialog = new ColorDialog();

            if (DialogResult.Cancel != colorDialog.ShowDialog(this))
            {
                _bAlertPopup.AlertNormalTitleColor = colorDialog.Color;
            }
        }

        private void titleTextColorOnHover_Click(object sender, EventArgs e)
        {
            var colorDialog = new ColorDialog();

            if (DialogResult.Cancel != colorDialog.ShowDialog(this))
            {
                _bAlertPopup.AlertOnHoverTitleColor = colorDialog.Color;
            }
        }

        private void BodyTextFontOnNormalClick(object sender, EventArgs e)
        {
            var fontDialog = new FontDialog();

            if (DialogResult.Cancel != fontDialog.ShowDialog(this))
            {
                _bAlertPopup.AlertNormalBodyTextFont = fontDialog.Font;
            }
        }

        private void BodyTextFontOnHoverClick(object sender, EventArgs e)
        {
            var fontDialog = new FontDialog();

            if (DialogResult.Cancel != fontDialog.ShowDialog(this))
            {
                _bAlertPopup.AlertOnHoverBodyTextFont = fontDialog.Font;
            }
        }

        private void BodyTextColorOnHoverClick(object sender, EventArgs e)
        {
            var colorDialog = new ColorDialog();

            if (DialogResult.Cancel != colorDialog.ShowDialog(this))
            {
                _bAlertPopup.AlertOnHoverBodyTextColor = colorDialog.Color;
            }
        }

        private void AlertTextSelectionRectangleColorClick(object sender, EventArgs e)
        {
            var colorDialog = new ColorDialog();

            if (DialogResult.Cancel != colorDialog.ShowDialog(this))
            {
                _bAlertPopup.AlertTextSelectionRectangleColor = colorDialog.Color;
            }
        }

        private void CustomPopupTitleIconClick(object sender, EventArgs e)
        {
            var fileDialog = new OpenFileDialog { InitialDirectory = "." };

            if (DialogResult.Cancel != fileDialog.ShowDialog(this))
            {
                Icon ic = null;

                try
                {
                    ic = new Icon(fileDialog.FileName);
                }
                catch
                {
                    _bAlertPopup.CustomTitleIcon = new Bitmap/*Icon*/(fileDialog.FileName);
                    return;
                }

                _bAlertPopup.CustomTitleIcon = new Icon(fileDialog.FileName).ToBitmap();
            }
            else
                _bAlertPopup.CustomTitleIcon = null;
        }

        private void SoundPlaybackFileUpdateRequested(object sender, EventArgs e)
        {
            var fileDialog = new OpenFileDialog { Filter = @"Sound Wav files (*.wav) | *.wav", InitialDirectory = "." };

            if (DialogResult.Cancel != fileDialog.ShowDialog(this))
            {
                _bAlertPopup.SoundPlayBackFile = fileDialog.FileName;
                _textBox1.Text = fileDialog.FileName;
            }
            else
            {
                _bAlertPopup.SoundPlayBackFile = string.Empty;
                _textBox1.Text = string.Empty;
            }
        }

        private void StartColorClick(object sender, EventArgs e)
        {
            var colorDialog = new ColorDialog();

            if (DialogResult.Cancel != colorDialog.ShowDialog(this))
            {
                _bAlertPopup.StartColor = colorDialog.Color;
            }
        }

        private void EndColorClick(object sender, EventArgs e)
        {
            var colorDialog = new ColorDialog();

            if (DialogResult.Cancel != colorDialog.ShowDialog(this))
            {
                _bAlertPopup.EndColor = colorDialog.Color;
            }
        }

        private void UseThisSpecifiColorClick(object sender, EventArgs e)
        {
            var colorDialog = new ColorDialog();

            if (DialogResult.Cancel != colorDialog.ShowDialog(this))
            {
                _bAlertPopup.SpecificColor = colorDialog.Color;
            }
        }

        private void CustomExitIconClick(object sender, EventArgs e)
        {
            var fileDialog = new OpenFileDialog { Filter = @"Icon files (*.ico) | *.ico", InitialDirectory = "." };
            _bAlertPopup.CustomExitIcon = DialogResult.Cancel != fileDialog.ShowDialog(this) ? new Icon(fileDialog.FileName) : null;
        }

        private void ThemeColorsSelectedIndexChanged(object sender, EventArgs e)
        {
            switch (_themeColors.SelectedIndex)
            {
                case 0: _bAlertPopup.PopupAlertThemeColor = AlertPopupThemeColor.Blue; break;
                case 1: _bAlertPopup.PopupAlertThemeColor = AlertPopupThemeColor.OliveGreen; break;
                case 2: _bAlertPopup.PopupAlertThemeColor = AlertPopupThemeColor.Silver; break;
            }
        }

        private void NumericUpDown1ValueChanged(object sender, EventArgs e)
        {
            _bAlertPopup.GradientOrientationAngle = (float)_numericUpDown1.Value;
        }

        private void AlertTextClickableCheckedChanged(object sender, EventArgs e)
        {
            _bAlertPopup.CanClickAlertText = _alertTextClickable.Checked;
        }

        private void AlertTitleIsClickableCheckedChanged(object sender, EventArgs e)
        {
            _bAlertPopup.CanClickTitle = _alertTitleIsClickable.Checked;
        }

        private void ExitButtonClickableCheckedChanged(object sender, EventArgs e)
        {
            _bAlertPopup.CanClickExitButton = _exitButtonClickable.Checked;
        }

        private void ShowTextAreaRectangleUpdated(object sender, EventArgs e)
        {
            _bAlertPopup.ShowTextAreaRectangle = _showTextAreaRectangle.Checked;
        }

        private void PlaySoundWhenPopupIsDisplayUpdated(object sender, EventArgs e)
        {
            _textBox1.Enabled = _checkBox1.Checked;
            _button1.Enabled = _checkBox1.Checked;
            _bAlertPopup.PlaySoundWhenPopupIsDisplayed = _checkBox1.Checked;
        }

        private void AboutClick(object sender, EventArgs e)
        {
            const string about = "BinaryAlertPopup .NET control Demo!\n\nCopyright (C) Binarymission Technologies Limited, UK\n\nWeb home: http://www.binarymission.co.uk";
            MessageBox.Show(this, about, @"About BinaryAlertPopup .NET control Demo!");
        }

        private void AlertTextClicked(object sender, EventArgs e)
        {
            MessageBox.Show(this, @"BinaryAlertPopup .NET text has been clicked!", @"Message text clicked!");
        }

        private void PopupTitleTextClicked(object sender, EventArgs e)
        {
            MessageBox.Show(this, @"BinaryAlertPopup .NET title text has been clicked!", @"Message text clicked!");
        }

        private void FactorsUpdated(object sender, EventArgs e)
        {
            _numericUpDown2.Enabled = _checkBox2.Checked;
            _numericUpDown3.Enabled = _checkBox2.Checked;
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {

        }

        private void CustomAlertPopupWindowImageChanged(object sender, EventArgs e)
        {
            var fileDialog = new OpenFileDialog
            {
                Filter =
                    Resources.BinaryAlertPopupDemoForm_button2_Click_All_Image_Files____bmp___jpg___gif____bmp___jpg___gif_Bitmap_files____bmp______bmp__GIF_files____gif______gif__JPEG_files____jpeg______jpeg_JPG_files____jpg______jpg,
                InitialDirectory = "."
            };

            if (DialogResult.Cancel != fileDialog.ShowDialog(this))
            {
                _bAlertPopup.CustomAlertPopupWindowImage = new Bitmap(fileDialog.FileName);
                _textBox2.Text = fileDialog.FileName;
            }
            else
            {
                _bAlertPopup.CustomAlertPopupWindowImage = null;
                _textBox2.Text = string.Empty;
            }
        }

        private void AlertStylesUpdated(object sender, EventArgs e)
        {
            _bAlertPopup.UseCustomAlertPopupWindowImage = _checkBox3.Checked;
            _textBox2.Enabled = _checkBox3.Checked;
            _button2.Enabled = _checkBox3.Checked;
            _popupWindowStyles.Enabled = !_checkBox3.Checked;
            _groupBox5.Enabled = !_checkBox3.Checked;

            _alertTextClickable.Text = _checkBox3.Checked ? @"Custom Image can be clicked" : @"Alert text can be clicked";

            _showTextAreaRectangle.Enabled = !_checkBox3.Checked;
            _alertTitleIsClickable.Enabled = !_checkBox3.Checked;
            _customPopupTitleIcon.Enabled = !_checkBox3.Checked;
            _groupBox1.Enabled = !_checkBox3.Checked;
            _groupBox2.Enabled = !_checkBox3.Checked;
            _checkBox4.Enabled = !_checkBox3.Checked;
            _popupWindowDisappearingStyles.Enabled = true;
        }

        private void PopupCustomImageClicked(object sender, CustomAlertPopupWindowImageClickedEventArgs e)
        {
            MessageBox.Show(this, @"Image clicked", @"X=" + e.MouseEventArgs.X + @" Y=" + e.MouseEventArgs.Y);
        }

        private void PopupExitButtonClicked(object sender, EventArgs e)
        {
            MessageBox.Show(this, @"Exit button clicked", @"Exit!");
        }

        private void ContextMenuShown(object sender, ref bool cancelContextMenuDisplayNow)
        {
            // Handle context menu shown event.
        }

        private void MenuItem1Clicked(object sender, EventArgs e)
        {
            PerformCleanup(sender);
        }

        private void PerformCleanup(object sender)
        {
            var menuItem = sender as MenuItem;
            if (menuItem != null) MessageBox.Show(this, @"Clicked """ + menuItem.Text + @"""");
            _bAlertPopup.CleanUpUponContextMenuItemClicked();
        }

        private void MenuItem2Clicked(object sender, EventArgs e)
        {
            PerformCleanup(sender);
        }

        private void MenuItem3Clicked(object sender, EventArgs e)
        {
            PerformCleanup(sender);
        }

        private void MenuItem4Clicked(object sender, EventArgs e)
        {
            PerformCleanup(sender);
        }

        private void MenuItem5Clicked(object sender, EventArgs e)
        {
            PerformCleanup(sender);
        }

        private void MenuItem6Clicked(object sender, EventArgs e)
        {
            PerformCleanup(sender);
        }

        private void MenuItem7Clicked(object sender, EventArgs e)
        {
            PerformCleanup(sender);
        }

        private void AlertChevronMenuFormDisplayed(object sender, EventArgs e)
        {
            ChevronMenuForm.DrawUsingGradientColors = _bAlertPopup.FillContextMenuDropDownChevronRectangleWithGradientColors;
            ChevronMenuForm.ChevronButtonColor = _bAlertPopup.ContextMenuDropDownChevronColor;
            ChevronMenuForm.OrientationAngle = _bAlertPopup.GradientOrientationAngleToUseForFillingDropDownChevronRectangle;
            ChevronMenuForm.StartColor = _bAlertPopup.StartColorToUseForFillingContextMenuDropDownChevronRectangleWithGradientColors;
            ChevronMenuForm.EndColor = _bAlertPopup.EndColorToUseForFillingContextMenuDropDownChevronRectangleWithGradientColors;
            ChevronMenuForm.SingleColor = _bAlertPopup.ColorToUseForFillingContextMenuDropDownChevronRectangleWithSingleColor;

            var cForm = new ChevronMenuForm();
            cForm.ShowDialog();

            _bAlertPopup.FillContextMenuDropDownChevronRectangleWithGradientColors =
                ChevronMenuForm.DrawUsingGradientColors;
            _bAlertPopup.ContextMenuDropDownChevronColor = ChevronMenuForm.ChevronButtonColor;
            _bAlertPopup.GradientOrientationAngleToUseForFillingDropDownChevronRectangle =
                ChevronMenuForm.OrientationAngle;
            _bAlertPopup.StartColorToUseForFillingContextMenuDropDownChevronRectangleWithGradientColors =
                ChevronMenuForm.StartColor;
            _bAlertPopup.EndColorToUseForFillingContextMenuDropDownChevronRectangleWithGradientColors =
                ChevronMenuForm.EndColor;
            _bAlertPopup.ColorToUseForFillingContextMenuDropDownChevronRectangleWithSingleColor =
                ChevronMenuForm.SingleColor;
        }

        private void PopupExitButtonClicked(object sender, ref bool cancelNow)
        {
            // Run your logic for handling Popup exited event
        }

        private void AlertPopupMouseMoved(object sender, MouseEventArgs e)
        {
            _bAlertPopup.KeepShowingUntilHiddenDeterministically();
        }

        private void AllowUserToDragDropPopupWindowChanged(object sender, EventArgs e)
        {
            _bAlertPopup.AllowUserToDragDropPopupWindow = _checkBox5.Checked;
        }

        private void CallSupportTeamToolStripMenuItemClick(object sender, EventArgs e)
        {
            var toolStripMenuItem = sender as ToolStripMenuItem;
            if (toolStripMenuItem != null)
                MessageBox.Show(this, @"Clicked """ + toolStripMenuItem.Text + @"""");
            _bAlertPopup.CleanUpUponContextMenuItemClicked();
        }

        private void RunALertPopupInADedicatedThread(object sender, EventArgs e)
        {
            // A simple "threaded" way of working with BinaryAlertPopup instance.

            var tStart = new ThreadStart(RunBinaryAlertPopupInstance);
            var thread = new Thread(tStart);
            thread.Start();
        }
    }
}
