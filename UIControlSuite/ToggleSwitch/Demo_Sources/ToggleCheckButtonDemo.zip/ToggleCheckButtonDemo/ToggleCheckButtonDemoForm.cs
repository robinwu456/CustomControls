﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.ToggleControls;
using ToggleCheckButtonDemo.Properties;

namespace ToggleCheckButtonDemo
{
    public partial class ToggleCheckButtonDemoForm : ModernChromeWindow
    {
        public ToggleCheckButtonDemoForm()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = Resources.Form1_Form1_ToggleCheckButton_Control_Demo___Binarymission_Technologies__UK_;
        }

        private void AppExitHandler(object sender, EventArgs e)
        {
            Close();
        }

        private void chkToggleControlState_CheckedChanged(object sender, EventArgs e)
        {
            foreach (var instance in Controls)
            {
                if (instance is ToggleSwitch)
                {
                    (instance as ToggleSwitch).IsChecked = chkToggleControlState.Checked;
                }
            }
        }

        private void toggleSwitchWin8_Toggled(object sender, EventArgs e)
        {
            toggleControlStatus.Text = toggleSwitchWin8.IsChecked ? "On" : "Off";

            // Do whatever else you may want to do upon a toggle state change. say for example...

            //toggleSwitchWin8.ToggleStickColor = toggleSwitchWin8.IsChecked ? Color.OrangeRed : Color.DarkGray;
            //toggleSwitchWin8.InnerBorderColor = Color.White;
            //toggleSwitchWin8.OuterBorderColor = toggleSwitchWin8.IsChecked ? Color.LightSalmon : Color.LightGray;
            //toggleSwitchWin8.BackgroundStartColor = Color.White;
            //toggleSwitchWin8.BackgroundEndColor = toggleSwitchWin8.IsChecked ? Color.Tomato : Color.DarkGray;
        }

        private void win8ToggleSwitch3_Toggled(object sender, EventArgs e)
        {
            label15.Text = win8ToggleSwitch3.IsChecked ? "On" : "Off";
        }

        private void chkWin8SwitchIsChecked_CheckedChanged(object sender, EventArgs e)
        {
            toggleSwitchWin8.IsChecked = chkWin8SwitchIsChecked.Checked;
        }

        private void chkWin8SwitchDrawGap_CheckedChanged(object sender, EventArgs e)
        {
            toggleSwitchWin8.ShouldDrawGapBetweenSwitchStickAndTrack = chkWin8SwitchDrawGap.Checked;
        }

        private void chkWin8SwitchDrawFocus_CheckedChanged(object sender, EventArgs e)
        {
            toggleSwitchWin8.ShouldDrawFocusRectangleWhenFocused = chkWin8SwitchDrawFocus.Checked;
        }

        private void btnWin8SwitchStickColor_Click(object sender, EventArgs e)
        {
            if (win8ToggleSwitchColorDialog1.ShowDialog(this) == DialogResult.OK)
            {
                toggleSwitchWin8.ToggleStickColor = win8ToggleSwitchColorDialog1.Color;
            }
        }

        private void btnWin8SwitchOuterBorder_Click(object sender, EventArgs e)
        {
            if (win8OuterBorderColorDialog1.ShowDialog(this) == DialogResult.OK)
            {
                toggleSwitchWin8.OuterBorderColor = win8OuterBorderColorDialog1.Color;
            }
        }

        private void btnWin8SwitchStartColor_Click(object sender, EventArgs e)
        {
            if (win8BackgroundStartColorDialog1.ShowDialog(this) == DialogResult.OK)
            {
                toggleSwitchWin8.BackgroundStartColor = win8BackgroundStartColorDialog1.Color;
            }
        }

        private void btnWin8SwitchEndColor_Click(object sender, EventArgs e)
        {
            if (win8BackgroundEndColorDialog1.ShowDialog(this) == DialogResult.OK)
            {
                toggleSwitchWin8.BackgroundEndColor = win8BackgroundEndColorDialog1.Color;
            }
        }

        private void btnWin8SwitchInnerBorderColor_Click(object sender, EventArgs e)
        {
            if (win8InnerBorderColorDialog1.ShowDialog(this) == DialogResult.OK)
            {
                toggleSwitchWin8.InnerBorderColor = win8InnerBorderColorDialog1.Color;
            }
        }

        private void Win8SwitchStickWidth_ValueChanged(object sender, EventArgs e)
        {
            toggleSwitchWin8.ToggleSwitchStickWidth = (int) win8SwitchStickWidth.Value;
        }

        private void win8SwitchGapWidth_ValueChanged(object sender, EventArgs e)
        {
            toggleSwitchWin8.SwitchStickControlGapWidth = (int)win8SwitchGapWidth.Value;
        }

        private void win8SwitchOuterBorderThickness_ValueChanged(object sender, EventArgs e)
        {
            toggleSwitchWin8.OuterBorderThickness = (int)win8SwitchOuterBorderThickness.Value;
        }

        private void win8SwitchInnerBorderThickness_ValueChanged(object sender, EventArgs e)
        {
            toggleSwitchWin8.InnerBorderThickness = (int)win8SwitchInnerBorderThickness.Value;
        }

        private void btnWin8SwitchUnCheckedStickColor_Click(object sender, EventArgs e)
        {
            if (win8ToggleSwitchColorDialog2.ShowDialog(this) == DialogResult.OK)
            {
                toggleSwitchWin8.ToggleStickColorUnchecked = win8ToggleSwitchColorDialog2.Color;
            }
        }

        private void btnWin8SwitchUnCheckedOuterBorderColor_Click(object sender, EventArgs e)
        {
            if (win8OuterBorderColorDialog2.ShowDialog(this) == DialogResult.OK)
            {
                toggleSwitchWin8.OuterBorderColorUnchecked = win8OuterBorderColorDialog2.Color;
            }
        }

        private void btnWin8SwitchUnCheckedStartColor_Click(object sender, EventArgs e)
        {
            if (win8BackgroundStartColorDialog2.ShowDialog(this) == DialogResult.OK)
            {
                toggleSwitchWin8.BackgroundStartColorUnchecked = win8BackgroundStartColorDialog2.Color;
            }
        }

        private void btnWin8SwitchUnCheckedEndColor_Click(object sender, EventArgs e)
        {
            if (win8BackgroundEndColorDialog2.ShowDialog(this) == DialogResult.OK)
            {
                toggleSwitchWin8.BackgroundEndColorUnchecked = win8BackgroundEndColorDialog2.Color;
            }
        }

        private void btnWin8SwitchUnCheckedInnerBorderColor_Click(object sender, EventArgs e)
        {
            if (win8InnerBorderColorDialog2.ShowDialog(this) == DialogResult.OK)
            {
                toggleSwitchWin8.InnerBorderColorUnchecked = win8InnerBorderColorDialog2.Color;
            }
        }

        private void AppExitCommandInvokerHandler(object sender, EventArgs e)
        {
            Close();
        }
    }
}
