﻿using Binarymission.WinForms.Controls.TabControls;
using System.Drawing;

namespace ToggleCheckButtonDemo
{
    partial class ToggleCheckButtonDemoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Drawing.StringFormat stringFormat1 = new System.Drawing.StringFormat();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ToggleCheckButtonDemoForm));
            this.win8ToggleSwitchColorDialog1 = new System.Windows.Forms.ColorDialog();
            this.win8OuterBorderColorDialog1 = new System.Windows.Forms.ColorDialog();
            this.win8InnerBorderColorDialog1 = new System.Windows.Forms.ColorDialog();
            this.win8BackgroundStartColorDialog1 = new System.Windows.Forms.ColorDialog();
            this.win8BackgroundEndColorDialog1 = new System.Windows.Forms.ColorDialog();
            this.binaryPowerTabStrip1 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip();
            this.binaryPowerTabPage1 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.chkToggleControlState = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.toggleCheckControl1 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl3 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl4 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl5 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl6 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl7 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl8 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl2 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl9 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl10 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl19 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl12 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl20 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl11 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl17 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl18 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl15 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl16 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl14 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.toggleCheckControl13 = new Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch();
            this.binaryPowerTabPage2 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnWin8SwitchUnCheckedInnerBorderColor = new System.Windows.Forms.Button();
            this.btnWin8SwitchInnerBorderColor = new System.Windows.Forms.Button();
            this.chkWin8SwitchDrawGap = new System.Windows.Forms.CheckBox();
            this.btnWin8SwitchStickColor = new System.Windows.Forms.Button();
            this.btnWin8SwitchOuterBorder = new System.Windows.Forms.Button();
            this.btnWin8SwitchStartColor = new System.Windows.Forms.Button();
            this.btnWin8SwitchEndColor = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.chkWin8SwitchIsChecked = new System.Windows.Forms.CheckBox();
            this.chkWin8SwitchDrawFocus = new System.Windows.Forms.CheckBox();
            this.btnWin8SwitchUnCheckedEndColor = new System.Windows.Forms.Button();
            this.win8SwitchStickWidth = new System.Windows.Forms.NumericUpDown();
            this.btnWin8SwitchUnCheckedStartColor = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.btnWin8SwitchUnCheckedOuterBorderColor = new System.Windows.Forms.Button();
            this.win8SwitchGapWidth = new System.Windows.Forms.NumericUpDown();
            this.btnWin8SwitchUnCheckedStickColor = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.win8SwitchOuterBorderThickness = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.win8SwitchInnerBorderThickness = new System.Windows.Forms.NumericUpDown();
            this.toggleControlStatus = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.toggleSwitchWin8 = new Binarymission.WinForms.Controls.ToggleControls.Win8ToggleSwitch();
            this.win8ToggleSwitch1 = new Binarymission.WinForms.Controls.ToggleControls.Win8ToggleSwitch();
            this.win8ToggleSwitch2 = new Binarymission.WinForms.Controls.ToggleControls.Win8ToggleSwitch();
            this.win8ToggleSwitch4 = new Binarymission.WinForms.Controls.ToggleControls.Win8ToggleSwitch();
            this.win8ToggleSwitch3 = new Binarymission.WinForms.Controls.ToggleControls.Win8ToggleSwitch();
            this.win8ToggleSwitchColorDialog2 = new System.Windows.Forms.ColorDialog();
            this.win8OuterBorderColorDialog2 = new System.Windows.Forms.ColorDialog();
            this.win8InnerBorderColorDialog2 = new System.Windows.Forms.ColorDialog();
            this.win8BackgroundStartColorDialog2 = new System.Windows.Forms.ColorDialog();
            this.win8BackgroundEndColorDialog2 = new System.Windows.Forms.ColorDialog();
            this.appExitCmdInvoker = new System.Windows.Forms.Button();
            this.binaryPowerTabStrip1.SuspendLayout();
            this.binaryPowerTabPage1.SuspendLayout();
            this.binaryPowerTabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.win8SwitchStickWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.win8SwitchGapWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.win8SwitchOuterBorderThickness)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.win8SwitchInnerBorderThickness)).BeginInit();
            this.SuspendLayout();
            // 
            // binaryPowerTabStrip1
            // 
            this.binaryPowerTabStrip1.Cursor = System.Windows.Forms.Cursors.Default;
            this.binaryPowerTabStrip1.CustomEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip1.CustomStartColor = System.Drawing.Color.LightSeaGreen;
            this.binaryPowerTabStrip1.DrawBorderAroundTabStrip = false;
            this.binaryPowerTabStrip1.DrawTabPageOnTopOfEachOther = false;
            this.binaryPowerTabStrip1.EmptySpaceLengthBeforeTheFirstTabPage = 8;
            this.binaryPowerTabStrip1.EnableAutomaticUpdateOfTabPagesHeaderSize = true;
            this.binaryPowerTabStrip1.EnableControlledLayoutRendering = false;
            this.binaryPowerTabStrip1.EnableDragAndDropOfTabPages = false;
            this.binaryPowerTabStrip1.EnableTabPageLevelCloseButtonRendering = false;
            this.binaryPowerTabStrip1.ExtendedWindowsXPRenderingFirstColor = System.Drawing.Color.Green;
            this.binaryPowerTabStrip1.ExtendedWindowsXPRenderingSecondColor = System.Drawing.Color.LightBlue;
            this.binaryPowerTabStrip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabStrip1.HeaderFont = null;
            this.binaryPowerTabStrip1.HeaderTextCloseButtonExtraGap = 8;
            this.binaryPowerTabStrip1.IsBackgroundTransparent = false;
            this.binaryPowerTabStrip1.KeepShowingTooltipEvenWhenMousePointerIsMoving = false;
            this.binaryPowerTabStrip1.Location = new System.Drawing.Point(10, 12);
            this.binaryPowerTabStrip1.Name = "binaryPowerTabStrip1";
            this.binaryPowerTabStrip1.NewlyAddedPagesAreLocatedAtLeftCorner = false;
            this.binaryPowerTabStrip1.PreventInvalidation = false;
            this.binaryPowerTabStrip1.RenderFullTextForTabPageHeader = false;
            this.binaryPowerTabStrip1.SelectedPageHeaderTextIsRenderedBold = false;
            this.binaryPowerTabStrip1.ShouldAutoSizeTabs = false;
            this.binaryPowerTabStrip1.ShouldDrawTabPageHeaderInMultiLines = false;
            this.binaryPowerTabStrip1.ShouldUpdateUponParentMove = false;
            this.binaryPowerTabStrip1.ShouldUpdateUponParentResize = false;
            this.binaryPowerTabStrip1.ShowToolTip = true;
            this.binaryPowerTabStrip1.Size = new System.Drawing.Size(749, 617);
            this.binaryPowerTabStrip1.TabBottomOrientationCloseButtonPosition = Binarymission.WinForms.Controls.TabControls.CloseButtonPosition.Bottom;
            stringFormat1.Alignment = System.Drawing.StringAlignment.Center;
            stringFormat1.FormatFlags = System.Drawing.StringFormatFlags.NoWrap;
            stringFormat1.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat1.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat1.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
            this.binaryPowerTabStrip1.TabHeaderStringFormat = stringFormat1;
            this.binaryPowerTabStrip1.TabIndex = 80;
            this.binaryPowerTabStrip1.TabPageBorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabStrip1.TabPageCloseButtonMouseEnterColor = System.Drawing.Color.Red;
            this.binaryPowerTabStrip1.TabPageCloseButtonRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPageCloseButtonRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPageCurrentSelectionIndicatorEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip1.TabPageCurrentSelectionIndicatorStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.binaryPowerTabStrip1.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.binaryPowerTabStrip1.TabPageHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPageHeaderHeight = 24;
            this.binaryPowerTabStrip1.TabPageHeaderShowsSideBar = false;
            this.binaryPowerTabStrip1.TabPageHeaderTextFontOverridesControlDefault = false;
            this.binaryPowerTabStrip1.TabPageHeaderWidth = 200;
            this.binaryPowerTabStrip1.TabPages.AddRange(new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage[] {
            this.binaryPowerTabPage1,
            this.binaryPowerTabPage2});
            this.binaryPowerTabStrip1.TabPagesCloseButtonColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPagesHaveGapBetweenThem = false;
            this.binaryPowerTabStrip1.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabStrip1.TabPagesOverflowCalculationStrategy = Binarymission.WinForms.Controls.TabControls.TabPagesOverflowCalculationStrategy.Pessimistic;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuDropDownColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuGlyphActiveRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPagesRenderingLocation = Binarymission.WinForms.Controls.TabControls.TabPagesRenderingLocation.Top;
            this.binaryPowerTabStrip1.TabRenderingStyle = Binarymission.WinForms.Controls.TabControls.RenderingStyle.Custom;
            this.binaryPowerTabStrip1.TabsOverflowMode = Binarymission.WinForms.Controls.TabControls.OverflowMode.Menu;
            this.binaryPowerTabStrip1.Text = "binaryPowerTabStrip1";
            this.binaryPowerTabStrip1.ThemeBorderColorCanBeOverridden = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.AutomaticDelay = 500;
            this.binaryPowerTabStrip1.ToolTipConfiguration.AutoPopDelay = 5000;
            this.binaryPowerTabStrip1.ToolTipConfiguration.BackColor = System.Drawing.SystemColors.Info;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.ToolTipConfiguration.InitialDelay = 500;
            this.binaryPowerTabStrip1.ToolTipConfiguration.IsBalloon = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ReshowDelay = 100;
            this.binaryPowerTabStrip1.ToolTipConfiguration.StripAmpersands = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ToolTipIcon = System.Windows.Forms.ToolTipIcon.None;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ToolTipTitle = "";
            this.binaryPowerTabStrip1.ToolTipConfiguration.UseAnimation = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.UseFading = false;
            this.binaryPowerTabStrip1.UseTabCurrentSelectionIndicatorColor = true;
            // 
            // binaryPowerTabPage1
            // 
            this.binaryPowerTabPage1.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage1.BorderColor = System.Drawing.Color.Silver;
            this.binaryPowerTabPage1.BorderSize = 1;
            this.binaryPowerTabPage1.Controls.Add(this.label9);
            this.binaryPowerTabPage1.Controls.Add(this.label1);
            this.binaryPowerTabPage1.Controls.Add(this.label2);
            this.binaryPowerTabPage1.Controls.Add(this.label3);
            this.binaryPowerTabPage1.Controls.Add(this.label4);
            this.binaryPowerTabPage1.Controls.Add(this.label5);
            this.binaryPowerTabPage1.Controls.Add(this.label6);
            this.binaryPowerTabPage1.Controls.Add(this.label7);
            this.binaryPowerTabPage1.Controls.Add(this.label8);
            this.binaryPowerTabPage1.Controls.Add(this.chkToggleControlState);
            this.binaryPowerTabPage1.Controls.Add(this.label10);
            this.binaryPowerTabPage1.Controls.Add(this.label11);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl1);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl3);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl4);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl5);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl6);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl7);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl8);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl2);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl9);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl10);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl19);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl12);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl20);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl11);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl17);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl18);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl15);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl16);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl14);
            this.binaryPowerTabPage1.Controls.Add(this.toggleCheckControl13);
            this.binaryPowerTabPage1.CurrentlySelected = true;
            this.binaryPowerTabPage1.CustomEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.binaryPowerTabPage1.CustomStartColor = System.Drawing.Color.LightSeaGreen;
            this.binaryPowerTabPage1.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage1.IsBackgroundTransparent = false;
            this.binaryPowerTabPage1.IsHeaderEnabled = true;
            this.binaryPowerTabPage1.Name = "binaryPowerTabPage1";
            this.binaryPowerTabPage1.Size = new System.Drawing.Size(747, 591);
            this.binaryPowerTabPage1.TabIndex = 0;
            this.binaryPowerTabPage1.TabPageContentIsDirty = false;
            this.binaryPowerTabPage1.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.Text = "ToggleSwitch control";
            this.binaryPowerTabPage1.ToolTipText = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(27, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(501, 15);
            this.label9.TabIndex = 22;
            this.label9.Text = "ToggleCheckControl instances: (with custom set color for Mouse hover color):";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(255, 428);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 15);
            this.label1.TabIndex = 11;
            this.label1.Text = "Control setup in various sizes:";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(371, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(368, 23);
            this.label2.TabIndex = 12;
            this.label2.Text = "Conrol supporting custom images for Checked/Unchecked states:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(473, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 15);
            this.label3.TabIndex = 13;
            this.label3.Text = "Without border";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(473, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 15);
            this.label4.TabIndex = 14;
            this.label4.Text = "With border";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(137, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 15);
            this.label5.TabIndex = 15;
            this.label5.Text = "Without border";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(138, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 15);
            this.label6.TabIndex = 16;
            this.label6.Text = "With border";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(366, 236);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(354, 21);
            this.label7.TabIndex = 17;
            this.label7.Text = "With custom colors for Checked && Unchecked states:";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(137, 174);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(132, 19);
            this.label8.TabIndex = 18;
            this.label8.Text = "With custom set Font";
            // 
            // chkToggleControlState
            // 
            this.chkToggleControlState.AutoSize = true;
            this.chkToggleControlState.Location = new System.Drawing.Point(33, 542);
            this.chkToggleControlState.Name = "chkToggleControlState";
            this.chkToggleControlState.Size = new System.Drawing.Size(255, 17);
            this.chkToggleControlState.TabIndex = 23;
            this.chkToggleControlState.Text = "Toggle check states in controls instances above";
            this.chkToggleControlState.UseVisualStyleBackColor = true;
            this.chkToggleControlState.CheckedChanged += new System.EventHandler(this.chkToggleControlState_CheckedChanged);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(50, 562);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(657, 17);
            this.label10.TabIndex = 24;
            this.label10.Text = "(Apart from the built-in mouse click based state changing, this illustrates the a" +
    "bility to programmatically toggle the control\'s checked state)";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(30, 235);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(344, 22);
            this.label11.TabIndex = 25;
            this.label11.Text = "With custom set Checked/Unchecked state text:";
            // 
            // toggleCheckControl1
            // 
            this.toggleCheckControl1.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl1.CheckedStateBackColor = System.Drawing.Color.Silver;
            this.toggleCheckControl1.CheckedStateImage = null;
            this.toggleCheckControl1.CheckedText = "ON";
            this.toggleCheckControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl1.GradientColor = System.Drawing.Color.Gainsboro;
            this.toggleCheckControl1.IsChecked = false;
            this.toggleCheckControl1.Location = new System.Drawing.Point(32, 60);
            this.toggleCheckControl1.Name = "toggleCheckControl1";
            this.toggleCheckControl1.OnHoverBackColor = System.Drawing.Color.Gainsboro;
            this.toggleCheckControl1.ShouldDrawBorder = false;
            this.toggleCheckControl1.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl1.Size = new System.Drawing.Size(86, 31);
            this.toggleCheckControl1.TabIndex = 0;
            this.toggleCheckControl1.Text = "toggleCheckControl1";
            this.toggleCheckControl1.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.toggleCheckControl1.UnCheckedStateImage = null;
            this.toggleCheckControl1.UnCheckedText = "OFF";
            // 
            // toggleCheckControl3
            // 
            this.toggleCheckControl3.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl3.CheckedStateBackColor = System.Drawing.Color.Maroon;
            this.toggleCheckControl3.CheckedStateImage = null;
            this.toggleCheckControl3.CheckedText = "UP";
            this.toggleCheckControl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.toggleCheckControl3.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(167)))), ((int)(((byte)(167)))));
            this.toggleCheckControl3.IsChecked = false;
            this.toggleCheckControl3.Location = new System.Drawing.Point(159, 291);
            this.toggleCheckControl3.Name = "toggleCheckControl3";
            this.toggleCheckControl3.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(167)))), ((int)(((byte)(167)))));
            this.toggleCheckControl3.ShouldDrawBorder = true;
            this.toggleCheckControl3.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl3.Size = new System.Drawing.Size(113, 29);
            this.toggleCheckControl3.TabIndex = 2;
            this.toggleCheckControl3.Text = "toggleCheckControl3";
            this.toggleCheckControl3.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(199)))), ((int)(((byte)(192)))));
            this.toggleCheckControl3.UnCheckedStateImage = null;
            this.toggleCheckControl3.UnCheckedText = "DOWN";
            // 
            // toggleCheckControl4
            // 
            this.toggleCheckControl4.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl4.CheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.toggleCheckControl4.CheckedStateImage = null;
            this.toggleCheckControl4.CheckedText = "ON";
            this.toggleCheckControl4.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl4.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(167)))), ((int)(((byte)(167)))));
            this.toggleCheckControl4.IsChecked = false;
            this.toggleCheckControl4.Location = new System.Drawing.Point(32, 168);
            this.toggleCheckControl4.Name = "toggleCheckControl4";
            this.toggleCheckControl4.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(167)))), ((int)(((byte)(167)))));
            this.toggleCheckControl4.ShouldDrawBorder = true;
            this.toggleCheckControl4.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl4.Size = new System.Drawing.Size(86, 29);
            this.toggleCheckControl4.TabIndex = 3;
            this.toggleCheckControl4.Text = "toggleCheckControl4";
            this.toggleCheckControl4.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(189)))), ((int)(((byte)(185)))));
            this.toggleCheckControl4.UnCheckedStateImage = null;
            this.toggleCheckControl4.UnCheckedText = "OFF";
            // 
            // toggleCheckControl5
            // 
            this.toggleCheckControl5.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl5.CheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.toggleCheckControl5.CheckedStateImage = null;
            this.toggleCheckControl5.CheckedText = "ON";
            this.toggleCheckControl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.toggleCheckControl5.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(222)))), ((int)(((byte)(189)))));
            this.toggleCheckControl5.IsChecked = false;
            this.toggleCheckControl5.Location = new System.Drawing.Point(30, 291);
            this.toggleCheckControl5.Name = "toggleCheckControl5";
            this.toggleCheckControl5.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(222)))), ((int)(((byte)(189)))));
            this.toggleCheckControl5.ShouldDrawBorder = true;
            this.toggleCheckControl5.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl5.Size = new System.Drawing.Size(109, 29);
            this.toggleCheckControl5.TabIndex = 4;
            this.toggleCheckControl5.Text = "toggleCheckControl5";
            this.toggleCheckControl5.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.toggleCheckControl5.UnCheckedStateImage = null;
            this.toggleCheckControl5.UnCheckedText = "OFF";
            // 
            // toggleCheckControl6
            // 
            this.toggleCheckControl6.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl6.CheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.toggleCheckControl6.CheckedStateImage = null;
            this.toggleCheckControl6.CheckedText = "Y";
            this.toggleCheckControl6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl6.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.toggleCheckControl6.IsChecked = false;
            this.toggleCheckControl6.Location = new System.Drawing.Point(323, 460);
            this.toggleCheckControl6.Name = "toggleCheckControl6";
            this.toggleCheckControl6.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.toggleCheckControl6.ShouldDrawBorder = true;
            this.toggleCheckControl6.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl6.Size = new System.Drawing.Size(146, 21);
            this.toggleCheckControl6.TabIndex = 5;
            this.toggleCheckControl6.Text = "toggleCheckControl6";
            this.toggleCheckControl6.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.toggleCheckControl6.UnCheckedStateImage = null;
            this.toggleCheckControl6.UnCheckedText = "N";
            // 
            // toggleCheckControl7
            // 
            this.toggleCheckControl7.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl7.CheckedStateBackColor = System.Drawing.Color.Green;
            this.toggleCheckControl7.CheckedStateImage = null;
            this.toggleCheckControl7.CheckedText = "Y";
            this.toggleCheckControl7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl7.ForeColor = System.Drawing.Color.White;
            this.toggleCheckControl7.GradientColor = System.Drawing.Color.Green;
            this.toggleCheckControl7.IsChecked = false;
            this.toggleCheckControl7.Location = new System.Drawing.Point(323, 497);
            this.toggleCheckControl7.Name = "toggleCheckControl7";
            this.toggleCheckControl7.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.toggleCheckControl7.ShouldDrawBorder = true;
            this.toggleCheckControl7.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl7.Size = new System.Drawing.Size(73, 21);
            this.toggleCheckControl7.TabIndex = 6;
            this.toggleCheckControl7.Text = "toggleCheckControl7";
            this.toggleCheckControl7.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.toggleCheckControl7.UnCheckedStateImage = null;
            this.toggleCheckControl7.UnCheckedText = "X";
            // 
            // toggleCheckControl8
            // 
            this.toggleCheckControl8.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl8.CheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(157)))), ((int)(((byte)(231)))));
            this.toggleCheckControl8.CheckedStateImage = null;
            this.toggleCheckControl8.CheckedText = "ON";
            this.toggleCheckControl8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl8.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(157)))), ((int)(((byte)(231)))));
            this.toggleCheckControl8.IsChecked = false;
            this.toggleCheckControl8.Location = new System.Drawing.Point(155, 460);
            this.toggleCheckControl8.Name = "toggleCheckControl8";
            this.toggleCheckControl8.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(213)))), ((int)(((byte)(244)))));
            this.toggleCheckControl8.ShouldDrawBorder = true;
            this.toggleCheckControl8.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl8.Size = new System.Drawing.Size(146, 58);
            this.toggleCheckControl8.TabIndex = 7;
            this.toggleCheckControl8.Text = "toggleCheckControl8";
            this.toggleCheckControl8.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(213)))), ((int)(((byte)(244)))));
            this.toggleCheckControl8.UnCheckedStateImage = null;
            this.toggleCheckControl8.UnCheckedText = "OFF";
            // 
            // toggleCheckControl2
            // 
            this.toggleCheckControl2.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl2.CheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(157)))), ((int)(((byte)(231)))));
            this.toggleCheckControl2.CheckedStateImage = null;
            this.toggleCheckControl2.CheckedText = "ON";
            this.toggleCheckControl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl2.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.toggleCheckControl2.IsChecked = false;
            this.toggleCheckControl2.Location = new System.Drawing.Point(32, 112);
            this.toggleCheckControl2.Name = "toggleCheckControl2";
            this.toggleCheckControl2.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.toggleCheckControl2.ShouldDrawBorder = true;
            this.toggleCheckControl2.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl2.Size = new System.Drawing.Size(86, 35);
            this.toggleCheckControl2.TabIndex = 8;
            this.toggleCheckControl2.Text = "toggleCheckControl2";
            this.toggleCheckControl2.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(213)))), ((int)(((byte)(244)))));
            this.toggleCheckControl2.UnCheckedStateImage = null;
            this.toggleCheckControl2.UnCheckedText = "OFF";
            // 
            // toggleCheckControl9
            // 
            this.toggleCheckControl9.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl9.CheckedStateBackColor = System.Drawing.Color.Silver;
            this.toggleCheckControl9.CheckedStateImage = global::ToggleCheckButtonDemo.Properties.Resources.ON;
            this.toggleCheckControl9.CheckedText = "ON";
            this.toggleCheckControl9.GradientColor = System.Drawing.Color.Gainsboro;
            this.toggleCheckControl9.IsChecked = false;
            this.toggleCheckControl9.Location = new System.Drawing.Point(374, 113);
            this.toggleCheckControl9.Name = "toggleCheckControl9";
            this.toggleCheckControl9.OnHoverBackColor = System.Drawing.Color.Gainsboro;
            this.toggleCheckControl9.ShouldDrawBorder = false;
            this.toggleCheckControl9.ShouldUseImageForCheckedState = true;
            this.toggleCheckControl9.Size = new System.Drawing.Size(81, 36);
            this.toggleCheckControl9.TabIndex = 9;
            this.toggleCheckControl9.Text = "toggleCheckControl9";
            this.toggleCheckControl9.UnCheckedStateBackColor = System.Drawing.Color.Gainsboro;
            this.toggleCheckControl9.UnCheckedStateImage = global::ToggleCheckButtonDemo.Properties.Resources.OFF;
            this.toggleCheckControl9.UnCheckedText = "OFF";
            // 
            // toggleCheckControl10
            // 
            this.toggleCheckControl10.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl10.CheckedStateBackColor = System.Drawing.Color.Silver;
            this.toggleCheckControl10.CheckedStateImage = global::ToggleCheckButtonDemo.Properties.Resources.ON;
            this.toggleCheckControl10.CheckedText = "ON";
            this.toggleCheckControl10.GradientColor = System.Drawing.Color.Gainsboro;
            this.toggleCheckControl10.IsChecked = false;
            this.toggleCheckControl10.Location = new System.Drawing.Point(374, 164);
            this.toggleCheckControl10.Name = "toggleCheckControl10";
            this.toggleCheckControl10.OnHoverBackColor = System.Drawing.Color.Gainsboro;
            this.toggleCheckControl10.ShouldDrawBorder = true;
            this.toggleCheckControl10.ShouldUseImageForCheckedState = true;
            this.toggleCheckControl10.Size = new System.Drawing.Size(81, 36);
            this.toggleCheckControl10.TabIndex = 10;
            this.toggleCheckControl10.Text = "toggleCheckControl10";
            this.toggleCheckControl10.UnCheckedStateBackColor = System.Drawing.Color.Gainsboro;
            this.toggleCheckControl10.UnCheckedStateImage = global::ToggleCheckButtonDemo.Properties.Resources.OFF;
            this.toggleCheckControl10.UnCheckedText = "OFF";
            // 
            // toggleCheckControl19
            // 
            this.toggleCheckControl19.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl19.CheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.toggleCheckControl19.CheckedStateImage = null;
            this.toggleCheckControl19.CheckedText = "TRUE";
            this.toggleCheckControl19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.toggleCheckControl19.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(222)))), ((int)(((byte)(189)))));
            this.toggleCheckControl19.IsChecked = false;
            this.toggleCheckControl19.Location = new System.Drawing.Point(31, 361);
            this.toggleCheckControl19.Name = "toggleCheckControl19";
            this.toggleCheckControl19.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(222)))), ((int)(((byte)(189)))));
            this.toggleCheckControl19.ShouldDrawBorder = true;
            this.toggleCheckControl19.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl19.Size = new System.Drawing.Size(109, 29);
            this.toggleCheckControl19.TabIndex = 33;
            this.toggleCheckControl19.Text = "toggleCheckControl19";
            this.toggleCheckControl19.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.toggleCheckControl19.UnCheckedStateImage = null;
            this.toggleCheckControl19.UnCheckedText = "FALSE";
            // 
            // toggleCheckControl12
            // 
            this.toggleCheckControl12.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl12.CheckedStateBackColor = System.Drawing.Color.Red;
            this.toggleCheckControl12.CheckedStateImage = null;
            this.toggleCheckControl12.CheckedText = "TRUE";
            this.toggleCheckControl12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl12.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.toggleCheckControl12.IsChecked = false;
            this.toggleCheckControl12.Location = new System.Drawing.Point(505, 293);
            this.toggleCheckControl12.Name = "toggleCheckControl12";
            this.toggleCheckControl12.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.toggleCheckControl12.ShouldDrawBorder = true;
            this.toggleCheckControl12.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl12.Size = new System.Drawing.Size(113, 29);
            this.toggleCheckControl12.TabIndex = 19;
            this.toggleCheckControl12.Text = "toggleCheckControl12";
            this.toggleCheckControl12.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(189)))), ((int)(((byte)(185)))));
            this.toggleCheckControl12.UnCheckedStateImage = null;
            this.toggleCheckControl12.UnCheckedText = "FALSE";
            // 
            // toggleCheckControl20
            // 
            this.toggleCheckControl20.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl20.CheckedStateBackColor = System.Drawing.Color.Maroon;
            this.toggleCheckControl20.CheckedStateImage = null;
            this.toggleCheckControl20.CheckedText = "Y";
            this.toggleCheckControl20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.toggleCheckControl20.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(167)))), ((int)(((byte)(167)))));
            this.toggleCheckControl20.IsChecked = false;
            this.toggleCheckControl20.Location = new System.Drawing.Point(160, 361);
            this.toggleCheckControl20.Name = "toggleCheckControl20";
            this.toggleCheckControl20.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(167)))), ((int)(((byte)(167)))));
            this.toggleCheckControl20.ShouldDrawBorder = true;
            this.toggleCheckControl20.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl20.Size = new System.Drawing.Size(113, 29);
            this.toggleCheckControl20.TabIndex = 32;
            this.toggleCheckControl20.Text = "toggleCheckControl20";
            this.toggleCheckControl20.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(199)))), ((int)(((byte)(192)))));
            this.toggleCheckControl20.UnCheckedStateImage = null;
            this.toggleCheckControl20.UnCheckedText = "N";
            // 
            // toggleCheckControl11
            // 
            this.toggleCheckControl11.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl11.CheckedStateBackColor = System.Drawing.Color.Gray;
            this.toggleCheckControl11.CheckedStateImage = null;
            this.toggleCheckControl11.CheckedText = "ON";
            this.toggleCheckControl11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl11.GradientColor = System.Drawing.Color.Gainsboro;
            this.toggleCheckControl11.IsChecked = false;
            this.toggleCheckControl11.Location = new System.Drawing.Point(371, 293);
            this.toggleCheckControl11.Name = "toggleCheckControl11";
            this.toggleCheckControl11.OnHoverBackColor = System.Drawing.Color.Gainsboro;
            this.toggleCheckControl11.ShouldDrawBorder = true;
            this.toggleCheckControl11.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl11.Size = new System.Drawing.Size(113, 29);
            this.toggleCheckControl11.TabIndex = 20;
            this.toggleCheckControl11.Text = "toggleCheckControl11";
            this.toggleCheckControl11.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.toggleCheckControl11.UnCheckedStateImage = null;
            this.toggleCheckControl11.UnCheckedText = "OFF";
            // 
            // toggleCheckControl17
            // 
            this.toggleCheckControl17.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl17.CheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.toggleCheckControl17.CheckedStateImage = null;
            this.toggleCheckControl17.CheckedText = "Yes";
            this.toggleCheckControl17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.toggleCheckControl17.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(222)))), ((int)(((byte)(189)))));
            this.toggleCheckControl17.IsChecked = false;
            this.toggleCheckControl17.Location = new System.Drawing.Point(30, 326);
            this.toggleCheckControl17.Name = "toggleCheckControl17";
            this.toggleCheckControl17.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(222)))), ((int)(((byte)(189)))));
            this.toggleCheckControl17.ShouldDrawBorder = true;
            this.toggleCheckControl17.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl17.Size = new System.Drawing.Size(109, 29);
            this.toggleCheckControl17.TabIndex = 31;
            this.toggleCheckControl17.Text = "toggleCheckControl17";
            this.toggleCheckControl17.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.toggleCheckControl17.UnCheckedStateImage = null;
            this.toggleCheckControl17.UnCheckedText = "No";
            // 
            // toggleCheckControl18
            // 
            this.toggleCheckControl18.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl18.CheckedStateBackColor = System.Drawing.Color.Maroon;
            this.toggleCheckControl18.CheckedStateImage = null;
            this.toggleCheckControl18.CheckedText = "IN";
            this.toggleCheckControl18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.toggleCheckControl18.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(167)))), ((int)(((byte)(167)))));
            this.toggleCheckControl18.IsChecked = false;
            this.toggleCheckControl18.Location = new System.Drawing.Point(159, 326);
            this.toggleCheckControl18.Name = "toggleCheckControl18";
            this.toggleCheckControl18.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(167)))), ((int)(((byte)(167)))));
            this.toggleCheckControl18.ShouldDrawBorder = true;
            this.toggleCheckControl18.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl18.Size = new System.Drawing.Size(113, 29);
            this.toggleCheckControl18.TabIndex = 30;
            this.toggleCheckControl18.Text = "toggleCheckControl18";
            this.toggleCheckControl18.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(199)))), ((int)(((byte)(192)))));
            this.toggleCheckControl18.UnCheckedStateImage = null;
            this.toggleCheckControl18.UnCheckedText = "OUT";
            // 
            // toggleCheckControl15
            // 
            this.toggleCheckControl15.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl15.CheckedStateBackColor = System.Drawing.Color.Gray;
            this.toggleCheckControl15.CheckedStateImage = null;
            this.toggleCheckControl15.CheckedText = "UP";
            this.toggleCheckControl15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl15.GradientColor = System.Drawing.Color.Gray;
            this.toggleCheckControl15.IsChecked = false;
            this.toggleCheckControl15.Location = new System.Drawing.Point(371, 363);
            this.toggleCheckControl15.Name = "toggleCheckControl15";
            this.toggleCheckControl15.OnHoverBackColor = System.Drawing.Color.Silver;
            this.toggleCheckControl15.ShouldDrawBorder = true;
            this.toggleCheckControl15.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl15.Size = new System.Drawing.Size(113, 29);
            this.toggleCheckControl15.TabIndex = 29;
            this.toggleCheckControl15.Text = "toggleCheckControl15";
            this.toggleCheckControl15.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.toggleCheckControl15.UnCheckedStateImage = null;
            this.toggleCheckControl15.UnCheckedText = "DOWN";
            // 
            // toggleCheckControl16
            // 
            this.toggleCheckControl16.BorderColor = System.Drawing.Color.White;
            this.toggleCheckControl16.CheckedStateBackColor = System.Drawing.Color.Green;
            this.toggleCheckControl16.CheckedStateImage = null;
            this.toggleCheckControl16.CheckedText = "IN";
            this.toggleCheckControl16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl16.ForeColor = System.Drawing.Color.White;
            this.toggleCheckControl16.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(231)))), ((int)(((byte)(201)))));
            this.toggleCheckControl16.IsChecked = false;
            this.toggleCheckControl16.Location = new System.Drawing.Point(505, 363);
            this.toggleCheckControl16.Name = "toggleCheckControl16";
            this.toggleCheckControl16.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(231)))), ((int)(((byte)(201)))));
            this.toggleCheckControl16.ShouldDrawBorder = true;
            this.toggleCheckControl16.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl16.Size = new System.Drawing.Size(113, 29);
            this.toggleCheckControl16.TabIndex = 28;
            this.toggleCheckControl16.Text = "toggleCheckControl16";
            this.toggleCheckControl16.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.toggleCheckControl16.UnCheckedStateImage = null;
            this.toggleCheckControl16.UnCheckedText = "OUT";
            // 
            // toggleCheckControl14
            // 
            this.toggleCheckControl14.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl14.CheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.toggleCheckControl14.CheckedStateImage = null;
            this.toggleCheckControl14.CheckedText = "Y";
            this.toggleCheckControl14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl14.GradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.toggleCheckControl14.IsChecked = false;
            this.toggleCheckControl14.Location = new System.Drawing.Point(504, 328);
            this.toggleCheckControl14.Name = "toggleCheckControl14";
            this.toggleCheckControl14.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.toggleCheckControl14.ShouldDrawBorder = true;
            this.toggleCheckControl14.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl14.Size = new System.Drawing.Size(113, 29);
            this.toggleCheckControl14.TabIndex = 26;
            this.toggleCheckControl14.Text = "toggleCheckControl14";
            this.toggleCheckControl14.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(189)))), ((int)(((byte)(185)))));
            this.toggleCheckControl14.UnCheckedStateImage = null;
            this.toggleCheckControl14.UnCheckedText = "N";
            // 
            // toggleCheckControl13
            // 
            this.toggleCheckControl13.BorderColor = System.Drawing.Color.DarkGray;
            this.toggleCheckControl13.CheckedStateBackColor = System.Drawing.Color.Gray;
            this.toggleCheckControl13.CheckedStateImage = null;
            this.toggleCheckControl13.CheckedText = "ON";
            this.toggleCheckControl13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toggleCheckControl13.GradientColor = System.Drawing.Color.Gainsboro;
            this.toggleCheckControl13.IsChecked = false;
            this.toggleCheckControl13.Location = new System.Drawing.Point(370, 328);
            this.toggleCheckControl13.Name = "toggleCheckControl13";
            this.toggleCheckControl13.OnHoverBackColor = System.Drawing.Color.Gainsboro;
            this.toggleCheckControl13.ShouldDrawBorder = true;
            this.toggleCheckControl13.ShouldUseImageForCheckedState = false;
            this.toggleCheckControl13.Size = new System.Drawing.Size(113, 29);
            this.toggleCheckControl13.TabIndex = 27;
            this.toggleCheckControl13.Text = "toggleCheckControl13";
            this.toggleCheckControl13.UnCheckedStateBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.toggleCheckControl13.UnCheckedStateImage = null;
            this.toggleCheckControl13.UnCheckedText = "OFF";
            // 
            // binaryPowerTabPage2
            // 
            this.binaryPowerTabPage2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage2.BorderColor = System.Drawing.Color.Silver;
            this.binaryPowerTabPage2.BorderSize = 1;
            this.binaryPowerTabPage2.Controls.Add(this.label12);
            this.binaryPowerTabPage2.Controls.Add(this.groupBox1);
            this.binaryPowerTabPage2.Controls.Add(this.toggleControlStatus);
            this.binaryPowerTabPage2.Controls.Add(this.label27);
            this.binaryPowerTabPage2.Controls.Add(this.label26);
            this.binaryPowerTabPage2.Controls.Add(this.label13);
            this.binaryPowerTabPage2.Controls.Add(this.label25);
            this.binaryPowerTabPage2.Controls.Add(this.label24);
            this.binaryPowerTabPage2.Controls.Add(this.label14);
            this.binaryPowerTabPage2.Controls.Add(this.label21);
            this.binaryPowerTabPage2.Controls.Add(this.label15);
            this.binaryPowerTabPage2.Controls.Add(this.label16);
            this.binaryPowerTabPage2.Controls.Add(this.toggleSwitchWin8);
            this.binaryPowerTabPage2.Controls.Add(this.win8ToggleSwitch1);
            this.binaryPowerTabPage2.Controls.Add(this.win8ToggleSwitch2);
            this.binaryPowerTabPage2.Controls.Add(this.win8ToggleSwitch4);
            this.binaryPowerTabPage2.Controls.Add(this.win8ToggleSwitch3);
            this.binaryPowerTabPage2.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage2.IsBackgroundTransparent = false;
            this.binaryPowerTabPage2.IsHeaderEnabled = true;
            this.binaryPowerTabPage2.Name = "binaryPowerTabPage2";
            this.binaryPowerTabPage2.Size = new System.Drawing.Size(747, 591);
            this.binaryPowerTabPage2.TabIndex = 1;
            this.binaryPowerTabPage2.TabPageContentIsDirty = false;
            this.binaryPowerTabPage2.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.Text = "Win8 ToggleSwitch control";
            this.binaryPowerTabPage2.ToolTipText = "";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(18, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(345, 15);
            this.label12.TabIndex = 35;
            this.label12.Text = "ToggleSwitch control mimicking the Windows 8 style:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnWin8SwitchUnCheckedInnerBorderColor);
            this.groupBox1.Controls.Add(this.btnWin8SwitchInnerBorderColor);
            this.groupBox1.Controls.Add(this.chkWin8SwitchDrawGap);
            this.groupBox1.Controls.Add(this.btnWin8SwitchStickColor);
            this.groupBox1.Controls.Add(this.btnWin8SwitchOuterBorder);
            this.groupBox1.Controls.Add(this.btnWin8SwitchStartColor);
            this.groupBox1.Controls.Add(this.btnWin8SwitchEndColor);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.chkWin8SwitchIsChecked);
            this.groupBox1.Controls.Add(this.chkWin8SwitchDrawFocus);
            this.groupBox1.Controls.Add(this.btnWin8SwitchUnCheckedEndColor);
            this.groupBox1.Controls.Add(this.win8SwitchStickWidth);
            this.groupBox1.Controls.Add(this.btnWin8SwitchUnCheckedStartColor);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.btnWin8SwitchUnCheckedOuterBorderColor);
            this.groupBox1.Controls.Add(this.win8SwitchGapWidth);
            this.groupBox1.Controls.Add(this.btnWin8SwitchUnCheckedStickColor);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.win8SwitchOuterBorderThickness);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.win8SwitchInnerBorderThickness);
            this.groupBox1.Location = new System.Drawing.Point(21, 265);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(644, 309);
            this.groupBox1.TabIndex = 78;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Customisation options:";
            // 
            // btnWin8SwitchUnCheckedInnerBorderColor
            // 
            this.btnWin8SwitchUnCheckedInnerBorderColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWin8SwitchUnCheckedInnerBorderColor.Location = new System.Drawing.Point(338, 195);
            this.btnWin8SwitchUnCheckedInnerBorderColor.Name = "btnWin8SwitchUnCheckedInnerBorderColor";
            this.btnWin8SwitchUnCheckedInnerBorderColor.Size = new System.Drawing.Size(140, 27);
            this.btnWin8SwitchUnCheckedInnerBorderColor.TabIndex = 75;
            this.btnWin8SwitchUnCheckedInnerBorderColor.Text = "Inner Border Color...";
            this.btnWin8SwitchUnCheckedInnerBorderColor.UseVisualStyleBackColor = true;
            this.btnWin8SwitchUnCheckedInnerBorderColor.Click += new System.EventHandler(this.btnWin8SwitchUnCheckedInnerBorderColor_Click);
            // 
            // btnWin8SwitchInnerBorderColor
            // 
            this.btnWin8SwitchInnerBorderColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWin8SwitchInnerBorderColor.Location = new System.Drawing.Point(20, 195);
            this.btnWin8SwitchInnerBorderColor.Name = "btnWin8SwitchInnerBorderColor";
            this.btnWin8SwitchInnerBorderColor.Size = new System.Drawing.Size(140, 27);
            this.btnWin8SwitchInnerBorderColor.TabIndex = 74;
            this.btnWin8SwitchInnerBorderColor.Text = "Inner Border Color...";
            this.btnWin8SwitchInnerBorderColor.UseVisualStyleBackColor = true;
            this.btnWin8SwitchInnerBorderColor.Click += new System.EventHandler(this.btnWin8SwitchInnerBorderColor_Click);
            // 
            // chkWin8SwitchDrawGap
            // 
            this.chkWin8SwitchDrawGap.AutoSize = true;
            this.chkWin8SwitchDrawGap.Checked = true;
            this.chkWin8SwitchDrawGap.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkWin8SwitchDrawGap.Location = new System.Drawing.Point(119, 33);
            this.chkWin8SwitchDrawGap.Name = "chkWin8SwitchDrawGap";
            this.chkWin8SwitchDrawGap.Size = new System.Drawing.Size(222, 17);
            this.chkWin8SwitchDrawGap.TabIndex = 51;
            this.chkWin8SwitchDrawGap.Text = "Should draw gap before/after toggle stick";
            this.chkWin8SwitchDrawGap.UseVisualStyleBackColor = true;
            this.chkWin8SwitchDrawGap.CheckedChanged += new System.EventHandler(this.chkWin8SwitchDrawGap_CheckedChanged);
            // 
            // btnWin8SwitchStickColor
            // 
            this.btnWin8SwitchStickColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWin8SwitchStickColor.Location = new System.Drawing.Point(20, 123);
            this.btnWin8SwitchStickColor.Name = "btnWin8SwitchStickColor";
            this.btnWin8SwitchStickColor.Size = new System.Drawing.Size(140, 27);
            this.btnWin8SwitchStickColor.TabIndex = 45;
            this.btnWin8SwitchStickColor.Text = "Toggle Stick Color...";
            this.btnWin8SwitchStickColor.UseVisualStyleBackColor = true;
            this.btnWin8SwitchStickColor.Click += new System.EventHandler(this.btnWin8SwitchStickColor_Click);
            // 
            // btnWin8SwitchOuterBorder
            // 
            this.btnWin8SwitchOuterBorder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWin8SwitchOuterBorder.Location = new System.Drawing.Point(171, 125);
            this.btnWin8SwitchOuterBorder.Name = "btnWin8SwitchOuterBorder";
            this.btnWin8SwitchOuterBorder.Size = new System.Drawing.Size(140, 27);
            this.btnWin8SwitchOuterBorder.TabIndex = 46;
            this.btnWin8SwitchOuterBorder.Text = "Outer Border Color...";
            this.btnWin8SwitchOuterBorder.UseVisualStyleBackColor = true;
            this.btnWin8SwitchOuterBorder.Click += new System.EventHandler(this.btnWin8SwitchOuterBorder_Click);
            // 
            // btnWin8SwitchStartColor
            // 
            this.btnWin8SwitchStartColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWin8SwitchStartColor.Location = new System.Drawing.Point(20, 158);
            this.btnWin8SwitchStartColor.Name = "btnWin8SwitchStartColor";
            this.btnWin8SwitchStartColor.Size = new System.Drawing.Size(140, 27);
            this.btnWin8SwitchStartColor.TabIndex = 47;
            this.btnWin8SwitchStartColor.Text = "Background Start Color...";
            this.btnWin8SwitchStartColor.UseVisualStyleBackColor = true;
            this.btnWin8SwitchStartColor.Click += new System.EventHandler(this.btnWin8SwitchStartColor_Click);
            // 
            // btnWin8SwitchEndColor
            // 
            this.btnWin8SwitchEndColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWin8SwitchEndColor.Location = new System.Drawing.Point(171, 160);
            this.btnWin8SwitchEndColor.Name = "btnWin8SwitchEndColor";
            this.btnWin8SwitchEndColor.Size = new System.Drawing.Size(140, 27);
            this.btnWin8SwitchEndColor.TabIndex = 48;
            this.btnWin8SwitchEndColor.Text = "Background End Color...";
            this.btnWin8SwitchEndColor.UseVisualStyleBackColor = true;
            this.btnWin8SwitchEndColor.Click += new System.EventHandler(this.btnWin8SwitchEndColor_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(335, 99);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(270, 13);
            this.label23.TabIndex = 73;
            this.label23.Text = "Customise colors (used when toggle IsChecked = false):";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(17, 97);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(266, 13);
            this.label22.TabIndex = 72;
            this.label22.Text = "Customise colors (used when toggle IsChecked = true):";
            // 
            // chkWin8SwitchIsChecked
            // 
            this.chkWin8SwitchIsChecked.AutoSize = true;
            this.chkWin8SwitchIsChecked.Checked = true;
            this.chkWin8SwitchIsChecked.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkWin8SwitchIsChecked.Location = new System.Drawing.Point(20, 33);
            this.chkWin8SwitchIsChecked.Name = "chkWin8SwitchIsChecked";
            this.chkWin8SwitchIsChecked.Size = new System.Drawing.Size(83, 17);
            this.chkWin8SwitchIsChecked.TabIndex = 50;
            this.chkWin8SwitchIsChecked.Text = "IsChecked?";
            this.chkWin8SwitchIsChecked.UseVisualStyleBackColor = true;
            this.chkWin8SwitchIsChecked.CheckedChanged += new System.EventHandler(this.chkWin8SwitchIsChecked_CheckedChanged);
            // 
            // chkWin8SwitchDrawFocus
            // 
            this.chkWin8SwitchDrawFocus.AutoSize = true;
            this.chkWin8SwitchDrawFocus.Checked = true;
            this.chkWin8SwitchDrawFocus.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkWin8SwitchDrawFocus.Location = new System.Drawing.Point(20, 58);
            this.chkWin8SwitchDrawFocus.Name = "chkWin8SwitchDrawFocus";
            this.chkWin8SwitchDrawFocus.Size = new System.Drawing.Size(230, 17);
            this.chkWin8SwitchDrawFocus.TabIndex = 52;
            this.chkWin8SwitchDrawFocus.Text = "Should draw focus rectangle when in focus";
            this.chkWin8SwitchDrawFocus.UseVisualStyleBackColor = true;
            this.chkWin8SwitchDrawFocus.CheckedChanged += new System.EventHandler(this.chkWin8SwitchDrawFocus_CheckedChanged);
            // 
            // btnWin8SwitchUnCheckedEndColor
            // 
            this.btnWin8SwitchUnCheckedEndColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWin8SwitchUnCheckedEndColor.Location = new System.Drawing.Point(489, 162);
            this.btnWin8SwitchUnCheckedEndColor.Name = "btnWin8SwitchUnCheckedEndColor";
            this.btnWin8SwitchUnCheckedEndColor.Size = new System.Drawing.Size(140, 27);
            this.btnWin8SwitchUnCheckedEndColor.TabIndex = 70;
            this.btnWin8SwitchUnCheckedEndColor.Text = "Background End Color...";
            this.btnWin8SwitchUnCheckedEndColor.UseVisualStyleBackColor = true;
            this.btnWin8SwitchUnCheckedEndColor.Click += new System.EventHandler(this.btnWin8SwitchUnCheckedEndColor_Click);
            // 
            // win8SwitchStickWidth
            // 
            this.win8SwitchStickWidth.Location = new System.Drawing.Point(167, 239);
            this.win8SwitchStickWidth.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.win8SwitchStickWidth.Minimum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.win8SwitchStickWidth.Name = "win8SwitchStickWidth";
            this.win8SwitchStickWidth.Size = new System.Drawing.Size(138, 20);
            this.win8SwitchStickWidth.TabIndex = 53;
            this.win8SwitchStickWidth.Value = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.win8SwitchStickWidth.ValueChanged += new System.EventHandler(this.Win8SwitchStickWidth_ValueChanged);
            // 
            // btnWin8SwitchUnCheckedStartColor
            // 
            this.btnWin8SwitchUnCheckedStartColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWin8SwitchUnCheckedStartColor.Location = new System.Drawing.Point(338, 160);
            this.btnWin8SwitchUnCheckedStartColor.Name = "btnWin8SwitchUnCheckedStartColor";
            this.btnWin8SwitchUnCheckedStartColor.Size = new System.Drawing.Size(140, 27);
            this.btnWin8SwitchUnCheckedStartColor.TabIndex = 69;
            this.btnWin8SwitchUnCheckedStartColor.Text = "Background Start Color...";
            this.btnWin8SwitchUnCheckedStartColor.UseVisualStyleBackColor = true;
            this.btnWin8SwitchUnCheckedStartColor.Click += new System.EventHandler(this.btnWin8SwitchUnCheckedStartColor_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(17, 241);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(93, 13);
            this.label17.TabIndex = 54;
            this.label17.Text = "Toggle stick width";
            // 
            // btnWin8SwitchUnCheckedOuterBorderColor
            // 
            this.btnWin8SwitchUnCheckedOuterBorderColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWin8SwitchUnCheckedOuterBorderColor.Location = new System.Drawing.Point(489, 127);
            this.btnWin8SwitchUnCheckedOuterBorderColor.Name = "btnWin8SwitchUnCheckedOuterBorderColor";
            this.btnWin8SwitchUnCheckedOuterBorderColor.Size = new System.Drawing.Size(140, 27);
            this.btnWin8SwitchUnCheckedOuterBorderColor.TabIndex = 68;
            this.btnWin8SwitchUnCheckedOuterBorderColor.Text = "Outer Border Color...";
            this.btnWin8SwitchUnCheckedOuterBorderColor.UseVisualStyleBackColor = true;
            this.btnWin8SwitchUnCheckedOuterBorderColor.Click += new System.EventHandler(this.btnWin8SwitchUnCheckedOuterBorderColor_Click);
            // 
            // win8SwitchGapWidth
            // 
            this.win8SwitchGapWidth.Location = new System.Drawing.Point(167, 265);
            this.win8SwitchGapWidth.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.win8SwitchGapWidth.Name = "win8SwitchGapWidth";
            this.win8SwitchGapWidth.Size = new System.Drawing.Size(138, 20);
            this.win8SwitchGapWidth.TabIndex = 55;
            this.win8SwitchGapWidth.ValueChanged += new System.EventHandler(this.win8SwitchGapWidth_ValueChanged);
            // 
            // btnWin8SwitchUnCheckedStickColor
            // 
            this.btnWin8SwitchUnCheckedStickColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWin8SwitchUnCheckedStickColor.Location = new System.Drawing.Point(338, 125);
            this.btnWin8SwitchUnCheckedStickColor.Name = "btnWin8SwitchUnCheckedStickColor";
            this.btnWin8SwitchUnCheckedStickColor.Size = new System.Drawing.Size(140, 27);
            this.btnWin8SwitchUnCheckedStickColor.TabIndex = 67;
            this.btnWin8SwitchUnCheckedStickColor.Text = "Toggle Stick Color...";
            this.btnWin8SwitchUnCheckedStickColor.UseVisualStyleBackColor = true;
            this.btnWin8SwitchUnCheckedStickColor.Click += new System.EventHandler(this.btnWin8SwitchUnCheckedStickColor_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(17, 267);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 13);
            this.label18.TabIndex = 56;
            this.label18.Text = "Gap width:";
            // 
            // win8SwitchOuterBorderThickness
            // 
            this.win8SwitchOuterBorderThickness.Location = new System.Drawing.Point(485, 244);
            this.win8SwitchOuterBorderThickness.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.win8SwitchOuterBorderThickness.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.win8SwitchOuterBorderThickness.Name = "win8SwitchOuterBorderThickness";
            this.win8SwitchOuterBorderThickness.Size = new System.Drawing.Size(138, 20);
            this.win8SwitchOuterBorderThickness.TabIndex = 57;
            this.win8SwitchOuterBorderThickness.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.win8SwitchOuterBorderThickness.ValueChanged += new System.EventHandler(this.win8SwitchOuterBorderThickness_ValueChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(335, 272);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(115, 13);
            this.label20.TabIndex = 60;
            this.label20.Text = "Inner border thickness:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(335, 246);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(117, 13);
            this.label19.TabIndex = 58;
            this.label19.Text = "Outer border thickness:";
            // 
            // win8SwitchInnerBorderThickness
            // 
            this.win8SwitchInnerBorderThickness.Location = new System.Drawing.Point(485, 270);
            this.win8SwitchInnerBorderThickness.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.win8SwitchInnerBorderThickness.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.win8SwitchInnerBorderThickness.Name = "win8SwitchInnerBorderThickness";
            this.win8SwitchInnerBorderThickness.Size = new System.Drawing.Size(138, 20);
            this.win8SwitchInnerBorderThickness.TabIndex = 59;
            this.win8SwitchInnerBorderThickness.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.win8SwitchInnerBorderThickness.ValueChanged += new System.EventHandler(this.win8SwitchInnerBorderThickness_ValueChanged);
            // 
            // toggleControlStatus
            // 
            this.toggleControlStatus.AutoSize = true;
            this.toggleControlStatus.Location = new System.Drawing.Point(27, 231);
            this.toggleControlStatus.Name = "toggleControlStatus";
            this.toggleControlStatus.Size = new System.Drawing.Size(21, 13);
            this.toggleControlStatus.TabIndex = 36;
            this.toggleControlStatus.Text = "On";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(199, 144);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(424, 13);
            this.label27.TabIndex = 77;
            this.label27.Text = "(Demonstrates rendering the control in a different color when it is in \"Switched " +
    "off\" mode)";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(199, 114);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(325, 13);
            this.label26.TabIndex = 76;
            this.label26.Text = "(Demonstrates rendering a custom color for each part of the control)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(22, 62);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(21, 13);
            this.label13.TabIndex = 38;
            this.label13.Text = "On";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(199, 89);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(311, 13);
            this.label25.TabIndex = 75;
            this.label25.Text = "(Demonstrates rendering a linear gradient drawing for the control)";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(197, 62);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(398, 13);
            this.label24.TabIndex = 74;
            this.label24.Text = "(Demonstrates rendering a gap between the toggle stick and the rest of the contro" +
    "l)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(22, 88);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(21, 13);
            this.label14.TabIndex = 40;
            this.label14.Text = "On";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(22, 192);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(372, 15);
            this.label21.TabIndex = 61;
            this.label21.Text = "Customise this Win 8 style toggle switch control instance:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(22, 140);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(21, 13);
            this.label15.TabIndex = 44;
            this.label15.Text = "On";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(22, 114);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(21, 13);
            this.label16.TabIndex = 42;
            this.label16.Text = "On";
            // 
            // toggleSwitchWin8
            // 
            this.toggleSwitchWin8.BackgroundEndColor = System.Drawing.Color.DarkGray;
            this.toggleSwitchWin8.BackgroundEndColorUnchecked = System.Drawing.Color.DarkGray;
            this.toggleSwitchWin8.BackgroundStartColor = System.Drawing.Color.DarkGray;
            this.toggleSwitchWin8.BackgroundStartColorUnchecked = System.Drawing.Color.DarkGray;
            this.toggleSwitchWin8.InnerBorderColor = System.Drawing.Color.White;
            this.toggleSwitchWin8.InnerBorderColorUnchecked = System.Drawing.Color.Empty;
            this.toggleSwitchWin8.InnerBorderThickness = 1;
            this.toggleSwitchWin8.IsChecked = true;
            this.toggleSwitchWin8.Location = new System.Drawing.Point(100, 228);
            this.toggleSwitchWin8.Name = "toggleSwitchWin8";
            this.toggleSwitchWin8.OuterBorderColor = System.Drawing.Color.LightGray;
            this.toggleSwitchWin8.OuterBorderColorUnchecked = System.Drawing.Color.LightGray;
            this.toggleSwitchWin8.OuterBorderThickness = 3;
            this.toggleSwitchWin8.ShouldDrawFocusRectangleWhenFocused = false;
            this.toggleSwitchWin8.ShouldDrawGapBetweenSwitchStickAndTrack = false;
            this.toggleSwitchWin8.Size = new System.Drawing.Size(66, 20);
            this.toggleSwitchWin8.SwitchStickControlGapWidth = 0;
            this.toggleSwitchWin8.TabIndex = 34;
            this.toggleSwitchWin8.Text = "toggleSwitchModern1";
            this.toggleSwitchWin8.ToggleStickColor = System.Drawing.Color.OrangeRed;
            this.toggleSwitchWin8.ToggleStickColorUnchecked = System.Drawing.Color.OrangeRed;
            this.toggleSwitchWin8.ToggleSwitchStickWidth = 13;
            this.toggleSwitchWin8.Toggled += new System.EventHandler(this.toggleSwitchWin8_Toggled);
            // 
            // win8ToggleSwitch1
            // 
            this.win8ToggleSwitch1.BackgroundEndColor = System.Drawing.Color.DarkGray;
            this.win8ToggleSwitch1.BackgroundEndColorUnchecked = System.Drawing.Color.DarkGray;
            this.win8ToggleSwitch1.BackgroundStartColor = System.Drawing.Color.DarkGray;
            this.win8ToggleSwitch1.BackgroundStartColorUnchecked = System.Drawing.Color.DarkGray;
            this.win8ToggleSwitch1.InnerBorderColor = System.Drawing.Color.White;
            this.win8ToggleSwitch1.InnerBorderColorUnchecked = System.Drawing.Color.White;
            this.win8ToggleSwitch1.InnerBorderThickness = 1;
            this.win8ToggleSwitch1.IsChecked = true;
            this.win8ToggleSwitch1.Location = new System.Drawing.Point(95, 59);
            this.win8ToggleSwitch1.Name = "win8ToggleSwitch1";
            this.win8ToggleSwitch1.OuterBorderColor = System.Drawing.Color.LightGray;
            this.win8ToggleSwitch1.OuterBorderColorUnchecked = System.Drawing.Color.LightGray;
            this.win8ToggleSwitch1.OuterBorderThickness = 3;
            this.win8ToggleSwitch1.ShouldDrawFocusRectangleWhenFocused = false;
            this.win8ToggleSwitch1.ShouldDrawGapBetweenSwitchStickAndTrack = true;
            this.win8ToggleSwitch1.Size = new System.Drawing.Size(66, 20);
            this.win8ToggleSwitch1.SwitchStickControlGapWidth = 1;
            this.win8ToggleSwitch1.TabIndex = 37;
            this.win8ToggleSwitch1.Text = "toggleSwitchModern1";
            this.win8ToggleSwitch1.ToggleStickColor = System.Drawing.Color.OrangeRed;
            this.win8ToggleSwitch1.ToggleStickColorUnchecked = System.Drawing.Color.Gray;
            this.win8ToggleSwitch1.ToggleSwitchStickWidth = 13;
            // 
            // win8ToggleSwitch2
            // 
            this.win8ToggleSwitch2.BackgroundEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.win8ToggleSwitch2.BackgroundEndColorUnchecked = System.Drawing.Color.Silver;
            this.win8ToggleSwitch2.BackgroundStartColor = System.Drawing.Color.White;
            this.win8ToggleSwitch2.BackgroundStartColorUnchecked = System.Drawing.Color.White;
            this.win8ToggleSwitch2.InnerBorderColor = System.Drawing.Color.Transparent;
            this.win8ToggleSwitch2.InnerBorderColorUnchecked = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.win8ToggleSwitch2.InnerBorderThickness = 1;
            this.win8ToggleSwitch2.IsChecked = true;
            this.win8ToggleSwitch2.Location = new System.Drawing.Point(95, 85);
            this.win8ToggleSwitch2.Name = "win8ToggleSwitch2";
            this.win8ToggleSwitch2.OuterBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.win8ToggleSwitch2.OuterBorderColorUnchecked = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.win8ToggleSwitch2.OuterBorderThickness = 3;
            this.win8ToggleSwitch2.ShouldDrawFocusRectangleWhenFocused = false;
            this.win8ToggleSwitch2.ShouldDrawGapBetweenSwitchStickAndTrack = false;
            this.win8ToggleSwitch2.Size = new System.Drawing.Size(66, 20);
            this.win8ToggleSwitch2.SwitchStickControlGapWidth = 0;
            this.win8ToggleSwitch2.TabIndex = 39;
            this.win8ToggleSwitch2.Text = "toggleSwitchModern1";
            this.win8ToggleSwitch2.ToggleStickColor = System.Drawing.Color.Teal;
            this.win8ToggleSwitch2.ToggleStickColorUnchecked = System.Drawing.Color.Gray;
            this.win8ToggleSwitch2.ToggleSwitchStickWidth = 13;
            // 
            // win8ToggleSwitch4
            // 
            this.win8ToggleSwitch4.BackgroundEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.win8ToggleSwitch4.BackgroundEndColorUnchecked = System.Drawing.Color.Silver;
            this.win8ToggleSwitch4.BackgroundStartColor = System.Drawing.Color.White;
            this.win8ToggleSwitch4.BackgroundStartColorUnchecked = System.Drawing.Color.White;
            this.win8ToggleSwitch4.InnerBorderColor = System.Drawing.Color.White;
            this.win8ToggleSwitch4.InnerBorderColorUnchecked = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.win8ToggleSwitch4.InnerBorderThickness = 1;
            this.win8ToggleSwitch4.IsChecked = true;
            this.win8ToggleSwitch4.Location = new System.Drawing.Point(95, 111);
            this.win8ToggleSwitch4.Name = "win8ToggleSwitch4";
            this.win8ToggleSwitch4.OuterBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.win8ToggleSwitch4.OuterBorderColorUnchecked = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.win8ToggleSwitch4.OuterBorderThickness = 2;
            this.win8ToggleSwitch4.ShouldDrawFocusRectangleWhenFocused = false;
            this.win8ToggleSwitch4.ShouldDrawGapBetweenSwitchStickAndTrack = true;
            this.win8ToggleSwitch4.Size = new System.Drawing.Size(66, 20);
            this.win8ToggleSwitch4.SwitchStickControlGapWidth = 1;
            this.win8ToggleSwitch4.TabIndex = 41;
            this.win8ToggleSwitch4.Text = "toggleSwitchModern1";
            this.win8ToggleSwitch4.ToggleStickColor = System.Drawing.Color.Maroon;
            this.win8ToggleSwitch4.ToggleStickColorUnchecked = System.Drawing.Color.Gray;
            this.win8ToggleSwitch4.ToggleSwitchStickWidth = 13;
            // 
            // win8ToggleSwitch3
            // 
            this.win8ToggleSwitch3.BackgroundEndColor = System.Drawing.Color.DarkGray;
            this.win8ToggleSwitch3.BackgroundEndColorUnchecked = System.Drawing.Color.Silver;
            this.win8ToggleSwitch3.BackgroundStartColor = System.Drawing.Color.DarkGray;
            this.win8ToggleSwitch3.BackgroundStartColorUnchecked = System.Drawing.Color.White;
            this.win8ToggleSwitch3.InnerBorderColor = System.Drawing.Color.White;
            this.win8ToggleSwitch3.InnerBorderColorUnchecked = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.win8ToggleSwitch3.InnerBorderThickness = 1;
            this.win8ToggleSwitch3.IsChecked = true;
            this.win8ToggleSwitch3.Location = new System.Drawing.Point(95, 137);
            this.win8ToggleSwitch3.Name = "win8ToggleSwitch3";
            this.win8ToggleSwitch3.OuterBorderColor = System.Drawing.Color.LightGray;
            this.win8ToggleSwitch3.OuterBorderColorUnchecked = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.win8ToggleSwitch3.OuterBorderThickness = 5;
            this.win8ToggleSwitch3.ShouldDrawFocusRectangleWhenFocused = false;
            this.win8ToggleSwitch3.ShouldDrawGapBetweenSwitchStickAndTrack = true;
            this.win8ToggleSwitch3.Size = new System.Drawing.Size(66, 20);
            this.win8ToggleSwitch3.SwitchStickControlGapWidth = 1;
            this.win8ToggleSwitch3.TabIndex = 43;
            this.win8ToggleSwitch3.Text = "toggleSwitchModern1";
            this.win8ToggleSwitch3.ToggleStickColor = System.Drawing.Color.Brown;
            this.win8ToggleSwitch3.ToggleStickColorUnchecked = System.Drawing.Color.Gray;
            this.win8ToggleSwitch3.ToggleSwitchStickWidth = 13;
            this.win8ToggleSwitch3.Toggled += new System.EventHandler(this.win8ToggleSwitch3_Toggled);
            // 
            // appExitCmdInvoker
            // 
            this.appExitCmdInvoker.Location = new System.Drawing.Point(645, 670);
            this.appExitCmdInvoker.Name = "appExitCmdInvoker";
            this.appExitCmdInvoker.Size = new System.Drawing.Size(114, 36);
            this.appExitCmdInvoker.TabIndex = 81;
            this.appExitCmdInvoker.Text = "E&xit";
            this.appExitCmdInvoker.UseVisualStyleBackColor = true;
            this.appExitCmdInvoker.Click += new System.EventHandler(this.AppExitCommandInvokerHandler);
            // 
            // ToggleCheckButtonDemoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(784, 756);
            this.Controls.Add(this.appExitCmdInvoker);
            this.Controls.Add(this.binaryPowerTabStrip1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ToggleCheckButtonDemoForm";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.binaryPowerTabStrip1.ResumeLayout(false);
            this.binaryPowerTabPage1.ResumeLayout(false);
            this.binaryPowerTabPage1.PerformLayout();
            this.binaryPowerTabPage2.ResumeLayout(false);
            this.binaryPowerTabPage2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.win8SwitchStickWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.win8SwitchGapWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.win8SwitchOuterBorderThickness)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.win8SwitchInnerBorderThickness)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl1;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl3;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl4;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl5;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl6;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl7;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl8;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl2;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl9;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl11;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox chkToggleControlState;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl13;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl14;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl15;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl16;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl17;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl18;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl19;
        private Binarymission.WinForms.Controls.ToggleControls.ToggleSwitch toggleCheckControl20;
        private Binarymission.WinForms.Controls.ToggleControls.Win8ToggleSwitch toggleSwitchWin8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label toggleControlStatus;
        private System.Windows.Forms.Label label13;
        private Binarymission.WinForms.Controls.ToggleControls.Win8ToggleSwitch win8ToggleSwitch1;
        private System.Windows.Forms.Label label14;
        private Binarymission.WinForms.Controls.ToggleControls.Win8ToggleSwitch win8ToggleSwitch2;
        private System.Windows.Forms.Label label15;
        private Binarymission.WinForms.Controls.ToggleControls.Win8ToggleSwitch win8ToggleSwitch3;
        private System.Windows.Forms.Label label16;
        private Binarymission.WinForms.Controls.ToggleControls.Win8ToggleSwitch win8ToggleSwitch4;
        private System.Windows.Forms.ColorDialog win8ToggleSwitchColorDialog1;
        private System.Windows.Forms.ColorDialog win8OuterBorderColorDialog1;
        private System.Windows.Forms.ColorDialog win8InnerBorderColorDialog1;
        private System.Windows.Forms.ColorDialog win8BackgroundStartColorDialog1;
        private System.Windows.Forms.ColorDialog win8BackgroundEndColorDialog1;
        private System.Windows.Forms.Button btnWin8SwitchStickColor;
        private System.Windows.Forms.Button btnWin8SwitchOuterBorder;
        private System.Windows.Forms.Button btnWin8SwitchEndColor;
        private System.Windows.Forms.Button btnWin8SwitchStartColor;
        private System.Windows.Forms.CheckBox chkWin8SwitchIsChecked;
        private System.Windows.Forms.CheckBox chkWin8SwitchDrawGap;
        private System.Windows.Forms.CheckBox chkWin8SwitchDrawFocus;
        private System.Windows.Forms.NumericUpDown win8SwitchStickWidth;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown win8SwitchGapWidth;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown win8SwitchOuterBorderThickness;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NumericUpDown win8SwitchInnerBorderThickness;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnWin8SwitchUnCheckedEndColor;
        private System.Windows.Forms.Button btnWin8SwitchUnCheckedStartColor;
        private System.Windows.Forms.Button btnWin8SwitchUnCheckedOuterBorderColor;
        private System.Windows.Forms.Button btnWin8SwitchUnCheckedStickColor;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.GroupBox groupBox1;
        private BinaryPowerTabStrip binaryPowerTabStrip1;
        private BinaryPowerTabPage binaryPowerTabPage1;
        private BinaryPowerTabPage binaryPowerTabPage2;
        private System.Windows.Forms.ColorDialog win8ToggleSwitchColorDialog2;
        private System.Windows.Forms.ColorDialog win8OuterBorderColorDialog2;
        private System.Windows.Forms.ColorDialog win8InnerBorderColorDialog2;
        private System.Windows.Forms.ColorDialog win8BackgroundStartColorDialog2;
        private System.Windows.Forms.ColorDialog win8BackgroundEndColorDialog2;
        private System.Windows.Forms.Button btnWin8SwitchInnerBorderColor;
        private System.Windows.Forms.Button btnWin8SwitchUnCheckedInnerBorderColor;
        private System.Windows.Forms.Button appExitCmdInvoker;
    }
}

