using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.ExtendedComboBoxControls;

namespace TreeViewComboBoxDemo
{
    /// <summary>
    /// Summary description for TreeViewComboBoxDemoForm.
    /// </summary>
    public class TreeViewComboBoxDemoForm : ModernChromeWindow
    {
        public TreeViewComboBoxDemoForm()
        {
            InitializeComponent();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
        }

        private void SetupTreeviewComboboxColorsForVisuals(object sender, System.EventArgs e)
        {
            if (_colorDialog1.ShowDialog() == DialogResult.Cancel) return;

            _binaryTreeViewComboBox1.CustomPaintingColor = this._colorDialog1.Color;
            _binaryTreeViewComboBox1.CustomControlBorderColor = this._colorDialog1.Color;
        }

        private void SetupTreeviewComboboxFontForVisuals(object sender, System.EventArgs e)
        {
            if (_fontDialog1.ShowDialog() == DialogResult.Cancel) return;

            _binaryTreeViewComboBox1.Font = _fontDialog1.Font;
        }

        private void SetupTreeviewComboboxDropdownWindowBorderColor(object sender, System.EventArgs e)
        {
            if (_colorDialog1.ShowDialog() == DialogResult.Cancel) return;
            _binaryTreeViewComboBox1.DropDownWindowBorderColor = _colorDialog1.Color;
        }

        private void HandleFormLoaded(object sender, System.EventArgs e)
        {
            PrepareTextDisplayStylesCombobox();

            _binaryTreeViewComboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            _selectedItemText.Text = @"Nothing selected as yet!";
            _textDisplayStyleComboBox.SelectedIndex = 0;

            #region You can also write code to setup the tree view, but it is not necessary, since you can use designer to set it up.

            // Setup your Tree view control.
            // This is just a simple construction. You could however build it any other manner as you would, like directly from data sources etc.

            // Note that if you are only working with the System.Windows.Forms.TreeView and want to pass on this control to BinaryTreeViewComboBox display,
            // then simply replace your TreeView with Binarymission.WinFormControls.ExtendedComboBoxControls.BinaryTreeViewComboBox.TreeViewNative
            // and continue to use your tree view as usual.
            // This way, you can use the internally defined / built-in support for the ISuuportTreeView interface implementation.

            // Only if you are not using System.Windows.Forms.TreeView control as the tree view object, then you will need to wrap that control into your 
            // custom class and implement ISupportTreeView interface.
            // For implementing this interface, please refer to the help guide which comes with a sample class implementing this interface, and you can
            // clone that in to your implementation.
            // Check the control's property "TreeViewInstance" in the help guide, for more information.

            /*
            Binarymission.WinFormControls.ExtendedComboBoxControls.BinaryTreeViewComboBox.TreeViewNative customTreeView =
                new Binarymission.WinFormControls.ExtendedComboBoxControls.BinaryTreeViewComboBox.TreeViewNative();
            
            customTreeView.ImageIndex = -1;
			customTreeView.Name = "customTreeViewInstance";
			customTreeView.SelectedImageIndex = -1;
			customTreeView.Size = new System.Drawing.Size(250, 350);
			customTreeView.TabIndex = 0;
			customTreeView.HideSelection = false;
			customTreeView.BorderStyle = BorderStyle.FixedSingle;
			//customTreeView.ImageList = this.imageList1;
			TreeNode root = new TreeNode("Corporate");
			root.ImageIndex = 0;
			root.SelectedImageIndex = 0;
			customTreeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[]{root});
			// Now add the child nodes to the root
			TreeNode projectNode = new TreeNode("Projects");
			projectNode.ImageIndex = 1;
			projectNode.SelectedImageIndex = 1;
			root.Nodes.Add(projectNode);
			TreeNode NETNode = new TreeNode("On .NET");
			NETNode.ImageIndex = 2;
			NETNode.SelectedImageIndex = 2;
			projectNode.Nodes.Add(NETNode);
			TreeNode temp1 = new TreeNode("Delivered (19)");
			temp1.ImageIndex = 3;
			temp1.SelectedImageIndex = 3;
			NETNode.Nodes.Add(temp1);
			TreeNode temp2 = new TreeNode("Work-in-Progress (23)");
			temp2.ImageIndex = 4;
			temp2.SelectedImageIndex = 4;
			NETNode.Nodes.Add(temp2);
			TreeNode temp3 = new TreeNode("System Study (8)");
			temp3.ImageIndex = 1;
			temp3.SelectedImageIndex = 1;
			customTreeView.SelectedNode = temp3;
			NETNode.Nodes.Add(temp3);
			TreeNode temp4 = new TreeNode("Appraisals (7)");
			temp4.ImageIndex = 2;
			temp4.SelectedImageIndex = 2;
			NETNode.Nodes.Add(temp4);
			TreeNode COMNode = new TreeNode("On COM+");
			COMNode.ImageIndex = 3;
			COMNode.SelectedImageIndex = 3;
			projectNode.Nodes.Add(COMNode);
			TreeNode temp5 = new TreeNode("Proposal Phase (7)");
			temp5.ImageIndex = 4;
			temp5.SelectedImageIndex = 4;
			COMNode.Nodes.Add(temp5);
			TreeNode temp6 = new TreeNode("Site Visit/Analysis (3)");
			temp6.ImageIndex = 1;
			temp6.SelectedImageIndex = 1;
			COMNode.Nodes.Add(temp6);
			TreeNode temp7 = new TreeNode("W-I-P (2)");
			temp7.ImageIndex = 2;
			temp7.SelectedImageIndex = 2;
			COMNode.Nodes.Add(temp7);
			TreeNode temp8 = new TreeNode("Delivered (41)");
			temp8.ImageIndex = 3;
			temp8.SelectedImageIndex = 3;
			COMNode.Nodes.Add(temp8);
			TreeNode ConsultNode = new TreeNode("On-line Consultancy");
			ConsultNode.ImageIndex = 4;
			ConsultNode.SelectedImageIndex = 4;
			projectNode.Nodes.Add(ConsultNode);
			TreeNode Assets = new TreeNode("Assets");
			Assets.ImageIndex = 1;
			Assets.SelectedImageIndex = 1;
			root.Nodes.Add(Assets);
			TreeNode People = new TreeNode("People");
			People.ImageIndex = 2;
			People.SelectedImageIndex = 2;
			root.Nodes.Add(People);
			TreeNode  Documents = new TreeNode("Documents (Templates)");
			Documents.ImageIndex = 3;
			Documents.SelectedImageIndex = 3;
			root.Nodes.Add(Documents);
			TreeNode  Papers = new TreeNode("White Papers");
			Papers.ImageIndex = 4;
			Papers.SelectedImageIndex = 4;
			Documents.Nodes.Add(Papers);
			TreeNode  Appraisals = new TreeNode("Appraisals");
			Appraisals.ImageIndex = 5;
			Appraisals.SelectedImageIndex = 5;
			Documents.Nodes.Add(Appraisals);
			customTreeView.TabIndex = 0;
			customTreeView.Scrollable = true;
			customTreeView.ExpandAll();
			
            // You could set the size of the drop-down window, if you need.
			//Size sz = new Size(350, customTreeView.Height);
			//this.binaryTreeViewComboBox1.DropDownWindowSize = sz;
			
             // Set your desired tree view control instance as the control that 
            // BinaryTreeViewComboBox .NET would display in its drop-down.

            this.binaryTreeViewComboBox1.TreeViewNativeInstance = customTreeView;
            customTreeView.BorderStyle = BorderStyle.None;
             * 
             * 
             * */

            #endregion

            _binaryTreeViewComboBox1.ShowBorderAlways = true;
            _binaryTreeViewComboBox1.TreeViewNativeInstance.ExpandAll();
            _binaryTreeViewComboBox1.TreeViewNativeInstance.Cursor = Cursors.Default;
        }

        private void PrepareTextDisplayStylesCombobox()
        {
            _textDisplayStyleComboBox.Items.AddRange(new object[]
            {
                "SelectedNode",
                "SelectedNodeAndAllChildNodes",
                "SelectedNodeAndAllParentNodesInTheHierarchy",
                "SelectedNodeAndChildrenAndAllParentNodesInTheHierarchy"
            });
        }

        private void SetupTreeviewComboboxDropdownWindowCloseCommandVisual(object sender, System.EventArgs e)
        {
            _openFileDialog1.Filter = @"Image Files(*.BMP;*.JPG;*.GIF)|*.BMP;*.JPG;*.GIF|All files (*.*)|*.*";
            _openFileDialog1.InitialDirectory = ".";

            if (_openFileDialog1.ShowDialog() == DialogResult.Cancel) return;

            _customImageFileLocation.Text = this._openFileDialog1.FileName;
            _binaryTreeViewComboBox1.CustomImageForClosingDropDownWindow = Image.FromFile(
                _customImageFileLocation.Text);
        }

        private void HandleTreeviewComboboxSelectedIndexChanged(object sender, System.EventArgs e)
        {
            var cmb = sender as BinaryTreeViewComboBox;
            if (cmb != null) _selectedItemText.Text = cmb.SelectedItem.ToString();
        }

        private void HandleTreeviewComboboxDisplayItemSetup(object sender, EventArgs e)
        {
            if (_textDisplayStyleComboBox.SelectedItem == null) return;

            switch (_textDisplayStyleComboBox.SelectedItem.ToString())
            {
                case "SelectedNode":
                    _binaryTreeViewComboBox1.DisplayThisFromTreeView = SelectionDisplayStyle.OnlySelectedNode;
                    break;
                case "SelectedNodeAndAllChildNodes":
                    _binaryTreeViewComboBox1.DisplayThisFromTreeView =
SelectionDisplayStyle.OnlySelectedNode |
SelectionDisplayStyle.IncludeAllChildNodes;
                    break;
                case "SelectedNodeAndAllParentNodesInTheHierarchy":
                    _binaryTreeViewComboBox1.DisplayThisFromTreeView =
SelectionDisplayStyle.OnlySelectedNode |
SelectionDisplayStyle.IncludeAllParentNodesInTheHierarchyPath;
                    break;
                case "SelectedNodeAndChildrenAndAllParentNodesInTheHierarchy":
                    _binaryTreeViewComboBox1.DisplayThisFromTreeView =
SelectionDisplayStyle.IncludeAllChildNodes |
SelectionDisplayStyle.IncludeAllParentNodesInTheHierarchyPath;
                    break;
            }
        }

        private void ShowBorderColorAlwaysCheckedChanged(object sender, EventArgs e)
        {
            if (_chkShowBorderColorAlways.Checked)
                _binaryTreeViewComboBox1.ShowBorderAlways = true;
            else
                _binaryTreeViewComboBox1.ShowBorderAlways = !true;
        }

        private void SetupSeperationCharacter(object sender, EventArgs e)
        {
            _binaryTreeViewComboBox1.SeperationCharacter = _seperationCharacterSetupTextBox.Text;
        }

        private void ApplyTreeViewComboboxFontToDropDownWindowCheckedChanged(object sender, EventArgs e)
        {
            _treeViewNative1.Font = _chkApplyTreeViewComboboxFontToDropDownWindow.Checked ? _fontDialog1.Font : DefaultFont;
        }

        private void BinaryTreeViewComboBoxAboutToShowDropDownWindow(object sender, EventArgs e)
        {
            _treeViewNative1.Font = _chkApplyTreeViewComboboxFontToDropDownWindow.Checked ? _fontDialog1.Font : DefaultFont;
        }

        #region Infrastructure bits

        private Label _label1;
        private Label _label2;
        private Label _label3;
        private BinaryTreeViewComboBox _binaryTreeViewComboBox1;
        private GroupBox _groupBox1;
        private SmartButton _comboBoxColor;
        private ColorDialog _colorDialog1;
        private FontDialog _fontDialog1;
        private SmartButton _buttonComboBoxFont;
        private SmartButton _treeViewBorderColor;
        private SmartButton _button1;
        private OpenFileDialog _openFileDialog1;
        private TextBox _customImageFileLocation;
        private Label _selectedItemText;
        private Label _displayTextStyle;
        private ComboBox _textDisplayStyleComboBox;
        private Label _sepChar;
        private TextBox _seperationCharacterSetupTextBox;
        private CheckBox _chkShowBorderColorAlways;
        private ImageList _imageList1;
        private BinaryTreeViewComboBox.TreeViewNative _treeViewNative1;
        private CheckBox _chkApplyTreeViewComboboxFontToDropDownWindow;
        private IContainer _components;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_components != null)
                {
                    _components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TreeViewComboBoxDemoForm));
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Delivered (19)");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Work-in-progress (33)");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("System Study (8)");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Audit (9)");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("On .NET", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4});
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Proposal phase (9)");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Site visit / Analysis (4)");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("W-I-P (2)");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Delivered (54)");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("On COM+", new System.Windows.Forms.TreeNode[] {
            treeNode6,
            treeNode7,
            treeNode8,
            treeNode9});
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Consultancy");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Projects", new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode10,
            treeNode11});
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("White Papers");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Appraisals");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Documents (Templates)", new System.Windows.Forms.TreeNode[] {
            treeNode13,
            treeNode14});
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Corporate", new System.Windows.Forms.TreeNode[] {
            treeNode12,
            treeNode15});
            this._label1 = new System.Windows.Forms.Label();
            this._groupBox1 = new System.Windows.Forms.GroupBox();
            this._chkApplyTreeViewComboboxFontToDropDownWindow = new System.Windows.Forms.CheckBox();
            this._chkShowBorderColorAlways = new System.Windows.Forms.CheckBox();
            this._seperationCharacterSetupTextBox = new System.Windows.Forms.TextBox();
            this._sepChar = new System.Windows.Forms.Label();
            this._textDisplayStyleComboBox = new System.Windows.Forms.ComboBox();
            this._displayTextStyle = new System.Windows.Forms.Label();
            this._label2 = new System.Windows.Forms.Label();
            this._button1 = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._customImageFileLocation = new System.Windows.Forms.TextBox();
            this._treeViewBorderColor = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._buttonComboBoxFont = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._comboBoxColor = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this._colorDialog1 = new System.Windows.Forms.ColorDialog();
            this._fontDialog1 = new System.Windows.Forms.FontDialog();
            this._openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this._selectedItemText = new System.Windows.Forms.Label();
            this._imageList1 = new System.Windows.Forms.ImageList(this._components);
            this._binaryTreeViewComboBox1 = new Binarymission.WinForms.Controls.ExtendedComboBoxControls.BinaryTreeViewComboBox();
            this._treeViewNative1 = new Binarymission.WinForms.Controls.ExtendedComboBoxControls.BinaryTreeViewComboBox.TreeViewNative();
            this._label3 = new System.Windows.Forms.Label();
            this._groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // _label1
            // 
            this._label1.Location = new System.Drawing.Point(16, 16);
            this._label1.Name = "_label1";
            this._label1.Size = new System.Drawing.Size(192, 16);
            this._label1.TabIndex = 0;
            this._label1.Text = "BinaryTreeViewComboBox .NET:";
            // 
            // _groupBox1
            // 
            this._groupBox1.Controls.Add(this._chkApplyTreeViewComboboxFontToDropDownWindow);
            this._groupBox1.Controls.Add(this._chkShowBorderColorAlways);
            this._groupBox1.Controls.Add(this._seperationCharacterSetupTextBox);
            this._groupBox1.Controls.Add(this._sepChar);
            this._groupBox1.Controls.Add(this._textDisplayStyleComboBox);
            this._groupBox1.Controls.Add(this._displayTextStyle);
            this._groupBox1.Controls.Add(this._label2);
            this._groupBox1.Controls.Add(this._button1);
            this._groupBox1.Controls.Add(this._customImageFileLocation);
            this._groupBox1.Controls.Add(this._treeViewBorderColor);
            this._groupBox1.Controls.Add(this._buttonComboBoxFont);
            this._groupBox1.Controls.Add(this._comboBoxColor);
            this._groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox1.Location = new System.Drawing.Point(16, 154);
            this._groupBox1.Name = "_groupBox1";
            this._groupBox1.Size = new System.Drawing.Size(575, 218);
            this._groupBox1.TabIndex = 2;
            this._groupBox1.TabStop = false;
            this._groupBox1.Text = "BinaryTreeViewComboBox properties";
            // 
            // chkApplyTreeViewComboboxFontToDropDownWindow
            // 
            this._chkApplyTreeViewComboboxFontToDropDownWindow.AutoSize = true;
            this._chkApplyTreeViewComboboxFontToDropDownWindow.Location = new System.Drawing.Point(264, 186);
            this._chkApplyTreeViewComboboxFontToDropDownWindow.Name = "_chkApplyTreeViewComboboxFontToDropDownWindow";
            this._chkApplyTreeViewComboboxFontToDropDownWindow.Size = new System.Drawing.Size(296, 17);
            this._chkApplyTreeViewComboboxFontToDropDownWindow.TabIndex = 11;
            this._chkApplyTreeViewComboboxFontToDropDownWindow.Text = "Apply TreeViewCombobox Font to the drop-down tree too";
            this._chkApplyTreeViewComboboxFontToDropDownWindow.UseVisualStyleBackColor = true;
            this._chkApplyTreeViewComboboxFontToDropDownWindow.CheckedChanged += new System.EventHandler(this.ApplyTreeViewComboboxFontToDropDownWindowCheckedChanged);
            // 
            // chkShowBorderColorAlways
            // 
            this._chkShowBorderColorAlways.Checked = true;
            this._chkShowBorderColorAlways.CheckState = System.Windows.Forms.CheckState.Checked;
            this._chkShowBorderColorAlways.Location = new System.Drawing.Point(19, 186);
            this._chkShowBorderColorAlways.Name = "_chkShowBorderColorAlways";
            this._chkShowBorderColorAlways.Size = new System.Drawing.Size(185, 16);
            this._chkShowBorderColorAlways.TabIndex = 10;
            this._chkShowBorderColorAlways.Text = "Show ComboBox border always";
            this._chkShowBorderColorAlways.CheckedChanged += new System.EventHandler(this.ShowBorderColorAlwaysCheckedChanged);
            // 
            // _seperationCharacterSetupTextBox
            // 
            this._seperationCharacterSetupTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._seperationCharacterSetupTextBox.Location = new System.Drawing.Point(264, 145);
            this._seperationCharacterSetupTextBox.Name = "_seperationCharacterSetupTextBox";
            this._seperationCharacterSetupTextBox.Size = new System.Drawing.Size(80, 20);
            this._seperationCharacterSetupTextBox.TabIndex = 9;
            this._seperationCharacterSetupTextBox.Text = ",";
            this._seperationCharacterSetupTextBox.TextChanged += new System.EventHandler(this.SetupSeperationCharacter);
            // 
            // _sepChar
            // 
            this._sepChar.Location = new System.Drawing.Point(16, 147);
            this._sepChar.Name = "_sepChar";
            this._sepChar.Size = new System.Drawing.Size(226, 20);
            this._sepChar.TabIndex = 8;
            this._sepChar.Text = "Multi node text display separation string:";
            // 
            // _textDisplayStyleComboBox
            // 
            this._textDisplayStyleComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._textDisplayStyleComboBox.Location = new System.Drawing.Point(264, 103);
            this._textDisplayStyleComboBox.Name = "_textDisplayStyleComboBox";
            this._textDisplayStyleComboBox.Size = new System.Drawing.Size(297, 21);
            this._textDisplayStyleComboBox.TabIndex = 7;
            this._textDisplayStyleComboBox.SelectedIndexChanged += new System.EventHandler(this.HandleTreeviewComboboxDisplayItemSetup);
            // 
            // _displayTextStyle
            // 
            this._displayTextStyle.Location = new System.Drawing.Point(261, 80);
            this._displayTextStyle.Name = "_displayTextStyle";
            this._displayTextStyle.Size = new System.Drawing.Size(152, 16);
            this._displayTextStyle.TabIndex = 6;
            this._displayTextStyle.Text = "ComboBox Display text style:";
            // 
            // _label2
            // 
            this._label2.Location = new System.Drawing.Point(14, 80);
            this._label2.Name = "_label2";
            this._label2.Size = new System.Drawing.Size(238, 16);
            this._label2.TabIndex = 5;
            this._label2.Text = "Drop-down window custom close button image:";
            // 
            // _button1
            // 
            this._button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._button1.BorderColor = System.Drawing.Color.Black;
            this._button1.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._button1.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._button1.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._button1.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._button1.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._button1.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._button1.ContextMenuProperties.UseGradientPainting = true;
            this._button1.DefaultTheme = true;
            this._button1.DialogResult = System.Windows.Forms.DialogResult.None;
            this._button1.DrawMenuButtonSeparator = true;
            this._button1.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._button1.DropDownMenuItems = null;
            this._button1.EndColor = System.Drawing.Color.Silver;
            this._button1.IsRenderingTheme = false;
            this._button1.LinearGradientRenderingAngle = 90F;
            this._button1.Location = new System.Drawing.Point(205, 104);
            this._button1.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._button1.MenuButtonSeparatorLineHeight = -1;
            this._button1.Name = "_button1";
            this._button1.PushedEndColor = System.Drawing.Color.White;
            this._button1.PushedStartColor = System.Drawing.Color.Silver;
            this._button1.Size = new System.Drawing.Size(21, 21);
            this._button1.StartColor = System.Drawing.Color.White;
            this._button1.TabIndex = 4;
            this._button1.Text = "...";
            this._button1.TextStringFormat = null;
            this._button1.TransparentColor = System.Drawing.Color.Empty;
            this._button1.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._button1.UseCustomTextStringFormat = false;
            this._button1.UseUserDefinedColorForArrowMark = true;
            this._button1.UseUserDefinedColorForMenuButtonSeparator = true;
            this._button1.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._button1.Click += new System.EventHandler(this.SetupTreeviewComboboxDropdownWindowCloseCommandVisual);
            // 
            // _customImageFileLocation
            // 
            this._customImageFileLocation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._customImageFileLocation.Location = new System.Drawing.Point(16, 104);
            this._customImageFileLocation.Name = "_customImageFileLocation";
            this._customImageFileLocation.Size = new System.Drawing.Size(188, 20);
            this._customImageFileLocation.TabIndex = 3;
            // 
            // _treeViewBorderColor
            // 
            this._treeViewBorderColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._treeViewBorderColor.BorderColor = System.Drawing.Color.Black;
            this._treeViewBorderColor.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._treeViewBorderColor.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._treeViewBorderColor.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._treeViewBorderColor.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._treeViewBorderColor.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._treeViewBorderColor.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._treeViewBorderColor.ContextMenuProperties.UseGradientPainting = true;
            this._treeViewBorderColor.DefaultTheme = true;
            this._treeViewBorderColor.DialogResult = System.Windows.Forms.DialogResult.None;
            this._treeViewBorderColor.DrawMenuButtonSeparator = true;
            this._treeViewBorderColor.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._treeViewBorderColor.DropDownMenuItems = null;
            this._treeViewBorderColor.EndColor = System.Drawing.Color.Silver;
            this._treeViewBorderColor.IsRenderingTheme = false;
            this._treeViewBorderColor.LinearGradientRenderingAngle = 90F;
            this._treeViewBorderColor.Location = new System.Drawing.Point(336, 32);
            this._treeViewBorderColor.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._treeViewBorderColor.MenuButtonSeparatorLineHeight = -1;
            this._treeViewBorderColor.Name = "_treeViewBorderColor";
            this._treeViewBorderColor.PushedEndColor = System.Drawing.Color.White;
            this._treeViewBorderColor.PushedStartColor = System.Drawing.Color.Silver;
            this._treeViewBorderColor.Size = new System.Drawing.Size(226, 32);
            this._treeViewBorderColor.StartColor = System.Drawing.Color.White;
            this._treeViewBorderColor.TabIndex = 2;
            this._treeViewBorderColor.Text = "DropDownTreeView Border color...";
            this._treeViewBorderColor.TextStringFormat = null;
            this._treeViewBorderColor.TransparentColor = System.Drawing.Color.Empty;
            this._treeViewBorderColor.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._treeViewBorderColor.UseCustomTextStringFormat = false;
            this._treeViewBorderColor.UseUserDefinedColorForArrowMark = true;
            this._treeViewBorderColor.UseUserDefinedColorForMenuButtonSeparator = true;
            this._treeViewBorderColor.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._treeViewBorderColor.Click += new System.EventHandler(this.SetupTreeviewComboboxDropdownWindowBorderColor);
            // 
            // _buttonComboBoxFont
            // 
            this._buttonComboBoxFont.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._buttonComboBoxFont.BorderColor = System.Drawing.Color.Black;
            this._buttonComboBoxFont.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._buttonComboBoxFont.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._buttonComboBoxFont.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._buttonComboBoxFont.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._buttonComboBoxFont.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._buttonComboBoxFont.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._buttonComboBoxFont.ContextMenuProperties.UseGradientPainting = true;
            this._buttonComboBoxFont.DefaultTheme = true;
            this._buttonComboBoxFont.DialogResult = System.Windows.Forms.DialogResult.None;
            this._buttonComboBoxFont.DrawMenuButtonSeparator = true;
            this._buttonComboBoxFont.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._buttonComboBoxFont.DropDownMenuItems = null;
            this._buttonComboBoxFont.EndColor = System.Drawing.Color.Silver;
            this._buttonComboBoxFont.IsRenderingTheme = false;
            this._buttonComboBoxFont.LinearGradientRenderingAngle = 90F;
            this._buttonComboBoxFont.Location = new System.Drawing.Point(176, 32);
            this._buttonComboBoxFont.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._buttonComboBoxFont.MenuButtonSeparatorLineHeight = -1;
            this._buttonComboBoxFont.Name = "_buttonComboBoxFont";
            this._buttonComboBoxFont.PushedEndColor = System.Drawing.Color.White;
            this._buttonComboBoxFont.PushedStartColor = System.Drawing.Color.Silver;
            this._buttonComboBoxFont.Size = new System.Drawing.Size(152, 32);
            this._buttonComboBoxFont.StartColor = System.Drawing.Color.White;
            this._buttonComboBoxFont.TabIndex = 1;
            this._buttonComboBoxFont.Text = "Combobox Font...";
            this._buttonComboBoxFont.TextStringFormat = null;
            this._buttonComboBoxFont.TransparentColor = System.Drawing.Color.Empty;
            this._buttonComboBoxFont.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._buttonComboBoxFont.UseCustomTextStringFormat = false;
            this._buttonComboBoxFont.UseUserDefinedColorForArrowMark = true;
            this._buttonComboBoxFont.UseUserDefinedColorForMenuButtonSeparator = true;
            this._buttonComboBoxFont.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._buttonComboBoxFont.Click += new System.EventHandler(this.SetupTreeviewComboboxFontForVisuals);
            // 
            // _comboBoxColor
            // 
            this._comboBoxColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this._comboBoxColor.BorderColor = System.Drawing.Color.Black;
            this._comboBoxColor.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this._comboBoxColor.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this._comboBoxColor.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this._comboBoxColor.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this._comboBoxColor.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this._comboBoxColor.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this._comboBoxColor.ContextMenuProperties.UseGradientPainting = true;
            this._comboBoxColor.DefaultTheme = true;
            this._comboBoxColor.DialogResult = System.Windows.Forms.DialogResult.None;
            this._comboBoxColor.DrawMenuButtonSeparator = true;
            this._comboBoxColor.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this._comboBoxColor.DropDownMenuItems = null;
            this._comboBoxColor.EndColor = System.Drawing.Color.Silver;
            this._comboBoxColor.IsRenderingTheme = false;
            this._comboBoxColor.LinearGradientRenderingAngle = 90F;
            this._comboBoxColor.Location = new System.Drawing.Point(16, 32);
            this._comboBoxColor.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this._comboBoxColor.MenuButtonSeparatorLineHeight = -1;
            this._comboBoxColor.Name = "_comboBoxColor";
            this._comboBoxColor.PushedEndColor = System.Drawing.Color.White;
            this._comboBoxColor.PushedStartColor = System.Drawing.Color.Silver;
            this._comboBoxColor.Size = new System.Drawing.Size(152, 32);
            this._comboBoxColor.StartColor = System.Drawing.Color.White;
            this._comboBoxColor.TabIndex = 0;
            this._comboBoxColor.Text = "Combobox Color...";
            this._comboBoxColor.TextStringFormat = null;
            this._comboBoxColor.TransparentColor = System.Drawing.Color.Empty;
            this._comboBoxColor.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this._comboBoxColor.UseCustomTextStringFormat = false;
            this._comboBoxColor.UseUserDefinedColorForArrowMark = true;
            this._comboBoxColor.UseUserDefinedColorForMenuButtonSeparator = true;
            this._comboBoxColor.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this._comboBoxColor.Click += new System.EventHandler(this.SetupTreeviewComboboxColorsForVisuals);
            // 
            // _selectedItemText
            // 
            this._selectedItemText.Location = new System.Drawing.Point(126, 118);
            this._selectedItemText.Name = "_selectedItemText";
            this._selectedItemText.Size = new System.Drawing.Size(451, 16);
            this._selectedItemText.TabIndex = 4;
            // 
            // _imageList1
            // 
            this._imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("_imageList1.ImageStream")));
            this._imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this._imageList1.Images.SetKeyName(0, "galeon-16x16x32b.png");
            this._imageList1.Images.SetKeyName(1, "iCab-16x16x32b.png");
            this._imageList1.Images.SetKeyName(2, "mozilla-16x16x32b.png");
            this._imageList1.Images.SetKeyName(3, "Net Positive-16x16x32b.png");
            this._imageList1.Images.SetKeyName(4, "phoenix-16x16x32b.png");
            // 
            // _binaryTreeViewComboBox1
            // 
            this._binaryTreeViewComboBox1.AlphaBlendFactorForControlPainting = 100;
            this._binaryTreeViewComboBox1.AlphaBlendFactorForDropDownPressedColor = 70;
            this._binaryTreeViewComboBox1.BackColor = System.Drawing.SystemColors.Window;
            this._binaryTreeViewComboBox1.ControlArrowColor = System.Drawing.Color.Black;
            this._binaryTreeViewComboBox1.CustomControlBorderColor = System.Drawing.Color.Teal;
            this._binaryTreeViewComboBox1.CustomDropDownWindowLocationPoint = new System.Drawing.Point(0, 0);
            this._binaryTreeViewComboBox1.CustomPaintingColor = System.Drawing.Color.Teal;
            this._binaryTreeViewComboBox1.DisplayCloseWindowImage = true;
            this._binaryTreeViewComboBox1.DisplayStyleIsFlat = true;
            this._binaryTreeViewComboBox1.DisplayThisFromTreeView = Binarymission.WinForms.Controls.ExtendedComboBoxControls.SelectionDisplayStyle.OnlySelectedNode;
            this._binaryTreeViewComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this._binaryTreeViewComboBox1.DropDownWindowBorderColor = System.Drawing.SystemColors.ControlText;
            this._binaryTreeViewComboBox1.DropDownWindowSize = new System.Drawing.Size(-1, 250);
            this._binaryTreeViewComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._binaryTreeViewComboBox1.ForeColor = System.Drawing.Color.Black;
            this._binaryTreeViewComboBox1.Location = new System.Drawing.Point(16, 40);
            this._binaryTreeViewComboBox1.Name = "_binaryTreeViewComboBox1";
            this._binaryTreeViewComboBox1.SetControlTextUponNodeSelection = true;
            this._binaryTreeViewComboBox1.ShowBorderAlways = true;
            this._binaryTreeViewComboBox1.ShowDropDownTreeViewWindowAfterAdjustingForVirtualAvailableScreenSpace = false;
            this._binaryTreeViewComboBox1.Size = new System.Drawing.Size(411, 21);
            this._binaryTreeViewComboBox1.TabIndex = 1;
            this._binaryTreeViewComboBox1.TreeViewNativeInstance = this._treeViewNative1;
            this._binaryTreeViewComboBox1.AboutToShowDropDownWindow += new System.EventHandler(this.BinaryTreeViewComboBoxAboutToShowDropDownWindow);
            this._binaryTreeViewComboBox1.SelectedIndexChanged += new System.EventHandler(this.HandleTreeviewComboboxSelectedIndexChanged);
            // 
            // _treeViewNative1
            // 
            this._treeViewNative1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._treeViewNative1.LineColor = System.Drawing.Color.Empty;
            this._treeViewNative1.Location = new System.Drawing.Point(420, 16);
            this._treeViewNative1.Name = "_treeViewNative1";
            treeNode1.ForeColor = System.Drawing.Color.Green;
            treeNode1.Name = "Node7";
            treeNode1.Text = "Delivered (19)";
            treeNode2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            treeNode2.Name = "Node8";
            treeNode2.Text = "Work-in-progress (33)";
            treeNode3.Name = "Node9";
            treeNode3.Text = "System Study (8)";
            treeNode4.ForeColor = System.Drawing.Color.Teal;
            treeNode4.Name = "Node10";
            treeNode4.Text = "Audit (9)";
            treeNode5.Name = "Node5";
            treeNode5.Text = "On .NET";
            treeNode6.Name = "Node12";
            treeNode6.Text = "Proposal phase (9)";
            treeNode7.ForeColor = System.Drawing.Color.Teal;
            treeNode7.Name = "Node13";
            treeNode7.Text = "Site visit / Analysis (4)";
            treeNode8.Name = "Node14";
            treeNode8.Text = "W-I-P (2)";
            treeNode9.ForeColor = System.Drawing.Color.Green;
            treeNode9.Name = "Node15";
            treeNode9.Text = "Delivered (54)";
            treeNode10.Name = "Node6";
            treeNode10.Text = "On COM+";
            treeNode11.Name = "Node16";
            treeNode11.Text = "Consultancy";
            treeNode12.Name = "Node1";
            treeNode12.Text = "Projects";
            treeNode13.Name = "Node3";
            treeNode13.Text = "White Papers";
            treeNode14.Name = "Node4";
            treeNode14.Text = "Appraisals";
            treeNode15.Name = "Node2";
            treeNode15.Text = "Documents (Templates)";
            treeNode16.Name = "Node0";
            treeNode16.Text = "Corporate";
            this._treeViewNative1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode16});
            this._treeViewNative1.Size = new System.Drawing.Size(202, 113);
            this._treeViewNative1.TabIndex = 8;
            // 
            // _label3
            // 
            this._label3.AutoSize = true;
            this._label3.Location = new System.Drawing.Point(20, 118);
            this._label3.Name = "label1";
            this._label3.Size = new System.Drawing.Size(91, 13);
            this._label3.TabIndex = 12;
            this._label3.Text = "Current Selection:";
            // 
            // TreeViewComboBoxDemoForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(621, 425);
            this.Controls.Add(this._label3);
            this.Controls.Add(this._selectedItemText);
            this.Controls.Add(this._groupBox1);
            this.Controls.Add(this._binaryTreeViewComboBox1);
            this.Controls.Add(this._label1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "TreeViewComboBoxDemoForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.TitlebarText = "Binarymission TreeViewCombobox .NET control Demo";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.HandleFormLoaded);
            this._groupBox1.ResumeLayout(false);
            this._groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.DoEvents();
            Application.Run(new TreeViewComboBoxDemoForm());
        }

        #endregion Infrastructure bits
    }
}
