﻿using Binarymission.Winforms.Controls;

namespace PostItNoteDemo
{
    partial class StickyNoteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StickyNoteForm));
            this.label1 = new System.Windows.Forms.Label();
            this.btnRunDefaultThemedNote = new System.Windows.Forms.Button();
            this.btnRunBlueThemedNote = new System.Windows.Forms.Button();
            this.btnRunOrangeThemedNote = new System.Windows.Forms.Button();
            this.btnRunBrownThemedNote = new System.Windows.Forms.Button();
            this.btnRunMonoChromeThemedNote = new System.Windows.Forms.Button();
            this.btnAppExit = new System.Windows.Forms.Button();
            this.groupBox2 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.txtStatusbarTooltip = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTitlebarTooltip = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.isStatusbarTooltipEnabled = new System.Windows.Forms.CheckBox();
            this.chkIsTitlebarTooltipEnabled = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.fontSetupDialogInvoker = new System.Windows.Forms.Button();
            this.noteText = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtStatusText = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.isUsingDefaultTextInputBox = new System.Windows.Forms.CheckBox();
            this.isStatusbarVisible = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.colorSetupDialogInvoker = new System.Windows.Forms.Button();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.noteTextForeColorDialog = new System.Windows.Forms.ColorDialog();
            this.btnSetupCustomNoteUI = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.chkSetupCustomNote = new System.Windows.Forms.CheckBox();
            this.grpAdvancedCustomOptions = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.statusbarForecolorDialogInvoker = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.postitnoteBackgroundColorInvoker = new System.Windows.Forms.Button();
            this.basicTitlebarGradientModes = new System.Windows.Forms.ComboBox();
            this.fullTitlebarGradientModes = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.basicTitlebarGradientEndColorInvoker = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.basicTitlebarGradientStartColorInvoker = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.isBasicTitlebarBackgroundGradient = new System.Windows.Forms.CheckBox();
            this.isDrawingBasicTitlebarEnabled = new System.Windows.Forms.RadioButton();
            this.fullTitlebarGradientEndColorInvoker = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.drawDefaultFullTitlebar = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.isFullTitlebarBackgroundGradient = new System.Windows.Forms.CheckBox();
            this.label14 = new System.Windows.Forms.Label();
            this.fullTitlebarGradientStartColorInvoker = new System.Windows.Forms.Button();
            this.groupBox3 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.fullTitlebarGradientStartColorDialog = new System.Windows.Forms.ColorDialog();
            this.fullTitlebarGradientEndColorDialog = new System.Windows.Forms.ColorDialog();
            this.basicTitlebarGradientStartColorDialog = new System.Windows.Forms.ColorDialog();
            this.basicTitlebarGradientEndColorDialog = new System.Windows.Forms.ColorDialog();
            this.postitnoteBackColorDialog = new System.Windows.Forms.ColorDialog();
            this.statusbarForecolorDialog = new System.Windows.Forms.ColorDialog();
            this.grpBuiltinThemes = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.groupBox2.SuspendLayout();
            this.grpAdvancedCustomOptions.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.grpBuiltinThemes.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "PostIt note Instances:";
            // 
            // btnRunDefaultThemedNote
            // 
            this.btnRunDefaultThemedNote.BackColor = System.Drawing.SystemColors.Control;
            this.btnRunDefaultThemedNote.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnRunDefaultThemedNote.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnRunDefaultThemedNote.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnRunDefaultThemedNote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRunDefaultThemedNote.Location = new System.Drawing.Point(17, 30);
            this.btnRunDefaultThemedNote.Name = "btnRunDefaultThemedNote";
            this.btnRunDefaultThemedNote.Size = new System.Drawing.Size(100, 26);
            this.btnRunDefaultThemedNote.TabIndex = 1;
            this.btnRunDefaultThemedNote.Text = "Default";
            this.btnRunDefaultThemedNote.UseVisualStyleBackColor = false;
            this.btnRunDefaultThemedNote.Click += new System.EventHandler(this.RunDefaultThemedNoteClicked);
            // 
            // btnRunBlueThemedNote
            // 
            this.btnRunBlueThemedNote.BackColor = System.Drawing.SystemColors.Control;
            this.btnRunBlueThemedNote.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnRunBlueThemedNote.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnRunBlueThemedNote.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnRunBlueThemedNote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRunBlueThemedNote.Location = new System.Drawing.Point(123, 30);
            this.btnRunBlueThemedNote.Name = "btnRunBlueThemedNote";
            this.btnRunBlueThemedNote.Size = new System.Drawing.Size(100, 26);
            this.btnRunBlueThemedNote.TabIndex = 2;
            this.btnRunBlueThemedNote.Text = "Blue";
            this.btnRunBlueThemedNote.UseVisualStyleBackColor = false;
            this.btnRunBlueThemedNote.Click += new System.EventHandler(this.RunBlueThemedNoteClicked);
            // 
            // btnRunOrangeThemedNote
            // 
            this.btnRunOrangeThemedNote.BackColor = System.Drawing.SystemColors.Control;
            this.btnRunOrangeThemedNote.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnRunOrangeThemedNote.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnRunOrangeThemedNote.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnRunOrangeThemedNote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRunOrangeThemedNote.Location = new System.Drawing.Point(229, 30);
            this.btnRunOrangeThemedNote.Name = "btnRunOrangeThemedNote";
            this.btnRunOrangeThemedNote.Size = new System.Drawing.Size(100, 26);
            this.btnRunOrangeThemedNote.TabIndex = 3;
            this.btnRunOrangeThemedNote.Text = "Orange";
            this.btnRunOrangeThemedNote.UseVisualStyleBackColor = false;
            this.btnRunOrangeThemedNote.Click += new System.EventHandler(this.RunOrangeThemedNoteClicked);
            // 
            // btnRunBrownThemedNote
            // 
            this.btnRunBrownThemedNote.BackColor = System.Drawing.SystemColors.Control;
            this.btnRunBrownThemedNote.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnRunBrownThemedNote.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnRunBrownThemedNote.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnRunBrownThemedNote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRunBrownThemedNote.Location = new System.Drawing.Point(124, 62);
            this.btnRunBrownThemedNote.Name = "btnRunBrownThemedNote";
            this.btnRunBrownThemedNote.Size = new System.Drawing.Size(100, 26);
            this.btnRunBrownThemedNote.TabIndex = 6;
            this.btnRunBrownThemedNote.Text = "Brown";
            this.btnRunBrownThemedNote.UseVisualStyleBackColor = false;
            this.btnRunBrownThemedNote.Click += new System.EventHandler(this.RunBrownThemedNoteClicked);
            // 
            // btnRunMonoChromeThemedNote
            // 
            this.btnRunMonoChromeThemedNote.BackColor = System.Drawing.SystemColors.Control;
            this.btnRunMonoChromeThemedNote.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnRunMonoChromeThemedNote.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnRunMonoChromeThemedNote.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnRunMonoChromeThemedNote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRunMonoChromeThemedNote.Location = new System.Drawing.Point(18, 62);
            this.btnRunMonoChromeThemedNote.Name = "btnRunMonoChromeThemedNote";
            this.btnRunMonoChromeThemedNote.Size = new System.Drawing.Size(100, 26);
            this.btnRunMonoChromeThemedNote.TabIndex = 7;
            this.btnRunMonoChromeThemedNote.Text = "MonoChrome";
            this.btnRunMonoChromeThemedNote.UseVisualStyleBackColor = false;
            this.btnRunMonoChromeThemedNote.Click += new System.EventHandler(this.RunMonoChromeThemedNoteClicked);
            // 
            // btnAppExit
            // 
            this.btnAppExit.BackColor = System.Drawing.SystemColors.Control;
            this.btnAppExit.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnAppExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnAppExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnAppExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAppExit.Location = new System.Drawing.Point(1098, 638);
            this.btnAppExit.Name = "btnAppExit";
            this.btnAppExit.Size = new System.Drawing.Size(100, 26);
            this.btnAppExit.TabIndex = 8;
            this.btnAppExit.Text = "E&xit";
            this.btnAppExit.UseVisualStyleBackColor = false;
            this.btnAppExit.Click += new System.EventHandler(this.AppExitClicked);
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundBrushColor1 = System.Drawing.Color.Transparent;
            this.groupBox2.BackgroundBrushColor2 = System.Drawing.Color.Transparent;
            this.groupBox2.BorderColor = System.Drawing.Color.DimGray;
            this.groupBox2.BorderThickness = 1F;
            this.groupBox2.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal;
            this.groupBox2.Controls.Add(this.txtStatusbarTooltip);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.isStatusbarTooltipEnabled);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.fontSetupDialogInvoker);
            this.groupBox2.Controls.Add(this.noteText);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtStatusText);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.isUsingDefaultTextInputBox);
            this.groupBox2.Controls.Add(this.isStatusbarVisible);
            this.groupBox2.DottedBorderDepth = 4;
            this.groupBox2.DottedBorderGap = 2;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopLeft;
            this.groupBox2.HeaderBackgroundColor1 = System.Drawing.Color.White;
            this.groupBox2.HeaderBackgroundColor2 = System.Drawing.Color.White;
            this.groupBox2.HeaderBackgroundLeftMargin = 0;
            this.groupBox2.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.groupBox2.HeaderBackgroundRightMargin = 2;
            this.groupBox2.HeaderBorderColor = System.Drawing.Color.Black;
            this.groupBox2.HeaderBorderThickness = 1;
            this.groupBox2.HeaderExtraHeightFactor = 8;
            this.groupBox2.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.groupBox2.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.groupBox2.IsHeaderBackgroundDrawingEnabled = true;
            this.groupBox2.IsHeaderBackgroundGradient = true;
            this.groupBox2.IsHeaderBorderDrawingEnabled = true;
            this.groupBox2.LinearGradientBrushGradientAngle = 90F;
            this.groupBox2.Location = new System.Drawing.Point(17, 169);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.groupBox2.RoundedCornersAngle = 60F;
            this.groupBox2.RoundedCornerTargets = Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.TopRight;
            this.groupBox2.ShouldDrawRoundedCorners = true;
            this.groupBox2.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.groupBox2.Size = new System.Drawing.Size(410, 454);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Standard Customisation Options";
            this.groupBox2.TextLeftMargin = 3;
            this.groupBox2.TextRightMargin = 3;
            // 
            // txtStatusbarTooltip
            // 
            this.txtStatusbarTooltip.Enabled = false;
            this.txtStatusbarTooltip.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatusbarTooltip.Location = new System.Drawing.Point(246, 301);
            this.txtStatusbarTooltip.Name = "txtStatusbarTooltip";
            this.txtStatusbarTooltip.Size = new System.Drawing.Size(141, 21);
            this.txtStatusbarTooltip.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(190, 304);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 15);
            this.label9.TabIndex = 17;
            this.label9.Text = "Tooltip:";
            // 
            // txtTitlebarTooltip
            // 
            this.txtTitlebarTooltip.Enabled = false;
            this.txtTitlebarTooltip.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTitlebarTooltip.Location = new System.Drawing.Point(263, 439);
            this.txtTitlebarTooltip.Name = "txtTitlebarTooltip";
            this.txtTitlebarTooltip.Size = new System.Drawing.Size(127, 21);
            this.txtTitlebarTooltip.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(210, 442);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 15);
            this.label4.TabIndex = 15;
            this.label4.Text = "Tooltip:";
            // 
            // isStatusbarTooltipEnabled
            // 
            this.isStatusbarTooltipEnabled.AutoSize = true;
            this.isStatusbarTooltipEnabled.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.isStatusbarTooltipEnabled.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.isStatusbarTooltipEnabled.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.isStatusbarTooltipEnabled.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.isStatusbarTooltipEnabled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.isStatusbarTooltipEnabled.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.isStatusbarTooltipEnabled.Location = new System.Drawing.Point(21, 302);
            this.isStatusbarTooltipEnabled.Name = "isStatusbarTooltipEnabled";
            this.isStatusbarTooltipEnabled.Size = new System.Drawing.Size(170, 19);
            this.isStatusbarTooltipEnabled.TabIndex = 14;
            this.isStatusbarTooltipEnabled.Text = "Statusbar Tooltip enabled?";
            this.isStatusbarTooltipEnabled.UseVisualStyleBackColor = true;
            this.isStatusbarTooltipEnabled.CheckedChanged += new System.EventHandler(this.IsStatusbarTooltipEnabledCheckedChanged);
            // 
            // isTitlebarTooltipEnabled
            // 
            this.chkIsTitlebarTooltipEnabled.AutoSize = true;
            this.chkIsTitlebarTooltipEnabled.Enabled = false;
            this.chkIsTitlebarTooltipEnabled.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.chkIsTitlebarTooltipEnabled.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.chkIsTitlebarTooltipEnabled.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.chkIsTitlebarTooltipEnabled.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.chkIsTitlebarTooltipEnabled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkIsTitlebarTooltipEnabled.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIsTitlebarTooltipEnabled.Location = new System.Drawing.Point(24, 440);
            this.chkIsTitlebarTooltipEnabled.Name = "isTitlebarTooltipEnabled";
            this.chkIsTitlebarTooltipEnabled.Size = new System.Drawing.Size(159, 19);
            this.chkIsTitlebarTooltipEnabled.TabIndex = 13;
            this.chkIsTitlebarTooltipEnabled.Text = "Titlebar Tooltip enabled?";
            this.chkIsTitlebarTooltipEnabled.UseVisualStyleBackColor = true;
            this.chkIsTitlebarTooltipEnabled.CheckedChanged += new System.EventHandler(this.IsTitlebarTooltipEnabledCheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(35, 223);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "PostIt note Font:";
            // 
            // fontSetupDialogInvoker
            // 
            this.fontSetupDialogInvoker.BackColor = System.Drawing.SystemColors.Control;
            this.fontSetupDialogInvoker.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.fontSetupDialogInvoker.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.fontSetupDialogInvoker.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.fontSetupDialogInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fontSetupDialogInvoker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fontSetupDialogInvoker.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fontSetupDialogInvoker.Location = new System.Drawing.Point(129, 219);
            this.fontSetupDialogInvoker.Name = "fontSetupDialogInvoker";
            this.fontSetupDialogInvoker.Size = new System.Drawing.Size(254, 23);
            this.fontSetupDialogInvoker.TabIndex = 9;
            this.fontSetupDialogInvoker.Text = "Abc...";
            this.fontSetupDialogInvoker.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.fontSetupDialogInvoker.UseVisualStyleBackColor = false;
            this.fontSetupDialogInvoker.Click += new System.EventHandler(this.FontDialogInvokerClicked);
            // 
            // noteText
            // 
            this.noteText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noteText.Location = new System.Drawing.Point(131, 68);
            this.noteText.Multiline = true;
            this.noteText.Name = "noteText";
            this.noteText.Size = new System.Drawing.Size(257, 115);
            this.noteText.TabIndex = 8;
            this.noteText.Text = "TODO(s): Today\r\n\r\n+ Chart data update\r\n+ Feedback review\r\n+ Timesheet update\r\n+ C" +
    "ertainly some more...";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(39, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "PostIt note text:";
            // 
            // txtStatusText
            // 
            this.txtStatusText.Enabled = false;
            this.txtStatusText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatusText.Location = new System.Drawing.Point(246, 273);
            this.txtStatusText.Name = "txtStatusText";
            this.txtStatusText.Size = new System.Drawing.Size(141, 21);
            this.txtStatusText.TabIndex = 6;
            this.txtStatusText.Text = "Sample status text.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(154, 276);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Status bar text:";
            // 
            // isUsingDefaultTextInputBox
            // 
            this.isUsingDefaultTextInputBox.AutoSize = true;
            this.isUsingDefaultTextInputBox.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.isUsingDefaultTextInputBox.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.isUsingDefaultTextInputBox.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.isUsingDefaultTextInputBox.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.isUsingDefaultTextInputBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.isUsingDefaultTextInputBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.isUsingDefaultTextInputBox.Location = new System.Drawing.Point(22, 38);
            this.isUsingDefaultTextInputBox.Name = "isUsingDefaultTextInputBox";
            this.isUsingDefaultTextInputBox.Size = new System.Drawing.Size(326, 19);
            this.isUsingDefaultTextInputBox.TabIndex = 3;
            this.isUsingDefaultTextInputBox.Text = "Use the built-in custom textbox control for input textbox?";
            this.isUsingDefaultTextInputBox.UseVisualStyleBackColor = true;
            // 
            // isStatusbarVisible
            // 
            this.isStatusbarVisible.AutoSize = true;
            this.isStatusbarVisible.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.isStatusbarVisible.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.isStatusbarVisible.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.isStatusbarVisible.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.isStatusbarVisible.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.isStatusbarVisible.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.isStatusbarVisible.Location = new System.Drawing.Point(21, 274);
            this.isStatusbarVisible.Name = "isStatusbarVisible";
            this.isStatusbarVisible.Size = new System.Drawing.Size(126, 19);
            this.isStatusbarVisible.TabIndex = 1;
            this.isStatusbarVisible.Text = "Display status bar?";
            this.isStatusbarVisible.UseVisualStyleBackColor = true;
            this.isStatusbarVisible.CheckedChanged += new System.EventHandler(this.IsStatusbarVisibleCheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(20, 352);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 15);
            this.label8.TabIndex = 12;
            this.label8.Text = "NoteText Forecolor:";
            // 
            // colorSetupDialogInvoker
            // 
            this.colorSetupDialogInvoker.BackColor = System.Drawing.SystemColors.Control;
            this.colorSetupDialogInvoker.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.colorSetupDialogInvoker.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.colorSetupDialogInvoker.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.colorSetupDialogInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.colorSetupDialogInvoker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colorSetupDialogInvoker.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.colorSetupDialogInvoker.Location = new System.Drawing.Point(263, 350);
            this.colorSetupDialogInvoker.Name = "colorSetupDialogInvoker";
            this.colorSetupDialogInvoker.Size = new System.Drawing.Size(128, 23);
            this.colorSetupDialogInvoker.TabIndex = 11;
            this.colorSetupDialogInvoker.Text = "Abc...";
            this.colorSetupDialogInvoker.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.colorSetupDialogInvoker.UseVisualStyleBackColor = false;
            this.colorSetupDialogInvoker.Click += new System.EventHandler(this.ColorSetupDialogInvokerClick);
            // 
            // btnSetupCustomNoteUI
            // 
            this.btnSetupCustomNoteUI.BackColor = System.Drawing.SystemColors.Control;
            this.btnSetupCustomNoteUI.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnSetupCustomNoteUI.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnSetupCustomNoteUI.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnSetupCustomNoteUI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSetupCustomNoteUI.Location = new System.Drawing.Point(757, 75);
            this.btnSetupCustomNoteUI.Name = "btnSetupCustomNoteUI";
            this.btnSetupCustomNoteUI.Size = new System.Drawing.Size(100, 26);
            this.btnSetupCustomNoteUI.TabIndex = 4;
            this.btnSetupCustomNoteUI.Text = "Custom";
            this.btnSetupCustomNoteUI.UseVisualStyleBackColor = false;
            this.btnSetupCustomNoteUI.Click += new System.EventHandler(this.SetupCustomNoteUiClicked);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(443, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 16);
            this.label3.TabIndex = 10;
            this.label3.Text = "OR alternatively...";
            // 
            // chkSetupCustomNote
            // 
            this.chkSetupCustomNote.AutoSize = true;
            this.chkSetupCustomNote.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.chkSetupCustomNote.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.chkSetupCustomNote.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.chkSetupCustomNote.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.chkSetupCustomNote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkSetupCustomNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSetupCustomNote.Location = new System.Drawing.Point(446, 82);
            this.chkSetupCustomNote.Name = "chkSetupCustomNote";
            this.chkSetupCustomNote.Size = new System.Drawing.Size(177, 19);
            this.chkSetupCustomNote.TabIndex = 11;
            this.chkSetupCustomNote.Text = "Setup Custom PostIt Note UI";
            this.chkSetupCustomNote.UseVisualStyleBackColor = true;
            this.chkSetupCustomNote.CheckedChanged += new System.EventHandler(this.SetupCustomNote);
            // 
            // grpAdvancedCustomOptions
            // 
            this.grpAdvancedCustomOptions.BackgroundBrushColor1 = System.Drawing.Color.Transparent;
            this.grpAdvancedCustomOptions.BackgroundBrushColor2 = System.Drawing.Color.Transparent;
            this.grpAdvancedCustomOptions.BorderColor = System.Drawing.Color.DimGray;
            this.grpAdvancedCustomOptions.BorderThickness = 1F;
            this.grpAdvancedCustomOptions.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal;
            this.grpAdvancedCustomOptions.Controls.Add(this.label19);
            this.grpAdvancedCustomOptions.Controls.Add(this.statusbarForecolorDialogInvoker);
            this.grpAdvancedCustomOptions.Controls.Add(this.txtTitlebarTooltip);
            this.grpAdvancedCustomOptions.Controls.Add(this.label4);
            this.grpAdvancedCustomOptions.Controls.Add(this.label18);
            this.grpAdvancedCustomOptions.Controls.Add(this.postitnoteBackgroundColorInvoker);
            this.grpAdvancedCustomOptions.Controls.Add(this.chkIsTitlebarTooltipEnabled);
            this.grpAdvancedCustomOptions.Controls.Add(this.basicTitlebarGradientModes);
            this.grpAdvancedCustomOptions.Controls.Add(this.fullTitlebarGradientModes);
            this.grpAdvancedCustomOptions.Controls.Add(this.label16);
            this.grpAdvancedCustomOptions.Controls.Add(this.basicTitlebarGradientEndColorInvoker);
            this.grpAdvancedCustomOptions.Controls.Add(this.label17);
            this.grpAdvancedCustomOptions.Controls.Add(this.basicTitlebarGradientStartColorInvoker);
            this.grpAdvancedCustomOptions.Controls.Add(this.label8);
            this.grpAdvancedCustomOptions.Controls.Add(this.colorSetupDialogInvoker);
            this.grpAdvancedCustomOptions.Controls.Add(this.label15);
            this.grpAdvancedCustomOptions.Controls.Add(this.isBasicTitlebarBackgroundGradient);
            this.grpAdvancedCustomOptions.Controls.Add(this.isDrawingBasicTitlebarEnabled);
            this.grpAdvancedCustomOptions.Controls.Add(this.fullTitlebarGradientEndColorInvoker);
            this.grpAdvancedCustomOptions.Controls.Add(this.label10);
            this.grpAdvancedCustomOptions.Controls.Add(this.drawDefaultFullTitlebar);
            this.grpAdvancedCustomOptions.Controls.Add(this.label13);
            this.grpAdvancedCustomOptions.Controls.Add(this.isFullTitlebarBackgroundGradient);
            this.grpAdvancedCustomOptions.Controls.Add(this.label14);
            this.grpAdvancedCustomOptions.Controls.Add(this.fullTitlebarGradientStartColorInvoker);
            this.grpAdvancedCustomOptions.DottedBorderDepth = 4;
            this.grpAdvancedCustomOptions.DottedBorderGap = 2;
            this.grpAdvancedCustomOptions.Enabled = false;
            this.grpAdvancedCustomOptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAdvancedCustomOptions.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopLeft;
            this.grpAdvancedCustomOptions.HeaderBackgroundColor1 = System.Drawing.Color.White;
            this.grpAdvancedCustomOptions.HeaderBackgroundColor2 = System.Drawing.Color.White;
            this.grpAdvancedCustomOptions.HeaderBackgroundLeftMargin = 0;
            this.grpAdvancedCustomOptions.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.grpAdvancedCustomOptions.HeaderBackgroundRightMargin = 2;
            this.grpAdvancedCustomOptions.HeaderBorderColor = System.Drawing.Color.Black;
            this.grpAdvancedCustomOptions.HeaderBorderThickness = 1;
            this.grpAdvancedCustomOptions.HeaderExtraHeightFactor = 8;
            this.grpAdvancedCustomOptions.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAdvancedCustomOptions.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.grpAdvancedCustomOptions.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.grpAdvancedCustomOptions.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.grpAdvancedCustomOptions.IsHeaderBackgroundDrawingEnabled = true;
            this.grpAdvancedCustomOptions.IsHeaderBackgroundGradient = true;
            this.grpAdvancedCustomOptions.IsHeaderBorderDrawingEnabled = true;
            this.grpAdvancedCustomOptions.LinearGradientBrushGradientAngle = 90F;
            this.grpAdvancedCustomOptions.Location = new System.Drawing.Point(446, 146);
            this.grpAdvancedCustomOptions.Name = "grpAdvancedCustomOptions";
            this.grpAdvancedCustomOptions.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.grpAdvancedCustomOptions.RoundedCornersAngle = 60F;
            this.grpAdvancedCustomOptions.RoundedCornerTargets = Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.TopRight;
            this.grpAdvancedCustomOptions.ShouldDrawRoundedCorners = true;
            this.grpAdvancedCustomOptions.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.grpAdvancedCustomOptions.Size = new System.Drawing.Size(411, 477);
            this.grpAdvancedCustomOptions.TabIndex = 12;
            this.grpAdvancedCustomOptions.TabStop = false;
            this.grpAdvancedCustomOptions.Text = "Advanced Customisation Options";
            this.grpAdvancedCustomOptions.TextLeftMargin = 3;
            this.grpAdvancedCustomOptions.TextRightMargin = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(20, 406);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(135, 15);
            this.label19.TabIndex = 36;
            this.label19.Text = "Statusbar text forecolor:";
            // 
            // statusbarForecolorDialogInvoker
            // 
            this.statusbarForecolorDialogInvoker.BackColor = System.Drawing.SystemColors.Control;
            this.statusbarForecolorDialogInvoker.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.statusbarForecolorDialogInvoker.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.statusbarForecolorDialogInvoker.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.statusbarForecolorDialogInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.statusbarForecolorDialogInvoker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusbarForecolorDialogInvoker.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.statusbarForecolorDialogInvoker.Location = new System.Drawing.Point(263, 404);
            this.statusbarForecolorDialogInvoker.Name = "statusbarForecolorDialogInvoker";
            this.statusbarForecolorDialogInvoker.Size = new System.Drawing.Size(128, 23);
            this.statusbarForecolorDialogInvoker.TabIndex = 35;
            this.statusbarForecolorDialogInvoker.Text = "Abc...";
            this.statusbarForecolorDialogInvoker.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.statusbarForecolorDialogInvoker.UseVisualStyleBackColor = false;
            this.statusbarForecolorDialogInvoker.Click += new System.EventHandler(this.StatusBarForecolorDialogInvokerClicked);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(20, 381);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(167, 15);
            this.label18.TabIndex = 34;
            this.label18.Text = "Postit Note background color:";
            // 
            // postitnoteBackgroundColorInvoker
            // 
            this.postitnoteBackgroundColorInvoker.BackColor = System.Drawing.SystemColors.Control;
            this.postitnoteBackgroundColorInvoker.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.postitnoteBackgroundColorInvoker.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.postitnoteBackgroundColorInvoker.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.postitnoteBackgroundColorInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.postitnoteBackgroundColorInvoker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postitnoteBackgroundColorInvoker.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.postitnoteBackgroundColorInvoker.Location = new System.Drawing.Point(263, 377);
            this.postitnoteBackgroundColorInvoker.Name = "postitnoteBackgroundColorInvoker";
            this.postitnoteBackgroundColorInvoker.Size = new System.Drawing.Size(127, 23);
            this.postitnoteBackgroundColorInvoker.TabIndex = 33;
            this.postitnoteBackgroundColorInvoker.Text = "Abc...";
            this.postitnoteBackgroundColorInvoker.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.postitnoteBackgroundColorInvoker.UseVisualStyleBackColor = false;
            this.postitnoteBackgroundColorInvoker.Click += new System.EventHandler(this.StickyNoteBackgroundColorInvokerClicked);
            // 
            // basicTitlebarGradientModes
            // 
            this.basicTitlebarGradientModes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.basicTitlebarGradientModes.FormattingEnabled = true;
            this.basicTitlebarGradientModes.Location = new System.Drawing.Point(265, 86);
            this.basicTitlebarGradientModes.Name = "basicTitlebarGradientModes";
            this.basicTitlebarGradientModes.Size = new System.Drawing.Size(126, 23);
            this.basicTitlebarGradientModes.TabIndex = 32;
            // 
            // fullTitlebarGradientModes
            // 
            this.fullTitlebarGradientModes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.fullTitlebarGradientModes.FormattingEnabled = true;
            this.fullTitlebarGradientModes.Location = new System.Drawing.Point(265, 242);
            this.fullTitlebarGradientModes.Name = "fullTitlebarGradientModes";
            this.fullTitlebarGradientModes.Size = new System.Drawing.Size(126, 23);
            this.fullTitlebarGradientModes.TabIndex = 31;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(63, 149);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(112, 15);
            this.label16.TabIndex = 30;
            this.label16.Text = "Gradient End color:";
            // 
            // basicTitlebarGradientEndColorInvoker
            // 
            this.basicTitlebarGradientEndColorInvoker.BackColor = System.Drawing.SystemColors.Control;
            this.basicTitlebarGradientEndColorInvoker.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.basicTitlebarGradientEndColorInvoker.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.basicTitlebarGradientEndColorInvoker.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.basicTitlebarGradientEndColorInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.basicTitlebarGradientEndColorInvoker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basicTitlebarGradientEndColorInvoker.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.basicTitlebarGradientEndColorInvoker.Location = new System.Drawing.Point(263, 150);
            this.basicTitlebarGradientEndColorInvoker.Name = "basicTitlebarGradientEndColorInvoker";
            this.basicTitlebarGradientEndColorInvoker.Size = new System.Drawing.Size(128, 23);
            this.basicTitlebarGradientEndColorInvoker.TabIndex = 29;
            this.basicTitlebarGradientEndColorInvoker.Text = "Abc...";
            this.basicTitlebarGradientEndColorInvoker.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.basicTitlebarGradientEndColorInvoker.UseVisualStyleBackColor = false;
            this.basicTitlebarGradientEndColorInvoker.Click += new System.EventHandler(this.BasicTitleBarGradientEndColorInvokerClicked);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(63, 119);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(115, 15);
            this.label17.TabIndex = 28;
            this.label17.Text = "Gradient Start color:";
            // 
            // basicTitlebarGradientStartColorInvoker
            // 
            this.basicTitlebarGradientStartColorInvoker.BackColor = System.Drawing.SystemColors.Control;
            this.basicTitlebarGradientStartColorInvoker.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.basicTitlebarGradientStartColorInvoker.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.basicTitlebarGradientStartColorInvoker.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.basicTitlebarGradientStartColorInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.basicTitlebarGradientStartColorInvoker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basicTitlebarGradientStartColorInvoker.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.basicTitlebarGradientStartColorInvoker.Location = new System.Drawing.Point(263, 120);
            this.basicTitlebarGradientStartColorInvoker.Name = "basicTitlebarGradientStartColorInvoker";
            this.basicTitlebarGradientStartColorInvoker.Size = new System.Drawing.Size(128, 23);
            this.basicTitlebarGradientStartColorInvoker.TabIndex = 27;
            this.basicTitlebarGradientStartColorInvoker.Text = "Abc...";
            this.basicTitlebarGradientStartColorInvoker.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.basicTitlebarGradientStartColorInvoker.UseVisualStyleBackColor = false;
            this.basicTitlebarGradientStartColorInvoker.Click += new System.EventHandler(this.BasicTitleBarGradientStartColorInvokerClicked);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(61, 306);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(112, 15);
            this.label15.TabIndex = 26;
            this.label15.Text = "Gradient End color:";
            // 
            // isBasicTitlebarBackgroundGradient
            // 
            this.isBasicTitlebarBackgroundGradient.AutoSize = true;
            this.isBasicTitlebarBackgroundGradient.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.isBasicTitlebarBackgroundGradient.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.isBasicTitlebarBackgroundGradient.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.isBasicTitlebarBackgroundGradient.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.isBasicTitlebarBackgroundGradient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.isBasicTitlebarBackgroundGradient.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.isBasicTitlebarBackgroundGradient.Location = new System.Drawing.Point(45, 55);
            this.isBasicTitlebarBackgroundGradient.Name = "isBasicTitlebarBackgroundGradient";
            this.isBasicTitlebarBackgroundGradient.Size = new System.Drawing.Size(303, 19);
            this.isBasicTitlebarBackgroundGradient.TabIndex = 20;
            this.isBasicTitlebarBackgroundGradient.Text = "Is the (built-in) \"basic titlebar\" background gradient?";
            this.isBasicTitlebarBackgroundGradient.UseVisualStyleBackColor = true;
            // 
            // isDrawingBasicTitlebarEnabled
            // 
            this.isDrawingBasicTitlebarEnabled.AutoSize = true;
            this.isDrawingBasicTitlebarEnabled.Location = new System.Drawing.Point(23, 30);
            this.isDrawingBasicTitlebarEnabled.Name = "isDrawingBasicTitlebarEnabled";
            this.isDrawingBasicTitlebarEnabled.Size = new System.Drawing.Size(325, 19);
            this.isDrawingBasicTitlebarEnabled.TabIndex = 19;
            this.isDrawingBasicTitlebarEnabled.TabStop = true;
            this.isDrawingBasicTitlebarEnabled.Text = "Is drawing the default (built-in) \"Basic\" titlebar enabled?";
            this.isDrawingBasicTitlebarEnabled.UseVisualStyleBackColor = true;
            // 
            // fullTitlebarGradientEndColorInvoker
            // 
            this.fullTitlebarGradientEndColorInvoker.BackColor = System.Drawing.SystemColors.Control;
            this.fullTitlebarGradientEndColorInvoker.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.fullTitlebarGradientEndColorInvoker.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.fullTitlebarGradientEndColorInvoker.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.fullTitlebarGradientEndColorInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fullTitlebarGradientEndColorInvoker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fullTitlebarGradientEndColorInvoker.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fullTitlebarGradientEndColorInvoker.Location = new System.Drawing.Point(266, 305);
            this.fullTitlebarGradientEndColorInvoker.Name = "fullTitlebarGradientEndColorInvoker";
            this.fullTitlebarGradientEndColorInvoker.Size = new System.Drawing.Size(125, 23);
            this.fullTitlebarGradientEndColorInvoker.TabIndex = 25;
            this.fullTitlebarGradientEndColorInvoker.Text = "Abc...";
            this.fullTitlebarGradientEndColorInvoker.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.fullTitlebarGradientEndColorInvoker.UseVisualStyleBackColor = false;
            this.fullTitlebarGradientEndColorInvoker.Click += new System.EventHandler(this.FullTitleBarGradientEndColorInvokerClicked);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(62, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(128, 15);
            this.label10.TabIndex = 11;
            this.label10.Text = "Linear gradient mode:";
            // 
            // drawDefaultFullTitlebar
            // 
            this.drawDefaultFullTitlebar.AutoSize = true;
            this.drawDefaultFullTitlebar.Location = new System.Drawing.Point(23, 189);
            this.drawDefaultFullTitlebar.Name = "drawDefaultFullTitlebar";
            this.drawDefaultFullTitlebar.Size = new System.Drawing.Size(315, 19);
            this.drawDefaultFullTitlebar.TabIndex = 13;
            this.drawDefaultFullTitlebar.TabStop = true;
            this.drawDefaultFullTitlebar.Text = "Is drawing the default (built-in) \"Full\" titlebar enabled?";
            this.drawDefaultFullTitlebar.UseVisualStyleBackColor = true;
            this.drawDefaultFullTitlebar.CheckedChanged += new System.EventHandler(this.DrawDefaultTitlebarCheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(61, 244);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(128, 15);
            this.label13.TabIndex = 21;
            this.label13.Text = "Linear gradient mode:";
            // 
            // isFullTitlebarBackgroundGradient
            // 
            this.isFullTitlebarBackgroundGradient.AutoSize = true;
            this.isFullTitlebarBackgroundGradient.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.isFullTitlebarBackgroundGradient.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.isFullTitlebarBackgroundGradient.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.isFullTitlebarBackgroundGradient.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.isFullTitlebarBackgroundGradient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.isFullTitlebarBackgroundGradient.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.isFullTitlebarBackgroundGradient.Location = new System.Drawing.Point(45, 214);
            this.isFullTitlebarBackgroundGradient.Name = "isFullTitlebarBackgroundGradient";
            this.isFullTitlebarBackgroundGradient.Size = new System.Drawing.Size(294, 19);
            this.isFullTitlebarBackgroundGradient.TabIndex = 22;
            this.isFullTitlebarBackgroundGradient.Text = "Is the (built-in) \"Full titlebar\" background gradient?";
            this.isFullTitlebarBackgroundGradient.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(61, 276);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(115, 15);
            this.label14.TabIndex = 24;
            this.label14.Text = "Gradient Start color:";
            // 
            // fullTitlebarGradientStartColorInvoker
            // 
            this.fullTitlebarGradientStartColorInvoker.BackColor = System.Drawing.SystemColors.Control;
            this.fullTitlebarGradientStartColorInvoker.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.fullTitlebarGradientStartColorInvoker.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.fullTitlebarGradientStartColorInvoker.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.fullTitlebarGradientStartColorInvoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fullTitlebarGradientStartColorInvoker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fullTitlebarGradientStartColorInvoker.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fullTitlebarGradientStartColorInvoker.Location = new System.Drawing.Point(266, 275);
            this.fullTitlebarGradientStartColorInvoker.Name = "fullTitlebarGradientStartColorInvoker";
            this.fullTitlebarGradientStartColorInvoker.Size = new System.Drawing.Size(125, 23);
            this.fullTitlebarGradientStartColorInvoker.TabIndex = 23;
            this.fullTitlebarGradientStartColorInvoker.Text = "Abc...";
            this.fullTitlebarGradientStartColorInvoker.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.fullTitlebarGradientStartColorInvoker.UseVisualStyleBackColor = false;
            this.fullTitlebarGradientStartColorInvoker.Click += new System.EventHandler(this.FullTitleBarGradientStartColorInvokerClicked);
            // 
            // groupBox3
            // 
            this.groupBox3.BackgroundBrushColor1 = System.Drawing.Color.Transparent;
            this.groupBox3.BackgroundBrushColor2 = System.Drawing.Color.Transparent;
            this.groupBox3.BorderColor = System.Drawing.Color.DimGray;
            this.groupBox3.BorderThickness = 1F;
            this.groupBox3.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal;
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.DottedBorderDepth = 4;
            this.groupBox3.DottedBorderGap = 2;
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopLeft;
            this.groupBox3.HeaderBackgroundColor1 = System.Drawing.Color.White;
            this.groupBox3.HeaderBackgroundColor2 = System.Drawing.Color.White;
            this.groupBox3.HeaderBackgroundLeftMargin = 0;
            this.groupBox3.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.groupBox3.HeaderBackgroundRightMargin = 2;
            this.groupBox3.HeaderBorderColor = System.Drawing.Color.Black;
            this.groupBox3.HeaderBorderThickness = 1;
            this.groupBox3.HeaderExtraHeightFactor = 8;
            this.groupBox3.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.groupBox3.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.groupBox3.IsHeaderBackgroundDrawingEnabled = true;
            this.groupBox3.IsHeaderBackgroundGradient = true;
            this.groupBox3.IsHeaderBorderDrawingEnabled = true;
            this.groupBox3.LinearGradientBrushGradientAngle = 90F;
            this.groupBox3.Location = new System.Drawing.Point(880, 53);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.groupBox3.RoundedCornersAngle = 60F;
            this.groupBox3.RoundedCornerTargets = Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.TopRight;
            this.groupBox3.ShouldDrawRoundedCorners = true;
            this.groupBox3.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.groupBox3.Size = new System.Drawing.Size(318, 570);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "More advanced capabilities available ";
            this.groupBox3.TextLeftMargin = 3;
            this.groupBox3.TextRightMargin = 3;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(16, 130);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(279, 70);
            this.label12.TabIndex = 12;
            this.label12.Text = "2. You could also set the property \"IsDefaultInputTextBoxVisible\" to false, and h" +
    "ost your own textbox/editing control as the note\'s text area control.";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(16, 39);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(279, 91);
            this.label11.TabIndex = 11;
            this.label11.Text = resources.GetString("label11.Text");
            // 
            // basicTitlebarGradientStartColorDialog
            // 
            this.basicTitlebarGradientStartColorDialog.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            // 
            // basicTitlebarGradientEndColorDialog
            // 
            this.basicTitlebarGradientEndColorDialog.Color = System.Drawing.Color.White;
            // 
            // postitnoteBackColorDialog
            // 
            this.postitnoteBackColorDialog.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            // 
            // grpBuiltinThemes
            // 
            this.grpBuiltinThemes.BackgroundBrushColor1 = System.Drawing.Color.Transparent;
            this.grpBuiltinThemes.BackgroundBrushColor2 = System.Drawing.Color.Transparent;
            this.grpBuiltinThemes.BorderColor = System.Drawing.Color.DimGray;
            this.grpBuiltinThemes.BorderThickness = 1F;
            this.grpBuiltinThemes.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal;
            this.grpBuiltinThemes.Controls.Add(this.btnRunDefaultThemedNote);
            this.grpBuiltinThemes.Controls.Add(this.btnRunBlueThemedNote);
            this.grpBuiltinThemes.Controls.Add(this.btnRunOrangeThemedNote);
            this.grpBuiltinThemes.Controls.Add(this.btnRunBrownThemedNote);
            this.grpBuiltinThemes.Controls.Add(this.btnRunMonoChromeThemedNote);
            this.grpBuiltinThemes.DottedBorderDepth = 4;
            this.grpBuiltinThemes.DottedBorderGap = 2;
            this.grpBuiltinThemes.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopLeft;
            this.grpBuiltinThemes.HeaderBackgroundColor1 = System.Drawing.Color.White;
            this.grpBuiltinThemes.HeaderBackgroundColor2 = System.Drawing.Color.White;
            this.grpBuiltinThemes.HeaderBackgroundLeftMargin = 0;
            this.grpBuiltinThemes.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.grpBuiltinThemes.HeaderBackgroundRightMargin = 2;
            this.grpBuiltinThemes.HeaderBorderColor = System.Drawing.Color.Black;
            this.grpBuiltinThemes.HeaderBorderThickness = 1;
            this.grpBuiltinThemes.HeaderExtraHeightFactor = 8;
            this.grpBuiltinThemes.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBuiltinThemes.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.grpBuiltinThemes.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.grpBuiltinThemes.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.grpBuiltinThemes.IsHeaderBackgroundDrawingEnabled = true;
            this.grpBuiltinThemes.IsHeaderBackgroundGradient = true;
            this.grpBuiltinThemes.IsHeaderBorderDrawingEnabled = true;
            this.grpBuiltinThemes.LinearGradientBrushGradientAngle = 90F;
            this.grpBuiltinThemes.Location = new System.Drawing.Point(17, 46);
            this.grpBuiltinThemes.Name = "grpBuiltinThemes";
            this.grpBuiltinThemes.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.grpBuiltinThemes.RoundedCornersAngle = 60F;
            this.grpBuiltinThemes.RoundedCornerTargets = Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.TopRight;
            this.grpBuiltinThemes.ShouldDrawRoundedCorners = true;
            this.grpBuiltinThemes.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.grpBuiltinThemes.Size = new System.Drawing.Size(410, 103);
            this.grpBuiltinThemes.TabIndex = 14;
            this.grpBuiltinThemes.TabStop = false;
            this.grpBuiltinThemes.Text = "Choose a built-in theme:";
            this.grpBuiltinThemes.TextLeftMargin = 3;
            this.grpBuiltinThemes.TextRightMargin = 3;
            // 
            // StickyNoteForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(1225, 714);
            this.Controls.Add(this.grpBuiltinThemes);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.grpAdvancedCustomOptions);
            this.Controls.Add(this.chkSetupCustomNote);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnAppExit);
            this.Controls.Add(this.btnSetupCustomNoteUI);
            this.Controls.Add(this.label1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "StickyNoteForm";
            this.TitlebarText = "Binarymission PostIt .NET control demo";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grpAdvancedCustomOptions.ResumeLayout(false);
            this.grpAdvancedCustomOptions.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.grpBuiltinThemes.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRunDefaultThemedNote;
        private System.Windows.Forms.Button btnRunBlueThemedNote;
        private System.Windows.Forms.Button btnRunOrangeThemedNote;
        private System.Windows.Forms.Button btnRunBrownThemedNote;
        private System.Windows.Forms.Button btnRunMonoChromeThemedNote;
        private System.Windows.Forms.Button btnAppExit;
        private AdvancedGroupBox groupBox2;
        private System.Windows.Forms.TextBox noteText;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtStatusText;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox isUsingDefaultTextInputBox;
        private System.Windows.Forms.CheckBox isStatusbarVisible;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button colorSetupDialogInvoker;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button fontSetupDialogInvoker;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ColorDialog noteTextForeColorDialog;
        private System.Windows.Forms.Button btnSetupCustomNoteUI;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkSetupCustomNote;
        private AdvancedGroupBox grpAdvancedCustomOptions;
        private System.Windows.Forms.TextBox txtStatusbarTooltip;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTitlebarTooltip;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox isStatusbarTooltipEnabled;
        private System.Windows.Forms.CheckBox chkIsTitlebarTooltipEnabled;
        private System.Windows.Forms.RadioButton drawDefaultFullTitlebar;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton isDrawingBasicTitlebarEnabled;
        private System.Windows.Forms.CheckBox isBasicTitlebarBackgroundGradient;
        private AdvancedGroupBox groupBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox isFullTitlebarBackgroundGradient;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button fullTitlebarGradientEndColorInvoker;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button fullTitlebarGradientStartColorInvoker;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button basicTitlebarGradientEndColorInvoker;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button basicTitlebarGradientStartColorInvoker;
        private System.Windows.Forms.ColorDialog fullTitlebarGradientStartColorDialog;
        private System.Windows.Forms.ColorDialog fullTitlebarGradientEndColorDialog;
        private System.Windows.Forms.ColorDialog basicTitlebarGradientStartColorDialog;
        private System.Windows.Forms.ColorDialog basicTitlebarGradientEndColorDialog;
        private System.Windows.Forms.ComboBox fullTitlebarGradientModes;
        private System.Windows.Forms.ComboBox basicTitlebarGradientModes;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button postitnoteBackgroundColorInvoker;
        private System.Windows.Forms.ColorDialog postitnoteBackColorDialog;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button statusbarForecolorDialogInvoker;
        private System.Windows.Forms.ColorDialog statusbarForecolorDialog;
        private AdvancedGroupBox grpBuiltinThemes;
    }
}

