﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls;
using Binarymission.WinForms.Controls.ContainerControls.Enums;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using PostItNoteDemo.Properties;

namespace PostItNoteDemo
{
    public partial class StickyNoteForm : ModernChromeWindow
    {
        public StickyNoteForm()
        {
            ConstructInstance();
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
        }

        private void ConstructInstance()
        {
            InitializeComponent();
            InitialiseStartupState();
        }
        
        private void InitialiseStartupState()
        {
            btnSetupCustomNoteUI.Enabled = chkSetupCustomNote.Checked;
            fullTitlebarGradientModes.Items.AddRange(Enum.GetNames(typeof(LinearGradientMode)));
            basicTitlebarGradientModes.Items.AddRange(Enum.GetNames(typeof(LinearGradientMode)));
            fullTitlebarGradientModes.SelectedIndex = 0;
            basicTitlebarGradientModes.SelectedIndex = 0;
        }

        private void RunDefaultThemedNoteClicked(object sender, EventArgs e)
        {
            var stickyNote = new PostItNote (this) {NoteTheme = NoteTheme.Default};
            SetupNoteInstance(stickyNote);
            stickyNote.Show(this);
        }

        private void SetupNoteInstance(PostItNote stickyNote)
        {
            if (stickyNote.NoteTheme == NoteTheme.Custom)
            {
                stickyNote.BackColor = postitnoteBackColorDialog.Color;
            }

            stickyNote.IsDefaultTitlebarVisible = drawDefaultFullTitlebar.Checked;
            stickyNote.BasicTitlebarLinearGradientMode = (LinearGradientMode) Enum.Parse(typeof (LinearGradientMode),
                                                                                         basicTitlebarGradientModes.SelectedItem.ToString());
            
            stickyNote.DefaultTitlebarLinearGradientMode = (LinearGradientMode) Enum.Parse(typeof (LinearGradientMode),
                                                                                         fullTitlebarGradientModes.SelectedItem.ToString());
            
            if (!isBasicTitlebarBackgroundGradient.Checked)
            {
                stickyNote.TitlebarBrush = new SolidBrush(fullTitlebarGradientStartColorDialog.Color);
            }
            else
            {
                stickyNote.BasicTitlebarGradientStartColor = basicTitlebarGradientStartColorDialog.Color;
                stickyNote.BasicTitlebarGradientEndColor = basicTitlebarGradientEndColorDialog.Color;
            }

            if (!isFullTitlebarBackgroundGradient.Checked)
            {
                stickyNote.TitlebarBrush = new SolidBrush(fullTitlebarGradientStartColorDialog.Color);
            }
            else
            {
                stickyNote.TitlebarBrush = null;
                stickyNote.DefaultTitlebarBrushStartColor = fullTitlebarGradientStartColorDialog.Color;
                stickyNote.DefaultTitlebarBrushEndColor = fullTitlebarGradientEndColorDialog.Color;
            }
            
            stickyNote.StatusbarForeColor = statusbarForecolorDialog.Color;
            stickyNote.IsStatusBarVisible = isStatusbarVisible.Checked;
            stickyNote.IsBasicTitlebarBackgroundGradient = isBasicTitlebarBackgroundGradient.Checked;
            stickyNote.NoteText = noteText.Text;
            stickyNote.StatusbarText = txtStatusText.Text;
            stickyNote.IsDefaultInputTextBoxVisible = isUsingDefaultTextInputBox.Checked;
            stickyNote.DefaultInputTextBoxFont = fontDialog1.Font;
            stickyNote.DefaultInputTextBoxForecolor = noteTextForeColorDialog.Color;
            stickyNote.PostItNoteCloseRequested += StickyNoteCloseRequested;
            stickyNote.PostItNoteCommandBarInvokeRequested += StickyNoteCommandBarInvokeRequested;
            stickyNote.PostiItNoteBasicTitlebarDoubleClicked += StickyNoteBasicTitlebarDoubleClicked;
            stickyNote.PostiItNoteBasicTitlebarRightClicked += StickyNoteBasicTitlebarRightClicked;
            stickyNote.PostiItNoteDefaultTitlebarDoubleClicked += StickyNoteDefaultTitlebarDoubleClicked;
            stickyNote.PostiItNoteDefaultTitlebarRightClicked += StickyNoteDefaultTitlebarRightClicked;
            stickyNote.TitlebarTooltip = chkIsTitlebarTooltipEnabled.Checked ? txtTitlebarTooltip.Text : null;
            stickyNote.StatusbarTooltip = isStatusbarTooltipEnabled.Checked ? txtStatusbarTooltip.Text : null;
        }

        private void RunBlueThemedNoteClicked(object sender, EventArgs e)
        {
            var stickyNote = new PostItNote(this) { NoteTheme = NoteTheme.Blue };
            SetupNoteInstance(stickyNote);
            stickyNote.Show(this);
        }

        private void RunOrangeThemedNoteClicked(object sender, EventArgs e)
        {
            var stickyNote = new PostItNote(this) { NoteTheme = NoteTheme.Orange };
            SetupNoteInstance(stickyNote);
            stickyNote.Show(this);
        }

        private void RunBrownThemedNoteClicked(object sender, EventArgs e)
        {
            var stickyNote = new PostItNote(this) { NoteTheme = NoteTheme.Brown };
            SetupNoteInstance(stickyNote);
            stickyNote.Show(this);
        }

        private void RunMonoChromeThemedNoteClicked(object sender, EventArgs e)
        {
            var stickyNote = new PostItNote(this) { NoteTheme = NoteTheme.MonoChrome };
            SetupNoteInstance(stickyNote);
            stickyNote.Show(this);
        }

        private void SetupCustomNoteUiClicked(object sender, EventArgs e)
        {
            var stickyNote = new PostItNote(this) { NoteTheme = NoteTheme.Custom };
            SetupNoteInstance(stickyNote);
            stickyNote.Show(this);
        }

        private void FontDialogInvokerClicked(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog(this);
            fontSetupDialogInvoker.Font = fontDialog1.Font;
        }

        private void ColorSetupDialogInvokerClick(object sender, EventArgs e)
        {
            noteTextForeColorDialog.ShowDialog(this);
            colorSetupDialogInvoker.ForeColor = noteTextForeColorDialog.Color;
        }

        private void StickyNoteDefaultTitlebarRightClicked(object sender, EventArgs e)
        {
            MessageBox.Show(Resources.PostitNote_PostiItNoteDefaultTitlebarRightClicked, 
                            Resources.PostitNote_PostiItNoteDefaultTitlebarRightClicked_Info, 
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        private void StickyNoteDefaultTitlebarDoubleClicked(object sender, EventArgs e)
        {
            MessageBox.Show(Resources.PostitNote_PostiItNoteDefaultTitlebarDoubleClicked,
                            Resources.PostitNote_PostiItNoteDefaultTitlebarRightClicked_Info, 
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        private void StickyNoteBasicTitlebarRightClicked(object sender, EventArgs e)
        {
            MessageBox.Show(Resources.PostitNote_PostiItNoteBasicTitlebarRightClicked,
                            Resources.PostitNote_PostiItNoteDefaultTitlebarRightClicked_Info,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        private void StickyNoteBasicTitlebarDoubleClicked(object sender, EventArgs e)
        {
            MessageBox.Show(Resources.PostitNote_PostiItNoteBasicTitlebarDoubleClicked, 
                            Resources.PostitNote_PostiItNoteDefaultTitlebarRightClicked_Info, 
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        private void StickyNoteCommandBarInvokeRequested(object sender, EventArgs e)
        {
            MessageBox.Show(Resources.PostitNote_PostItNoteCommandBarInvokeRequested, 
                            Resources.PostitNote_PostItNoteCommandBarInvokeRequested_Command_Bar,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        private static void StickyNoteCloseRequested(object sender, EventArgs e)
        {
            var stickyNote = sender as PostItNote;
            stickyNote?.Close();
        }

        private void AppExitClicked(object sender, EventArgs e)
        {
            Close();
        }

        private void SetupCustomNote(object sender, EventArgs e)
        {
            grpBuiltinThemes.Enabled = !chkSetupCustomNote.Checked;
            grpAdvancedCustomOptions.Enabled = chkSetupCustomNote.Checked;
            btnSetupCustomNoteUI.Enabled = chkSetupCustomNote.Checked;
        }

        private void FullTitleBarGradientStartColorInvokerClicked(object sender, EventArgs e)
        {
            fullTitlebarGradientStartColorDialog.ShowDialog(this);
            fullTitlebarGradientStartColorInvoker.ForeColor = fullTitlebarGradientStartColorDialog.Color;
        }

        private void FullTitleBarGradientEndColorInvokerClicked(object sender, EventArgs e)
        {
            fullTitlebarGradientEndColorDialog.ShowDialog(this);
            fullTitlebarGradientEndColorInvoker.ForeColor = fullTitlebarGradientEndColorDialog.Color;
        }

        private void BasicTitleBarGradientStartColorInvokerClicked(object sender, EventArgs e)
        {
            basicTitlebarGradientStartColorDialog.ShowDialog(this);
            basicTitlebarGradientStartColorInvoker.ForeColor = basicTitlebarGradientStartColorDialog.Color;
        }

        private void BasicTitleBarGradientEndColorInvokerClicked(object sender, EventArgs e)
        {
            basicTitlebarGradientEndColorDialog.ShowDialog(this);
            basicTitlebarGradientEndColorInvoker.ForeColor = basicTitlebarGradientEndColorDialog.Color;
        }

        private void StickyNoteBackgroundColorInvokerClicked(object sender, EventArgs e)
        {
            postitnoteBackColorDialog.ShowDialog(this);
            postitnoteBackgroundColorInvoker.BackColor = postitnoteBackColorDialog.Color;
        }

        private void StatusBarForecolorDialogInvokerClicked(object sender, EventArgs e)
        {
            statusbarForecolorDialog.ShowDialog(this);
            statusbarForecolorDialogInvoker.ForeColor = statusbarForecolorDialog.Color;
        }

        private void IsTitlebarTooltipEnabledCheckedChanged(object sender, EventArgs e)
        {
            txtTitlebarTooltip.Enabled = chkIsTitlebarTooltipEnabled.Checked;
        }

        private void IsStatusbarTooltipEnabledCheckedChanged(object sender, EventArgs e)
        {
            txtStatusbarTooltip.Enabled = isStatusbarTooltipEnabled.Checked;
        }

        private void IsStatusbarVisibleCheckedChanged(object sender, EventArgs e)
        {
            txtStatusText.Enabled = isStatusbarVisible.Checked;
        }

        private void DrawDefaultTitlebarCheckedChanged(object sender, EventArgs e)
        {
            chkIsTitlebarTooltipEnabled.Enabled = drawDefaultFullTitlebar.Checked;
        }
    }
}