﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using Binarymission.AdvancedControlsDemo.Properties;
using Binarymission.WinForms.Controls.AdvancedContainers;
using Binarymission.WinForms.Controls.AdvancedListControls.DataEntities;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace Binarymission.AdvancedControlsDemo
{
    public partial class DemoWindow : ModernChromeWindow
    {
        private Dictionary<int, Image> _resourcesToSelectFrom;
        private Random _random;
        private List<CheckedImageListBoxItem> _randomDataCheckedImageListBoxItems;
        private List<CheckedImageListBoxItem> _weekDaysDataCheckedImageListBoxItems;
        private List<CheckedImageListBoxItem> _colorsDataCheckedImageListBoxItems;


        public DemoWindow()
        {
            InitializeComponent();
            Load += Form1_Load;
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            TitlebarText = @"Binarymission - Multi-selectable CheckedImageListBox Combobox Demo";
            multiSelectableCheckedImageListCombobox1.ItemCheckStateChanged += MultiSelectableCheckedImageListComboboxItemCheckStateChanged;
            multiSelectableCheckedImageListCombobox2.ItemCheckStateChanged += MultiSelectableCheckedImageListComboboxItemCheckStateChanged;
            multiSelectableCheckedImageListCombobox3.ItemCheckStateChanged += MultiSelectableCheckedImageListComboboxItemCheckStateChanged;
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            InitialiseFields();

            SetupResources();

            LoadControlInstanceWithRandomData();

            LoadControlInstanceWithWeekDays();

            LoadControlInstanceWithSystemColors();
        }

        private void MultiSelectableCheckedImageListComboboxItemCheckStateChanged(object sender,
            Binarymission.WinForms.Controls.AdvancedListControls.Events.ItemCheckStateChangedEventArgs e)
        {
            // Perform your custom functionality here - i.e. whatever you wan to do as and when the user checks/unchecks an item in the drop-down checked-listbox view.
        }

        private void InitialiseFields()
        {
            _random = new Random();
            _randomDataCheckedImageListBoxItems = new List<CheckedImageListBoxItem>();
            _weekDaysDataCheckedImageListBoxItems = new List<CheckedImageListBoxItem>();
            _colorsDataCheckedImageListBoxItems = new List<CheckedImageListBoxItem>();
        }

        private void LoadControlInstanceWithRandomData()
        {
            // Populating some random data for the first control instance.

            for (var i = 0; i < 25; i++)
            {
                var item = new CheckedImageListBoxItem
                {
                    Title = $"Title {i}",
                    Image = SelectImageAtRandom(),
                    ContentText = string.Format(
                    "{1}Sample custom drop-down Checked-Image-Listbox item content for index." +
                    "{1}{1}As you click / select an item from this drop-down view, the selected list-item's chosen propery value is added to the combobox text display area using a (configurable) separator text, to allow multile selection." +
                    "",
                    i,
                    Environment.NewLine),
                    IsChecked = false,
                    IsEnabled = true
                };

                _randomDataCheckedImageListBoxItems.Add(item);
            }

            if (_randomDataCheckedImageListBoxItems != null)
            {
                multiSelectableCheckedImageListCombobox1.MultiSelectableCheckedImageListBoxConfiguration.Items =
                    _randomDataCheckedImageListBoxItems;

                // IMPORTANT!! Set the control;s display member property with any property of your choice from the item type - i.e. CheckedImageListBoxItem class.
                multiSelectableCheckedImageListCombobox1.DisplayMember = "Title";
            }
        }

        private void LoadControlInstanceWithWeekDays()
        {
            // Populating some random data for the second control instance.

            var weekDays = from wd in Enum.GetValues(typeof(DayOfWeek))
                              .OfType<DayOfWeek>()
                              .ToList()
                           select wd;

            foreach (var weekDay in weekDays)
            {
                var dayOfWeek = weekDay.ToString();

                var item = new CheckedImageListBoxItem
                {
                    Title = "Day Of Week",
                    ContentText = dayOfWeek,
                    IsChecked = false,
                    IsEnabled = true
                };

                _weekDaysDataCheckedImageListBoxItems.Add(item);
            }

            if (_weekDaysDataCheckedImageListBoxItems != null)
            {
                multiSelectableCheckedImageListCombobox2.MultiSelectableCheckedImageListBoxConfiguration.Items =
                    _weekDaysDataCheckedImageListBoxItems;

                // IMPORTANT!! Set the control;s display member property with any property of your choice from the item type - i.e. CheckedImageListBoxItem class.
                multiSelectableCheckedImageListCombobox2.DisplayMember = "ContentText";
            }
        }

        private void LoadControlInstanceWithSystemColors()
        {
            // Populating some random data for the third control instance.

            var systemColors = from sc in Binarymission.WinForms.Controls.CommonUtils.Shared.BuildDataFromStaticType(typeof(Color))
                                    select sc;

            foreach (var color in systemColors)
            {
                var item = new CheckedImageListBoxItem
                {
                    ContentText = color.Key,
                    IsChecked = false,
                    IsEnabled = true
                };

                _colorsDataCheckedImageListBoxItems.Add(item);
            }

            if (_colorsDataCheckedImageListBoxItems != null)
            {
                multiSelectableCheckedImageListCombobox3.MultiSelectableCheckedImageListBoxConfiguration.Items =
                    _colorsDataCheckedImageListBoxItems;

                // IMPORTANT!! Set the control;s display member property with any property of your choice from the item type - i.e. CheckedImageListBoxItem class.
                multiSelectableCheckedImageListCombobox3.DisplayMember = "ContentText";
            }
        }

        private Image SelectImageAtRandom()
        {
            return _resourcesToSelectFrom[_random.Next(1, 9)];
        }

        private void SetupResources()
        {
            _resourcesToSelectFrom = new Dictionary<int, Image>
            {
                {1, Resources.Alarm},
                {2, Resources.Clip},
                {3, Resources.History},
                {4, Resources.Item_Image},
                {5, Resources.NoteOpen},
                {6, Resources.Piece},
                {7, Resources.Screen},
                {8, Resources.History}
            };
        }

        private void EnableDrawingSidebarsCheckedChanged(object sender, EventArgs e)
        {
            foreach (var multiSelectableCheckedImageListCombobox in 
                Controls.OfType<MultiSelectableCheckedImageListCombobox>())
            {
                multiSelectableCheckedImageListCombobox.
                    MultiSelectableCheckedImageListBoxConfiguration.
                        IsItemSidebarDrawingEnabled = chkEnableDrawingSidebars.Checked;
            }
        }

        private void ControlInstancesAreReadOnlyModeCheckedChanged(object sender, EventArgs e)
        {
            foreach (var multiSelectableCheckedImageListCombobox in
               Controls.OfType<MultiSelectableCheckedImageListCombobox>())
            {
                multiSelectableCheckedImageListCombobox.
                    MultiSelectableCheckedImageListBoxConfiguration.
                        IsReadOnly = chkControlInstancesAreReadOnlyMode.Checked;
            }
        }

        private void ControlInstancesAreBlockedFromDropdownDisplayCheckedChanged(object sender, EventArgs e)
        {
            foreach (var multiSelectableCheckedImageListCombobox in
                Controls.OfType<MultiSelectableCheckedImageListCombobox>())
            {
                multiSelectableCheckedImageListCombobox.IsDropdownInvocationBlocked
                         = chkControlInstancesAreBlockedFromDropdownDisplay.Checked;
            }
        }

        private void KeepAllItemsSelectedCheckedChanged(object sender, EventArgs e)
        {
            foreach (var multiSelectableCheckedImageListCombobox in
                Controls.OfType<MultiSelectableCheckedImageListCombobox>())
            {
                multiSelectableCheckedImageListCombobox.ToggleCheckStateForAllItems = chkKeepAllItemsSelected.Checked;
            }
        }

        private void CheckUncheckUponClickCheckedChanged(object sender, EventArgs e)
        {
            foreach (var multiSelectableCheckedImageListCombobox in
                Controls.OfType<MultiSelectableCheckedImageListCombobox>())
            {
                multiSelectableCheckedImageListCombobox.MultiSelectableCheckedImageListBoxConfiguration.CheckOnClick = chkCheckUncheckUponClick.Checked;
            }
        }

        private void SeperationDelimiterCharsTextChanged(object sender, EventArgs e)
        {
            foreach (var multiSelectableCheckedImageListCombobox in
                            Controls.OfType<MultiSelectableCheckedImageListCombobox>())
            {
                multiSelectableCheckedImageListCombobox.CheckedItemTextDisplaySeparationDelimiterChars =
                    txtSeperationDelimiterChars.Text;
            }
        }

        private void ExitCommandInvokerClick(object sender, EventArgs e)
        {
            Close();
        }
    }
}
