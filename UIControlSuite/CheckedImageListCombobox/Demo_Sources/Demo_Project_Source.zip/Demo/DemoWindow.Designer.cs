﻿using Binarymission.WinForms.Controls.AdvancedContainers;

namespace Binarymission.AdvancedControlsDemo
{
    partial class DemoWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Binarymission.WinForms.Controls.AdvancedContainers.MultiSelectableCheckedImageListComboboxControl.Configuration.MultiSeletableCheckedImageListBoxConfiguration multiSeletableCheckedImageListBoxConfiguration1 = new Binarymission.WinForms.Controls.AdvancedContainers.MultiSelectableCheckedImageListComboboxControl.Configuration.MultiSeletableCheckedImageListBoxConfiguration();
            Binarymission.WinForms.Controls.AdvancedContainers.MultiSelectableCheckedImageListComboboxControl.Configuration.MultiSeletableCheckedImageListBoxConfiguration multiSeletableCheckedImageListBoxConfiguration2 = new Binarymission.WinForms.Controls.AdvancedContainers.MultiSelectableCheckedImageListComboboxControl.Configuration.MultiSeletableCheckedImageListBoxConfiguration();
            Binarymission.WinForms.Controls.AdvancedContainers.MultiSelectableCheckedImageListComboboxControl.Configuration.MultiSeletableCheckedImageListBoxConfiguration multiSeletableCheckedImageListBoxConfiguration3 = new Binarymission.WinForms.Controls.AdvancedContainers.MultiSelectableCheckedImageListComboboxControl.Configuration.MultiSeletableCheckedImageListBoxConfiguration();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DemoWindow));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.chkCheckUncheckUponClick = new System.Windows.Forms.CheckBox();
            this.chkKeepAllItemsSelected = new System.Windows.Forms.CheckBox();
            this.chkControlInstancesAreBlockedFromDropdownDisplay = new System.Windows.Forms.CheckBox();
            this.chkControlInstancesAreReadOnlyMode = new System.Windows.Forms.CheckBox();
            this.chkEnableDrawingSidebars = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSeperationDelimiterChars = new System.Windows.Forms.TextBox();
            this.multiSelectableCheckedImageListCombobox3 = new Binarymission.WinForms.Controls.AdvancedContainers.MultiSelectableCheckedImageListCombobox();
            this.multiSelectableCheckedImageListCombobox2 = new Binarymission.WinForms.Controls.AdvancedContainers.MultiSelectableCheckedImageListCombobox();
            this.multiSelectableCheckedImageListCombobox1 = new Binarymission.WinForms.Controls.AdvancedContainers.MultiSelectableCheckedImageListCombobox();
            this.btnExitCommandInvoker = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(263, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "A) Control instance hosting custom list data:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(650, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "B) Week days data:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1020, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "C) SystemColors data:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(26, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(392, 18);
            this.label4.TabIndex = 6;
            this.label4.Text = "CheckedImageListBoxCombobox control instances Demo";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.chkCheckUncheckUponClick);
            this.groupBox1.Controls.Add(this.chkKeepAllItemsSelected);
            this.groupBox1.Controls.Add(this.chkControlInstancesAreBlockedFromDropdownDisplay);
            this.groupBox1.Controls.Add(this.chkControlInstancesAreReadOnlyMode);
            this.groupBox1.Controls.Add(this.chkEnableDrawingSidebars);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(18, 555);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1188, 132);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Options:";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(7, 109);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(793, 25);
            this.label6.TabIndex = 10;
            this.label6.Text = "There are tons of more customisations (properties) that you can setup to deeply c" +
    "ustomise the control.";
            // 
            // chkCheckUncheckUponClick
            // 
            this.chkCheckUncheckUponClick.AutoSize = true;
            this.chkCheckUncheckUponClick.Checked = true;
            this.chkCheckUncheckUponClick.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCheckUncheckUponClick.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCheckUncheckUponClick.Location = new System.Drawing.Point(505, 30);
            this.chkCheckUncheckUponClick.Name = "chkCheckUncheckUponClick";
            this.chkCheckUncheckUponClick.Size = new System.Drawing.Size(262, 20);
            this.chkCheckUncheckUponClick.TabIndex = 6;
            this.chkCheckUncheckUponClick.Text = "Change check/uncheck state upon click";
            this.chkCheckUncheckUponClick.UseVisualStyleBackColor = true;
            this.chkCheckUncheckUponClick.CheckedChanged += new System.EventHandler(this.CheckUncheckUponClickCheckedChanged);
            // 
            // chkKeepAllItemsSelected
            // 
            this.chkKeepAllItemsSelected.AutoSize = true;
            this.chkKeepAllItemsSelected.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkKeepAllItemsSelected.Location = new System.Drawing.Point(505, 56);
            this.chkKeepAllItemsSelected.Name = "chkKeepAllItemsSelected";
            this.chkKeepAllItemsSelected.Size = new System.Drawing.Size(199, 20);
            this.chkKeepAllItemsSelected.TabIndex = 5;
            this.chkKeepAllItemsSelected.Text = "Check All / Uncheck All Items";
            this.chkKeepAllItemsSelected.UseVisualStyleBackColor = true;
            this.chkKeepAllItemsSelected.CheckedChanged += new System.EventHandler(this.KeepAllItemsSelectedCheckedChanged);
            // 
            // chkControlInstancesAreBlockedFromDropdownDisplay
            // 
            this.chkControlInstancesAreBlockedFromDropdownDisplay.AutoSize = true;
            this.chkControlInstancesAreBlockedFromDropdownDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkControlInstancesAreBlockedFromDropdownDisplay.Location = new System.Drawing.Point(12, 79);
            this.chkControlInstancesAreBlockedFromDropdownDisplay.Name = "chkControlInstancesAreBlockedFromDropdownDisplay";
            this.chkControlInstancesAreBlockedFromDropdownDisplay.Size = new System.Drawing.Size(347, 20);
            this.chkControlInstancesAreBlockedFromDropdownDisplay.TabIndex = 4;
            this.chkControlInstancesAreBlockedFromDropdownDisplay.Text = "Control instances are blocked from drop-down display";
            this.chkControlInstancesAreBlockedFromDropdownDisplay.UseVisualStyleBackColor = true;
            this.chkControlInstancesAreBlockedFromDropdownDisplay.CheckedChanged += new System.EventHandler(this.ControlInstancesAreBlockedFromDropdownDisplayCheckedChanged);
            // 
            // chkControlInstancesAreReadOnlyMode
            // 
            this.chkControlInstancesAreReadOnlyMode.AutoSize = true;
            this.chkControlInstancesAreReadOnlyMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkControlInstancesAreReadOnlyMode.Location = new System.Drawing.Point(12, 53);
            this.chkControlInstancesAreReadOnlyMode.Name = "chkControlInstancesAreReadOnlyMode";
            this.chkControlInstancesAreReadOnlyMode.Size = new System.Drawing.Size(312, 20);
            this.chkControlInstancesAreReadOnlyMode.TabIndex = 1;
            this.chkControlInstancesAreReadOnlyMode.Text = "Instances\' drop-down view is in ReadOnly mode";
            this.chkControlInstancesAreReadOnlyMode.UseVisualStyleBackColor = true;
            this.chkControlInstancesAreReadOnlyMode.CheckedChanged += new System.EventHandler(this.ControlInstancesAreReadOnlyModeCheckedChanged);
            // 
            // chkEnableDrawingSidebars
            // 
            this.chkEnableDrawingSidebars.AutoSize = true;
            this.chkEnableDrawingSidebars.Checked = true;
            this.chkEnableDrawingSidebars.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkEnableDrawingSidebars.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEnableDrawingSidebars.Location = new System.Drawing.Point(12, 30);
            this.chkEnableDrawingSidebars.Name = "chkEnableDrawingSidebars";
            this.chkEnableDrawingSidebars.Size = new System.Drawing.Size(429, 20);
            this.chkEnableDrawingSidebars.TabIndex = 0;
            this.chkEnableDrawingSidebars.Text = "Enable drawing Sidebars on the items when selected / mouse hover";
            this.chkEnableDrawingSidebars.UseVisualStyleBackColor = true;
            this.chkEnableDrawingSidebars.CheckedChanged += new System.EventHandler(this.EnableDrawingSidebarsCheckedChanged);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(826, 585);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(251, 49);
            this.label5.TabIndex = 8;
            this.label5.Text = "Checked items seperation delimiter for text display:";
            // 
            // txtSeperationDelimiterChars
            // 
            this.txtSeperationDelimiterChars.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeperationDelimiterChars.Location = new System.Drawing.Point(1088, 597);
            this.txtSeperationDelimiterChars.Name = "txtSeperationDelimiterChars";
            this.txtSeperationDelimiterChars.Size = new System.Drawing.Size(74, 22);
            this.txtSeperationDelimiterChars.TabIndex = 9;
            this.txtSeperationDelimiterChars.Text = " --- ";
            this.txtSeperationDelimiterChars.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSeperationDelimiterChars.TextChanged += new System.EventHandler(this.SeperationDelimiterCharsTextChanged);
            // 
            // multiSelectableCheckedImageListCombobox3
            // 
            this.multiSelectableCheckedImageListCombobox3.AlphaBlendFactorForControlPainting = 100;
            this.multiSelectableCheckedImageListCombobox3.AlphaBlendFactorForDropDownPressedColor = 70;
            this.multiSelectableCheckedImageListCombobox3.AlphaBlendFactorForItemSelectionColor = 70;
            this.multiSelectableCheckedImageListCombobox3.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.multiSelectableCheckedImageListCombobox3.BackColor = System.Drawing.SystemColors.Window;
            this.multiSelectableCheckedImageListCombobox3.CheckedItemTextDisplaySeparationDelimiterChars = " --- ";
            this.multiSelectableCheckedImageListCombobox3.ComboBoxIsReadOnly = true;
            this.multiSelectableCheckedImageListCombobox3.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.multiSelectableCheckedImageListCombobox3.CustomControlBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.multiSelectableCheckedImageListCombobox3.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.multiSelectableCheckedImageListCombobox3.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.multiSelectableCheckedImageListCombobox3.CustomPaintingColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.multiSelectableCheckedImageListCombobox3.DisplayLocation = new System.Drawing.Point(0, 0);
            this.multiSelectableCheckedImageListCombobox3.DisplayMember = null;
            this.multiSelectableCheckedImageListCombobox3.DrawTheControlBasedOnWindowsOS = true;
            this.multiSelectableCheckedImageListCombobox3.DropdownContentMargin = new System.Windows.Forms.Padding(0);
            this.multiSelectableCheckedImageListCombobox3.DropdownContentPadding = new System.Windows.Forms.Padding(0);
            this.multiSelectableCheckedImageListCombobox3.DropdownResizeGripperColor = System.Drawing.Color.Gray;
            this.multiSelectableCheckedImageListCombobox3.DropdownResizeSectionBorderColor = System.Drawing.Color.Empty;
            this.multiSelectableCheckedImageListCombobox3.DropdownResizeSectionFillColor = System.Drawing.Color.Empty;
            this.multiSelectableCheckedImageListCombobox3.DropdownSize = new System.Drawing.Size(350, 300);
            this.multiSelectableCheckedImageListCombobox3.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.multiSelectableCheckedImageListCombobox3.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.multiSelectableCheckedImageListCombobox3.DropDownWindowBorderThickness = 0F;
            this.multiSelectableCheckedImageListCombobox3.ExtendedDropdownButtonImage = null;
            this.multiSelectableCheckedImageListCombobox3.ExtendedDropdownButtonInternalImage = null;
            this.multiSelectableCheckedImageListCombobox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.multiSelectableCheckedImageListCombobox3.IntegralHeight = false;
            this.multiSelectableCheckedImageListCombobox3.IsDropdownInvocationBlocked = false;
            this.multiSelectableCheckedImageListCombobox3.IsInExtendedReadOnlyMode = false;
            this.multiSelectableCheckedImageListCombobox3.IsTextSelectedUponGainingFocus = false;
            this.multiSelectableCheckedImageListCombobox3.Location = new System.Drawing.Point(1023, 107);
            multiSeletableCheckedImageListBoxConfiguration1.AnnotationImageOnMouseHover = null;
            multiSeletableCheckedImageListBoxConfiguration1.BackColor = System.Drawing.SystemColors.Window;
            multiSeletableCheckedImageListBoxConfiguration1.CheckBoxSize = new System.Drawing.Size(16, 16);
            multiSeletableCheckedImageListBoxConfiguration1.CheckedStateImage = null;
            multiSeletableCheckedImageListBoxConfiguration1.CheckOnClick = true;
            multiSeletableCheckedImageListBoxConfiguration1.IsAnnotationEnabled = true;
            multiSeletableCheckedImageListBoxConfiguration1.IsImageDrawnWhenUsingDefaultItemTooltip = false;
            multiSeletableCheckedImageListBoxConfiguration1.IsItemSidebarBorderDrawingEnabled = true;
            multiSeletableCheckedImageListBoxConfiguration1.IsItemSidebarDrawingEnabled = true;
            multiSeletableCheckedImageListBoxConfiguration1.IsReadOnly = false;
            multiSeletableCheckedImageListBoxConfiguration1.ItemAlternateEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration1.ItemAlternateGradientFactor = 90F;
            multiSeletableCheckedImageListBoxConfiguration1.ItemAlternateStartColor = System.Drawing.Color.Wheat;
            multiSeletableCheckedImageListBoxConfiguration1.ItemContentFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            multiSeletableCheckedImageListBoxConfiguration1.ItemContentTextColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration1.ItemDisabledContentTextColor = System.Drawing.SystemColors.GrayText;
            multiSeletableCheckedImageListBoxConfiguration1.ItemDisabledEndColor = System.Drawing.SystemColors.Window;
            multiSeletableCheckedImageListBoxConfiguration1.ItemDisabledStartColor = System.Drawing.SystemColors.ControlLight;
            multiSeletableCheckedImageListBoxConfiguration1.ItemDisabledTitleTextColor = System.Drawing.SystemColors.GrayText;
            multiSeletableCheckedImageListBoxConfiguration1.ItemMouseHoverBorderColor = System.Drawing.Color.DarkBlue;
            multiSeletableCheckedImageListBoxConfiguration1.ItemMouseHoverBorderThickness = 1;
            multiSeletableCheckedImageListBoxConfiguration1.ItemMouseHoverContentTextForeColor = System.Drawing.Color.Blue;
            multiSeletableCheckedImageListBoxConfiguration1.ItemMouseHoverEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration1.ItemMouseHoverGradientFactor = 90F;
            multiSeletableCheckedImageListBoxConfiguration1.ItemMouseHoverStartColor = System.Drawing.Color.SkyBlue;
            multiSeletableCheckedImageListBoxConfiguration1.ItemMouseHoverTitleForeColor = System.Drawing.Color.Red;
            multiSeletableCheckedImageListBoxConfiguration1.ItemReadOnlyBorderColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration1.ItemReadOnlyContentTextColor = System.Drawing.SystemColors.WindowText;
            multiSeletableCheckedImageListBoxConfiguration1.ItemReadOnlyEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration1.ItemReadOnlyStartColor = System.Drawing.Color.GhostWhite;
            multiSeletableCheckedImageListBoxConfiguration1.ItemReadOnlyTitleTextColor = System.Drawing.SystemColors.WindowText;
            multiSeletableCheckedImageListBoxConfiguration1.ItemSelectedBorderColor = System.Drawing.Color.Red;
            multiSeletableCheckedImageListBoxConfiguration1.ItemSelectedBorderThickness = 1;
            multiSeletableCheckedImageListBoxConfiguration1.ItemSelectedEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration1.ItemSelectedGradientFactor = 90F;
            multiSeletableCheckedImageListBoxConfiguration1.ItemSelectedStartColor = System.Drawing.Color.LightSalmon;
            multiSeletableCheckedImageListBoxConfiguration1.ItemSpacing = 6;
            multiSeletableCheckedImageListBoxConfiguration1.ItemTitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            multiSeletableCheckedImageListBoxConfiguration1.ItemTitleTextColor = System.Drawing.Color.Brown;
            multiSeletableCheckedImageListBoxConfiguration1.ItemTooltipContentFont = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            multiSeletableCheckedImageListBoxConfiguration1.ItemTooltipTitleFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            multiSeletableCheckedImageListBoxConfiguration1.ItemUnselectedBorderColor = System.Drawing.Color.BurlyWood;
            multiSeletableCheckedImageListBoxConfiguration1.ItemUnselectedBorderThickness = 1;
            multiSeletableCheckedImageListBoxConfiguration1.ItemUnselectedContentTextColor = System.Drawing.Color.Brown;
            multiSeletableCheckedImageListBoxConfiguration1.ItemUnselectedEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration1.ItemUnselectedGradientFactor = 270F;
            multiSeletableCheckedImageListBoxConfiguration1.ItemUnselectedStartColor = System.Drawing.Color.NavajoWhite;
            multiSeletableCheckedImageListBoxConfiguration1.ItemUnselectedTitleTextColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration1.MinimumItemTopAndBottomMargin = 7;
            multiSeletableCheckedImageListBoxConfiguration1.PaddingBetweenItemComponents = 8;
            multiSeletableCheckedImageListBoxConfiguration1.SelectionMode = System.Windows.Forms.SelectionMode.None;
            multiSeletableCheckedImageListBoxConfiguration1.ShouldAnimateItemImage = false;
            multiSeletableCheckedImageListBoxConfiguration1.ShouldDrawCheckBoxInVisualStyle = true;
            multiSeletableCheckedImageListBoxConfiguration1.ShouldDrawItemBorder = true;
            multiSeletableCheckedImageListBoxConfiguration1.ShouldDrawTopItemSpacingForFirstItem = false;
            multiSeletableCheckedImageListBoxConfiguration1.ShouldEnableAlternatingColors = false;
            multiSeletableCheckedImageListBoxConfiguration1.ShouldExpandItemFullViewUponClick = false;
            multiSeletableCheckedImageListBoxConfiguration1.ShouldRefreshBasedOnMessage = true;
            multiSeletableCheckedImageListBoxConfiguration1.ShouldShowDefaultTooltipOnItemHover = false;
            multiSeletableCheckedImageListBoxConfiguration1.ShouldUseImageForCheckState = false;
            multiSeletableCheckedImageListBoxConfiguration1.SidebarBorderThickness = 1;
            multiSeletableCheckedImageListBoxConfiguration1.SidebarGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            multiSeletableCheckedImageListBoxConfiguration1.SidebarItemHoveredStateBorderColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration1.SidebarItemHoveredStateEndColor = System.Drawing.Color.CornflowerBlue;
            multiSeletableCheckedImageListBoxConfiguration1.SidebarItemHoveredStateStartColor = System.Drawing.Color.RoyalBlue;
            multiSeletableCheckedImageListBoxConfiguration1.SidebarItemSelectedStateBorderColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration1.SidebarItemSelectedStateEndColor = System.Drawing.Color.BurlyWood;
            multiSeletableCheckedImageListBoxConfiguration1.SidebarItemSelectedStateStartColor = System.Drawing.Color.Brown;
            multiSeletableCheckedImageListBoxConfiguration1.SidebarWidth = 12;
            multiSeletableCheckedImageListBoxConfiguration1.UncheckedStateImage = null;
            this.multiSelectableCheckedImageListCombobox3.MultiSelectableCheckedImageListBoxConfiguration = multiSeletableCheckedImageListBoxConfiguration1;
            this.multiSelectableCheckedImageListCombobox3.Name = "multiSelectableCheckedImageListCombobox3";
            this.multiSelectableCheckedImageListCombobox3.SelectedIndexFromDropList = -1;
            this.multiSelectableCheckedImageListCombobox3.ShouldDrawBidirectionalResizeGripper = true;
            this.multiSelectableCheckedImageListCombobox3.ShouldDrawDropdownResizeSectionWith3DBorder = false;
            this.multiSelectableCheckedImageListCombobox3.ShouldDrawExtendedDropdownButton = false;
            this.multiSelectableCheckedImageListCombobox3.ShouldDrawVerticalResizeGripper = true;
            this.multiSelectableCheckedImageListCombobox3.ShowBorderAlways = true;
            this.multiSelectableCheckedImageListCombobox3.Size = new System.Drawing.Size(280, 21);
            this.multiSelectableCheckedImageListCombobox3.TabIndex = 2;
            this.multiSelectableCheckedImageListCombobox3.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.multiSelectableCheckedImageListCombobox3.ToggleCheckStateForAllItems = false;
            // 
            // multiSelectableCheckedImageListCombobox2
            // 
            this.multiSelectableCheckedImageListCombobox2.AlphaBlendFactorForControlPainting = 100;
            this.multiSelectableCheckedImageListCombobox2.AlphaBlendFactorForDropDownPressedColor = 70;
            this.multiSelectableCheckedImageListCombobox2.AlphaBlendFactorForItemSelectionColor = 70;
            this.multiSelectableCheckedImageListCombobox2.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.multiSelectableCheckedImageListCombobox2.BackColor = System.Drawing.SystemColors.Window;
            this.multiSelectableCheckedImageListCombobox2.CheckedItemTextDisplaySeparationDelimiterChars = " --- ";
            this.multiSelectableCheckedImageListCombobox2.ComboBoxIsReadOnly = true;
            this.multiSelectableCheckedImageListCombobox2.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.multiSelectableCheckedImageListCombobox2.CustomControlBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.multiSelectableCheckedImageListCombobox2.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.multiSelectableCheckedImageListCombobox2.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.multiSelectableCheckedImageListCombobox2.CustomPaintingColor = System.Drawing.Color.Green;
            this.multiSelectableCheckedImageListCombobox2.DisplayLocation = new System.Drawing.Point(0, 0);
            this.multiSelectableCheckedImageListCombobox2.DisplayMember = null;
            this.multiSelectableCheckedImageListCombobox2.DrawTheControlBasedOnWindowsOS = true;
            this.multiSelectableCheckedImageListCombobox2.DropdownContentMargin = new System.Windows.Forms.Padding(0);
            this.multiSelectableCheckedImageListCombobox2.DropdownContentPadding = new System.Windows.Forms.Padding(0);
            this.multiSelectableCheckedImageListCombobox2.DropdownResizeGripperColor = System.Drawing.Color.Gray;
            this.multiSelectableCheckedImageListCombobox2.DropdownResizeSectionBorderColor = System.Drawing.Color.Empty;
            this.multiSelectableCheckedImageListCombobox2.DropdownResizeSectionFillColor = System.Drawing.Color.Empty;
            this.multiSelectableCheckedImageListCombobox2.DropdownSize = new System.Drawing.Size(350, 225);
            this.multiSelectableCheckedImageListCombobox2.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.multiSelectableCheckedImageListCombobox2.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.multiSelectableCheckedImageListCombobox2.DropDownWindowBorderThickness = 0F;
            this.multiSelectableCheckedImageListCombobox2.ExtendedDropdownButtonImage = null;
            this.multiSelectableCheckedImageListCombobox2.ExtendedDropdownButtonInternalImage = null;
            this.multiSelectableCheckedImageListCombobox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.multiSelectableCheckedImageListCombobox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multiSelectableCheckedImageListCombobox2.IntegralHeight = false;
            this.multiSelectableCheckedImageListCombobox2.IsDropdownInvocationBlocked = false;
            this.multiSelectableCheckedImageListCombobox2.IsInExtendedReadOnlyMode = false;
            this.multiSelectableCheckedImageListCombobox2.IsTextSelectedUponGainingFocus = false;
            this.multiSelectableCheckedImageListCombobox2.Location = new System.Drawing.Point(653, 107);
            multiSeletableCheckedImageListBoxConfiguration2.AnnotationImageOnMouseHover = null;
            multiSeletableCheckedImageListBoxConfiguration2.BackColor = System.Drawing.SystemColors.Window;
            multiSeletableCheckedImageListBoxConfiguration2.CheckBoxSize = new System.Drawing.Size(16, 16);
            multiSeletableCheckedImageListBoxConfiguration2.CheckedStateImage = null;
            multiSeletableCheckedImageListBoxConfiguration2.CheckOnClick = true;
            multiSeletableCheckedImageListBoxConfiguration2.IsAnnotationEnabled = true;
            multiSeletableCheckedImageListBoxConfiguration2.IsImageDrawnWhenUsingDefaultItemTooltip = false;
            multiSeletableCheckedImageListBoxConfiguration2.IsItemSidebarBorderDrawingEnabled = false;
            multiSeletableCheckedImageListBoxConfiguration2.IsItemSidebarDrawingEnabled = true;
            multiSeletableCheckedImageListBoxConfiguration2.IsReadOnly = false;
            multiSeletableCheckedImageListBoxConfiguration2.ItemAlternateEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration2.ItemAlternateGradientFactor = 90F;
            multiSeletableCheckedImageListBoxConfiguration2.ItemAlternateStartColor = System.Drawing.Color.Wheat;
            multiSeletableCheckedImageListBoxConfiguration2.ItemContentFont = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            multiSeletableCheckedImageListBoxConfiguration2.ItemContentTextColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration2.ItemDisabledContentTextColor = System.Drawing.SystemColors.GrayText;
            multiSeletableCheckedImageListBoxConfiguration2.ItemDisabledEndColor = System.Drawing.SystemColors.Window;
            multiSeletableCheckedImageListBoxConfiguration2.ItemDisabledStartColor = System.Drawing.SystemColors.ControlLight;
            multiSeletableCheckedImageListBoxConfiguration2.ItemDisabledTitleTextColor = System.Drawing.SystemColors.GrayText;
            multiSeletableCheckedImageListBoxConfiguration2.ItemMouseHoverBorderColor = System.Drawing.Color.DarkBlue;
            multiSeletableCheckedImageListBoxConfiguration2.ItemMouseHoverBorderThickness = 1;
            multiSeletableCheckedImageListBoxConfiguration2.ItemMouseHoverContentTextForeColor = System.Drawing.Color.Blue;
            multiSeletableCheckedImageListBoxConfiguration2.ItemMouseHoverEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration2.ItemMouseHoverGradientFactor = 90F;
            multiSeletableCheckedImageListBoxConfiguration2.ItemMouseHoverStartColor = System.Drawing.Color.SkyBlue;
            multiSeletableCheckedImageListBoxConfiguration2.ItemMouseHoverTitleForeColor = System.Drawing.Color.Maroon;
            multiSeletableCheckedImageListBoxConfiguration2.ItemReadOnlyBorderColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration2.ItemReadOnlyContentTextColor = System.Drawing.SystemColors.WindowText;
            multiSeletableCheckedImageListBoxConfiguration2.ItemReadOnlyEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration2.ItemReadOnlyStartColor = System.Drawing.Color.GhostWhite;
            multiSeletableCheckedImageListBoxConfiguration2.ItemReadOnlyTitleTextColor = System.Drawing.SystemColors.WindowText;
            multiSeletableCheckedImageListBoxConfiguration2.ItemSelectedBorderColor = System.Drawing.Color.Red;
            multiSeletableCheckedImageListBoxConfiguration2.ItemSelectedBorderThickness = 1;
            multiSeletableCheckedImageListBoxConfiguration2.ItemSelectedEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration2.ItemSelectedGradientFactor = 90F;
            multiSeletableCheckedImageListBoxConfiguration2.ItemSelectedStartColor = System.Drawing.Color.LightSalmon;
            multiSeletableCheckedImageListBoxConfiguration2.ItemSpacing = 6;
            multiSeletableCheckedImageListBoxConfiguration2.ItemTitleFont = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            multiSeletableCheckedImageListBoxConfiguration2.ItemTitleTextColor = System.Drawing.Color.Brown;
            multiSeletableCheckedImageListBoxConfiguration2.ItemTooltipContentFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            multiSeletableCheckedImageListBoxConfiguration2.ItemTooltipTitleFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            multiSeletableCheckedImageListBoxConfiguration2.ItemUnselectedBorderColor = System.Drawing.Color.BurlyWood;
            multiSeletableCheckedImageListBoxConfiguration2.ItemUnselectedBorderThickness = 1;
            multiSeletableCheckedImageListBoxConfiguration2.ItemUnselectedContentTextColor = System.Drawing.Color.Brown;
            multiSeletableCheckedImageListBoxConfiguration2.ItemUnselectedEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration2.ItemUnselectedGradientFactor = 270F;
            multiSeletableCheckedImageListBoxConfiguration2.ItemUnselectedStartColor = System.Drawing.Color.NavajoWhite;
            multiSeletableCheckedImageListBoxConfiguration2.ItemUnselectedTitleTextColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration2.MinimumItemTopAndBottomMargin = 7;
            multiSeletableCheckedImageListBoxConfiguration2.PaddingBetweenItemComponents = 8;
            multiSeletableCheckedImageListBoxConfiguration2.SelectionMode = System.Windows.Forms.SelectionMode.None;
            multiSeletableCheckedImageListBoxConfiguration2.ShouldAnimateItemImage = false;
            multiSeletableCheckedImageListBoxConfiguration2.ShouldDrawCheckBoxInVisualStyle = true;
            multiSeletableCheckedImageListBoxConfiguration2.ShouldDrawItemBorder = true;
            multiSeletableCheckedImageListBoxConfiguration2.ShouldDrawTopItemSpacingForFirstItem = false;
            multiSeletableCheckedImageListBoxConfiguration2.ShouldEnableAlternatingColors = false;
            multiSeletableCheckedImageListBoxConfiguration2.ShouldExpandItemFullViewUponClick = false;
            multiSeletableCheckedImageListBoxConfiguration2.ShouldRefreshBasedOnMessage = true;
            multiSeletableCheckedImageListBoxConfiguration2.ShouldShowDefaultTooltipOnItemHover = false;
            multiSeletableCheckedImageListBoxConfiguration2.ShouldUseImageForCheckState = false;
            multiSeletableCheckedImageListBoxConfiguration2.SidebarBorderThickness = 1;
            multiSeletableCheckedImageListBoxConfiguration2.SidebarGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            multiSeletableCheckedImageListBoxConfiguration2.SidebarItemHoveredStateBorderColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration2.SidebarItemHoveredStateEndColor = System.Drawing.Color.CornflowerBlue;
            multiSeletableCheckedImageListBoxConfiguration2.SidebarItemHoveredStateStartColor = System.Drawing.Color.RoyalBlue;
            multiSeletableCheckedImageListBoxConfiguration2.SidebarItemSelectedStateBorderColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration2.SidebarItemSelectedStateEndColor = System.Drawing.Color.BurlyWood;
            multiSeletableCheckedImageListBoxConfiguration2.SidebarItemSelectedStateStartColor = System.Drawing.Color.Brown;
            multiSeletableCheckedImageListBoxConfiguration2.SidebarWidth = 12;
            multiSeletableCheckedImageListBoxConfiguration2.UncheckedStateImage = null;
            this.multiSelectableCheckedImageListCombobox2.MultiSelectableCheckedImageListBoxConfiguration = multiSeletableCheckedImageListBoxConfiguration2;
            this.multiSelectableCheckedImageListCombobox2.Name = "multiSelectableCheckedImageListCombobox2";
            this.multiSelectableCheckedImageListCombobox2.SelectedIndexFromDropList = -1;
            this.multiSelectableCheckedImageListCombobox2.ShouldDrawBidirectionalResizeGripper = true;
            this.multiSelectableCheckedImageListCombobox2.ShouldDrawDropdownResizeSectionWith3DBorder = false;
            this.multiSelectableCheckedImageListCombobox2.ShouldDrawExtendedDropdownButton = false;
            this.multiSelectableCheckedImageListCombobox2.ShouldDrawVerticalResizeGripper = true;
            this.multiSelectableCheckedImageListCombobox2.ShowBorderAlways = true;
            this.multiSelectableCheckedImageListCombobox2.Size = new System.Drawing.Size(272, 21);
            this.multiSelectableCheckedImageListCombobox2.TabIndex = 1;
            this.multiSelectableCheckedImageListCombobox2.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.multiSelectableCheckedImageListCombobox2.ToggleCheckStateForAllItems = false;
            // 
            // multiSelectableCheckedImageListCombobox1
            // 
            this.multiSelectableCheckedImageListCombobox1.AlphaBlendFactorForControlPainting = 100;
            this.multiSelectableCheckedImageListCombobox1.AlphaBlendFactorForDropDownPressedColor = 70;
            this.multiSelectableCheckedImageListCombobox1.AlphaBlendFactorForItemSelectionColor = 70;
            this.multiSelectableCheckedImageListCombobox1.AlphaBlendingfactorForFilterAndGroupingPanelBackColor = 135;
            this.multiSelectableCheckedImageListCombobox1.BackColor = System.Drawing.SystemColors.Window;
            this.multiSelectableCheckedImageListCombobox1.CheckedItemTextDisplaySeparationDelimiterChars = " --- ";
            this.multiSelectableCheckedImageListCombobox1.ComboBoxIsReadOnly = true;
            this.multiSelectableCheckedImageListCombobox1.ControlArrowColor = System.Drawing.SystemColors.WindowText;
            this.multiSelectableCheckedImageListCombobox1.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.multiSelectableCheckedImageListCombobox1.CustomControlBorderColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.multiSelectableCheckedImageListCombobox1.CustomControlDropDownButtonFillColorWhenNotInFocus = System.Drawing.Color.Transparent;
            this.multiSelectableCheckedImageListCombobox1.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.multiSelectableCheckedImageListCombobox1.DisplayLocation = new System.Drawing.Point(0, 0);
            this.multiSelectableCheckedImageListCombobox1.DisplayMember = null;
            this.multiSelectableCheckedImageListCombobox1.DrawTheControlBasedOnWindowsOS = true;
            this.multiSelectableCheckedImageListCombobox1.DropdownContentMargin = new System.Windows.Forms.Padding(0);
            this.multiSelectableCheckedImageListCombobox1.DropdownContentPadding = new System.Windows.Forms.Padding(0);
            this.multiSelectableCheckedImageListCombobox1.DropdownResizeGripperColor = System.Drawing.Color.Gray;
            this.multiSelectableCheckedImageListCombobox1.DropdownResizeSectionBorderColor = System.Drawing.Color.Empty;
            this.multiSelectableCheckedImageListCombobox1.DropdownResizeSectionFillColor = System.Drawing.Color.Empty;
            this.multiSelectableCheckedImageListCombobox1.DropdownSize = new System.Drawing.Size(600, 375);
            this.multiSelectableCheckedImageListCombobox1.DropDownWindowBackgroundColor = System.Drawing.SystemColors.Window;
            this.multiSelectableCheckedImageListCombobox1.DropDownWindowBorderColor = System.Drawing.Color.Transparent;
            this.multiSelectableCheckedImageListCombobox1.DropDownWindowBorderThickness = 0F;
            this.multiSelectableCheckedImageListCombobox1.ExtendedDropdownButtonImage = null;
            this.multiSelectableCheckedImageListCombobox1.ExtendedDropdownButtonInternalImage = null;
            this.multiSelectableCheckedImageListCombobox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.multiSelectableCheckedImageListCombobox1.IntegralHeight = false;
            this.multiSelectableCheckedImageListCombobox1.IsDropdownInvocationBlocked = false;
            this.multiSelectableCheckedImageListCombobox1.IsInExtendedReadOnlyMode = false;
            this.multiSelectableCheckedImageListCombobox1.IsTextSelectedUponGainingFocus = false;
            this.multiSelectableCheckedImageListCombobox1.Location = new System.Drawing.Point(29, 107);
            multiSeletableCheckedImageListBoxConfiguration3.AnnotationImageOnMouseHover = null;
            multiSeletableCheckedImageListBoxConfiguration3.BackColor = System.Drawing.SystemColors.Window;
            multiSeletableCheckedImageListBoxConfiguration3.CheckBoxSize = new System.Drawing.Size(16, 16);
            multiSeletableCheckedImageListBoxConfiguration3.CheckedStateImage = null;
            multiSeletableCheckedImageListBoxConfiguration3.CheckOnClick = true;
            multiSeletableCheckedImageListBoxConfiguration3.IsAnnotationEnabled = true;
            multiSeletableCheckedImageListBoxConfiguration3.IsImageDrawnWhenUsingDefaultItemTooltip = false;
            multiSeletableCheckedImageListBoxConfiguration3.IsItemSidebarBorderDrawingEnabled = true;
            multiSeletableCheckedImageListBoxConfiguration3.IsItemSidebarDrawingEnabled = true;
            multiSeletableCheckedImageListBoxConfiguration3.IsReadOnly = false;
            multiSeletableCheckedImageListBoxConfiguration3.ItemAlternateEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration3.ItemAlternateGradientFactor = 90F;
            multiSeletableCheckedImageListBoxConfiguration3.ItemAlternateStartColor = System.Drawing.Color.Wheat;
            multiSeletableCheckedImageListBoxConfiguration3.ItemContentFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            multiSeletableCheckedImageListBoxConfiguration3.ItemContentTextColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration3.ItemDisabledContentTextColor = System.Drawing.SystemColors.GrayText;
            multiSeletableCheckedImageListBoxConfiguration3.ItemDisabledEndColor = System.Drawing.SystemColors.Window;
            multiSeletableCheckedImageListBoxConfiguration3.ItemDisabledStartColor = System.Drawing.SystemColors.ControlLight;
            multiSeletableCheckedImageListBoxConfiguration3.ItemDisabledTitleTextColor = System.Drawing.SystemColors.GrayText;
            multiSeletableCheckedImageListBoxConfiguration3.ItemMouseHoverBorderColor = System.Drawing.Color.DarkBlue;
            multiSeletableCheckedImageListBoxConfiguration3.ItemMouseHoverBorderThickness = 1;
            multiSeletableCheckedImageListBoxConfiguration3.ItemMouseHoverContentTextForeColor = System.Drawing.Color.Blue;
            multiSeletableCheckedImageListBoxConfiguration3.ItemMouseHoverEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration3.ItemMouseHoverGradientFactor = 90F;
            multiSeletableCheckedImageListBoxConfiguration3.ItemMouseHoverStartColor = System.Drawing.Color.SkyBlue;
            multiSeletableCheckedImageListBoxConfiguration3.ItemMouseHoverTitleForeColor = System.Drawing.Color.Maroon;
            multiSeletableCheckedImageListBoxConfiguration3.ItemReadOnlyBorderColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration3.ItemReadOnlyContentTextColor = System.Drawing.SystemColors.WindowText;
            multiSeletableCheckedImageListBoxConfiguration3.ItemReadOnlyEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration3.ItemReadOnlyStartColor = System.Drawing.Color.GhostWhite;
            multiSeletableCheckedImageListBoxConfiguration3.ItemReadOnlyTitleTextColor = System.Drawing.SystemColors.WindowText;
            multiSeletableCheckedImageListBoxConfiguration3.ItemSelectedBorderColor = System.Drawing.Color.Red;
            multiSeletableCheckedImageListBoxConfiguration3.ItemSelectedBorderThickness = 1;
            multiSeletableCheckedImageListBoxConfiguration3.ItemSelectedEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration3.ItemSelectedGradientFactor = 90F;
            multiSeletableCheckedImageListBoxConfiguration3.ItemSelectedStartColor = System.Drawing.Color.LightSalmon;
            multiSeletableCheckedImageListBoxConfiguration3.ItemSpacing = 6;
            multiSeletableCheckedImageListBoxConfiguration3.ItemTitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            multiSeletableCheckedImageListBoxConfiguration3.ItemTitleTextColor = System.Drawing.Color.Brown;
            multiSeletableCheckedImageListBoxConfiguration3.ItemTooltipContentFont = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            multiSeletableCheckedImageListBoxConfiguration3.ItemTooltipTitleFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            multiSeletableCheckedImageListBoxConfiguration3.ItemUnselectedBorderColor = System.Drawing.Color.BurlyWood;
            multiSeletableCheckedImageListBoxConfiguration3.ItemUnselectedBorderThickness = 1;
            multiSeletableCheckedImageListBoxConfiguration3.ItemUnselectedContentTextColor = System.Drawing.Color.Brown;
            multiSeletableCheckedImageListBoxConfiguration3.ItemUnselectedEndColor = System.Drawing.Color.White;
            multiSeletableCheckedImageListBoxConfiguration3.ItemUnselectedGradientFactor = 270F;
            multiSeletableCheckedImageListBoxConfiguration3.ItemUnselectedStartColor = System.Drawing.Color.NavajoWhite;
            multiSeletableCheckedImageListBoxConfiguration3.ItemUnselectedTitleTextColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration3.MinimumItemTopAndBottomMargin = 7;
            multiSeletableCheckedImageListBoxConfiguration3.PaddingBetweenItemComponents = 8;
            multiSeletableCheckedImageListBoxConfiguration3.SelectionMode = System.Windows.Forms.SelectionMode.None;
            multiSeletableCheckedImageListBoxConfiguration3.ShouldAnimateItemImage = false;
            multiSeletableCheckedImageListBoxConfiguration3.ShouldDrawCheckBoxInVisualStyle = true;
            multiSeletableCheckedImageListBoxConfiguration3.ShouldDrawItemBorder = true;
            multiSeletableCheckedImageListBoxConfiguration3.ShouldDrawTopItemSpacingForFirstItem = false;
            multiSeletableCheckedImageListBoxConfiguration3.ShouldEnableAlternatingColors = false;
            multiSeletableCheckedImageListBoxConfiguration3.ShouldExpandItemFullViewUponClick = false;
            multiSeletableCheckedImageListBoxConfiguration3.ShouldRefreshBasedOnMessage = true;
            multiSeletableCheckedImageListBoxConfiguration3.ShouldShowDefaultTooltipOnItemHover = false;
            multiSeletableCheckedImageListBoxConfiguration3.ShouldUseImageForCheckState = false;
            multiSeletableCheckedImageListBoxConfiguration3.SidebarBorderThickness = 1;
            multiSeletableCheckedImageListBoxConfiguration3.SidebarGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            multiSeletableCheckedImageListBoxConfiguration3.SidebarItemHoveredStateBorderColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration3.SidebarItemHoveredStateEndColor = System.Drawing.Color.CornflowerBlue;
            multiSeletableCheckedImageListBoxConfiguration3.SidebarItemHoveredStateStartColor = System.Drawing.Color.RoyalBlue;
            multiSeletableCheckedImageListBoxConfiguration3.SidebarItemSelectedStateBorderColor = System.Drawing.Color.Black;
            multiSeletableCheckedImageListBoxConfiguration3.SidebarItemSelectedStateEndColor = System.Drawing.Color.BurlyWood;
            multiSeletableCheckedImageListBoxConfiguration3.SidebarItemSelectedStateStartColor = System.Drawing.Color.Brown;
            multiSeletableCheckedImageListBoxConfiguration3.SidebarWidth = 12;
            multiSeletableCheckedImageListBoxConfiguration3.UncheckedStateImage = null;
            this.multiSelectableCheckedImageListCombobox1.MultiSelectableCheckedImageListBoxConfiguration = multiSeletableCheckedImageListBoxConfiguration3;
            this.multiSelectableCheckedImageListCombobox1.Name = "multiSelectableCheckedImageListCombobox1";
            this.multiSelectableCheckedImageListCombobox1.SelectedIndexFromDropList = -1;
            this.multiSelectableCheckedImageListCombobox1.ShouldDrawBidirectionalResizeGripper = true;
            this.multiSelectableCheckedImageListCombobox1.ShouldDrawDropdownResizeSectionWith3DBorder = false;
            this.multiSelectableCheckedImageListCombobox1.ShouldDrawExtendedDropdownButton = false;
            this.multiSelectableCheckedImageListCombobox1.ShouldDrawVerticalResizeGripper = true;
            this.multiSelectableCheckedImageListCombobox1.ShowBorderAlways = true;
            this.multiSelectableCheckedImageListCombobox1.Size = new System.Drawing.Size(256, 21);
            this.multiSelectableCheckedImageListCombobox1.TabIndex = 0;
            this.multiSelectableCheckedImageListCombobox1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.multiSelectableCheckedImageListCombobox1.ToggleCheckStateForAllItems = false;
            // 
            // btnExitCommandInvoker
            // 
            this.btnExitCommandInvoker.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExitCommandInvoker.Location = new System.Drawing.Point(1238, 687);
            this.btnExitCommandInvoker.Name = "btnExitCommandInvoker";
            this.btnExitCommandInvoker.Size = new System.Drawing.Size(95, 35);
            this.btnExitCommandInvoker.TabIndex = 10;
            this.btnExitCommandInvoker.Text = "E&xit";
            this.btnExitCommandInvoker.UseVisualStyleBackColor = true;
            this.btnExitCommandInvoker.Click += new System.EventHandler(this.ExitCommandInvokerClick);
            // 
            // DemoWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(1358, 776);
            this.Controls.Add(this.btnExitCommandInvoker);
            this.Controls.Add(this.txtSeperationDelimiterChars);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.multiSelectableCheckedImageListCombobox3);
            this.Controls.Add(this.multiSelectableCheckedImageListCombobox2);
            this.Controls.Add(this.multiSelectableCheckedImageListCombobox1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DemoWindow";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MultiSelectableCheckedImageListCombobox multiSelectableCheckedImageListCombobox1;
        private MultiSelectableCheckedImageListCombobox multiSelectableCheckedImageListCombobox2;
        private MultiSelectableCheckedImageListCombobox multiSelectableCheckedImageListCombobox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkEnableDrawingSidebars;
        private System.Windows.Forms.CheckBox chkControlInstancesAreReadOnlyMode;
        private System.Windows.Forms.CheckBox chkControlInstancesAreBlockedFromDropdownDisplay;
        private System.Windows.Forms.CheckBox chkKeepAllItemsSelected;
        private System.Windows.Forms.CheckBox chkCheckUncheckUponClick;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSeperationDelimiterChars;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnExitCommandInvoker;
    }
}