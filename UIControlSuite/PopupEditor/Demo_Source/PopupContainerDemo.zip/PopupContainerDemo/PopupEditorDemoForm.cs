﻿using System;
using System.Drawing;
using System.Linq;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.ExtendedContainers.Popup;
using PopupContainerDemo.ChildContent;

namespace PopupContainerDemo
{
    public partial class PopupEditorDemoForm : ModernChromeWindow
    {
        // Some instances of the application specific custom views that we would like to host inside the PopupEditor .NET control.
        private SampleAppDataInputView _sampleAppDataInputView1;
        private SampleAppDataInputView _sampleAppDataInputView2;
        private SampleAppDataInputView _sampleAppDataInputView3;

        public PopupEditorDemoForm()
        {
            InitializeComponent();

            InitialiseFields();

            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            Load += PopupEditorDemoForm_Load;
        }

        private void InitialiseFields()
        {
            _sampleAppDataInputView1 = new SampleAppDataInputView();
            _sampleAppDataInputView1.ViewUpdateRequested += (o, e) =>
            {
                popupEditor1.DisplayText = _sampleAppDataInputView1.SelectionResult;

                ClosePopupView(popupEditor1);
            };

            _sampleAppDataInputView2 = new SampleAppDataInputView();
            _sampleAppDataInputView2.ViewUpdateRequested +=
                (o, e) =>
                {
                    popupEditor2.DisplayText = _sampleAppDataInputView2.SelectionResult;

                    ClosePopupView(popupEditor2);
                };

            _sampleAppDataInputView3 = new SampleAppDataInputView();
            _sampleAppDataInputView3.ViewUpdateRequested += (o, e) =>
            {
                popupEditor3.DisplayText = _sampleAppDataInputView3.SelectionResult;

                ClosePopupView(popupEditor3);
            };
        }

        private void ClosePopupView(PopupEditor popupInstance)
        {
            if (chkShouldAutoCLosePopuViewUponChangesAccepted.Checked)
            {
                popupInstance.ClosePopup();
            }
        }

        private void PopupEditorDemoForm_Load(object sender, EventArgs e)
        {
            // You can do all the below setup in design-time,
            // but here I am showing the setup of some properties in code, so you can appreciate some core features of the control.

            SetupPopupEditorInstance(popupEditor1, _sampleAppDataInputView1);
            SetupPopupEditorInstance(popupEditor2, _sampleAppDataInputView2);
            SetupPopupEditorInstance(popupEditor3, _sampleAppDataInputView3);

            // Just to prove the point/fancy, let's make some changes to the configuration of the other two popup editor instances...

            popupEditor2.DisplayTextVisualToTotalSizeRatio = 40;
            popupEditor3.DisplayTextVisualToTotalSizeRatio = 60;
        }

        private void SetupPopupEditorInstance(PopupEditor popupEditor,
            SampleAppDataInputView childViewInstanceToHostInPopupView)
        {
            // Demo-ing some of the core features...

            // Setup your custom content for drop-down view
            // To do this, simply associate one of our application views as this popup-editor's drop-down view.
            popupEditor.PopupContentHost = childViewInstanceToHostInPopupView;

            // Setup a custom size for the drop-down view.
            popupEditor.DropDownSize = new Size(290, 370);

            // Setup a custom ratio of sizing for each of the components in the popup-editor.
            popupEditor.DisplayTextVisualToTotalSizeRatio = 80;

            // Setup custom handlers for the events exposed by the control, in order to 
            // specify what to do when each event fires... 
            // for example, what to display once the drop-down view is closed.
            popupEditor.DropDownPopupOpened += PopupEditorOnDropDownPopupOpened;
            popupEditor.DropDownPopupClosed += (s, e) =>
                                                popupEditor.DisplayText = childViewInstanceToHostInPopupView.SelectionResult;

            // You could also set a text string as display item for the drop-down button/command
            // If you set it to null, either the control will draw its own images
            // or alternatively you can specify various images that needs to be used
            // for various visual states of the drop-down command visual section. 
            popupEditor.PopupCommandVisualText = null;
        }

        private void PopupEditorOnDropDownPopupOpened(object sender, EventArgs eventArgs)
        {
            // Handle it, if you need to.
        }

        private void chkRememberUserSizing_CheckedChanged(object sender, EventArgs e)
        {
            foreach (var popupEditor in Controls.OfType<PopupEditor>())
            {
                popupEditor.ShouldRememberUserSizedDropDownSize = chkRememberUserSizing.Checked;
            }
        }

        private void chkShouldEnableDropDownResizingCapabilities_CheckedChanged(object sender, EventArgs e)
        {
            foreach (var popupEditor in Controls.OfType<PopupEditor>())
            {
                popupEditor.EnableDropDownResizing = chkShouldEnableDropDownResizingCapabilities.Checked;
            }
        }
    }
}
