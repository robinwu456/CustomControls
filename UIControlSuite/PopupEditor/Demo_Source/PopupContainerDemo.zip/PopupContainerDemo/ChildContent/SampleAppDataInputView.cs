﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PopupContainerDemo.ChildContent
{
    // This is a sample application specific class that has some data that will be queried by the applicaiton form to 
    // update the PopupEditor's DisplayText area in a way/format the applicaiton wants.
    // The PopupEditor control tiself does not have any afinity or knowledge of the controls/views that it hosts.
    // So it is upto the appliciton using the PopupEditor control to update its display text area,
    // by setting its DisplayText property.
    // In this sample, we do it via this view's SelectionResult property.
    // IN your applications, you amy choose to do in any other manner too (maybe via an abstraction on top of these views
    // that will expose a common property for data query that the applicaito;'s form can use to update the PopupEditor.

    public partial class SampleAppDataInputView : UserControl
    {
        public string SelectionResult { get; set; }

        internal event EventHandler ViewUpdateRequested;

        public SampleAppDataInputView()
        {
            InitializeComponent();
        }

        private void btnUpdate_Click(object sender, System.EventArgs e)
        {
            CollectCheckedItemsData();
            OnViewUpdateRequested();
        }

        private void CollectCheckedItemsData()
        {
            if (checkedListBox1.CheckedItems.Count == 0)
            {
                SelectionResult = string.Empty;
            }
            else
            {
                var sbuilder = new StringBuilder();

                foreach (var index in checkedListBox1.CheckedIndices)
                {
                    sbuilder.Append($"{checkedListBox1.Items[(int)index]} : ");
                }

                var selectionResult = sbuilder.ToString();
                SelectionResult = selectionResult.Remove(selectionResult.Length - 3, 3);
            }
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);

            if(!Visible)
                CollectCheckedItemsData();
        }

        protected virtual void OnViewUpdateRequested()
        {
            ViewUpdateRequested?.Invoke(this, EventArgs.Empty);
        }
    }
}
