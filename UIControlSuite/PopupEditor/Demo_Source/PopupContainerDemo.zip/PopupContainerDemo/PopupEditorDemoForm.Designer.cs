﻿namespace PopupContainerDemo
{
    partial class PopupEditorDemoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PopupEditorDemoForm));
            this.label1 = new System.Windows.Forms.Label();
            this.chkRememberUserSizing = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.chkShouldAutoCLosePopuViewUponChangesAccepted = new System.Windows.Forms.CheckBox();
            this.popupEditor3 = new Binarymission.WinForms.Controls.ExtendedContainers.Popup.PopupEditor();
            this.popupEditor2 = new Binarymission.WinForms.Controls.ExtendedContainers.Popup.PopupEditor();
            this.popupEditor1 = new Binarymission.WinForms.Controls.ExtendedContainers.Popup.PopupEditor();
            this.chkShouldEnableDropDownResizingCapabilities = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(366, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Binarymission PopupEditor controls in various configurations";
            // 
            // chkRememberUserSizing
            // 
            this.chkRememberUserSizing.AutoSize = true;
            this.chkRememberUserSizing.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRememberUserSizing.Location = new System.Drawing.Point(20, 389);
            this.chkRememberUserSizing.Name = "chkRememberUserSizing";
            this.chkRememberUserSizing.Size = new System.Drawing.Size(502, 20);
            this.chkRememberUserSizing.TabIndex = 5;
            this.chkRememberUserSizing.Text = "Should the popupedit controls remember the user sizing of the drop-down views?";
            this.chkRememberUserSizing.UseVisualStyleBackColor = true;
            this.chkRememberUserSizing.CheckedChanged += new System.EventHandler(this.chkRememberUserSizing_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(343, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(287, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "DisplayTextVisualToTotalSizeRatio set to 40%";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(344, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(287, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "DisplayTextVisualToTotalSizeRatio set to 60%";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(344, 201);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(339, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "and the Size set to a larger size (Use cases: POS/Kiosk)";
            // 
            // chkShouldAutoCLosePopuViewUponChangesAccepted
            // 
            this.chkShouldAutoCLosePopuViewUponChangesAccepted.AutoSize = true;
            this.chkShouldAutoCLosePopuViewUponChangesAccepted.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShouldAutoCLosePopuViewUponChangesAccepted.Location = new System.Drawing.Point(20, 415);
            this.chkShouldAutoCLosePopuViewUponChangesAccepted.Name = "chkShouldAutoCLosePopuViewUponChangesAccepted";
            this.chkShouldAutoCLosePopuViewUponChangesAccepted.Size = new System.Drawing.Size(557, 20);
            this.chkShouldAutoCLosePopuViewUponChangesAccepted.TabIndex = 9;
            this.chkShouldAutoCLosePopuViewUponChangesAccepted.Text = "Should automatically close the popup window, upon accepting changes in rhe popup " +
    "view";
            this.chkShouldAutoCLosePopuViewUponChangesAccepted.UseVisualStyleBackColor = true;
            // 
            // popupEditor3
            // 
            this.popupEditor3.BorderThickness = 0F;
            this.popupEditor3.DisplayLocation = new System.Drawing.Point(0, 0);
            this.popupEditor3.DisplayText = null;
            this.popupEditor3.DisplayTextVisualToTotalSizeRatio = 60F;
            this.popupEditor3.EnableDropDownResizing = true;
            this.popupEditor3.DropDownContentPadding = new System.Windows.Forms.Padding(0);
            this.popupEditor3.DropDownResizeGripperColor = System.Drawing.Color.White;
            this.popupEditor3.DropDownResizeSectionBorderColor = System.Drawing.Color.SteelBlue;
            this.popupEditor3.DropDownResizeSectionFillColor = System.Drawing.Color.SteelBlue;
            this.popupEditor3.DropDownSize = new System.Drawing.Size(0, 0);
            this.popupEditor3.Location = new System.Drawing.Point(346, 226);
            this.popupEditor3.Name = "popupEditor3";
            this.popupEditor3.PopupCommandVisualBorderColor = System.Drawing.Color.SteelBlue;
            this.popupEditor3.PopupCommandVisualBorderColorOnHover = System.Drawing.Color.SteelBlue;
            this.popupEditor3.PopupCommandVisualBorderColorOnPressed = System.Drawing.Color.SteelBlue;
            this.popupEditor3.PopupCommandVisualFont = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.popupEditor3.PopupCommandVisualHoveredBackColor = System.Drawing.Color.LightCoral;
            this.popupEditor3.PopupCommandVisualHoverStateImage = null;
            this.popupEditor3.PopupCommandVisualMaximumInternalImageDrawingSize = new System.Drawing.Size(64, 64);
            this.popupEditor3.PopupCommandVisualNormalBackColor = System.Drawing.Color.SteelBlue;
            this.popupEditor3.PopupCommandVisualNormalStateImage = null;
            this.popupEditor3.PopupCommandVisualPressedBackColor = System.Drawing.Color.Navy;
            this.popupEditor3.PopupCommandVisualPressedStateImage = null;
            this.popupEditor3.PopupCommandVisualShouldApplyPaddingWhilePositioningImage = false;
            this.popupEditor3.PopupCommandVisualText = null;
            this.popupEditor3.PopupCommandVisualTextForeColor = System.Drawing.SystemColors.WindowText;
            this.popupEditor3.PopupContentHost = null;
            this.popupEditor3.ShouldDrawBidirectionalResizeGripper = true;
            this.popupEditor3.ShouldDrawDropDownResizeSectionWith3DBorder = false;
            this.popupEditor3.ShouldDrawDropShadow = false;
            this.popupEditor3.ShouldDrawVerticalResizeGripper = true;
            this.popupEditor3.ShouldRememberUserSizedDropDownSize = false;
            this.popupEditor3.Size = new System.Drawing.Size(382, 99);
            this.popupEditor3.TabIndex = 3;
            this.popupEditor3.Text = "popupEditor4";
            this.popupEditor3.TextDisplayVisualBackColor = System.Drawing.SystemColors.Window;
            this.popupEditor3.TextDisplayVisualBorderColor = System.Drawing.Color.SteelBlue;
            this.popupEditor3.TextDisplayVisualBorderThickness = 1;
            this.popupEditor3.TextDisplayVisualFont = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.popupEditor3.TextDisplayVisualTextForeColor = System.Drawing.Color.SteelBlue;
            // 
            // popupEditor2
            // 
            this.popupEditor2.BorderThickness = 0F;
            this.popupEditor2.DisplayLocation = new System.Drawing.Point(0, 0);
            this.popupEditor2.DisplayText = null;
            this.popupEditor2.DisplayTextVisualToTotalSizeRatio = 40F;
            this.popupEditor2.EnableDropDownResizing = true;
            this.popupEditor2.DropDownContentPadding = new System.Windows.Forms.Padding(0);
            this.popupEditor2.DropDownResizeGripperColor = System.Drawing.Color.White;
            this.popupEditor2.DropDownResizeSectionBorderColor = System.Drawing.Color.Teal;
            this.popupEditor2.DropDownResizeSectionFillColor = System.Drawing.Color.Teal;
            this.popupEditor2.DropDownSize = new System.Drawing.Size(0, 0);
            this.popupEditor2.Location = new System.Drawing.Point(346, 122);
            this.popupEditor2.Name = "popupEditor2";
            this.popupEditor2.PopupCommandVisualBorderColor = System.Drawing.Color.Teal;
            this.popupEditor2.PopupCommandVisualBorderColorOnHover = System.Drawing.Color.Teal;
            this.popupEditor2.PopupCommandVisualBorderColorOnPressed = System.Drawing.Color.Teal;
            this.popupEditor2.PopupCommandVisualFont = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.popupEditor2.PopupCommandVisualHoveredBackColor = System.Drawing.Color.Teal;
            this.popupEditor2.PopupCommandVisualHoverStateImage = null;
            this.popupEditor2.PopupCommandVisualMaximumInternalImageDrawingSize = new System.Drawing.Size(32, 32);
            this.popupEditor2.PopupCommandVisualNormalBackColor = System.Drawing.Color.Teal;
            this.popupEditor2.PopupCommandVisualNormalStateImage = null;
            this.popupEditor2.PopupCommandVisualPressedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.popupEditor2.PopupCommandVisualPressedStateImage = null;
            this.popupEditor2.PopupCommandVisualShouldApplyPaddingWhilePositioningImage = false;
            this.popupEditor2.PopupCommandVisualText = null;
            this.popupEditor2.PopupCommandVisualTextForeColor = System.Drawing.SystemColors.WindowText;
            this.popupEditor2.PopupContentHost = null;
            this.popupEditor2.ShouldDrawBidirectionalResizeGripper = true;
            this.popupEditor2.ShouldDrawDropDownResizeSectionWith3DBorder = false;
            this.popupEditor2.ShouldDrawDropShadow = false;
            this.popupEditor2.ShouldDrawVerticalResizeGripper = true;
            this.popupEditor2.ShouldRememberUserSizedDropDownSize = false;
            this.popupEditor2.Size = new System.Drawing.Size(253, 25);
            this.popupEditor2.TabIndex = 1;
            this.popupEditor2.Text = "popupEditor2";
            this.popupEditor2.TextDisplayVisualBackColor = System.Drawing.SystemColors.Window;
            this.popupEditor2.TextDisplayVisualBorderColor = System.Drawing.Color.Teal;
            this.popupEditor2.TextDisplayVisualBorderThickness = 1;
            this.popupEditor2.TextDisplayVisualFont = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.popupEditor2.TextDisplayVisualTextForeColor = System.Drawing.Color.Teal;
            // 
            // popupEditor1
            // 
            this.popupEditor1.BorderThickness = 0F;
            this.popupEditor1.DisplayLocation = new System.Drawing.Point(0, 0);
            this.popupEditor1.DisplayText = null;
            this.popupEditor1.DisplayTextVisualToTotalSizeRatio = 80F;
            this.popupEditor1.EnableDropDownResizing = true;
            this.popupEditor1.DropDownContentPadding = new System.Windows.Forms.Padding(0);
            this.popupEditor1.DropDownResizeGripperColor = System.Drawing.Color.White;
            this.popupEditor1.DropDownResizeSectionBorderColor = System.Drawing.Color.SlateGray;
            this.popupEditor1.DropDownResizeSectionFillColor = System.Drawing.Color.SlateGray;
            this.popupEditor1.DropDownSize = new System.Drawing.Size(0, 0);
            this.popupEditor1.Location = new System.Drawing.Point(19, 63);
            this.popupEditor1.Name = "popupEditor1";
            this.popupEditor1.PopupCommandVisualBorderColor = System.Drawing.Color.Chocolate;
            this.popupEditor1.PopupCommandVisualBorderColorOnHover = System.Drawing.Color.DarkRed;
            this.popupEditor1.PopupCommandVisualBorderColorOnPressed = System.Drawing.Color.SlateGray;
            this.popupEditor1.PopupCommandVisualFont = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.popupEditor1.PopupCommandVisualHoveredBackColor = System.Drawing.Color.DarkRed;
            this.popupEditor1.PopupCommandVisualHoverStateImage = null;
            this.popupEditor1.PopupCommandVisualMaximumInternalImageDrawingSize = new System.Drawing.Size(32, 32);
            this.popupEditor1.PopupCommandVisualNormalBackColor = System.Drawing.Color.Chocolate;
            this.popupEditor1.PopupCommandVisualNormalStateImage = null;
            this.popupEditor1.PopupCommandVisualPressedBackColor = System.Drawing.Color.SlateGray;
            this.popupEditor1.PopupCommandVisualPressedStateImage = null;
            this.popupEditor1.PopupCommandVisualShouldApplyPaddingWhilePositioningImage = false;
            this.popupEditor1.PopupCommandVisualText = null;
            this.popupEditor1.PopupCommandVisualTextForeColor = System.Drawing.SystemColors.WindowText;
            this.popupEditor1.PopupContentHost = null;
            this.popupEditor1.ShouldDrawBidirectionalResizeGripper = true;
            this.popupEditor1.ShouldDrawDropDownResizeSectionWith3DBorder = false;
            this.popupEditor1.ShouldDrawDropShadow = false;
            this.popupEditor1.ShouldDrawVerticalResizeGripper = true;
            this.popupEditor1.ShouldRememberUserSizedDropDownSize = false;
            this.popupEditor1.Size = new System.Drawing.Size(253, 37);
            this.popupEditor1.TabIndex = 0;
            this.popupEditor1.Text = "popupEditor1";
            this.popupEditor1.TextDisplayVisualBackColor = System.Drawing.SystemColors.Window;
            this.popupEditor1.TextDisplayVisualBorderColor = System.Drawing.Color.SlateGray;
            this.popupEditor1.TextDisplayVisualBorderThickness = 1;
            this.popupEditor1.TextDisplayVisualFont = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.popupEditor1.TextDisplayVisualTextForeColor = System.Drawing.Color.SlateGray;
            // 
            // chkShouldEnableDropDownResizingCapabilities
            // 
            this.chkShouldEnableDropDownResizingCapabilities.AutoSize = true;
            this.chkShouldEnableDropDownResizingCapabilities.Checked = true;
            this.chkShouldEnableDropDownResizingCapabilities.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShouldEnableDropDownResizingCapabilities.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShouldEnableDropDownResizingCapabilities.Location = new System.Drawing.Point(20, 441);
            this.chkShouldEnableDropDownResizingCapabilities.Name = "chkShouldEnableDropDownResizingCapabilities";
            this.chkShouldEnableDropDownResizingCapabilities.Size = new System.Drawing.Size(305, 20);
            this.chkShouldEnableDropDownResizingCapabilities.TabIndex = 10;
            this.chkShouldEnableDropDownResizingCapabilities.Text = "Should enable resizing the drop-down window?";
            this.chkShouldEnableDropDownResizingCapabilities.UseVisualStyleBackColor = true;
            this.chkShouldEnableDropDownResizingCapabilities.CheckedChanged += new System.EventHandler(this.chkShouldEnableDropDownResizingCapabilities_CheckedChanged);
            // 
            // PopupEditorDemoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(759, 514);
            this.Controls.Add(this.chkShouldEnableDropDownResizingCapabilities);
            this.Controls.Add(this.chkShouldAutoCLosePopuViewUponChangesAccepted);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.chkRememberUserSizing);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.popupEditor3);
            this.Controls.Add(this.popupEditor2);
            this.Controls.Add(this.popupEditor1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PopupEditorDemoForm";
            this.TitlebarText = "Binarymission PopupEditor .NET control demo!";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Binarymission.WinForms.Controls.ExtendedContainers.Popup.PopupEditor popupEditor1;
        private Binarymission.WinForms.Controls.ExtendedContainers.Popup.PopupEditor popupEditor2;
        private Binarymission.WinForms.Controls.ExtendedContainers.Popup.PopupEditor popupEditor3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkRememberUserSizing;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkShouldAutoCLosePopuViewUponChangesAccepted;
        private System.Windows.Forms.CheckBox chkShouldEnableDropDownResizingCapabilities;
    }
}