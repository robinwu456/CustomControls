﻿using System;
using System.Drawing;
using System.Drawing.Text;
using System.Text;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.TreeControls.Advanced;

namespace TreeListViewDemo
{
    // For this demo, I have used my ModernChromeWindow class as my form.
    // If you would like to run the sample with the plain old Form class, simply replace "ModernChromeWindow" to "Form",
    // and comment out the code in the private method SetupChromeProperties().

    public partial class Form1 : ModernChromeWindow
    {
        private BinaryTreeListView _binaryTreeListView1;
        private BinaryTreeListViewColumn _subjectColumn;
        private DataGridViewTextBoxColumn _messageIdColumn;
        private DataGridViewCheckBoxColumn _followUpColumn;
        private int _randomizationCount = 1;
        private BinaryTreeListViewNode _mainParentNode;
        
        public Form1()
        {
            InitializeComponent();

            // Setup some handlers to a context menu command in the tree-list view.
            // This is just to prove the ability that, if you need to, you can collect data from the tree-list view control instance,
            // and also play with its internal structures like background color, etc.
            SetupEventHandlers();

            // Setup the tree-list instance
            SetupTreeListControlAndItsData();

            // Set a root parent node that will host all other nodes in the application.
            SetupRootParentNode();

            // Setup node instances, for building up the tree.
            SetupTreeListNodes();
            
            // Just for fun, let us also re-order columns, and move the tree-list view column to be the last column.
            // Of course, note that the control also supports letting the user re-order columns at runtime as he/she wishes too.
            ReorderColumns();

            // Setting up some fancy properties for the ModernChromeWindow instance.
            SetupChromeProperties();

            ExpandMainParentNodeOneLevel();
            // All done, and ready to display a tree list of your data now. :-)
        }

        private void ExpandMainParentNodeOneLevel()
        {
            _mainParentNode?.Expand(false);
        }

        private void SetupEventHandlers()
        {
            copySelectedNodesToClipboard.Click += CopySelectedNodesToClipboardClick;
            applyBackColorForColumnToolstripItem.Click += ApplyBackColorForColumnToolstripItemOnClick;
            cmdExpandNode.Click += ExpandeNodeClickHandler;
            cmdCollapseNode.Click += CollapseNodeClickHandler;
            cmdExpandNodeDeep.Click += ExpandNodesDeepClickHandler;
            cmdCollapseNodeDeep.Click += CollapseNodesDeepClickHandler;
        }

        private void ExpandeNodeClickHandler(object sender, EventArgs e)
        {
            _binaryTreeListView1.CurrentNode.Expand(false);
        }

        private void ExpandNodesDeepClickHandler(object sender, EventArgs e)
        {
            _binaryTreeListView1.CurrentNode.Expand(true);
        }

        private void CollapseNodeClickHandler(object sender, EventArgs e)
        {
            _binaryTreeListView1.CurrentNode.Collapse(false);
        }

        private void CollapseNodesDeepClickHandler(object sender, EventArgs e)
        {
            _binaryTreeListView1.CurrentNode.Collapse(true);
        }

        private void SetupRootParentNode()
        {
            _binaryTreeListView1.ClearAllNodes();

            var cellInfo = new BinaryTreeListViewCellInfo
            {
                Text = "All customer emails",
                ShowImage = true
            };

            // Create the first top level node instance, with some custom data
            _mainParentNode = _binaryTreeListView1.Nodes.Add(cellInfo, $"{0}", true);
        }

        
        private void ApplyBackColorForColumnToolstripItemOnClick(object sender, EventArgs eventArgs)
        {
            if (_binaryTreeListView1.CurrentCell == null) return;

            var columnToApplyBackgroundColor = _binaryTreeListView1.CurrentCell.ColumnIndex;

            _binaryTreeListView1.Columns[columnToApplyBackgroundColor].DefaultCellStyle.BackColor = ((ToolStripMenuItem)sender).Checked ? Color.FromArgb(255,
                233, 255, 217) : Color.White;
        }

        private void CopySelectedNodesToClipboardClick(object sender, System.EventArgs e)
        {
            var rows = _binaryTreeListView1.SelectedRows;
            var stringBuilder = new StringBuilder();

            foreach (var item in rows)
            {
                stringBuilder.AppendLine(item.ToString());
                stringBuilder.AppendLine($"The node's check status was {((BinaryTreeListViewNode) item).CellInfoCheckStatus}");
            }

            Clipboard.SetDataObject(stringBuilder.ToString(), false, 5, 200);
            MessageBox.Show(@"Selected nodes data have been copied to clipboard.", 
                            @"Copy successful",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }
        
        // Note that all the things I do here in this method, can be done directly from the Visual Studio Designer (Design-time) itself.
        // You do not need to hand-code these.
        // I do these in code here just to illustrate what happens behind the scenes, so you can understand the work flow of how and what gets setup.
        private void SetupTreeListControlAndItsData()
        {
            SuspendLayout();

            StartPosition = FormStartPosition.CenterScreen;

            // Instantiate the control
            // Let us also setup some properties of the control, like mode images etc.

            _binaryTreeListView1 = new BinaryTreeListView
            {
                TabIndex = 1,
                Dock = DockStyle.Fill,
                AllowUserToOrderColumns = true,
                AllowUserToResizeColumns = true,
                DrawGlassBackgroundHighlightingOnMouseEnter = false,
                DrawColumnSeparatorWhenUsingBuiltinRendering = true,
                CellEditingMode = DataGridViewEditMode.EditOnKeystrokeOrF2,
                CollapseImage = Properties.Resources.Minus_1,
                ExpandImage = Properties.Resources.Plus_1,
                EnableCommitingEditWhenMovingFocusFromEditContext = true,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells,
                CellBorderStyle = DataGridViewCellBorderStyle.None,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.White,
                LineDrawingColor = Color.Sienna,
                ColumnSeparatorDrawingColor = Color.DarkGray,
                StartColorForRenderingColumnHeader = Color.Wheat,
                EndColorForRenderingColumnHeader = Color.White,
                StartColorForRenderingRow = Color.Wheat,
                EndColorForRenderingRow = Color.White,
                ContextMenuStrip = contextMenuStrip1
            };

            // Add it to the Form.Controls collection.
            Controls.Add(_binaryTreeListView1);
            _binaryTreeListView1.BringToFront();

            // Let us just attach an event handler for the CellFormatting event and show that we can update the formatting on the fly.
            _binaryTreeListView1.CellFormatting += BinaryTreeListView1CellFormatting;

            ResumeLayout(false);
            PerformLayout();

            // Setup some columns
            _subjectColumn = new BinaryTreeListViewColumn();

            // Let us set the tree-list column to support multi-line text
            _binaryTreeListView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            _subjectColumn.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

            // Set a specific font... just for fun! :)
            _subjectColumn.DefaultCellStyle.Font = new Font(new FontFamily(GenericFontFamilies.Monospace), 11f, FontStyle.Regular);

            // Setup some more columns for the tree-list view.
            _messageIdColumn = new DataGridViewTextBoxColumn();
            _followUpColumn = new DataGridViewCheckBoxColumn();

            // setup font for the column headers
            _binaryTreeListView1.ColumnHeadersDefaultCellStyle.Font = new Font(new FontFamily(GenericFontFamilies.Monospace), 10f, FontStyle.Regular);
            _binaryTreeListView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.Brown;
            _binaryTreeListView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


            // Set some properties of these columns.
            _subjectColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            _messageIdColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            _followUpColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            _subjectColumn.HeaderText = @"Subject";
            _messageIdColumn.HeaderText = @"Message Id";
            _followUpColumn.HeaderText = @"Should Follow Up?";

            _subjectColumn.DefaultCellStyle.ForeColor = Color.Brown;

            _messageIdColumn.DefaultCellStyle.ForeColor = Color.SteelBlue;
            _messageIdColumn.DefaultCellStyle.Font = new Font(DefaultFont, FontStyle.Bold);
            _messageIdColumn.DefaultCellStyle.Padding = new Padding(6, _messageIdColumn.DefaultCellStyle.Padding.Top,
                                                                _messageIdColumn.DefaultCellStyle.Padding.Right,
                                                                _messageIdColumn.DefaultCellStyle.Padding.Bottom);

            _followUpColumn.DefaultCellStyle.Padding = new Padding(6, _followUpColumn.DefaultCellStyle.Padding.Top,
                                                                _followUpColumn.DefaultCellStyle.Padding.Right,
                                                                _followUpColumn.DefaultCellStyle.Padding.Bottom);

            // Add these columns in to BinaryTreeListViewInstance.
            _binaryTreeListView1.Columns.AddRange(_subjectColumn, _messageIdColumn, _followUpColumn);
        }
        
        private void SetupTreeListNodes(bool clearAllItemsFirst = false)
        {
            if (clearAllItemsFirst)
            {
                _binaryTreeListView1.ClearAllNodes();
                SetupRootParentNode();
                ExpandMainParentNodeOneLevel();
            }

            BinaryTreeListViewNode node = null;

            var cellInfo = new BinaryTreeListViewCellInfo
            {
                Text = "Compiled API guide query",
                ShowImage = true
            };

            // Create the first top level node instance, with some custom data
            //node = _binaryTreeListView1.Nodes.Add(cellInfo, $"{1}", true);
            node = _mainParentNode.Nodes.Add(cellInfo, $"{1}", true);

            var i = 2;
            
            for (; i < 25; i++)
            {
                cellInfo = new BinaryTreeListViewCellInfo
                {
                    Text = "Re: Compiled API guide query",
                    ShowImage = true
                };

                // Add some child nodes to this node instance...
                node = node.Nodes.Add(cellInfo, $"{i}", true);
                var newChildNode = node.Nodes.Add(cellInfo, $"{++i}", true);
                var anotherNewChildNode = node.Nodes.Add(cellInfo, $"{++i}", true);

                // Setup node specific image
                var printImage = new Bitmap(Properties.Resources.Print, new Size(16, 16));
                var findImage = new Bitmap(Properties.Resources.Find, new Size(16, 16));
                newChildNode.ShowNodeImage = anotherNewChildNode.ShowNodeImage = true;
                newChildNode.Image = printImage;
                anotherNewChildNode.Image = findImage;
                
                // Let us setup check box on these child nodes.

                if (!renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem.Checked) continue;

                // Let us just randomize the choice for setting up radio-button or check-boxes on the leaf nodes...
                // Of course, in real application, it will be your business logic that will decide these kinds of things, indeed.
                if (i % 2 == 0)
                {
                    newChildNode.CellInfoCheckStatus = CellInfoCheckStatus.CheckBoxCheckedNormal;
                    anotherNewChildNode.CellInfoCheckStatus = CellInfoCheckStatus.CheckBoxCheckedNormal;
                }
                else
                {
                    newChildNode.CellInfoCheckStatus = CellInfoCheckStatus.RadioButtonCheckedNormal;
                    anotherNewChildNode.CellInfoCheckStatus = CellInfoCheckStatus.RadioButtonUncheckedNormal;    
                }
            }

            // Let us create some more siblings node at the top level.

            var messageCount = i;
            CreateTreeListViewNode("Question on NodeInfoEx class / type", ref messageCount, true);
            CreateTreeListViewNode("Unit testing UI components", ref messageCount, true);
            CreateTreeListViewNode(@"Info on Setting up multi-line text. This is a long subject text. I would like to know how to setup a particular tree-list view column row to have multiple lines of text?
Please send to me a sample project for the same. Thanks.", ref messageCount, true);
            CreateTreeListViewNode("Changing background color for rows", ref messageCount, true);
            CreateTreeListViewNode("Demo MSI package", ref messageCount, true);
            CreateTreeListViewNode("LINQ queries", ref messageCount, true);
        }

        private void ReorderColumns()
        {
            // Here I am setting up some fancy columns order that I like ;)
            // You can change it anyway you want too, and also be able to do this visually at run-time too.

            _followUpColumn.DisplayIndex = 0;
            _subjectColumn.DisplayIndex = 1;
            _messageIdColumn.DisplayIndex = 2;
        }

        private void SetupChromeProperties()
        {
            ChromeTitlebarHeight = 42;
            ShouldDrawWindowEdgesWithRoundedCorners = false;
            ShouldRenderAppIconUsingStandardSize = true;
            TitlebarText = @"Binarymission TreeListView (WinForms) Demo";
        }
        
        void BinaryTreeListView1CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            var binaryTreeListView = sender as BinaryTreeListView;
            if (binaryTreeListView == null || !binaryTreeListView.Rows[e.RowIndex].Selected) return;

            var isTreeListColumn = binaryTreeListView.Columns[e.ColumnIndex] is BinaryTreeListViewColumn;
            
            if (!applyTreelistColumnFormattingToAllColumnsToolStripMenuItem.Checked)
            {
                if (!isTreeListColumn)
                {
                    e.CellStyle.Font = new Font(e.CellStyle.Font, FontStyle.Regular);
                    e.CellStyle.SelectionBackColor = Color.LightSalmon;
                    e.CellStyle.SelectionForeColor = Color.White;
                    return;
                 }
            }

            e.CellStyle.Font = new Font(e.CellStyle.Font, FontStyle.Bold | FontStyle.Italic);
            e.CellStyle.SelectionBackColor = Color.PeachPuff;
            e.CellStyle.SelectionForeColor = Color.Black;
        }
        
        private void CreateTreeListViewNode(string subjectColumnText, ref int messageIdColumnText, bool shouldFollowUpColumnValue)
        {
            var cellInfo = new BinaryTreeListViewCellInfo
            {
                Text = string.Format(subjectColumnText),
                ShowImage = true
            };

            var nodeInstance = _mainParentNode.Nodes.Add(cellInfo, $"{messageIdColumnText}", shouldFollowUpColumnValue);

            // Let us add some child nodes to this node instance...
            cellInfo = new BinaryTreeListViewCellInfo
            {
                Text = $"Re: {subjectColumnText}",
                ShowImage = true
            };

            messageIdColumnText += 1;
            var childNode = nodeInstance.Nodes.Add(cellInfo, $"{messageIdColumnText}", shouldFollowUpColumnValue);
            var anotherChildNode = nodeInstance.Nodes.Add(cellInfo, $"{messageIdColumnText}", shouldFollowUpColumnValue);
            
            // Let us setup check box on these child nodes.
            // Let us just randomize the choice for setting up radio-button or check-boxes on the leaf nodes...
            // Of course, in real application, it will be your business logic that will decide these kinds of things, indeed.

            if (renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem.Checked)
            {
                if (_randomizationCount%2 == 0)
                {
                    childNode.CellInfoCheckStatus = CellInfoCheckStatus.CheckBoxCheckedNormal;
                    anotherChildNode.CellInfoCheckStatus = CellInfoCheckStatus.CheckBoxUncheckedNormal;
                }
                else if (_randomizationCount % 2 == 1)
                {
                    var printImage = new Bitmap(Properties.Resources.Print, new Size(16, 16));
                    var findImage = new Bitmap(Properties.Resources.Find, new Size(16, 16));
                    childNode.Image = printImage;
                    anotherChildNode.Image = findImage;
                }
                else
                {
                    childNode.CellInfoCheckStatus = CellInfoCheckStatus.RadioButtonCheckedNormal;
                    anotherChildNode.CellInfoCheckStatus = CellInfoCheckStatus.RadioButtonUncheckedNormal;
                }
            }
            
            _randomizationCount++;
        }
        
        private void ExitToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            Close();
        }

        private void AllowColumnReorderingToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            allowColumnReorderingToolStripMenuItem.Checked = !allowColumnReorderingToolStripMenuItem.Checked;
            _binaryTreeListView1.AllowUserToOrderColumns = allowColumnReorderingToolStripMenuItem.Checked;
        }

        private void AllowRowHeightToBeResizeableToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            allowRowHeightToBeResizeableToolStripMenuItem.Checked =
                !allowRowHeightToBeResizeableToolStripMenuItem.Checked;
            _binaryTreeListView1.AutoSizeRowsMode = allowRowHeightToBeResizeableToolStripMenuItem.Checked
                ? DataGridViewAutoSizeRowsMode.None
                : DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
        }

        private void AllowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem.Checked =
                !allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem.Checked;
            _subjectColumn.DefaultCellStyle.WrapMode = allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem.Checked ? DataGridViewTriState.True : DataGridViewTriState.False;
        }

        private void ExpandAllNodesToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            _binaryTreeListView1.ExpandAllNodes();
        }

        private void CollapseAllNodesToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            _binaryTreeListView1.CollapseAllNodes();
        }

        private void ShowNodeImageToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            showNodeImageToolStripMenuItem.Checked = !showNodeImageToolStripMenuItem.Checked;

            SetupTreeListNodes(true);
            _binaryTreeListView1.CollapseImage = showNodeImageToolStripMenuItem.Checked
                ? Properties.Resources.Minus_1
                : null;
            _binaryTreeListView1.ExpandImage = showNodeImageToolStripMenuItem.Checked
                ? Properties.Resources.Plus_1
                : null;
        }

        private void EnableDrawingNodeConnectingLinesToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            enableDrawingNodeConnectingLinesToolStripMenuItem.Checked =
                !enableDrawingNodeConnectingLinesToolStripMenuItem.Checked;

            _binaryTreeListView1.DrawNodeConnectingLines = enableDrawingNodeConnectingLinesToolStripMenuItem.Checked;
            SetupTreeListNodes(true);
        }

        private void EnableTreelistColumnCellEditingToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            enableTreelistColumnCellEditingToolStripMenuItem.Checked =
                !enableTreelistColumnCellEditingToolStripMenuItem.Checked;
            _subjectColumn.ReadOnly = !enableTreelistColumnCellEditingToolStripMenuItem.Checked;
        }

        private void ApplyTreelistColumnFormattingToAllColumnsToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            applyTreelistColumnFormattingToAllColumnsToolStripMenuItem.Checked =
                !applyTreelistColumnFormattingToAllColumnsToolStripMenuItem.Checked;
        }

        private void DrawColumnSeparatorLineToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            drawColumnSeparatorLineToolStripMenuItem.Checked = !drawColumnSeparatorLineToolStripMenuItem.Checked;
            _binaryTreeListView1.DrawColumnSeparatorWhenUsingBuiltinRendering =
                drawColumnSeparatorLineToolStripMenuItem.Checked;
            _binaryTreeListView1.Invalidate();
        }

        private void RenderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItemToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem.Checked =
                !renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem.Checked;

            SetupTreeListControlAndItsData();
            SetupTreeListNodes(true);
            ReorderColumns();
        }

        private void DrawCellBorderWhenSelectingACellClick(object sender, System.EventArgs e)
        {
            drawCellBorderWhenSelectingACell.Checked = !drawCellBorderWhenSelectingACell.Checked;
            _binaryTreeListView1.CellBorderColor = Color.Red;
            _binaryTreeListView1.CellBorderWidth = 1;
            _binaryTreeListView1.ShouldDrawCellBorderWhenSelected = drawCellBorderWhenSelectingACell.Checked;
        }

        private void DrawColumnBackgroundDrawingUponMouseHoveringToolstripMenuClick(object sender, EventArgs e)
        {
            drawColumnBackgroundDrawingUponMouseHoveringToolstripMenu.Checked =
                !drawColumnBackgroundDrawingUponMouseHoveringToolstripMenu.Checked;

            _binaryTreeListView1.ColumnBackgroundOnMouseHoverColor = Color.FromArgb(255, 210, 230, 219);
            _binaryTreeListView1.ShouldDrawColumnBackgroundUponMouseHovering = drawColumnBackgroundDrawingUponMouseHoveringToolstripMenu.Checked;
        }

        private void drawColumnBackgroundWithRandomColorUponSelectingACell_Click(object sender, EventArgs e)
        {
            drawColumnBackgroundWithRandomColorUponSelectingACell.Checked =
                !drawColumnBackgroundWithRandomColorUponSelectingACell.Checked;

            _binaryTreeListView1.ColumnBackgroundOnCellSelectionColor = Color.FromArgb(255,246,226,186);
            _binaryTreeListView1.ShouldDrawColumnBackgroundUponCellSelection = drawColumnBackgroundWithRandomColorUponSelectingACell.Checked;
        }

        private void enableAutomaticBuiltInDragDropOfTreeNodesFeatureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _binaryTreeListView1.EnableAutomaticBuiltInDragDrop =
                enableAutomaticBuiltinDragDropOfTreeNodesFeatureToolStripMenuItem.Checked;
        }

        private void expandTheSelectedNodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _binaryTreeListView1.CurrentNode.Expand(true);
        }

        private void collapseTheSelectedNodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _binaryTreeListView1.CurrentNode.Collapse(true);
        }

        private void expandTheSelectedNodeOnlyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _binaryTreeListView1.ExpandNode(_binaryTreeListView1.CurrentNode, false);
        }

        private void collapseTheSelectedNodeOnlyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _binaryTreeListView1.CollapseNode(_binaryTreeListView1.CurrentNode, false);
        }
    }
}
