using System;
using System.Drawing;
using System.Windows.Forms;
using System.Globalization;
using Binarymission.WinFormsControls.Demo.Properties;
using Binarymission.WinForms.Controls.DateTimeControls;

namespace Binarymission.WinFormsControls.Demo
{
    public partial class BinaryDatePickerDemoApplication : Form
    {
        private void Form1_Load(object sender, EventArgs e)
        {
            Icon = Resources.app;
            SetupUi();
            RefreshDateControlDisplay();
        }

        private void SetupUi()
        {
            _binaryDatePicker1.Focus();

            SetupCulturesList();

            SetupControlProperties();
        }

        private void SetupControlProperties()
        {
            _todayButtonText.Text = _binaryDatePicker1.TodayButtonText;
            _closeButtonText.Text = _binaryDatePicker1.CloseButtonText;
            _binaryDatePicker1.BinaryCultureInfo = CultureInfo.CreateSpecificCulture(_cmbBxCultureInfo.SelectedItem.ToString());
            _binaryDatePicker1.NullDateString = "-- No date selected --";
            _binaryDatePicker1.ValueIsNull = true;
            _binaryDatePicker1.EnableCustomDateXMLFeed = false;
            _chkEnableControlTextBox.Checked = true;
            _chkEnableLegendDisplay.Checked = true;
            _txtCustomFormat.Text = @"MMMM dd yyyy',' hh:mm:ss tt";
            _fontDialog1.Font = _binaryDatePicker1.Font;
            _appStatusbar.Text =
                @"BinaryDatePicker.NET Control library Demo application! Copyright � Binarymission Technologies Ltd., UK.";
            _dateChangeDisplayLabel.Text = _binaryDatePicker1.ValueIsNull != true
                ? $"Current selected date : " + ((DateTime) (_binaryDatePicker1.Value)).ToString(_txtCustomFormat.Text)
                : @"Current selected date : Null Value";

            _cmbBoxDateFormat.Items.Add("Long");
            _cmbBoxDateFormat.Items.Add("Short");
            _cmbBoxDateFormat.Items.Add("Custom");
            _cmbBoxDateFormat.SelectedIndex = 0;
            _txtCustomFormat.Enabled = false;
            _toolTip1.SetToolTip(_chkEnableXml,
                "Remember, the XML date data will be parsed based on the Current culture of the current thread!");
            _toolTip1.SetToolTip(_txtXmlFileSelect,
                "Remember, the XML date data will be parsed based on the Current culture of the current thread!");

            string[] borderStyleItems = {"Normal", "Dotted"};
            _cmbBxControlTextBoxBorderStyle.Items.AddRange(borderStyleItems);
            _cmbBxControlTextBoxBorderStyle.SelectedIndex = 0;
            _spinnerControlBorderDepth.Value = Convert.ToInt32(_binaryDatePicker1.DotBorderDepth);
            _spinnerControlBorderGap.Value = Convert.ToInt32(_binaryDatePicker1.DotBorderGap);
            _cmbBxControlTextBoxBorderStyle.Enabled = true;
            _cmbBxTodayFlatStyle.SelectedIndex = 0;
            _cmbBxCloseFlatStyle.SelectedIndex = 0;
        }

        private void SetupCulturesList()
        {
            var culary = CultureInfo.GetCultures(CultureTypes.InstalledWin32Cultures);
            var items = new string[culary.Length + 1];
            items[0] = CultureInfo.CurrentCulture.Name;

            var counter = 1;
            foreach (var cultureStr in culary)
            {
                items[counter++] = cultureStr.ToString();
            }

            _cmbBxCultureInfo.Items.AddRange(items);
            _cmbBxCultureInfo.SelectedIndex = 0;
        }

        public void RefreshDateControlDisplay()
        {
            string time;

            if (_binaryDatePicker1.ValueIsNull)
                time = "No date is selected. Value is NULL";
            else
            {
                var minValue = (DateTime)(_binaryDatePicker1.Value);
                time = minValue.ToString(_binaryDatePicker1.CustomFormat, _binaryDatePicker1.BinaryCultureInfo);
            }

            var ss = "The currently selected date is : " + time;
            var sb = new System.Text.StringBuilder();
            sb.Append(ss);
            sb.Append(Environment.NewLine);
            sb.Append(Environment.NewLine);
            sb.Append(Environment.NewLine);
            _dateChangeDisplayLabel.Text = sb.ToString();
        }

        public void CustomDateChanged(object sender, EventArgs e)
        {
            string time;

            if (_binaryDatePicker1.ValueIsNull == true)
            {
                time = "No date is selected. Value is NULL";
            }
            else
            {
                var minValue = (DateTime)(_binaryDatePicker1.Value);
                time = minValue.ToString(_binaryDatePicker1.CustomFormat, _binaryDatePicker1.BinaryCultureInfo);
            }

            var ss = "The currently selected date is : " + time;
            var sb = new System.Text.StringBuilder();
            sb.Append(ss);
            sb.Append(Environment.NewLine);
            sb.Append(Environment.NewLine);
            sb.Append("Note: This message is displayed only to illustrate an example of how you can handle the \"BinaryDateChanged\" event of the BinaryDatePicker� .NET control.");
            sb.Append(Environment.NewLine);
            _dateChangeDisplayLabel.Text = $@"BinaryDateChanged event handled : " + sb;
        }

        private void EnableControlTextBoxCheckedChanged(object sender, EventArgs e)
        {
            if (_chkEnableControlTextBox.CheckState == CheckState.Checked)
            {
                _binaryDatePicker1.DisplayTextState = true;
                _btnChageFont.Enabled = true;
                _btnControlTextBoxForecolorChange.Enabled = true;
                _btnControlTextBoxBackcolorChange.Enabled = true;
                _btnControlTextBoxBorderColorChange.Enabled = true;
                _cmbBxControlTextBoxBorderStyle.Enabled = true;
                _chkShowBorderAlways.Enabled = true;
                _chkShowCustomMenu.Enabled = true;
                _chkEnableExtendedStyle.Enabled = true;
                _spinnerControlBorderDepth.Enabled = true;
                _spinnerControlBorderGap.Enabled = true;
            }
            else
            {
                _binaryDatePicker1.DisplayTextState = false;
                _btnChageFont.Enabled = false;
                _btnControlTextBoxForecolorChange.Enabled = false;
                _btnControlTextBoxBackcolorChange.Enabled = false;
                _btnControlTextBoxBorderColorChange.Enabled = false;
                _cmbBxControlTextBoxBorderStyle.Enabled = false;
                _chkShowBorderAlways.Enabled = false;
                _chkShowCustomMenu.Enabled = false;
                _chkEnableExtendedStyle.Enabled = false;
                _spinnerControlBorderDepth.Enabled = false;
                _spinnerControlBorderGap.Enabled = false;
            }
        }

        private void EnableLegendDisplayCheckedChanged(object sender, EventArgs e)
        {
            _binaryDatePicker1.CalendarLegendDisplay = _chkEnableLegendDisplay.CheckState == CheckState.Checked;
        }

        private void CustomFormatTextChanged(object sender, EventArgs e)
        {
            if (_txtCustomFormat.Text != string.Empty)
            {
                try
                {
                    _binaryDatePicker1.CustomFormat = _txtCustomFormat.Text;
                }
                catch
                {
                    _txtCustomFormat.Text = _binaryDatePicker1.CustomFormat;
                }
            }
            else
                _txtCustomFormat.Text = _binaryDatePicker1.CustomFormat;

            RefreshHelpString();
        }

        private void ChageFontClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel == _fontDialog1.ShowDialog(this)) return;
            _binaryDatePicker1.Font = _fontDialog1.Font;
        }

        private void CalendarForecolorChangeClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                _binaryDatePicker1.CalendarForeColor = _colorDialog1.Color;
        }

        private void CalendarBackcolorChangeClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                _binaryDatePicker1.CalendarMonthBackColor = _colorDialog1.Color;
        }

        private void CalendarTitleForecolorChangeClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                    _binaryDatePicker1.CalendarMonthTitleForeColor = _colorDialog1.Color;
        }

        private void NavigationControlColorClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                    _binaryDatePicker1.CalendarMonthAndYearTrackerColor = _colorDialog1.Color;
        }

        private void SelectedDateForecolorClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                    _binaryDatePicker1.SelectionDateForeColor = _colorDialog1.Color;
        }

        private void SelectedDateCircleColorClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                    _binaryDatePicker1.SelectionDateEllipseColor = _colorDialog1.Color;
        }

        private void TodayDateForeColorClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                    _binaryDatePicker1.TodayForeColor = _colorDialog1.Color;
        }

        private void TodayDateCircleColorClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                    _binaryDatePicker1.TodayEllipseColor = _colorDialog1.Color;
        }

        private void AppStatusbarPanelClicked(object sender, StatusBarPanelClickEventArgs e)
        {
            var message = "Binarymission Outlook Style DatePicker control for WinForms.";
            MessageBox.Show(this, message, @"About DatePicker control");
        }

        private void ControlTextBoxForecolorChangeClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel == _colorDialog1.ShowDialog(this)) return;
            _binaryDatePicker1.ForeColor = _colorDialog1.Color;

            if (_binaryDatePicker1.UseDropDownImageStyle == DropDownImageStyle.GlassRendering)
            {
                _binaryDatePicker1.CalenderDropDownGlassRenderingStartColor = Color.White;
                _binaryDatePicker1.CalenderDropDownGlassRenderingEndColor = _colorDialog1.Color;
                _binaryDatePicker1.CalenderDropDownArrowGlassRenderingColor = SystemColors.WindowText;
            }
        }

        private void ControlTextBoxBackcolorChangeClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                _binaryDatePicker1.BackColor = _colorDialog1.Color;
        }

        private void AppExitClicked(object sender, EventArgs e)
        {
            Close();
        }

        private void AboutClicked(object sender, EventArgs e)
        {
            var message = "Binarymission Outlook Style DatePicker control for WinForms.";
            MessageBox.Show(this, message, @"About DatePicker control");
        }

        private void CustomFormatTextBoxMouseEnter(object sender, EventArgs e)
        {
            _toolTip1.SetToolTip(_txtCustomFormat,
                "Set a valid Custom format string (refer to \"DateTimeFormatInfo\" type in .NET SDK), that will be used to display the date string in the control's text box!");
        }

        private void EnableControlTextBoxMouseEnter(object sender, EventArgs e)
        {
            _toolTip1.SetToolTip(_chkEnableControlTextBox, "Tick off this checkbox if you want to disable the control's text box!");
        }

        private void EnableLegendDisplayMouseEnter(object sender, EventArgs e)
        {
            _toolTip1.SetToolTip(_chkEnableLegendDisplay, "Tick off this checkbox to disable the legend display facility in the control's calendar!");
        }

        private void DateFormatComboBoxSelectedIndexChanged(object sender, EventArgs e)
        {
            _txtCustomFormat.Enabled = false;
            if (_cmbBoxDateFormat.Text == @"Long")
                _binaryDatePicker1.Format = BinaryDatePickerFormat.Long;
            else if (_cmbBoxDateFormat.Text == @"Short")
                _binaryDatePicker1.Format = BinaryDatePickerFormat.Short;
            else if (_cmbBoxDateFormat.Text == @"Custom")
            {
                _txtCustomFormat.Enabled = true;
                if (_txtCustomFormat.Text == "")
                {
                    _txtCustomFormat.Text = @"MMMMM dd yyyy 'at' hh tt";
                }
                _binaryDatePicker1.Format = BinaryDatePickerFormat.Custom;
                _binaryDatePicker1.CustomFormat = _txtCustomFormat.Text;
            }

            // Just to refresh the text box in the BinaryDatePicker control, we are executing our custom routine.
            RefreshHelpString();
        }

        private void EnableSelectionCircleCheckedChanged(object sender, EventArgs e)
        {
            if (_chkEnableSelectionCircle.CheckState == CheckState.Checked)
            {
                _chkEnableLegendDisplay.Enabled = true;
                _binaryDatePicker1.MarkSelectedDate = true;
            }
            else
            {
                _chkEnableLegendDisplay.Enabled = false;
                _binaryDatePicker1.MarkSelectedDate = false;
            }
        }

        private void SetMinDateValueChanged(object sender, EventArgs e)
        {
            _binaryDatePicker1.MinValue = new DateTime(_dateTimePickerSetMinDate.Value.Year, _dateTimePickerSetMinDate.Value.Month, _dateTimePickerSetMinDate.Value.Day, _binaryDatePicker1.BinaryCultureInfo.Calendar);
            RefreshHelpString();
        }

        private void SetMaxDateValueChanged(object sender, EventArgs e)
        {
            _binaryDatePicker1.MaxValue = new DateTime(_dateTimePickerSetMaxDate.Value.Year, _dateTimePickerSetMaxDate.Value.Month, _dateTimePickerSetMaxDate.Value.Day, _binaryDatePicker1.BinaryCultureInfo.Calendar);
            RefreshHelpString();
        }

        private void XmlFileSelectClicked(object sender, EventArgs e)
        {
            try
            {
                var prevFile = _txtXmlFileSelect.Text;
                _of1.Filter = @"XML files | *.xml";
                _of1.FileName = "*.xml";
                _of1.InitialDirectory = @"..\..";
                _of1.Multiselect = false;
                if (DialogResult.Cancel != _of1.ShowDialog(this))
                {
                    _of1.OpenFile();
                    var name = _of1.FileName;
                    if (name.ToUpper().EndsWith(".XML") == true)
                        _txtXmlFileSelect.Text = _of1.FileName;
                    else
                        _txtXmlFileSelect.Text = prevFile;
                }
                else
                {
                    _txtXmlFileSelect.Text = prevFile;
                }
            }
            catch { _txtXmlFileSelect.Text = @"CustomDates.xml"; }
            finally
            {
                _binaryDatePicker1.CustomDateXMLFeed = _txtXmlFileSelect.Text;
            }
        }

        private void EnableXmlCheckedChanged(object sender, EventArgs e)
        {
            if (_chkEnableXml.CheckState == CheckState.Checked)
            {
                _txtXmlFileSelect.Enabled = true;
                _btnXmlFileSelect.Enabled = true;
                _binaryDatePicker1.EnableCustomDateXMLFeed = true;
                _binaryDatePicker1.CustomDateXMLFeed = _txtXmlFileSelect.Text;
            }
            else
            {
                _txtXmlFileSelect.Enabled = false;
                _btnXmlFileSelect.Enabled = false;
                _binaryDatePicker1.EnableCustomDateXMLFeed = false;
                _binaryDatePicker1.CustomDateXMLFeed = "";
            }
        }

        private void XmlFileSelectTextChanged(object sender, EventArgs e)
        {
            _binaryDatePicker1.EnableCustomDateXMLFeed = true;
            _binaryDatePicker1.CustomDateXMLFeed = _txtXmlFileSelect.Text;
        }

        private void EnableExtendedStyleCheckedChanged(object sender, EventArgs e)
        {
            if (_chkEnableExtendedStyle.CheckState == CheckState.Checked)
            {
                _binaryDatePicker1.EditControlStyleIsExtended = true;
                _cmbBxControlTextBoxBorderStyle.Enabled = true;
                _chkShowBorderAlways.Enabled = true;
            }
            else
            {
                _binaryDatePicker1.EditControlStyleIsExtended = false;
                _cmbBxControlTextBoxBorderStyle.Enabled = false;
                _chkShowBorderAlways.Enabled = false;
            }
        }

        private void ShowCustomMenuCheckedChanged(object sender, EventArgs e)
        {
            _binaryDatePicker1.ShowCustomMenu = _chkShowCustomMenu.CheckState == CheckState.Checked;
        }

        private void ControlTextBoxBorderColorChangeClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                _binaryDatePicker1.BorderColor = _colorDialog1.Color;
        }

        private void ControlTextBoxBorderStyleComboBoxSelectedIndexChanged(object sender, EventArgs e)
        {
            if (_cmbBxControlTextBoxBorderStyle.SelectedIndex == 0)
            {
                _g7.Enabled = false;
                _spinnerControlBorderDepth.Enabled = false;
                _spinnerControlBorderGap.Enabled = false;
                _binaryDatePicker1.DrawBorderAs = BorderState.Normal;
            }
            else
            {
                _g7.Enabled = true;
                _spinnerControlBorderDepth.Enabled = true;
                _spinnerControlBorderGap.Enabled = true;
                _binaryDatePicker1.DrawBorderAs = BorderState.Dotted;
            }
        }

        private void ShowBorderAlwaysCheckBoxCheckedChanged(object sender, EventArgs e)
        {
            _binaryDatePicker1.ShowBorderAlways = _chkShowBorderAlways.CheckState == CheckState.Checked;
        }

        private void ControlBorderDepthNumerictextboxValueChanged(object sender, EventArgs e)
        {
            _binaryDatePicker1.DotBorderDepth = Convert.ToInt32(_spinnerControlBorderDepth.Value);
        }

        private void ControlBorderGapNumerictextboxValueChanged(object sender, EventArgs e)
        {
            _binaryDatePicker1.DotBorderGap = Convert.ToInt32(_spinnerControlBorderGap.Value);
        }

        private void CultureInfoComboboxSelectedIndexChanged(object sender, EventArgs e)
        {
            var info = CultureInfo.CreateSpecificCulture(_cmbBxCultureInfo.SelectedItem.ToString());
            _binaryDatePicker1.BinaryCultureInfo = info;
            RefreshHelpString();
        }

        private void TodayButtonTextTextChanged(object sender, EventArgs e)
        {
            _binaryDatePicker1.TodayButtonText = _todayButtonText.Text;
        }

        private void CloseButtonTextTextChanged(object sender, EventArgs e)
        {
            _binaryDatePicker1.CloseButtonText = _closeButtonText.Text;
        }

        private void BinaryCalendarActivated(object sender, EventArgs e)
        {
            _dateChangeDisplayLabel.Text = "";
        }

        private void binaryDatePicker1_BinaryCalendarDeactivated(object sender, EventArgs e)
        {
            if (_binaryDatePicker1.ValueIsNull == false)
            {
                var minValue = (DateTime)(_binaryDatePicker1.Value);
                var messageBit = "The currently selected date is : " + minValue.ToString(_binaryDatePicker1.CustomFormat, _binaryDatePicker1.BinaryCultureInfo);
                var sb = new System.Text.StringBuilder();
                sb.Append(messageBit);
                sb.Append(Environment.NewLine);
                sb.Append(Environment.NewLine);
                sb.Append("Note: This message is displayed only to illustrate an example of how you can handle the \"BinaryDateChanged\" event of the BinaryDatePicker� .NET control.");
                sb.Append(Environment.NewLine);
                _dateChangeDisplayLabel.Text = @"BinaryDateChanged event handled : " + sb;
            }
            else
            {
                var messageBit = "The currently selected date is : " + "No date is selected. Value is NULL";
                var sb = new System.Text.StringBuilder();
                sb.Append(messageBit);
                sb.Append(Environment.NewLine);
                sb.Append(Environment.NewLine);
                sb.Append("Note: This message is displayed only to illustrate an example of how you can handle the \"BinaryDateChanged\" event of the BinaryDatePicker� .NET control.");
                sb.Append(Environment.NewLine);
                _dateChangeDisplayLabel.Text = @"BinaryDateChanged event handled : " + sb;
            }
        }

        private void RefreshHelpString()
        {
            if (_binaryDatePicker1.ValueIsNull == true)
            {
                string messageBit;

                DateTime minValue;
                var result = DateTime.TryParseExact(_binaryDatePicker1.Value.ToString(), _binaryDatePicker1.CustomFormat, _binaryDatePicker1.BinaryCultureInfo, DateTimeStyles.None, out minValue);
                if (result == false)
                    messageBit = $"The currently selected date is : " + _binaryDatePicker1.Value;
                else
                    messageBit = $"The currently selected date is : " + ((DateTime)_binaryDatePicker1.Value).ToString(_binaryDatePicker1.CustomFormat, _binaryDatePicker1.BinaryCultureInfo);

                var sb = new System.Text.StringBuilder();
                sb.Append(messageBit);
                sb.Append(Environment.NewLine);
                sb.Append(Environment.NewLine);
                sb.Append(Environment.NewLine);
                _dateChangeDisplayLabel.Text = sb.ToString();
            }
            else
            {
                var messageBit = "The currently selected date is : " + "No date is selected. Value is NULL";
                var sb = new System.Text.StringBuilder();
                sb.Append(messageBit);
                sb.Append(Environment.NewLine);
                sb.Append(Environment.NewLine);
                sb.Append(Environment.NewLine);
                _dateChangeDisplayLabel.Text = sb.ToString();
            }
        }

        private void TodayFlatStyleSelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedOption = _cmbBxTodayFlatStyle.SelectedItem.ToString();
            switch (selectedOption)
            {
                case "Standard":
                    _binaryDatePicker1.TodayButtonFlatStyle = FlatStyle.Standard;
                    break;
                case "Flat":
                    _binaryDatePicker1.TodayButtonFlatStyle = FlatStyle.Flat;
                    break;
                case "Popup":
                    _binaryDatePicker1.TodayButtonFlatStyle = FlatStyle.Popup;
                    break;
                case "System":
                    _binaryDatePicker1.TodayButtonFlatStyle = FlatStyle.System;
                    break;
                default:
                    _binaryDatePicker1.TodayButtonFlatStyle = FlatStyle.Standard;
                    break;
            }
        }

        private void CloseFlatStyleSelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedOption = _cmbBxCloseFlatStyle.SelectedItem.ToString();
            switch (selectedOption)
            {
                case "Standard":
                    _binaryDatePicker1.CloseButtonFlatStyle = FlatStyle.Standard;
                    break;
                case "Flat":
                    _binaryDatePicker1.CloseButtonFlatStyle = FlatStyle.Flat;
                    break;
                case "Popup":
                    _binaryDatePicker1.CloseButtonFlatStyle = FlatStyle.Popup;
                    break;
                case "System":
                    _binaryDatePicker1.CloseButtonFlatStyle = FlatStyle.System;
                    break;
                default:
                    _binaryDatePicker1.CloseButtonFlatStyle = FlatStyle.Standard;
                    break;
            }
        }

        private void TodayButtonBackcolorClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                _binaryDatePicker1.TodayButtonBackColor = _colorDialog1.Color;
        }

        private void TodayButtonForecolorClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                _binaryDatePicker1.TodayButtonForeColor = _colorDialog1.Color;
        }

        private void CloseButtonBackcolorClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                _binaryDatePicker1.CloseButtonBackColor = _colorDialog1.Color;
        }

        private void CloseButtonForecolorClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                _binaryDatePicker1.CloseButtonForeColor = _colorDialog1.Color;
        }

        private void chkDisplayTodayCloseButtons_CheckedChanged(object sender, EventArgs e)
        {
            if (_chkDisplayTodayCloseButtons.CheckState == CheckState.Unchecked)
            {
                _binaryDatePicker1.TodayCloseButtonsAreVisible = false;
                _cmbBxTodayFlatStyle.Enabled = false;
                _cmbBxCloseFlatStyle.Enabled = false;
                _btnTodayButtonBackcolor.Enabled = false;
                _btnTodayButtonForecolor.Enabled = false;
                _btnCloseButtonBackcolor.Enabled = false;
                _btnCloseButtonForecolor.Enabled = false;
            }
            else
            {
                _binaryDatePicker1.TodayCloseButtonsAreVisible = true;
                _cmbBxTodayFlatStyle.Enabled = true;
                _cmbBxCloseFlatStyle.Enabled = true;
                _btnTodayButtonBackcolor.Enabled = true;
                _btnTodayButtonForecolor.Enabled = true;
                _btnCloseButtonBackcolor.Enabled = true;
                _btnCloseButtonForecolor.Enabled = true;
            }
        }

        private void CustomImageFileLocatorClicked(object sender, EventArgs e)
        {
            _of1.Filter = @"Bitmap files | *.bmp";
            _of1.FileName = "*.bmp";
            _of1.InitialDirectory = ".";
            _of1.Multiselect = false;

            if (DialogResult.Cancel == _of1.ShowDialog(this)) return;

            _of1.OpenFile();
            var name = _of1.FileName;

            if (name.ToUpper().EndsWith(".BMP") != true) return;

            var bmp = (Bitmap)(Image.FromFile(_of1.FileName));
            _txtCustomImageFile.Text = _of1.FileName;
            _binaryDatePicker1.CustomDropDownImage = bmp;
        }

        private void CustomImageStyleSelectedIndexChanged(object sender, EventArgs e)
        {
            switch (_cbxCustomImageStyle.SelectedIndex)
            {
                case 0:
                    _txtCustomImageFile.Enabled = false;
                    _btnCustomImageFileLocator.Enabled = false;
                    _binaryDatePicker1.UseDropDownImageStyle = DropDownImageStyle.GlassRendering;
                    break;
                case 1:
                    _txtCustomImageFile.Enabled = false;
                    _btnCustomImageFileLocator.Enabled = false;
                    _binaryDatePicker1.UseDropDownImageStyle = DropDownImageStyle.DropDownArrow;
                    break;
                case 2:
                    _txtCustomImageFile.Enabled = false;
                    _btnCustomImageFileLocator.Enabled = false;
                    _binaryDatePicker1.UseDropDownImageStyle = DropDownImageStyle.BuiltInCalendarImage;
                    break;
                case 3:
                    _txtCustomImageFile.Enabled = true;
                    _btnCustomImageFileLocator.Enabled = true;
                    _binaryDatePicker1.UseDropDownImageStyle = DropDownImageStyle.CustomImage;
                    break;
                default:
                    _txtCustomImageFile.Enabled = false;
                    _btnCustomImageFileLocator.Enabled = false;
                    _binaryDatePicker1.UseDropDownImageStyle = DropDownImageStyle.BuiltInCalendarImage;
                    break;
            }
        }

        private void GlassRenderingStartColorClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                _binaryDatePicker1.CalenderDropDownGlassRenderingStartColor = _colorDialog1.Color;
        }

        private void GlassRenderingEndColorClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                _binaryDatePicker1.CalenderDropDownGlassRenderingEndColor = _colorDialog1.Color;
        }

        private void GlassRenderingArrowColorClicked(object sender, EventArgs e)
        {
            if (DialogResult.Cancel != _colorDialog1.ShowDialog(this))
                _binaryDatePicker1.CalenderDropDownArrowGlassRenderingColor = _colorDialog1.Color;
        }
    }
}