﻿using Binarymission.WinForms.Controls.DateTimeControls;
using System;
using System.Windows.Forms;

namespace Binarymission.WinFormsControls.Demo
{
    public partial class BinaryDatePickerDemoApplication
    {
        #region Fields

        private GroupBox _groupBox2;
        private ColorDialog _colorDialog1;
        private FontDialog _fontDialog1;
        private Button _button11;
        private ToolTip _toolTip1;
        private GroupBox _groupBox1;
        private Label _label2;
        private DateTimePicker _dateTimePickerSetMinDate;
        private Label _label3;
        private Label _label4;
        private DateTimePicker _dateTimePickerSetMaxDate;
        private System.ComponentModel.IContainer components;
        private GroupBox _groupBox5;
        private GroupBox _groupBox3;
        private OpenFileDialog _of1;
        private GroupBox _groupBox4;
        private GroupBox _groupBox6;
        private Label _label5;
        private Label _label6;
        private GroupBox _g7;
        private Label _label7;
        private Label _label8;
        private GroupBox _groupBox7;
        private Label _label9;
        private Label _label10;
        private Label _label11;
        private Label _label12;
        private Button _btnChageFont;
        private Button _btnControlTextBoxForecolorChange;
        private Button _btnControlTextBoxBackcolorChange;
        private Button _btnControlTextBoxBorderColorChange;
        private ComboBox _cmbBxControlTextBoxBorderStyle;
        private NumericUpDown _spinnerControlBorderDepth;
        private NumericUpDown _spinnerControlBorderGap;
        private CheckBox _chkShowBorderAlways;
        private CheckBox _chkEnableExtendedStyle;
        private CheckBox _chkEnableControlTextBox;
        private CheckBox _chkShowCustomMenu;
        private Button _btnCalendarForecolorChange;
        private Button _btnCalendarBackcolorChange;
        private Button _btnCalendarTitleForecolorChange;
        private Button _btnNavigationControlColor;
        private Button _btnSelectedDateForecolor;
        private Button _btnSelectedDateCircleColor;
        private Button _btnTodayDateForeColor;
        private Button _btnTodayDateCircleColor;
        private CheckBox _chkEnableSelectionCircle;
        private CheckBox _chkEnableLegendDisplay;
        private CheckBox _chkEnableXml;
        private TextBox _txtXmlFileSelect;
        private Button _btnXmlFileSelect;
        private ComboBox _cmbBoxDateFormat;
        private TextBox _txtCustomFormat;
        private ComboBox _cmbBxCultureInfo;
        private TextBox _todayButtonText;
        private TextBox _closeButtonText;
        private StatusBar _appStatusbar;
        private Button _about;
        private Label _dateChangeDisplayLabel;
        private BinaryDatePicker _binaryDatePicker1;
        private Button _btnTodayButtonBackcolor;
        private Button _btnTodayButtonForecolor;
        private Button _btnCloseButtonBackcolor;
        private Button _btnCloseButtonForecolor;
        private ComboBox _cmbBxTodayFlatStyle;
        private Label _label1;
        private ComboBox _cmbBxCloseFlatStyle;
        private Label _label13;
        private CheckBox _chkDisplayTodayCloseButtons;
        private Label _label14;
        private TextBox _txtCustomImageFile;
        private Button _btnCustomImageFileLocator;
        private Label _label15;
        private ComboBox _cbxCustomImageStyle;
        private Button _btnGlassRenderingStartColor;
        private Button _btnGlassRenderingEndColor;
        private Button _btnGlassRenderingArrowColor;
        private ToolTip _tip = new ToolTip();

        #endregion

        public BinaryDatePickerDemoApplication()
        {
           Application.EnableVisualStyles();
           Application.DoEvents();
           InitializeComponent();
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            var resources = new System.ComponentModel.ComponentResourceManager(typeof(BinaryDatePickerDemoApplication));
            this._groupBox2 = new System.Windows.Forms.GroupBox();
            this._groupBox3 = new System.Windows.Forms.GroupBox();
            this._txtXmlFileSelect = new System.Windows.Forms.TextBox();
            this._btnXmlFileSelect = new System.Windows.Forms.Button();
            this._chkEnableXml = new System.Windows.Forms.CheckBox();
            this._groupBox5 = new System.Windows.Forms.GroupBox();
            this._txtCustomFormat = new System.Windows.Forms.TextBox();
            this._label4 = new System.Windows.Forms.Label();
            this._dateTimePickerSetMaxDate = new System.Windows.Forms.DateTimePicker();
            this._label3 = new System.Windows.Forms.Label();
            this._dateTimePickerSetMinDate = new System.Windows.Forms.DateTimePicker();
            this._cmbBoxDateFormat = new System.Windows.Forms.ComboBox();
            this._label2 = new System.Windows.Forms.Label();
            this._chkEnableSelectionCircle = new System.Windows.Forms.CheckBox();
            this._chkEnableLegendDisplay = new System.Windows.Forms.CheckBox();
            this._btnTodayDateCircleColor = new System.Windows.Forms.Button();
            this._btnTodayDateForeColor = new System.Windows.Forms.Button();
            this._btnSelectedDateCircleColor = new System.Windows.Forms.Button();
            this._btnSelectedDateForecolor = new System.Windows.Forms.Button();
            this._btnNavigationControlColor = new System.Windows.Forms.Button();
            this._btnCalendarTitleForecolorChange = new System.Windows.Forms.Button();
            this._btnCalendarBackcolorChange = new System.Windows.Forms.Button();
            this._btnCalendarForecolorChange = new System.Windows.Forms.Button();
            this._colorDialog1 = new System.Windows.Forms.ColorDialog();
            this._fontDialog1 = new System.Windows.Forms.FontDialog();
            this._about = new System.Windows.Forms.Button();
            this._button11 = new System.Windows.Forms.Button();
            this._appStatusbar = new System.Windows.Forms.StatusBar();
            this._toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this._groupBox1 = new System.Windows.Forms.GroupBox();
            this._cbxCustomImageStyle = new System.Windows.Forms.ComboBox();
            this._label15 = new System.Windows.Forms.Label();
            this._btnCustomImageFileLocator = new System.Windows.Forms.Button();
            this._txtCustomImageFile = new System.Windows.Forms.TextBox();
            this._label14 = new System.Windows.Forms.Label();
            this._binaryDatePicker1 = new BinaryDatePicker();
            this._dateChangeDisplayLabel = new System.Windows.Forms.Label();
            this._label5 = new System.Windows.Forms.Label();
            this._of1 = new System.Windows.Forms.OpenFileDialog();
            this._groupBox4 = new System.Windows.Forms.GroupBox();
            this._chkShowBorderAlways = new System.Windows.Forms.CheckBox();
            this._g7 = new System.Windows.Forms.GroupBox();
            this._label8 = new System.Windows.Forms.Label();
            this._label7 = new System.Windows.Forms.Label();
            this._spinnerControlBorderDepth = new System.Windows.Forms.NumericUpDown();
            this._spinnerControlBorderGap = new System.Windows.Forms.NumericUpDown();
            this._cmbBxControlTextBoxBorderStyle = new System.Windows.Forms.ComboBox();
            this._label6 = new System.Windows.Forms.Label();
            this._btnControlTextBoxBorderColorChange = new System.Windows.Forms.Button();
            this._chkShowCustomMenu = new System.Windows.Forms.CheckBox();
            this._chkEnableExtendedStyle = new System.Windows.Forms.CheckBox();
            this._btnChageFont = new System.Windows.Forms.Button();
            this._btnControlTextBoxForecolorChange = new System.Windows.Forms.Button();
            this._btnControlTextBoxBackcolorChange = new System.Windows.Forms.Button();
            this._chkEnableControlTextBox = new System.Windows.Forms.CheckBox();
            this._groupBox6 = new System.Windows.Forms.GroupBox();
            this._btnGlassRenderingStartColor = new System.Windows.Forms.Button();
            this._btnGlassRenderingEndColor = new System.Windows.Forms.Button();
            this._chkDisplayTodayCloseButtons = new System.Windows.Forms.CheckBox();
            this._btnCloseButtonForecolor = new System.Windows.Forms.Button();
            this._btnCloseButtonBackcolor = new System.Windows.Forms.Button();
            this._btnTodayButtonForecolor = new System.Windows.Forms.Button();
            this._btnTodayButtonBackcolor = new System.Windows.Forms.Button();
            this._groupBox7 = new System.Windows.Forms.GroupBox();
            this._cmbBxTodayFlatStyle = new System.Windows.Forms.ComboBox();
            this._label1 = new System.Windows.Forms.Label();
            this._closeButtonText = new System.Windows.Forms.TextBox();
            this._todayButtonText = new System.Windows.Forms.TextBox();
            this._label12 = new System.Windows.Forms.Label();
            this._label11 = new System.Windows.Forms.Label();
            this._label10 = new System.Windows.Forms.Label();
            this._cmbBxCultureInfo = new System.Windows.Forms.ComboBox();
            this._label9 = new System.Windows.Forms.Label();
            this._cmbBxCloseFlatStyle = new System.Windows.Forms.ComboBox();
            this._label13 = new System.Windows.Forms.Label();
            this._btnGlassRenderingArrowColor = new System.Windows.Forms.Button();
            this._groupBox2.SuspendLayout();
            this._groupBox3.SuspendLayout();
            this._groupBox5.SuspendLayout();
            this._groupBox1.SuspendLayout();
            this._groupBox4.SuspendLayout();
            this._g7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._spinnerControlBorderDepth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._spinnerControlBorderGap)).BeginInit();
            this._groupBox6.SuspendLayout();
            this._groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this._groupBox2.Controls.Add(this._groupBox3);
            this._groupBox2.Controls.Add(this._groupBox5);
            this._groupBox2.Controls.Add(this._label4);
            this._groupBox2.Controls.Add(this._dateTimePickerSetMaxDate);
            this._groupBox2.Controls.Add(this._label3);
            this._groupBox2.Controls.Add(this._dateTimePickerSetMinDate);
            this._groupBox2.Controls.Add(this._cmbBoxDateFormat);
            this._groupBox2.Controls.Add(this._label2);
            this._groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox2.ForeColor = System.Drawing.Color.Blue;
            this._groupBox2.Location = new System.Drawing.Point(248, 427);
            this._groupBox2.Name = "_groupBox2";
            this._groupBox2.Size = new System.Drawing.Size(520, 120);
            this._groupBox2.TabIndex = 21;
            this._groupBox2.TabStop = false;
            this._groupBox2.Text = "Control\'s Date settings";
            // 
            // groupBox3
            // 
            this._groupBox3.Controls.Add(this._txtXmlFileSelect);
            this._groupBox3.Controls.Add(this._btnXmlFileSelect);
            this._groupBox3.Controls.Add(this._chkEnableXml);
            this._groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox3.ForeColor = System.Drawing.SystemColors.WindowText;
            this._groupBox3.Location = new System.Drawing.Point(8, 16);
            this._groupBox3.Name = "_groupBox3";
            this._groupBox3.Size = new System.Drawing.Size(160, 96);
            this._groupBox3.TabIndex = 22;
            this._groupBox3.TabStop = false;
            this._groupBox3.Text = "Custom date data";
            // 
            // txtXMLFile_Select
            // 
            this._txtXmlFileSelect.Enabled = false;
            this._txtXmlFileSelect.Location = new System.Drawing.Point(8, 64);
            this._txtXmlFileSelect.Name = "_txtXmlFileSelect";
            this._txtXmlFileSelect.Size = new System.Drawing.Size(120, 20);
            this._txtXmlFileSelect.TabIndex = 24;
            this._txtXmlFileSelect.Text = "..\\..\\CustomDates.xml";
            this._txtXmlFileSelect.TextChanged += new System.EventHandler(this.XmlFileSelectTextChanged);
            // 
            // btnXMLFile_Select
            // 
            this._btnXmlFileSelect.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnXmlFileSelect.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnXmlFileSelect.Location = new System.Drawing.Point(128, 64);
            this._btnXmlFileSelect.Name = "_btnXmlFileSelect";
            this._btnXmlFileSelect.Size = new System.Drawing.Size(24, 20);
            this._btnXmlFileSelect.TabIndex = 25;
            this._btnXmlFileSelect.Text = "...";
            this._btnXmlFileSelect.Click += new System.EventHandler(this.XmlFileSelectClicked);
            // 
            // chkEnable_XML
            // 
            this._chkEnableXml.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._chkEnableXml.ForeColor = System.Drawing.SystemColors.WindowText;
            this._chkEnableXml.Location = new System.Drawing.Point(8, 24);
            this._chkEnableXml.Name = "_chkEnableXml";
            this._chkEnableXml.Size = new System.Drawing.Size(136, 32);
            this._chkEnableXml.TabIndex = 23;
            this._chkEnableXml.Text = "Enable XML based Custom Dates";
            this._chkEnableXml.CheckedChanged += new System.EventHandler(this.EnableXmlCheckedChanged);
            // 
            // groupBox5
            // 
            this._groupBox5.Controls.Add(this._txtCustomFormat);
            this._groupBox5.ForeColor = System.Drawing.SystemColors.WindowText;
            this._groupBox5.Location = new System.Drawing.Point(360, 64);
            this._groupBox5.Name = "_groupBox5";
            this._groupBox5.Size = new System.Drawing.Size(152, 50);
            this._groupBox5.TabIndex = 32;
            this._groupBox5.TabStop = false;
            this._groupBox5.Text = "Set Custom date format";
            // 
            // txtCustom_Format
            // 
            this._txtCustomFormat.Location = new System.Drawing.Point(8, 24);
            this._txtCustomFormat.Name = "_txtCustomFormat";
            this._txtCustomFormat.Size = new System.Drawing.Size(136, 20);
            this._txtCustomFormat.TabIndex = 33;
            this._txtCustomFormat.TextChanged += new System.EventHandler(this.CustomFormatTextChanged);
            // 
            // label4
            // 
            this._label4.ForeColor = System.Drawing.SystemColors.WindowText;
            this._label4.Location = new System.Drawing.Point(360, 16);
            this._label4.Name = "_label4";
            this._label4.Size = new System.Drawing.Size(104, 16);
            this._label4.TabIndex = 30;
            this._label4.Text = "Set Maximum Date";
            // 
            // dateTimePicker_SetMaxDate
            // 
            this._dateTimePickerSetMaxDate.Location = new System.Drawing.Point(360, 32);
            this._dateTimePickerSetMaxDate.Name = "_dateTimePickerSetMaxDate";
            this._dateTimePickerSetMaxDate.Size = new System.Drawing.Size(152, 20);
            this._dateTimePickerSetMaxDate.TabIndex = 31;
            this._dateTimePickerSetMaxDate.Value = new System.DateTime(2072, 12, 31, 0, 0, 0, 0);
            this._dateTimePickerSetMaxDate.ValueChanged += new System.EventHandler(this.SetMaxDateValueChanged);
            // 
            // label3
            // 
            this._label3.ForeColor = System.Drawing.SystemColors.WindowText;
            this._label3.Location = new System.Drawing.Point(176, 16);
            this._label3.Name = "_label3";
            this._label3.Size = new System.Drawing.Size(104, 16);
            this._label3.TabIndex = 26;
            this._label3.Text = "Set Minimum Date";
            // 
            // dateTimePicker_SetMinDate
            // 
            this._dateTimePickerSetMinDate.Location = new System.Drawing.Point(176, 32);
            this._dateTimePickerSetMinDate.Name = "_dateTimePickerSetMinDate";
            this._dateTimePickerSetMinDate.Size = new System.Drawing.Size(152, 20);
            this._dateTimePickerSetMinDate.TabIndex = 27;
            this._dateTimePickerSetMinDate.Value = new System.DateTime(2003, 1, 1, 0, 0, 0, 0);
            this._dateTimePickerSetMinDate.ValueChanged += new System.EventHandler(this.SetMinDateValueChanged);
            // 
            // cmbBox_DateFormat
            // 
            this._cmbBoxDateFormat.DisplayMember = "Long;Short;Time;Custom";
            this._cmbBoxDateFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cmbBoxDateFormat.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._cmbBoxDateFormat.Location = new System.Drawing.Point(176, 80);
            this._cmbBoxDateFormat.Name = "_cmbBoxDateFormat";
            this._cmbBoxDateFormat.Size = new System.Drawing.Size(152, 21);
            this._cmbBoxDateFormat.TabIndex = 29;
            this._cmbBoxDateFormat.SelectedIndexChanged += new System.EventHandler(this.DateFormatComboBoxSelectedIndexChanged);
            // 
            // label2
            // 
            this._label2.ForeColor = System.Drawing.SystemColors.WindowText;
            this._label2.Location = new System.Drawing.Point(176, 64);
            this._label2.Name = "_label2";
            this._label2.Size = new System.Drawing.Size(100, 16);
            this._label2.TabIndex = 28;
            this._label2.Text = "Date format:-";
            // 
            // chkEnable_Selection_Circle
            // 
            this._chkEnableSelectionCircle.Checked = true;
            this._chkEnableSelectionCircle.CheckState = System.Windows.Forms.CheckState.Checked;
            this._chkEnableSelectionCircle.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._chkEnableSelectionCircle.ForeColor = System.Drawing.SystemColors.WindowText;
            this._chkEnableSelectionCircle.Location = new System.Drawing.Point(11, 179);
            this._chkEnableSelectionCircle.Name = "_chkEnableSelectionCircle";
            this._chkEnableSelectionCircle.Size = new System.Drawing.Size(152, 32);
            this._chkEnableSelectionCircle.TabIndex = 16;
            this._chkEnableSelectionCircle.Text = "Enable selected date\'s circle display";
            this._chkEnableSelectionCircle.CheckedChanged += new System.EventHandler(this.EnableSelectionCircleCheckedChanged);
            // 
            // chkEnable_Legend_Display
            // 
            this._chkEnableLegendDisplay.Checked = true;
            this._chkEnableLegendDisplay.CheckState = System.Windows.Forms.CheckState.Checked;
            this._chkEnableLegendDisplay.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._chkEnableLegendDisplay.ForeColor = System.Drawing.SystemColors.WindowText;
            this._chkEnableLegendDisplay.Location = new System.Drawing.Point(171, 179);
            this._chkEnableLegendDisplay.Name = "_chkEnableLegendDisplay";
            this._chkEnableLegendDisplay.Size = new System.Drawing.Size(152, 32);
            this._chkEnableLegendDisplay.TabIndex = 17;
            this._chkEnableLegendDisplay.Text = "Switch on legend display";
            this._chkEnableLegendDisplay.CheckedChanged += new System.EventHandler(this.EnableLegendDisplayCheckedChanged);
            this._chkEnableLegendDisplay.MouseEnter += new System.EventHandler(this.EnableLegendDisplayMouseEnter);
            // 
            // btnToday_Date_Circle_Color
            // 
            this._btnTodayDateCircleColor.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnTodayDateCircleColor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnTodayDateCircleColor.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnTodayDateCircleColor.Location = new System.Drawing.Point(136, 96);
            this._btnTodayDateCircleColor.Name = "_btnTodayDateCircleColor";
            this._btnTodayDateCircleColor.Size = new System.Drawing.Size(120, 32);
            this._btnTodayDateCircleColor.TabIndex = 19;
            this._btnTodayDateCircleColor.Text = "\"Today\'s date\" circle fill color...";
            this._btnTodayDateCircleColor.Click += new System.EventHandler(this.TodayDateCircleColorClicked);
            // 
            // btnToday_Date_ForeColor
            // 
            this._btnTodayDateForeColor.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnTodayDateForeColor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnTodayDateForeColor.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnTodayDateForeColor.Location = new System.Drawing.Point(8, 96);
            this._btnTodayDateForeColor.Name = "_btnTodayDateForeColor";
            this._btnTodayDateForeColor.Size = new System.Drawing.Size(120, 32);
            this._btnTodayDateForeColor.TabIndex = 18;
            this._btnTodayDateForeColor.Text = "\"Today\'s date\" forecolor...";
            this._btnTodayDateForeColor.Click += new System.EventHandler(this.TodayDateForeColorClicked);
            // 
            // btnSelected_Date_Circle_Color
            // 
            this._btnSelectedDateCircleColor.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnSelectedDateCircleColor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnSelectedDateCircleColor.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnSelectedDateCircleColor.Location = new System.Drawing.Point(136, 56);
            this._btnSelectedDateCircleColor.Name = "_btnSelectedDateCircleColor";
            this._btnSelectedDateCircleColor.Size = new System.Drawing.Size(120, 32);
            this._btnSelectedDateCircleColor.TabIndex = 15;
            this._btnSelectedDateCircleColor.Text = "Selected date circle fill color...";
            this._btnSelectedDateCircleColor.Click += new System.EventHandler(this.SelectedDateCircleColorClicked);
            // 
            // btnSelected_Date_Forecolor
            // 
            this._btnSelectedDateForecolor.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnSelectedDateForecolor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnSelectedDateForecolor.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnSelectedDateForecolor.Location = new System.Drawing.Point(8, 56);
            this._btnSelectedDateForecolor.Name = "_btnSelectedDateForecolor";
            this._btnSelectedDateForecolor.Size = new System.Drawing.Size(120, 32);
            this._btnSelectedDateForecolor.TabIndex = 14;
            this._btnSelectedDateForecolor.Text = "Selected date forecolor...";
            this._btnSelectedDateForecolor.Click += new System.EventHandler(this.SelectedDateForecolorClicked);
            // 
            // btnNavigation_Control_Color
            // 
            this._btnNavigationControlColor.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnNavigationControlColor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnNavigationControlColor.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnNavigationControlColor.Location = new System.Drawing.Point(392, 16);
            this._btnNavigationControlColor.Name = "_btnNavigationControlColor";
            this._btnNavigationControlColor.Size = new System.Drawing.Size(120, 32);
            this._btnNavigationControlColor.TabIndex = 13;
            this._btnNavigationControlColor.Text = "Navigation controls color...";
            this._btnNavigationControlColor.Click += new System.EventHandler(this.NavigationControlColorClicked);
            // 
            // btnCalendar_Title_Forecolor_Change
            // 
            this._btnCalendarTitleForecolorChange.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnCalendarTitleForecolorChange.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnCalendarTitleForecolorChange.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnCalendarTitleForecolorChange.Location = new System.Drawing.Point(264, 16);
            this._btnCalendarTitleForecolorChange.Name = "_btnCalendarTitleForecolorChange";
            this._btnCalendarTitleForecolorChange.Size = new System.Drawing.Size(120, 32);
            this._btnCalendarTitleForecolorChange.TabIndex = 12;
            this._btnCalendarTitleForecolorChange.Text = " Title forecolor...";
            this._btnCalendarTitleForecolorChange.Click += new System.EventHandler(this.CalendarTitleForecolorChangeClicked);
            // 
            // btnCalendar_Backcolor_Change
            // 
            this._btnCalendarBackcolorChange.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnCalendarBackcolorChange.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnCalendarBackcolorChange.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnCalendarBackcolorChange.Location = new System.Drawing.Point(136, 16);
            this._btnCalendarBackcolorChange.Name = "_btnCalendarBackcolorChange";
            this._btnCalendarBackcolorChange.Size = new System.Drawing.Size(120, 32);
            this._btnCalendarBackcolorChange.TabIndex = 11;
            this._btnCalendarBackcolorChange.Text = "Change backcolor...";
            this._btnCalendarBackcolorChange.Click += new System.EventHandler(this.CalendarBackcolorChangeClicked);
            // 
            // btnCalendar_Forecolor_Change
            // 
            this._btnCalendarForecolorChange.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnCalendarForecolorChange.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnCalendarForecolorChange.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnCalendarForecolorChange.Location = new System.Drawing.Point(8, 16);
            this._btnCalendarForecolorChange.Name = "_btnCalendarForecolorChange";
            this._btnCalendarForecolorChange.Size = new System.Drawing.Size(120, 32);
            this._btnCalendarForecolorChange.TabIndex = 10;
            this._btnCalendarForecolorChange.Text = "Change forecolor...";
            this._btnCalendarForecolorChange.Click += new System.EventHandler(this.CalendarForecolorChangeClicked);
            // 
            // About
            // 
            this._about.Cursor = System.Windows.Forms.Cursors.Hand;
            this._about.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._about.Location = new System.Drawing.Point(624, 562);
            this._about.Name = "_about";
            this._about.Size = new System.Drawing.Size(72, 24);
            this._about.TabIndex = 34;
            this._about.Text = "&About...";
            this._about.Click += new System.EventHandler(this.AboutClicked);
            // 
            // button11
            // 
            this._button11.Cursor = System.Windows.Forms.Cursors.Hand;
            this._button11.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._button11.Location = new System.Drawing.Point(704, 562);
            this._button11.Name = "_button11";
            this._button11.Size = new System.Drawing.Size(64, 24);
            this._button11.TabIndex = 35;
            this._button11.Text = "E&xit";
            this._button11.Click += new System.EventHandler(this.AppExitClicked);
            // 
            // App_Statusbar
            // 
            this._appStatusbar.Location = new System.Drawing.Point(0, 594);
            this._appStatusbar.Name = "_appStatusbar";
            this._appStatusbar.Size = new System.Drawing.Size(778, 22);
            this._appStatusbar.TabIndex = 37;
            this._appStatusbar.Text = "statusBar1";
            this._appStatusbar.PanelClick += new System.Windows.Forms.StatusBarPanelClickEventHandler(this.AppStatusbarPanelClicked);
            // 
            // toolTip1
            // 
            this._toolTip1.AutomaticDelay = 2000;
            this._toolTip1.AutoPopDelay = 2000;
            this._toolTip1.InitialDelay = 400;
            this._toolTip1.ReshowDelay = 400;
            // 
            // groupBox1
            // 
            this._groupBox1.Controls.Add(this._cbxCustomImageStyle);
            this._groupBox1.Controls.Add(this._label15);
            this._groupBox1.Controls.Add(this._btnCustomImageFileLocator);
            this._groupBox1.Controls.Add(this._txtCustomImageFile);
            this._groupBox1.Controls.Add(this._label14);
            this._groupBox1.Controls.Add(this._binaryDatePicker1);
            this._groupBox1.Controls.Add(this._dateChangeDisplayLabel);
            this._groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox1.Location = new System.Drawing.Point(9, 8);
            this._groupBox1.Name = "_groupBox1";
            this._groupBox1.Size = new System.Drawing.Size(231, 368);
            this._groupBox1.TabIndex = 0;
            this._groupBox1.TabStop = false;
            this._groupBox1.Text = "Date settings";
            // 
            // cbxCustomImageStyle
            // 
            this._cbxCustomImageStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbxCustomImageStyle.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._cbxCustomImageStyle.Items.AddRange(new object[] {
            "GlassRendering",
            "DropDownArrow",
            "BuiltInCalendarImage",
            "CustomImage"});
            this._cbxCustomImageStyle.Location = new System.Drawing.Point(8, 280);
            this._cbxCustomImageStyle.Name = "_cbxCustomImageStyle";
            this._cbxCustomImageStyle.Size = new System.Drawing.Size(208, 21);
            this._cbxCustomImageStyle.TabIndex = 43;
            this._cbxCustomImageStyle.SelectedIndexChanged += new System.EventHandler(this.CustomImageStyleSelectedIndexChanged);
            // 
            // label15
            // 
            this._label15.Location = new System.Drawing.Point(7, 248);
            this._label15.Name = "_label15";
            this._label15.Size = new System.Drawing.Size(217, 32);
            this._label15.TabIndex = 42;
            this._label15.Text = "Set a custom image style (for drop-down button):";
            // 
            // btnCustomImageFileLocator
            // 
            this._btnCustomImageFileLocator.Enabled = false;
            this._btnCustomImageFileLocator.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnCustomImageFileLocator.Location = new System.Drawing.Point(192, 336);
            this._btnCustomImageFileLocator.Name = "_btnCustomImageFileLocator";
            this._btnCustomImageFileLocator.Size = new System.Drawing.Size(24, 21);
            this._btnCustomImageFileLocator.TabIndex = 41;
            this._btnCustomImageFileLocator.Text = "...";
            this._btnCustomImageFileLocator.Click += new System.EventHandler(this.CustomImageFileLocatorClicked);
            // 
            // txtCustomImageFile
            // 
            this._txtCustomImageFile.Enabled = false;
            this._txtCustomImageFile.Location = new System.Drawing.Point(8, 336);
            this._txtCustomImageFile.Name = "_txtCustomImageFile";
            this._txtCustomImageFile.Size = new System.Drawing.Size(184, 20);
            this._txtCustomImageFile.TabIndex = 40;
            // 
            // label14
            // 
            this._label14.Location = new System.Drawing.Point(8, 312);
            this._label14.Name = "_label14";
            this._label14.Size = new System.Drawing.Size(217, 16);
            this._label14.TabIndex = 39;
            this._label14.Text = "Set a custom image for drop-down button :-";
            // 
            // binaryDatePicker1
            // 
            this._binaryDatePicker1.BinaryCultureInfo = new System.Globalization.CultureInfo("en-GB");
            this._binaryDatePicker1.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this._binaryDatePicker1.CalendarForeColor = System.Drawing.SystemColors.ControlText;
            this._binaryDatePicker1.CalendarInactiveDateForeColor = System.Drawing.SystemColors.ControlDark;
            this._binaryDatePicker1.CalendarLegendDisplay = true;
            this._binaryDatePicker1.CalendarMonthAndYearTrackerColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this._binaryDatePicker1.CalendarMonthBackColor = System.Drawing.SystemColors.Window;
            this._binaryDatePicker1.CalendarMonthTitleForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this._binaryDatePicker1.CalenderDropDownArrowGlassRenderingColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this._binaryDatePicker1.CalenderDropDownGlassRenderingEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this._binaryDatePicker1.CalenderDropDownGlassRenderingStartColor = System.Drawing.SystemColors.Window;
            this._binaryDatePicker1.CloseButtonBackColor = System.Drawing.SystemColors.Control;
            this._binaryDatePicker1.CloseButtonFlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this._binaryDatePicker1.CloseButtonForeColor = System.Drawing.SystemColors.WindowText;
            this._binaryDatePicker1.CloseButtonText = "Close";
            this._binaryDatePicker1.CustomDateXMLFeed = "";
            this._binaryDatePicker1.CustomDropDownImage = null;
            this._binaryDatePicker1.CustomFormat = "D";
            this._binaryDatePicker1.DisplayTextState = true;
            this._binaryDatePicker1.DotBorderDepth = 4;
            this._binaryDatePicker1.DotBorderGap = 5;
            this._binaryDatePicker1.DrawBorderAs = BorderState.Normal;
            this._binaryDatePicker1.DropWindowIsShowing = false;
            this._binaryDatePicker1.EnableCustomDateXMLFeed = false;
            this._binaryDatePicker1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this._binaryDatePicker1.Format = BinaryDatePickerFormat.Long;
            this._binaryDatePicker1.HostedFromChildContainer = false;
            this._binaryDatePicker1.Location = new System.Drawing.Point(8, 24);
            this._binaryDatePicker1.MarkSelectedDate = true;
            this._binaryDatePicker1.MaxValue = new System.DateTime(2072, 12, 31, 23, 48, 14, 699);
            this._binaryDatePicker1.MinValue = new System.DateTime(2003, 1, 1, 23, 48, 14, 699);
            this._binaryDatePicker1.Name = "_binaryDatePicker1";
            this._binaryDatePicker1.NullDateString = "";
            this._binaryDatePicker1.RenderDropDownButtonWithVisualStyles = true;
            this._binaryDatePicker1.SelectionDateEllipseColor = System.Drawing.Color.Blue;
            this._binaryDatePicker1.SelectionDateForeColor = System.Drawing.Color.Yellow;
            this._binaryDatePicker1.ShowBorderAlways = true;
            this._binaryDatePicker1.ShowCustomMenu = true;
            this._binaryDatePicker1.ShowDropDownCalendarWindowAfterAdjustingForVirtualAvaliableScreenSpace = true;
            this._binaryDatePicker1.ShowPopupOnEnter = false;
            this._binaryDatePicker1.Size = new System.Drawing.Size(216, 21);
            this._binaryDatePicker1.SpecialDates = new System.DateTime[0];
            this._binaryDatePicker1.SpecialDatesFillColor = System.Drawing.SystemColors.ControlDarkDark;
            this._binaryDatePicker1.SpecialDatesForeColor = System.Drawing.SystemColors.ControlLightLight;
            this._binaryDatePicker1.TabIndex = 38;
            this._binaryDatePicker1.TabStop = false;
            this._binaryDatePicker1.Text = "13 August 2003";
            this._binaryDatePicker1.TodayButtonBackColor = System.Drawing.SystemColors.Control;
            this._binaryDatePicker1.TodayButtonFlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this._binaryDatePicker1.TodayButtonForeColor = System.Drawing.SystemColors.WindowText;
            this._binaryDatePicker1.TodayButtonText = "Today";
            this._binaryDatePicker1.TodayCloseButtonsAreVisible = true;
            this._binaryDatePicker1.TodayEllipseColor = System.Drawing.Color.Green;
            this._binaryDatePicker1.TodayForeColor = System.Drawing.Color.Yellow;
            this._binaryDatePicker1.UseDropDownImageStyle = DropDownImageStyle.DropDownArrow;
            this._binaryDatePicker1.Value = new System.DateTime(2011, 9, 30, 23, 48, 14, 699);
            this._binaryDatePicker1.ValueIsNull = false;
            this._binaryDatePicker1.BinaryDateChanged += new System.EventHandler(this.CustomDateChanged);
            this._binaryDatePicker1.BinaryCalendarActivated += new System.EventHandler(this.BinaryCalendarActivated);
            this._binaryDatePicker1.BinaryCalendarDeactivated += new System.EventHandler(this.binaryDatePicker1_BinaryCalendarDeactivated);
            // 
            // DateChangeDisplay_Label
            // 
            this._dateChangeDisplayLabel.Location = new System.Drawing.Point(16, 70);
            this._dateChangeDisplayLabel.Name = "_dateChangeDisplayLabel";
            this._dateChangeDisplayLabel.Size = new System.Drawing.Size(200, 160);
            this._dateChangeDisplayLabel.TabIndex = 37;
            // 
            // label5
            // 
            this._label5.ForeColor = System.Drawing.Color.Blue;
            this._label5.Location = new System.Drawing.Point(8, 20);
            this._label5.Name = "_label5";
            this._label5.Size = new System.Drawing.Size(272, 16);
            this._label5.TabIndex = 1;
            this._label5.Text = "BinaryDatePicker .NET control:-";
            // 
            // groupBox4
            // 
            this._groupBox4.Controls.Add(this._chkShowBorderAlways);
            this._groupBox4.Controls.Add(this._g7);
            this._groupBox4.Controls.Add(this._cmbBxControlTextBoxBorderStyle);
            this._groupBox4.Controls.Add(this._label6);
            this._groupBox4.Controls.Add(this._btnControlTextBoxBorderColorChange);
            this._groupBox4.Controls.Add(this._chkShowCustomMenu);
            this._groupBox4.Controls.Add(this._chkEnableExtendedStyle);
            this._groupBox4.Controls.Add(this._btnChageFont);
            this._groupBox4.Controls.Add(this._btnControlTextBoxForecolorChange);
            this._groupBox4.Controls.Add(this._btnControlTextBoxBackcolorChange);
            this._groupBox4.Controls.Add(this._chkEnableControlTextBox);
            this._groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox4.ForeColor = System.Drawing.Color.Blue;
            this._groupBox4.Location = new System.Drawing.Point(248, 16);
            this._groupBox4.Name = "_groupBox4";
            this._groupBox4.Size = new System.Drawing.Size(520, 168);
            this._groupBox4.TabIndex = 3;
            this._groupBox4.TabStop = false;
            this._groupBox4.Text = "Control\'s Date displaying text box related properties";
            // 
            // chkShowBorderAlways
            // 
            this._chkShowBorderAlways.Checked = true;
            this._chkShowBorderAlways.CheckState = System.Windows.Forms.CheckState.Checked;
            this._chkShowBorderAlways.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._chkShowBorderAlways.ForeColor = System.Drawing.SystemColors.WindowText;
            this._chkShowBorderAlways.Location = new System.Drawing.Point(384, 80);
            this._chkShowBorderAlways.Name = "_chkShowBorderAlways";
            this._chkShowBorderAlways.Size = new System.Drawing.Size(128, 32);
            this._chkShowBorderAlways.TabIndex = 16;
            this._chkShowBorderAlways.Text = "Show border always";
            this._chkShowBorderAlways.CheckedChanged += new System.EventHandler(this.ShowBorderAlwaysCheckBoxCheckedChanged);
            // 
            // g7
            // 
            this._g7.Controls.Add(this._label8);
            this._g7.Controls.Add(this._label7);
            this._g7.Controls.Add(this._spinnerControlBorderDepth);
            this._g7.Controls.Add(this._spinnerControlBorderGap);
            this._g7.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._g7.ForeColor = System.Drawing.SystemColors.WindowText;
            this._g7.Location = new System.Drawing.Point(160, 64);
            this._g7.Name = "_g7";
            this._g7.Size = new System.Drawing.Size(200, 56);
            this._g7.TabIndex = 15;
            this._g7.TabStop = false;
            this._g7.Text = "Dotted border\'s properties";
            // 
            // label8
            // 
            this._label8.ForeColor = System.Drawing.SystemColors.WindowText;
            this._label8.Location = new System.Drawing.Point(112, 24);
            this._label8.Name = "_label8";
            this._label8.Size = new System.Drawing.Size(32, 16);
            this._label8.TabIndex = 16;
            this._label8.Text = "Gap";
            // 
            // label7
            // 
            this._label7.ForeColor = System.Drawing.SystemColors.WindowText;
            this._label7.Location = new System.Drawing.Point(8, 24);
            this._label7.Name = "_label7";
            this._label7.Size = new System.Drawing.Size(40, 16);
            this._label7.TabIndex = 15;
            this._label7.Text = "Depth";
            // 
            // spinnerControl_Border_Depth
            // 
            this._spinnerControlBorderDepth.Location = new System.Drawing.Point(48, 24);
            this._spinnerControlBorderDepth.Name = "_spinnerControlBorderDepth";
            this._spinnerControlBorderDepth.Size = new System.Drawing.Size(48, 20);
            this._spinnerControlBorderDepth.TabIndex = 13;
            this._spinnerControlBorderDepth.ValueChanged += new System.EventHandler(this.ControlBorderDepthNumerictextboxValueChanged);
            // 
            // spinnerControl_Border_Gap
            // 
            this._spinnerControlBorderGap.Location = new System.Drawing.Point(144, 24);
            this._spinnerControlBorderGap.Name = "_spinnerControlBorderGap";
            this._spinnerControlBorderGap.Size = new System.Drawing.Size(48, 20);
            this._spinnerControlBorderGap.TabIndex = 14;
            this._spinnerControlBorderGap.ValueChanged += new System.EventHandler(this.ControlBorderGapNumerictextboxValueChanged);
            // 
            // cmbBx_ControlTextBox_BorderStyle
            // 
            this._cmbBxControlTextBoxBorderStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cmbBxControlTextBoxBorderStyle.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._cmbBxControlTextBoxBorderStyle.Location = new System.Drawing.Point(16, 88);
            this._cmbBxControlTextBoxBorderStyle.Name = "_cmbBxControlTextBoxBorderStyle";
            this._cmbBxControlTextBoxBorderStyle.Size = new System.Drawing.Size(104, 21);
            this._cmbBxControlTextBoxBorderStyle.TabIndex = 12;
            this._cmbBxControlTextBoxBorderStyle.SelectedIndexChanged += new System.EventHandler(this.ControlTextBoxBorderStyleComboBoxSelectedIndexChanged);
            // 
            // label6
            // 
            this._label6.ForeColor = System.Drawing.SystemColors.WindowText;
            this._label6.Location = new System.Drawing.Point(14, 72);
            this._label6.Name = "_label6";
            this._label6.Size = new System.Drawing.Size(114, 16);
            this._label6.TabIndex = 11;
            this._label6.Text = "Control\'s border style";
            // 
            // btnControlTextBox_BorderColorChange
            // 
            this._btnControlTextBoxBorderColorChange.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnControlTextBoxBorderColorChange.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnControlTextBoxBorderColorChange.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnControlTextBoxBorderColorChange.Location = new System.Drawing.Point(384, 24);
            this._btnControlTextBoxBorderColorChange.Name = "_btnControlTextBoxBorderColorChange";
            this._btnControlTextBoxBorderColorChange.Size = new System.Drawing.Size(120, 32);
            this._btnControlTextBoxBorderColorChange.TabIndex = 10;
            this._btnControlTextBoxBorderColorChange.Text = "Set border color...";
            this._btnControlTextBoxBorderColorChange.Click += new System.EventHandler(this.ControlTextBoxBorderColorChangeClicked);
            // 
            // chkShow_CustomMenu
            // 
            this._chkShowCustomMenu.Checked = true;
            this._chkShowCustomMenu.CheckState = System.Windows.Forms.CheckState.Checked;
            this._chkShowCustomMenu.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._chkShowCustomMenu.ForeColor = System.Drawing.SystemColors.WindowText;
            this._chkShowCustomMenu.Location = new System.Drawing.Point(376, 120);
            this._chkShowCustomMenu.Name = "_chkShowCustomMenu";
            this._chkShowCustomMenu.Size = new System.Drawing.Size(128, 40);
            this._chkShowCustomMenu.TabIndex = 9;
            this._chkShowCustomMenu.Text = "Show Custom menu";
            this._chkShowCustomMenu.CheckedChanged += new System.EventHandler(this.ShowCustomMenuCheckedChanged);
            // 
            // chkEnable_ExtendedStyle
            // 
            this._chkEnableExtendedStyle.Checked = true;
            this._chkEnableExtendedStyle.CheckState = System.Windows.Forms.CheckState.Checked;
            this._chkEnableExtendedStyle.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._chkEnableExtendedStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this._chkEnableExtendedStyle.Location = new System.Drawing.Point(16, 128);
            this._chkEnableExtendedStyle.Name = "_chkEnableExtendedStyle";
            this._chkEnableExtendedStyle.Size = new System.Drawing.Size(136, 32);
            this._chkEnableExtendedStyle.TabIndex = 7;
            this._chkEnableExtendedStyle.Text = "Enable Extended style Text box";
            this._chkEnableExtendedStyle.CheckedChanged += new System.EventHandler(this.EnableExtendedStyleCheckedChanged);
            // 
            // btnChageFont
            // 
            this._btnChageFont.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnChageFont.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnChageFont.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnChageFont.Location = new System.Drawing.Point(8, 24);
            this._btnChageFont.Name = "_btnChageFont";
            this._btnChageFont.Size = new System.Drawing.Size(120, 32);
            this._btnChageFont.TabIndex = 4;
            this._btnChageFont.Text = "Change  font...";
            this._btnChageFont.Click += new System.EventHandler(this.ChageFontClicked);
            // 
            // btnControlTextBox_ForecolorChange
            // 
            this._btnControlTextBoxForecolorChange.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnControlTextBoxForecolorChange.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnControlTextBoxForecolorChange.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnControlTextBoxForecolorChange.Location = new System.Drawing.Point(136, 24);
            this._btnControlTextBoxForecolorChange.Name = "_btnControlTextBoxForecolorChange";
            this._btnControlTextBoxForecolorChange.Size = new System.Drawing.Size(112, 32);
            this._btnControlTextBoxForecolorChange.TabIndex = 5;
            this._btnControlTextBoxForecolorChange.Text = "Change forecolor...";
            this._btnControlTextBoxForecolorChange.Click += new System.EventHandler(this.ControlTextBoxForecolorChangeClicked);
            // 
            // btnControlTextBox_BackcolorChange
            // 
            this._btnControlTextBoxBackcolorChange.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnControlTextBoxBackcolorChange.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnControlTextBoxBackcolorChange.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnControlTextBoxBackcolorChange.Location = new System.Drawing.Point(256, 24);
            this._btnControlTextBoxBackcolorChange.Name = "_btnControlTextBoxBackcolorChange";
            this._btnControlTextBoxBackcolorChange.Size = new System.Drawing.Size(120, 32);
            this._btnControlTextBoxBackcolorChange.TabIndex = 6;
            this._btnControlTextBoxBackcolorChange.Text = "Change backcolor...";
            this._btnControlTextBoxBackcolorChange.Click += new System.EventHandler(this.ControlTextBoxBackcolorChangeClicked);
            // 
            // chkEnable_ControlTextBox
            // 
            this._chkEnableControlTextBox.Checked = true;
            this._chkEnableControlTextBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this._chkEnableControlTextBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._chkEnableControlTextBox.ForeColor = System.Drawing.SystemColors.WindowText;
            this._chkEnableControlTextBox.Location = new System.Drawing.Point(200, 128);
            this._chkEnableControlTextBox.Name = "_chkEnableControlTextBox";
            this._chkEnableControlTextBox.Size = new System.Drawing.Size(128, 32);
            this._chkEnableControlTextBox.TabIndex = 8;
            this._chkEnableControlTextBox.Text = "Enable control\'s date display text control";
            this._chkEnableControlTextBox.CheckedChanged += new System.EventHandler(this.EnableControlTextBoxCheckedChanged);
            this._chkEnableControlTextBox.MouseEnter += new System.EventHandler(this.EnableControlTextBoxMouseEnter);
            // 
            // groupBox6
            // 
            this._groupBox6.Controls.Add(this._btnGlassRenderingArrowColor);
            this._groupBox6.Controls.Add(this._btnGlassRenderingStartColor);
            this._groupBox6.Controls.Add(this._btnGlassRenderingEndColor);
            this._groupBox6.Controls.Add(this._chkDisplayTodayCloseButtons);
            this._groupBox6.Controls.Add(this._btnCloseButtonForecolor);
            this._groupBox6.Controls.Add(this._btnCloseButtonBackcolor);
            this._groupBox6.Controls.Add(this._btnTodayButtonForecolor);
            this._groupBox6.Controls.Add(this._btnTodayButtonBackcolor);
            this._groupBox6.Controls.Add(this._btnCalendarForecolorChange);
            this._groupBox6.Controls.Add(this._btnCalendarBackcolorChange);
            this._groupBox6.Controls.Add(this._btnCalendarTitleForecolorChange);
            this._groupBox6.Controls.Add(this._btnNavigationControlColor);
            this._groupBox6.Controls.Add(this._btnSelectedDateForecolor);
            this._groupBox6.Controls.Add(this._btnSelectedDateCircleColor);
            this._groupBox6.Controls.Add(this._btnTodayDateForeColor);
            this._groupBox6.Controls.Add(this._btnTodayDateCircleColor);
            this._groupBox6.Controls.Add(this._chkEnableLegendDisplay);
            this._groupBox6.Controls.Add(this._chkEnableSelectionCircle);
            this._groupBox6.ForeColor = System.Drawing.SystemColors.WindowText;
            this._groupBox6.Location = new System.Drawing.Point(248, 194);
            this._groupBox6.Name = "_groupBox6";
            this._groupBox6.Size = new System.Drawing.Size(520, 222);
            this._groupBox6.TabIndex = 9;
            this._groupBox6.TabStop = false;
            this._groupBox6.Text = "Control\'s Calendar related properties";
            // 
            // btnGlassRenderingStartColor
            // 
            this._btnGlassRenderingStartColor.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnGlassRenderingStartColor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnGlassRenderingStartColor.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnGlassRenderingStartColor.Location = new System.Drawing.Point(9, 137);
            this._btnGlassRenderingStartColor.Name = "_btnGlassRenderingStartColor";
            this._btnGlassRenderingStartColor.Size = new System.Drawing.Size(151, 32);
            this._btnGlassRenderingStartColor.TabIndex = 25;
            this._btnGlassRenderingStartColor.Text = "Glass rendering Start Color...";
            this._btnGlassRenderingStartColor.Click += new System.EventHandler(this.GlassRenderingStartColorClicked);
            // 
            // btnGlassRenderingEndColor
            // 
            this._btnGlassRenderingEndColor.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnGlassRenderingEndColor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnGlassRenderingEndColor.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnGlassRenderingEndColor.Location = new System.Drawing.Point(168, 138);
            this._btnGlassRenderingEndColor.Name = "_btnGlassRenderingEndColor";
            this._btnGlassRenderingEndColor.Size = new System.Drawing.Size(148, 32);
            this._btnGlassRenderingEndColor.TabIndex = 26;
            this._btnGlassRenderingEndColor.Text = "Glass Rendering End Color...";
            this._btnGlassRenderingEndColor.Click += new System.EventHandler(this.GlassRenderingEndColorClicked);
            // 
            // chkDisplayTodayCloseButtons
            // 
            this._chkDisplayTodayCloseButtons.Checked = true;
            this._chkDisplayTodayCloseButtons.CheckState = System.Windows.Forms.CheckState.Checked;
            this._chkDisplayTodayCloseButtons.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._chkDisplayTodayCloseButtons.ForeColor = System.Drawing.SystemColors.WindowText;
            this._chkDisplayTodayCloseButtons.Location = new System.Drawing.Point(339, 187);
            this._chkDisplayTodayCloseButtons.Name = "_chkDisplayTodayCloseButtons";
            this._chkDisplayTodayCloseButtons.Size = new System.Drawing.Size(168, 24);
            this._chkDisplayTodayCloseButtons.TabIndex = 24;
            this._chkDisplayTodayCloseButtons.Text = "Display Today/Close buttons";
            this._chkDisplayTodayCloseButtons.CheckedChanged += new System.EventHandler(this.chkDisplayTodayCloseButtons_CheckedChanged);
            // 
            // btnCloseButtonForecolor
            // 
            this._btnCloseButtonForecolor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnCloseButtonForecolor.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnCloseButtonForecolor.Location = new System.Drawing.Point(392, 96);
            this._btnCloseButtonForecolor.Name = "_btnCloseButtonForecolor";
            this._btnCloseButtonForecolor.Size = new System.Drawing.Size(120, 32);
            this._btnCloseButtonForecolor.TabIndex = 23;
            this._btnCloseButtonForecolor.Text = "\"Close\" button Forecolor";
            this._btnCloseButtonForecolor.Click += new System.EventHandler(this.CloseButtonForecolorClicked);
            // 
            // btnCloseButtonBackcolor
            // 
            this._btnCloseButtonBackcolor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnCloseButtonBackcolor.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnCloseButtonBackcolor.Location = new System.Drawing.Point(264, 96);
            this._btnCloseButtonBackcolor.Name = "_btnCloseButtonBackcolor";
            this._btnCloseButtonBackcolor.Size = new System.Drawing.Size(120, 32);
            this._btnCloseButtonBackcolor.TabIndex = 22;
            this._btnCloseButtonBackcolor.Text = "\"Close\" button Backcolor";
            this._btnCloseButtonBackcolor.Click += new System.EventHandler(this.CloseButtonBackcolorClicked);
            // 
            // btnTodayButtonForecolor
            // 
            this._btnTodayButtonForecolor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnTodayButtonForecolor.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnTodayButtonForecolor.Location = new System.Drawing.Point(392, 56);
            this._btnTodayButtonForecolor.Name = "_btnTodayButtonForecolor";
            this._btnTodayButtonForecolor.Size = new System.Drawing.Size(120, 32);
            this._btnTodayButtonForecolor.TabIndex = 21;
            this._btnTodayButtonForecolor.Text = "\"Today\" button Forecolor";
            this._btnTodayButtonForecolor.Click += new System.EventHandler(this.TodayButtonForecolorClicked);
            // 
            // btnTodayButtonBackcolor
            // 
            this._btnTodayButtonBackcolor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnTodayButtonBackcolor.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnTodayButtonBackcolor.Location = new System.Drawing.Point(264, 56);
            this._btnTodayButtonBackcolor.Name = "_btnTodayButtonBackcolor";
            this._btnTodayButtonBackcolor.Size = new System.Drawing.Size(120, 32);
            this._btnTodayButtonBackcolor.TabIndex = 20;
            this._btnTodayButtonBackcolor.Text = "\"Today\" button Backcolor";
            this._btnTodayButtonBackcolor.Click += new System.EventHandler(this.TodayButtonBackcolorClicked);
            // 
            // groupBox7
            // 
            this._groupBox7.Controls.Add(this._cmbBxTodayFlatStyle);
            this._groupBox7.Controls.Add(this._label1);
            this._groupBox7.Controls.Add(this._closeButtonText);
            this._groupBox7.Controls.Add(this._todayButtonText);
            this._groupBox7.Controls.Add(this._label12);
            this._groupBox7.Controls.Add(this._label11);
            this._groupBox7.Controls.Add(this._label10);
            this._groupBox7.Controls.Add(this._cmbBxCultureInfo);
            this._groupBox7.Controls.Add(this._label9);
            this._groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._groupBox7.Location = new System.Drawing.Point(8, 384);
            this._groupBox7.Name = "_groupBox7";
            this._groupBox7.Size = new System.Drawing.Size(232, 176);
            this._groupBox7.TabIndex = 38;
            this._groupBox7.TabStop = false;
            this._groupBox7.Text = "Culture && other properties";
            // 
            // cmbBx_TodayFlatStyle
            // 
            this._cmbBxTodayFlatStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cmbBxTodayFlatStyle.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._cmbBxTodayFlatStyle.Items.AddRange(new object[] {
            "Standard",
            "Flat",
            "Popup",
            "System"});
            this._cmbBxTodayFlatStyle.Location = new System.Drawing.Point(13, 144);
            this._cmbBxTodayFlatStyle.Name = "_cmbBxTodayFlatStyle";
            this._cmbBxTodayFlatStyle.Size = new System.Drawing.Size(99, 21);
            this._cmbBxTodayFlatStyle.TabIndex = 8;
            this._cmbBxTodayFlatStyle.SelectedIndexChanged += new System.EventHandler(this.TodayFlatStyleSelectedIndexChanged);
            // 
            // label1
            // 
            this._label1.Location = new System.Drawing.Point(11, 128);
            this._label1.Name = "_label1";
            this._label1.Size = new System.Drawing.Size(93, 16);
            this._label1.TabIndex = 7;
            this._label1.Text = "\"Today\" FlatStyle";
            // 
            // CloseButton_Text
            // 
            this._closeButtonText.Location = new System.Drawing.Point(104, 104);
            this._closeButtonText.Name = "_closeButtonText";
            this._closeButtonText.Size = new System.Drawing.Size(112, 20);
            this._closeButtonText.TabIndex = 6;
            this._closeButtonText.Text = "Close";
            this._closeButtonText.TextChanged += new System.EventHandler(this.CloseButtonTextTextChanged);
            // 
            // TodayButton_Text
            // 
            this._todayButtonText.Location = new System.Drawing.Point(104, 80);
            this._todayButtonText.Name = "_todayButtonText";
            this._todayButtonText.Size = new System.Drawing.Size(112, 20);
            this._todayButtonText.TabIndex = 5;
            this._todayButtonText.Text = "Today";
            this._todayButtonText.TextChanged += new System.EventHandler(this.TodayButtonTextTextChanged);
            // 
            // label12
            // 
            this._label12.Location = new System.Drawing.Point(16, 104);
            this._label12.Name = "_label12";
            this._label12.Size = new System.Drawing.Size(80, 16);
            this._label12.TabIndex = 4;
            this._label12.Text = "\"Close\" Button";
            // 
            // label11
            // 
            this._label11.Location = new System.Drawing.Point(16, 80);
            this._label11.Name = "_label11";
            this._label11.Size = new System.Drawing.Size(80, 16);
            this._label11.TabIndex = 3;
            this._label11.Text = "\"Today\" Button";
            // 
            // label10
            // 
            this._label10.Location = new System.Drawing.Point(14, 60);
            this._label10.Name = "_label10";
            this._label10.Size = new System.Drawing.Size(152, 16);
            this._label10.TabIndex = 2;
            this._label10.Text = "Set Calendar button(s) text :";
            // 
            // cmbBx_CultureInfo
            // 
            this._cmbBxCultureInfo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cmbBxCultureInfo.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._cmbBxCultureInfo.Location = new System.Drawing.Point(16, 32);
            this._cmbBxCultureInfo.Name = "_cmbBxCultureInfo";
            this._cmbBxCultureInfo.Size = new System.Drawing.Size(208, 21);
            this._cmbBxCultureInfo.TabIndex = 1;
            this._cmbBxCultureInfo.SelectedIndexChanged += new System.EventHandler(this.CultureInfoComboboxSelectedIndexChanged);
            // 
            // label9
            // 
            this._label9.Location = new System.Drawing.Point(14, 16);
            this._label9.Name = "_label9";
            this._label9.Size = new System.Drawing.Size(80, 16);
            this._label9.TabIndex = 0;
            this._label9.Text = "Set Culture";
            // 
            // cmbBx_CloseFlatStyle
            // 
            this._cmbBxCloseFlatStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cmbBxCloseFlatStyle.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._cmbBxCloseFlatStyle.Items.AddRange(new object[] {
            "Standard",
            "Flat",
            "Popup",
            "System"});
            this._cmbBxCloseFlatStyle.Location = new System.Drawing.Point(128, 528);
            this._cmbBxCloseFlatStyle.Name = "_cmbBxCloseFlatStyle";
            this._cmbBxCloseFlatStyle.Size = new System.Drawing.Size(104, 21);
            this._cmbBxCloseFlatStyle.TabIndex = 40;
            this._cmbBxCloseFlatStyle.SelectedIndexChanged += new System.EventHandler(this.CloseFlatStyleSelectedIndexChanged);
            // 
            // label13
            // 
            this._label13.Location = new System.Drawing.Point(128, 512);
            this._label13.Name = "_label13";
            this._label13.Size = new System.Drawing.Size(93, 16);
            this._label13.TabIndex = 39;
            this._label13.Text = "\"Close\" FlatStyle";
            // 
            // btnGlassRenderingArrowColor
            // 
            this._btnGlassRenderingArrowColor.Cursor = System.Windows.Forms.Cursors.Hand;
            this._btnGlassRenderingArrowColor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._btnGlassRenderingArrowColor.ForeColor = System.Drawing.SystemColors.WindowText;
            this._btnGlassRenderingArrowColor.Location = new System.Drawing.Point(325, 139);
            this._btnGlassRenderingArrowColor.Name = "_btnGlassRenderingArrowColor";
            this._btnGlassRenderingArrowColor.Size = new System.Drawing.Size(187, 32);
            this._btnGlassRenderingArrowColor.TabIndex = 27;
            this._btnGlassRenderingArrowColor.Text = "Glass Rendering Arrow Color...";
            this._btnGlassRenderingArrowColor.Click += new System.EventHandler(this.GlassRenderingArrowColorClicked);
            // 
            // BinaryDatePickerDemoApplication
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(778, 616);
            this.Controls.Add(this._cmbBxCloseFlatStyle);
            this.Controls.Add(this._label13);
            this.Controls.Add(this._groupBox7);
            this.Controls.Add(this._groupBox6);
            this.Controls.Add(this._groupBox4);
            this.Controls.Add(this._groupBox1);
            this.Controls.Add(this._appStatusbar);
            this.Controls.Add(this._button11);
            this.Controls.Add(this._about);
            this.Controls.Add(this._groupBox2);
            this.ForeColor = System.Drawing.SystemColors.WindowText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("app")));
            this.MaximizeBox = false;
            this.Name = "BinaryDatePickerDemoApplication";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BinaryDatePicker.NET demo application! Copyright © www.binarymission.co.uk";
            this.Load += new System.EventHandler(this.Form1_Load);
            this._groupBox2.ResumeLayout(false);
            this._groupBox3.ResumeLayout(false);
            this._groupBox3.PerformLayout();
            this._groupBox5.ResumeLayout(false);
            this._groupBox5.PerformLayout();
            this._groupBox1.ResumeLayout(false);
            this._groupBox1.PerformLayout();
            this._groupBox4.ResumeLayout(false);
            this._g7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._spinnerControlBorderDepth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._spinnerControlBorderGap)).EndInit();
            this._groupBox6.ResumeLayout(false);
            this._groupBox7.ResumeLayout(false);
            this._groupBox7.PerformLayout();
            this.ResumeLayout(false);

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.Run(new BinaryDatePickerDemoApplication());
        }
    }
}
