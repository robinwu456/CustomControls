using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.BinaryButtonSuite;
using Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.Popups;
using Binarymission.WinForms.Controls.TextControls;

namespace BinaryToolTipDemo
{
    /// <summary>
    /// Summary description for ToolTipDemoForm
    /// </summary>
    public class ToolTipDemoForm : ModernChromeWindow
    {
        private void HandleExtendedStandardRenderingStyleChanged(object sender, EventArgs e)
        {
            if (_chkExtendedStandardRenderingStyle.Checked)
            {
                _binaryToolTip1.SetBinaryToolTipStyle(_btnTestButton, BinaryToolTipStyle.Standard);
                _binaryToolTip1.SetBinaryToolTipStyle(_txttextBox1, BinaryToolTipStyle.Standard);
                _nudnumericUpDown4.Enabled = false;
            }
            else
            {
                _binaryToolTip1.SetBinaryToolTipStyle(_btnTestButton, BinaryToolTipStyle.BalloonType);
                _binaryToolTip1.SetBinaryToolTipStyle(_txttextBox1, BinaryToolTipStyle.BalloonType);
                _nudnumericUpDown4.Enabled = true;
            }
        }

        private void HandleExtendedBaloonRenderingStyleChanged(object sender, EventArgs e)
        {
            if (_chkBaloonStyleRenderingStyle.Checked)
            {
                _binaryToolTip1.SetBinaryToolTipStyle(_btnTestButton, BinaryToolTipStyle.BalloonType);
                _binaryToolTip1.SetBinaryToolTipStyle(_txttextBox1, BinaryToolTipStyle.BalloonType);
                _nudnumericUpDown4.Enabled = true;
            }
            else
            {
                _binaryToolTip1.SetBinaryToolTipStyle(_btnTestButton, BinaryToolTipStyle.Standard);
                _binaryToolTip1.SetBinaryToolTipStyle(_txttextBox1, BinaryToolTipStyle.Standard);
                _nudnumericUpDown4.Enabled = false;
            }
        }

        private void SetupTooltipBorderColour(object sender, EventArgs e)
        {
            if (_ocolor.ShowDialog(this) != DialogResult.Cancel)
            {
                _binaryToolTip1.BorderColor = _ocolor.Color;
                _binaryPointTip1.BorderColor = _ocolor.Color;
            }
        }

        private void SetupTooltipBackColour(object sender, EventArgs e)
        {
            if (_ocolor.ShowDialog(this) != DialogResult.Cancel)
            {
                _binaryToolTip1.BackColor = _ocolor.Color;
                _binaryPointTip1.BackColor = _ocolor.Color;
            }
        }

        private void SetupTooltipTitleForeColour(object sender, EventArgs e)
        {
            if (_ocolor.ShowDialog(this) != DialogResult.Cancel)
            {
                _binaryToolTip1.TitleForeColor = _ocolor.Color;
                _binaryPointTip1.TitleForeColor = _ocolor.Color;
            }
        }

        private void SetupTooltipTextForeColour(object sender, EventArgs e)
        {
            if (_ocolor.ShowDialog(this) != DialogResult.Cancel)
            {
                _binaryToolTip1.TextForeColor = _ocolor.Color;
                _binaryPointTip1.TextForeColor = _ocolor.Color;
            }
        }

        private void SetupToolTipTextFont(object sender, EventArgs e)
        {
            if (_ofont.ShowDialog(this) != DialogResult.Cancel)
            {
                _binaryToolTip1.ToolTipTextFont = _ofont.Font;
                _binaryPointTip1.ToolTipTextFont = _ofont.Font;
            }
        }

        private void HandleTooltipTitleBoldFontChanged(object sender, EventArgs e)
        {
            if (_chkIsTooltipTitleBoldFont.Checked)
            {
                _binaryToolTip1.TitleWillBeBold = true;
                _binaryPointTip1.TitleWillBeBold = true;
            }
            else
            {
                _binaryToolTip1.TitleWillBeBold = false;
                _binaryPointTip1.TitleWillBeBold = false;
            }
        }

        private void HandleTooltipTitleUnderlineFontChanged(object sender, EventArgs e)
        {
            if (_chkHandleTooltipTitleUnderlineAspect.Checked)
            {
                _binaryToolTip1.TitleWillBeUnderlined = true;
                _binaryPointTip1.TitleWillBeUnderlined = true;
            }
            else
            {
                _binaryToolTip1.TitleWillBeUnderlined = false;
                _binaryPointTip1.TitleWillBeUnderlined = false;
            }
        }

        private void SetupTooltipImage(object sender, EventArgs e)
        {
            _ofile.Filter = "Image Files(*.BMP;*.JPG;*.GIF)|*.BMP;*.JPG;*.GIF|All files (*.*)|*.*";
            _ofile.InitialDirectory = ".";

            if (_ofile.ShowDialog(this) == DialogResult.Cancel) return;

            _txttextBox2.Text = _ofile.FileName;
            var bmp = new Bitmap(_ofile.FileName);
            _binaryToolTip1.SetBinaryToolTipIcon(_btnTestButton, bmp);
            _binaryToolTip1.SetBinaryToolTipIcon(_txttextBox1, bmp);
            _binaryPointTip1.Image = bmp;
        }

        private void HandleApplicationExiitRequested(object sender, EventArgs e)
        {
            Close();
        }

        private void FormLoaded(object sender, EventArgs e)
        {
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
            _binaryToolTip1.SetBinaryToolTipTitle(_btnTestButton, _tooltitle.Text);
            _binaryToolTip1.SetBinaryToolTipTitle(_txttextBox1, _tooltitle.Text);
            _binaryToolTip1.SetBinaryToolTipText(_btnTestButton, _tooltext.Text);
            _binaryToolTip1.SetBinaryToolTipText(_txttextBox1, _tooltext.Text);
        }

        private void HandleTooltipTitleChanged(object sender, EventArgs e)
        {
            _binaryToolTip1.SetBinaryToolTipTitle(_btnTestButton, _tooltitle.Text);
            _binaryToolTip1.SetBinaryToolTipTitle(_txttextBox1, _tooltitle.Text);
        }

        private void HandleTooltipBodyTextChanged(object sender, EventArgs e)
        {
            _binaryToolTip1.SetBinaryToolTipText(_btnTestButton, _tooltext.Text);
            _binaryToolTip1.SetBinaryToolTipText(_txttextBox1, _tooltext.Text);
        }

        private void HandleTooltipDropShadowOffsetXValueChanged(object sender, EventArgs e)
        {
            var ptx = Convert.ToInt32(_nudnumericUpDown1.Value);
            var pt = new Point(ptx, _binaryToolTip1.ShadowOffset.Y);
            _binaryToolTip1.ShadowOffset = pt;
            _binaryPointTip1.ShadowOffset = pt;
        }

        private void HandleTooltipDropShadowOffsetYValueChanged(object sender, EventArgs e)
        {
            var pty = Convert.ToInt32(_nudnumericUpDown2.Value);
            var pt = new Point(_binaryToolTip1.ShadowOffset.X, pty);
            _binaryToolTip1.ShadowOffset = pt;
            _binaryPointTip1.ShadowOffset = pt;
        }

        private void HandleTooltipHideDelayChanged(object sender, EventArgs e)
        {
            _binaryToolTip1.ToolTipHideDelay = Convert.ToInt32(_nudnumericUpDown3.Value);
        }

        private void HandleTooltipBaloonEdgeCurveFactorChanged(object sender, EventArgs e)
        {
            _binaryToolTip1.BalloonEdgeCurveFactor = Convert.ToInt32(_nudnumericUpDown4.Value);
            _binaryPointTip1.BalloonEdgeCurveFactor = Convert.ToInt32(_nudnumericUpDown4.Value);
        }

        private void HandleTooltipCustomWidthChanged(object sender, EventArgs e)
        {
            _binaryToolTip1.CustomWidth = Convert.ToInt32(_customwidth.Value);
            _binaryPointTip1.CustomWidth = Convert.ToInt32(_customwidth.Value);
        }

        private void HandleTooltipAutomaticMultilineRenderingSetupChanged(object sender, EventArgs e)
        {
            if (_enableMultiline.Checked)
            {
                _binaryToolTip1.AutomaticMultiLineSupport = true;
                _binaryPointTip1.AutomaticMultiLineSupport = true;
                _customwidth.Enabled = true;
            }
            else
            {
                _binaryToolTip1.AutomaticMultiLineSupport = false;
                _binaryPointTip1.AutomaticMultiLineSupport = false;
                _customwidth.Enabled = false;
            }
        }

        private void DisplayPointTooltipAtDeterministicLocation(object sender, EventArgs e)
        {
            var px = Convert.ToInt32(_textBox1.Text);
            var py = Convert.ToInt32(_textBox2.Text);
            _binaryPointTip1.Show(_tooltitle.Text,
                                    _tooltext.Text,
                                    PointToScreen(new Point(py, px)),
                                    (float)(_nudnumericUpDown3.Value),
                                    _binaryPointTip1.Image,
                                    (_chkExtendedStandardRenderingStyle.Checked) ? BinaryToolTipStyle.Standard : BinaryToolTipStyle.BalloonType);
        }
        
        private void PerformPointTooltipHideUponMouseMove(object sender, EventArgs e)
        {
            _binaryPointTip1.Hide();
        }

        #region Infrastructure bits

        private GroupBox _grpgroupBox1;
        private BinaryExtendedText _txttextBox1;
        private BinaryToolTip _binaryToolTip1;
        private GroupBox _grpgroupBox2;
        private GroupBox _grpgroupBox3;
        private ExtendedRadioButton _chkExtendedStandardRenderingStyle;
        private ExtendedRadioButton _chkBaloonStyleRenderingStyle;
        private GroupBox _grpgroupBox4;
        private SmartButton _btnbutton2;
        private SmartButton _btnbutton3;
        private SmartButton _btnbutton4;
        private SmartButton _btnbutton5;
        private GroupBox _grpgroupBox5;
        private SmartButton _btnbutton6;
        private ExtendedCheckBox _chkIsTooltipTitleBoldFont;
        private ExtendedCheckBox _chkHandleTooltipTitleUnderlineAspect;
        private Label _lbllabel1;
        private BinaryExtendedText _txttextBox2;
        private SmartButton _btnbutton7;
        private SmartButton _btnbutton9;
        private OpenFileDialog _ofile;
        private FontDialog _ofont;
        private ColorDialog _ocolor;
        private GroupBox _grpgroupBox6;
        private Label _lbllabel2;
        private Label _label1;
        private BinaryExtendedText _tooltitle;
        private BinaryExtendedText _tooltext;
        private Label _lbllabel3;
        private Label _lbllabel4;
        private Label _lbllabel5;
        private Label _lbllabel6;
        private NumericUpDown _nudnumericUpDown3;
        private Label _lbllabel7;
        private NumericUpDown _nudnumericUpDown4;
        private BinaryPointTip _binaryPointTip1;
        private GroupBox _groupBox1;
        private Label _label2;
        private Label _label3;
        private Label _label4;
        private GroupBox _groupBox2;
        private Label _label5;
        private NumericUpDown _customwidth;
        private ExtendedCheckBox _enableMultiline;
        private BinaryExtendedText _textBox1;
        private BinaryExtendedText _textBox2;
        private SmartButton _button1;
        private NumericUpDown _nudnumericUpDown2;
        private NumericUpDown _nudnumericUpDown1;
        private SmartButton _btnTestButton;
        private IContainer components;

        public ToolTipDemoForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new Container();
            var resources = new ComponentResourceManager(typeof(ToolTipDemoForm));
            _grpgroupBox1 = new GroupBox();
            _btnTestButton = new SmartButton();
            _txttextBox1 = new BinaryExtendedText();
            _binaryToolTip1 = new BinaryToolTip(components);
            _grpgroupBox2 = new GroupBox();
            _groupBox2 = new GroupBox();
            _customwidth = new NumericUpDown();
            _label5 = new Label();
            _enableMultiline = new ExtendedCheckBox();
            _nudnumericUpDown4 = new NumericUpDown();
            _lbllabel7 = new Label();
            _nudnumericUpDown3 = new NumericUpDown();
            _lbllabel6 = new Label();
            _nudnumericUpDown2 = new NumericUpDown();
            _nudnumericUpDown1 = new NumericUpDown();
            _lbllabel5 = new Label();
            _lbllabel4 = new Label();
            _lbllabel3 = new Label();
            _btnbutton7 = new SmartButton();
            _txttextBox2 = new BinaryExtendedText();
            _lbllabel1 = new Label();
            _grpgroupBox5 = new GroupBox();
            _chkHandleTooltipTitleUnderlineAspect = new ExtendedCheckBox();
            _chkIsTooltipTitleBoldFont = new ExtendedCheckBox();
            _btnbutton6 = new SmartButton();
            _grpgroupBox4 = new GroupBox();
            _btnbutton5 = new SmartButton();
            _btnbutton4 = new SmartButton();
            _btnbutton3 = new SmartButton();
            _btnbutton2 = new SmartButton();
            _grpgroupBox3 = new GroupBox();
            _chkBaloonStyleRenderingStyle = new ExtendedRadioButton();
            _chkExtendedStandardRenderingStyle = new ExtendedRadioButton();
            _btnbutton9 = new SmartButton();
            _grpgroupBox6 = new GroupBox();
            _groupBox1 = new GroupBox();
            _button1 = new SmartButton();
            _textBox2 = new BinaryExtendedText();
            _textBox1 = new BinaryExtendedText();
            _label2 = new Label();
            _label3 = new Label();
            _label4 = new Label();
            _tooltext = new BinaryExtendedText();
            _label1 = new Label();
            _tooltitle = new BinaryExtendedText();
            _lbllabel2 = new Label();
            _ofile = new System.Windows.Forms.OpenFileDialog();
            _ofont = new FontDialog();
            _ocolor = new ColorDialog();
            _binaryPointTip1 = new BinaryPointTip(components);
            _grpgroupBox1.SuspendLayout();
            _grpgroupBox2.SuspendLayout();
            _groupBox2.SuspendLayout();
            ((ISupportInitialize)(_customwidth)).BeginInit();
            ((ISupportInitialize)(_nudnumericUpDown4)).BeginInit();
            ((ISupportInitialize)(_nudnumericUpDown3)).BeginInit();
            ((ISupportInitialize)(_nudnumericUpDown2)).BeginInit();
            ((ISupportInitialize)(_nudnumericUpDown1)).BeginInit();
            _grpgroupBox5.SuspendLayout();
            _grpgroupBox4.SuspendLayout();
            _grpgroupBox3.SuspendLayout();
            _grpgroupBox6.SuspendLayout();
            _groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // _grpgroupBox1
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_grpgroupBox1, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_grpgroupBox1, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_grpgroupBox1, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_grpgroupBox1, "");
            _grpgroupBox1.Controls.Add(_btnTestButton);
            _grpgroupBox1.Controls.Add(_txttextBox1);
            _grpgroupBox1.Location = new System.Drawing.Point(8, 8);
            _grpgroupBox1.Name = "_grpgroupBox1";
            _grpgroupBox1.Size = new System.Drawing.Size(264, 128);
            _grpgroupBox1.TabIndex = 0;
            _grpgroupBox1.TabStop = false;
            _grpgroupBox1.Text = "BinaryToolTip .NET enabled controls";
            // 
            // _btnTestButton
            // 
            _btnTestButton.BackColor = Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            _binaryToolTip1.SetBinaryToolTipIcon(_btnTestButton, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_btnTestButton, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_btnTestButton, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_btnTestButton, "");
            _btnTestButton.BorderColor = Color.Black;
            _btnTestButton.ContextMenuProperties.MenuItemBackgroundColor = SystemColors.Menu;
            _btnTestButton.ContextMenuProperties.MenuItemBorderColor = SystemColors.ControlText;
            _btnTestButton.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            _btnTestButton.ContextMenuProperties.MenuItemSelectionColor = Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            _btnTestButton.ContextMenuProperties.MenuSideBarRenderingColor = SystemColors.Control;
            _btnTestButton.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            _btnTestButton.ContextMenuProperties.UseGradientPainting = true;
            _btnTestButton.DefaultTheme = true;
            _btnTestButton.DialogResult = System.Windows.Forms.DialogResult.None;
            _btnTestButton.DrawMenuButtonSeparator = true;
            _btnTestButton.DropDownArrowMarkColor = Color.RoyalBlue;
            _btnTestButton.DropDownMenuItems = null;
            _btnTestButton.EndColor = Color.White;
            _btnTestButton.IsRenderingTheme = true;
            _btnTestButton.LinearGradientRenderingAngle = 90F;
            _btnTestButton.Location = new System.Drawing.Point(15, 29);
            _btnTestButton.MenuButtonSeparatorColor = Color.Blue;
            _btnTestButton.MenuButtonSeparatorLineHeight = -1;
            _btnTestButton.Name = "_btnTestButton";
            _btnTestButton.PushedEndColor = Color.Silver;
            _btnTestButton.PushedStartColor = Color.White;
            _btnTestButton.Size = new System.Drawing.Size(234, 51);
            _btnTestButton.StartColor = Color.Silver;
            _btnTestButton.TabIndex = 2;
            _btnTestButton.Text = "binarySmartButton1";
            _btnTestButton.TextStringFormat = null;
            _btnTestButton.TransparentColor = Color.Empty;
            _btnTestButton.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            _btnTestButton.UseCustomTextStringFormat = false;
            _btnTestButton.UseUserDefinedColorForArrowMark = true;
            _btnTestButton.UseUserDefinedColorForMenuButtonSeparator = true;
            _btnTestButton.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            // 
            // _txttextBox1
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_txttextBox1, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_txttextBox1, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_txttextBox1, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_txttextBox1, "");
            _txttextBox1.Location = new System.Drawing.Point(16, 96);
            _txttextBox1.Name = "_txttextBox1";
            _txttextBox1.Size = new System.Drawing.Size(232, 20);
            _txttextBox1.TabIndex = 1;
            _txttextBox1.Text = "Test edit box";
            // 
            // _binaryToolTip1
            // 
            _binaryToolTip1.AutomaticMultiLineSupport = true;
            _binaryToolTip1.BackColor = Color.LightYellow;
            _binaryToolTip1.BalloonEdgeCurveFactor = 15;
            _binaryToolTip1.BorderColor = Color.Green;
            _binaryToolTip1.CustomWidth = 100;
            _binaryToolTip1.ShadowOffset = new System.Drawing.Point(7, 7);
            _binaryToolTip1.TextForeColor = Color.Green;
            _binaryToolTip1.TitleForeColor = Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            _binaryToolTip1.TitleWillBeBold = true;
            _binaryToolTip1.TitleWillBeUnderlined = false;
            _binaryToolTip1.ToolTipTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            // 
            // _grpgroupBox2
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_grpgroupBox2, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_grpgroupBox2, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_grpgroupBox2, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_grpgroupBox2, "");
            _grpgroupBox2.Controls.Add(_groupBox2);
            _grpgroupBox2.Controls.Add(_nudnumericUpDown4);
            _grpgroupBox2.Controls.Add(_lbllabel7);
            _grpgroupBox2.Controls.Add(_nudnumericUpDown3);
            _grpgroupBox2.Controls.Add(_lbllabel6);
            _grpgroupBox2.Controls.Add(_nudnumericUpDown2);
            _grpgroupBox2.Controls.Add(_nudnumericUpDown1);
            _grpgroupBox2.Controls.Add(_lbllabel5);
            _grpgroupBox2.Controls.Add(_lbllabel4);
            _grpgroupBox2.Controls.Add(_lbllabel3);
            _grpgroupBox2.Controls.Add(_btnbutton7);
            _grpgroupBox2.Controls.Add(_txttextBox2);
            _grpgroupBox2.Controls.Add(_lbllabel1);
            _grpgroupBox2.Controls.Add(_grpgroupBox5);
            _grpgroupBox2.Controls.Add(_grpgroupBox4);
            _grpgroupBox2.Controls.Add(_grpgroupBox3);
            _grpgroupBox2.Location = new System.Drawing.Point(280, 8);
            _grpgroupBox2.Name = "_grpgroupBox2";
            _grpgroupBox2.Size = new System.Drawing.Size(432, 496);
            _grpgroupBox2.TabIndex = 1;
            _grpgroupBox2.TabStop = false;
            _grpgroupBox2.Text = "BinaryToolTip .NET properties";
            // 
            // _groupBox2
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_groupBox2, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_groupBox2, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_groupBox2, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_groupBox2, "");
            _groupBox2.Controls.Add(_customwidth);
            _groupBox2.Controls.Add(_label5);
            _groupBox2.Controls.Add(_enableMultiline);
            _groupBox2.Location = new System.Drawing.Point(16, 416);
            _groupBox2.Name = "_groupBox2";
            _groupBox2.Size = new System.Drawing.Size(408, 72);
            _groupBox2.TabIndex = 15;
            _groupBox2.TabStop = false;
            _groupBox2.Text = "Multiline tooltip properties";
            // 
            // _customwidth
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_customwidth, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_customwidth, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_customwidth, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_customwidth, "");
            _customwidth.Location = new System.Drawing.Point(336, 32);
            _customwidth.Maximum = new decimal(new int[] {
            550,
            0,
            0,
            0});
            _customwidth.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            _customwidth.Name = "_customwidth";
            _customwidth.Size = new System.Drawing.Size(64, 20);
            _customwidth.TabIndex = 2;
            _customwidth.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            _customwidth.ValueChanged += new EventHandler(HandleTooltipCustomWidthChanged);
            // 
            // _label5
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_label5, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_label5, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_label5, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_label5, "");
            _label5.Location = new System.Drawing.Point(184, 32);
            _label5.Name = "_label5";
            _label5.Size = new System.Drawing.Size(152, 16);
            _label5.TabIndex = 1;
            _label5.Text = "Custom Tooltip widow width :";
            // 
            // _enableMultiline
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_enableMultiline, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_enableMultiline, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_enableMultiline, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_enableMultiline, "");
            _enableMultiline.Checked = true;
            _enableMultiline.CheckState = System.Windows.Forms.CheckState.Checked;
            _enableMultiline.Location = new System.Drawing.Point(8, 24);
            _enableMultiline.Name = "_enableMultiline";
            _enableMultiline.Size = new System.Drawing.Size(160, 40);
            _enableMultiline.TabIndex = 0;
            _enableMultiline.Text = "Enable Automatic multiline tooltips";
            _enableMultiline.CheckedChanged += new EventHandler(HandleTooltipAutomaticMultilineRenderingSetupChanged);
            // 
            // _nudnumericUpDown4
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_nudnumericUpDown4, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_nudnumericUpDown4, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_nudnumericUpDown4, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_nudnumericUpDown4, "");
            _nudnumericUpDown4.Enabled = false;
            _nudnumericUpDown4.Location = new System.Drawing.Point(352, 384);
            _nudnumericUpDown4.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            _nudnumericUpDown4.Name = "_nudnumericUpDown4";
            _nudnumericUpDown4.Size = new System.Drawing.Size(56, 20);
            _nudnumericUpDown4.TabIndex = 14;
            _nudnumericUpDown4.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            _nudnumericUpDown4.ValueChanged += new EventHandler(HandleTooltipBaloonEdgeCurveFactorChanged);
            // 
            // _lbllabel7
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_lbllabel7, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_lbllabel7, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_lbllabel7, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_lbllabel7, "");
            _lbllabel7.Location = new System.Drawing.Point(240, 386);
            _lbllabel7.Name = "_lbllabel7";
            _lbllabel7.Size = new System.Drawing.Size(104, 16);
            _lbllabel7.TabIndex = 13;
            _lbllabel7.Text = "Edge Curve factor:";
            // 
            // _nudnumericUpDown3
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_nudnumericUpDown3, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_nudnumericUpDown3, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_nudnumericUpDown3, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_nudnumericUpDown3, "");
            _nudnumericUpDown3.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            _nudnumericUpDown3.Location = new System.Drawing.Point(136, 384);
            _nudnumericUpDown3.Maximum = new decimal(new int[] {
            50000,
            0,
            0,
            0});
            _nudnumericUpDown3.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            _nudnumericUpDown3.Name = "_nudnumericUpDown3";
            _nudnumericUpDown3.Size = new System.Drawing.Size(80, 20);
            _nudnumericUpDown3.TabIndex = 12;
            _nudnumericUpDown3.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            _nudnumericUpDown3.TextChanged += new EventHandler(HandleTooltipHideDelayChanged);
            _nudnumericUpDown3.ValueChanged += new EventHandler(HandleTooltipHideDelayChanged);
            // 
            // _lbllabel6
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_lbllabel6, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_lbllabel6, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_lbllabel6, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_lbllabel6, "");
            _lbllabel6.Location = new System.Drawing.Point(16, 384);
            _lbllabel6.Name = "_lbllabel6";
            _lbllabel6.Size = new System.Drawing.Size(112, 16);
            _lbllabel6.TabIndex = 11;
            _lbllabel6.Text = "Tooltip Hide delay:";
            // 
            // _nudnumericUpDown2
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_nudnumericUpDown2, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_nudnumericUpDown2, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_nudnumericUpDown2, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_nudnumericUpDown2, "");
            _nudnumericUpDown2.Location = new System.Drawing.Point(264, 350);
            _nudnumericUpDown2.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            _nudnumericUpDown2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            _nudnumericUpDown2.Name = "_nudnumericUpDown2";
            _nudnumericUpDown2.Size = new System.Drawing.Size(56, 20);
            _nudnumericUpDown2.TabIndex = 10;
            _nudnumericUpDown2.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            _nudnumericUpDown2.TextChanged += new EventHandler(HandleTooltipDropShadowOffsetYValueChanged);
            _nudnumericUpDown2.ValueChanged += new EventHandler(HandleTooltipDropShadowOffsetYValueChanged);
            // 
            // _nudnumericUpDown1
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_nudnumericUpDown1, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_nudnumericUpDown1, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_nudnumericUpDown1, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_nudnumericUpDown1, "");
            _nudnumericUpDown1.Location = new System.Drawing.Point(176, 350);
            _nudnumericUpDown1.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            _nudnumericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            _nudnumericUpDown1.Name = "_nudnumericUpDown1";
            _nudnumericUpDown1.Size = new System.Drawing.Size(56, 20);
            _nudnumericUpDown1.TabIndex = 9;
            _nudnumericUpDown1.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            _nudnumericUpDown1.TextChanged += new EventHandler(HandleTooltipDropShadowOffsetXValueChanged);
            _nudnumericUpDown1.ValueChanged += new EventHandler(HandleTooltipDropShadowOffsetXValueChanged);
            // 
            // _lbllabel5
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_lbllabel5, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_lbllabel5, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_lbllabel5, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_lbllabel5, "");
            _lbllabel5.Location = new System.Drawing.Point(240, 352);
            _lbllabel5.Name = "_lbllabel5";
            _lbllabel5.Size = new System.Drawing.Size(16, 16);
            _lbllabel5.TabIndex = 8;
            _lbllabel5.Text = "Y:";
            // 
            // _lbllabel4
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_lbllabel4, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_lbllabel4, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_lbllabel4, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_lbllabel4, "");
            _lbllabel4.Location = new System.Drawing.Point(152, 352);
            _lbllabel4.Name = "_lbllabel4";
            _lbllabel4.Size = new System.Drawing.Size(16, 16);
            _lbllabel4.TabIndex = 7;
            _lbllabel4.Text = "X:";
            // 
            // _lbllabel3
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_lbllabel3, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_lbllabel3, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_lbllabel3, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_lbllabel3, "");
            _lbllabel3.Location = new System.Drawing.Point(16, 352);
            _lbllabel3.Name = "_lbllabel3";
            _lbllabel3.Size = new System.Drawing.Size(120, 16);
            _lbllabel3.TabIndex = 6;
            _lbllabel3.Text = "Drop Shadow offset:";
            // 
            // _btnbutton7
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_btnbutton7, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_btnbutton7, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_btnbutton7, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_btnbutton7, "");
            _btnbutton7.Location = new System.Drawing.Point(400, 320);
            _btnbutton7.Name = "_btnbutton7";
            _btnbutton7.Size = new System.Drawing.Size(20, 20);
            _btnbutton7.TabIndex = 5;
            _btnbutton7.Text = "...";
            _btnbutton7.Click += new EventHandler(SetupTooltipImage);
            // 
            // _txttextBox2
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_txttextBox2, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_txttextBox2, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_txttextBox2, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_txttextBox2, "");
            _txttextBox2.Location = new System.Drawing.Point(128, 320);
            _txttextBox2.Name = "_txttextBox2";
            _txttextBox2.ReadOnly = true;
            _txttextBox2.Size = new System.Drawing.Size(272, 20);
            _txttextBox2.TabIndex = 4;
            // 
            // _lbllabel1
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_lbllabel1, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_lbllabel1, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_lbllabel1, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_lbllabel1, "");
            _lbllabel1.Location = new System.Drawing.Point(16, 320);
            _lbllabel1.Name = "_lbllabel1";
            _lbllabel1.Size = new System.Drawing.Size(104, 24);
            _lbllabel1.TabIndex = 3;
            _lbllabel1.Text = "Tooltip Title Image:";
            // 
            // _grpgroupBox5
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_grpgroupBox5, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_grpgroupBox5, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_grpgroupBox5, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_grpgroupBox5, "");
            _grpgroupBox5.Controls.Add(_chkHandleTooltipTitleUnderlineAspect);
            _grpgroupBox5.Controls.Add(_chkIsTooltipTitleBoldFont);
            _grpgroupBox5.Controls.Add(_btnbutton6);
            _grpgroupBox5.Location = new System.Drawing.Point(8, 200);
            _grpgroupBox5.Name = "_grpgroupBox5";
            _grpgroupBox5.Size = new System.Drawing.Size(416, 104);
            _grpgroupBox5.TabIndex = 2;
            _grpgroupBox5.TabStop = false;
            _grpgroupBox5.Text = "Font related properties";
            // 
            // chkHandleTooltipTitleUnderlineAspect
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_chkHandleTooltipTitleUnderlineAspect, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_chkHandleTooltipTitleUnderlineAspect, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_chkHandleTooltipTitleUnderlineAspect, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_chkHandleTooltipTitleUnderlineAspect, "");
            _chkHandleTooltipTitleUnderlineAspect.Location = new System.Drawing.Point(216, 64);
            _chkHandleTooltipTitleUnderlineAspect.Name = "_chkHandleTooltipTitleUnderlineAspect";
            _chkHandleTooltipTitleUnderlineAspect.Size = new System.Drawing.Size(192, 32);
            _chkHandleTooltipTitleUnderlineAspect.TabIndex = 3;
            _chkHandleTooltipTitleUnderlineAspect.Text = "Tooltip Title will be in Underlined";
            _chkHandleTooltipTitleUnderlineAspect.CheckedChanged += new EventHandler(HandleTooltipTitleUnderlineFontChanged);
            // 
            // chkIsTooltipTitleBoldFont
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_chkIsTooltipTitleBoldFont, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_chkIsTooltipTitleBoldFont, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_chkIsTooltipTitleBoldFont, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_chkIsTooltipTitleBoldFont, "");
            _chkIsTooltipTitleBoldFont.Checked = true;
            _chkIsTooltipTitleBoldFont.CheckState = System.Windows.Forms.CheckState.Checked;
            _chkIsTooltipTitleBoldFont.Location = new System.Drawing.Point(16, 64);
            _chkIsTooltipTitleBoldFont.Name = "_chkIsTooltipTitleBoldFont";
            _chkIsTooltipTitleBoldFont.Size = new System.Drawing.Size(184, 32);
            _chkIsTooltipTitleBoldFont.TabIndex = 2;
            _chkIsTooltipTitleBoldFont.Text = "Tooltip Title will be in Bold font";
            _chkIsTooltipTitleBoldFont.CheckedChanged += new EventHandler(HandleTooltipTitleBoldFontChanged);
            // 
            // _btnbutton6
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_btnbutton6, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_btnbutton6, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_btnbutton6, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_btnbutton6, "");
            _btnbutton6.Location = new System.Drawing.Point(16, 24);
            _btnbutton6.Name = "_btnbutton6";
            _btnbutton6.Size = new System.Drawing.Size(128, 32);
            _btnbutton6.TabIndex = 1;
            _btnbutton6.Text = "Tooltip Text font...";
            _btnbutton6.Click += new EventHandler(SetupToolTipTextFont);
            // 
            // _grpgroupBox4
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_grpgroupBox4, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_grpgroupBox4, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_grpgroupBox4, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_grpgroupBox4, "");
            _grpgroupBox4.Controls.Add(_btnbutton5);
            _grpgroupBox4.Controls.Add(_btnbutton4);
            _grpgroupBox4.Controls.Add(_btnbutton3);
            _grpgroupBox4.Controls.Add(_btnbutton2);
            _grpgroupBox4.Location = new System.Drawing.Point(8, 80);
            _grpgroupBox4.Name = "_grpgroupBox4";
            _grpgroupBox4.Size = new System.Drawing.Size(416, 112);
            _grpgroupBox4.TabIndex = 1;
            _grpgroupBox4.TabStop = false;
            _grpgroupBox4.Text = "Color related properties";
            // 
            // _btnbutton5
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_btnbutton5, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_btnbutton5, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_btnbutton5, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_btnbutton5, "");
            _btnbutton5.Location = new System.Drawing.Point(160, 64);
            _btnbutton5.Name = "_btnbutton5";
            _btnbutton5.Size = new System.Drawing.Size(128, 32);
            _btnbutton5.TabIndex = 3;
            _btnbutton5.Text = "Tooltip Text forecolor...";
            _btnbutton5.Click += new EventHandler(SetupTooltipTextForeColour);
            // 
            // _btnbutton4
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_btnbutton4, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_btnbutton4, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_btnbutton4, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_btnbutton4, "");
            _btnbutton4.Location = new System.Drawing.Point(16, 64);
            _btnbutton4.Name = "_btnbutton4";
            _btnbutton4.Size = new System.Drawing.Size(128, 32);
            _btnbutton4.TabIndex = 2;
            _btnbutton4.Text = "Tooltip Title forecolor...";
            _btnbutton4.Click += new EventHandler(SetupTooltipTitleForeColour);
            // 
            // _btnbutton3
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_btnbutton3, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_btnbutton3, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_btnbutton3, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_btnbutton3, "");
            _btnbutton3.Location = new System.Drawing.Point(160, 24);
            _btnbutton3.Name = "_btnbutton3";
            _btnbutton3.Size = new System.Drawing.Size(128, 32);
            _btnbutton3.TabIndex = 1;
            _btnbutton3.Text = "Tooltip backcolor...";
            _btnbutton3.Click += new EventHandler(SetupTooltipBackColour);
            // 
            // _btnbutton2
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_btnbutton2, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_btnbutton2, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_btnbutton2, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_btnbutton2, "");
            _btnbutton2.Location = new System.Drawing.Point(16, 24);
            _btnbutton2.Name = "_btnbutton2";
            _btnbutton2.Size = new System.Drawing.Size(128, 32);
            _btnbutton2.TabIndex = 0;
            _btnbutton2.Text = "Tooltip Border color...";
            _btnbutton2.Click += new EventHandler(SetupTooltipBorderColour);
            // 
            // _grpgroupBox3
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_grpgroupBox3, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_grpgroupBox3, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_grpgroupBox3, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_grpgroupBox3, "");
            _grpgroupBox3.Controls.Add(_chkBaloonStyleRenderingStyle);
            _grpgroupBox3.Controls.Add(_chkExtendedStandardRenderingStyle);
            _grpgroupBox3.Location = new System.Drawing.Point(8, 24);
            _grpgroupBox3.Name = "_grpgroupBox3";
            _grpgroupBox3.Size = new System.Drawing.Size(416, 48);
            _grpgroupBox3.TabIndex = 0;
            _grpgroupBox3.TabStop = false;
            _grpgroupBox3.Text = "BinaryToolTip Style";
            // 
            // chkBaloonStyleRenderingStyle
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_chkBaloonStyleRenderingStyle, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_chkBaloonStyleRenderingStyle, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_chkBaloonStyleRenderingStyle, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_chkBaloonStyleRenderingStyle, "");
            _chkBaloonStyleRenderingStyle.Location = new System.Drawing.Point(280, 16);
            _chkBaloonStyleRenderingStyle.Name = "_chkBaloonStyleRenderingStyle";
            _chkBaloonStyleRenderingStyle.Size = new System.Drawing.Size(104, 24);
            _chkBaloonStyleRenderingStyle.TabIndex = 1;
            _chkBaloonStyleRenderingStyle.Text = "Balloon style";
            _chkBaloonStyleRenderingStyle.CheckedChanged += new EventHandler(HandleExtendedBaloonRenderingStyleChanged);
            // 
            // chkExtendedStandardRenderingStyle
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_chkExtendedStandardRenderingStyle, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_chkExtendedStandardRenderingStyle, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_chkExtendedStandardRenderingStyle, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_chkExtendedStandardRenderingStyle, "");
            _chkExtendedStandardRenderingStyle.Checked = true;
            _chkExtendedStandardRenderingStyle.Location = new System.Drawing.Point(16, 16);
            _chkExtendedStandardRenderingStyle.Name = "_chkExtendedStandardRenderingStyle";
            _chkExtendedStandardRenderingStyle.Size = new System.Drawing.Size(152, 24);
            _chkExtendedStandardRenderingStyle.TabIndex = 0;
            _chkExtendedStandardRenderingStyle.TabStop = true;
            _chkExtendedStandardRenderingStyle.Text = "Extended Standard style";
            _chkExtendedStandardRenderingStyle.CheckedChanged += new EventHandler(HandleExtendedStandardRenderingStyleChanged);
            // 
            // _btnbutton9
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_btnbutton9, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_btnbutton9, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_btnbutton9, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_btnbutton9, "");
            _btnbutton9.Location = new System.Drawing.Point(624, 523);
            _btnbutton9.Name = "_btnbutton9";
            _btnbutton9.Size = new System.Drawing.Size(88, 32);
            _btnbutton9.TabIndex = 3;
            _btnbutton9.Text = "E&xit";
            _btnbutton9.Click += new EventHandler(HandleApplicationExiitRequested);
            // 
            // _grpgroupBox6
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_grpgroupBox6, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_grpgroupBox6, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_grpgroupBox6, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_grpgroupBox6, "");
            _grpgroupBox6.Controls.Add(_groupBox1);
            _grpgroupBox6.Controls.Add(_tooltext);
            _grpgroupBox6.Controls.Add(_label1);
            _grpgroupBox6.Controls.Add(_tooltitle);
            _grpgroupBox6.Controls.Add(_lbllabel2);
            _grpgroupBox6.Location = new System.Drawing.Point(8, 152);
            _grpgroupBox6.Name = "_grpgroupBox6";
            _grpgroupBox6.Size = new System.Drawing.Size(264, 352);
            _grpgroupBox6.TabIndex = 5;
            _grpgroupBox6.TabStop = false;
            _grpgroupBox6.Text = "Tooltip Title/Text";
            // 
            // _groupBox1
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_groupBox1, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_groupBox1, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_groupBox1, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_groupBox1, "");
            _groupBox1.Controls.Add(_button1);
            _groupBox1.Controls.Add(_textBox2);
            _groupBox1.Controls.Add(_textBox1);
            _groupBox1.Controls.Add(_label2);
            _groupBox1.Controls.Add(_label3);
            _groupBox1.Controls.Add(_label4);
            _groupBox1.Location = new System.Drawing.Point(16, 240);
            _groupBox1.Name = "_groupBox1";
            _groupBox1.Size = new System.Drawing.Size(232, 96);
            _groupBox1.TabIndex = 16;
            _groupBox1.TabStop = false;
            _groupBox1.Text = "BinaryPointTip Demo";
            // 
            // _button1
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_button1, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_button1, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_button1, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_button1, "");
            _button1.Location = new System.Drawing.Point(160, 50);
            _button1.Name = "_button1";
            _button1.Size = new System.Drawing.Size(64, 24);
            _button1.TabIndex = 21;
            _button1.Text = "Show";
            _button1.Click += new EventHandler(DisplayPointTooltipAtDeterministicLocation);
            _button1.MouseLeave += new EventHandler(PerformPointTooltipHideUponMouseMove);
            // 
            // _textBox2
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_textBox2, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_textBox2, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_textBox2, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_textBox2, "");
            _textBox2.Location = new System.Drawing.Point(112, 52);
            _textBox2.MaxLength = 3;
            _textBox2.Name = "_textBox2";
            _textBox2.Size = new System.Drawing.Size(40, 20);
            _textBox2.TabIndex = 20;
            _textBox2.Text = "250";
            _textBox2.TextChanged += new EventHandler(DisplayPointTooltipAtDeterministicLocation);
            // 
            // _textBox1
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_textBox1, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_textBox1, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_textBox1, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_textBox1, "");
            _textBox1.Location = new System.Drawing.Point(32, 52);
            _textBox1.MaxLength = 3;
            _textBox1.Name = "_textBox1";
            _textBox1.Size = new System.Drawing.Size(40, 20);
            _textBox1.TabIndex = 19;
            _textBox1.Text = "150";
            _textBox1.TextChanged += new EventHandler(DisplayPointTooltipAtDeterministicLocation);
            // 
            // _label2
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_label2, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_label2, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_label2, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_label2, "");
            _label2.Location = new System.Drawing.Point(88, 54);
            _label2.Name = "_label2";
            _label2.Size = new System.Drawing.Size(16, 16);
            _label2.TabIndex = 18;
            _label2.Text = "Y:";
            // 
            // _label3
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_label3, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_label3, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_label3, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_label3, "");
            _label3.Location = new System.Drawing.Point(8, 54);
            _label3.Name = "_label3";
            _label3.Size = new System.Drawing.Size(16, 16);
            _label3.TabIndex = 17;
            _label3.Text = "X:";
            // 
            // _label4
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_label4, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_label4, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_label4, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_label4, "");
            _label4.Location = new System.Drawing.Point(8, 30);
            _label4.Name = "_label4";
            _label4.Size = new System.Drawing.Size(120, 16);
            _label4.TabIndex = 16;
            _label4.Text = "Point Tooltip position:";
            // 
            // _tooltext
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_tooltext, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_tooltext, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_tooltext, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_tooltext, "");
            _tooltext.Location = new System.Drawing.Point(17, 96);
            _tooltext.Multiline = true;
            _tooltext.Name = "_tooltext";
            _tooltext.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            _tooltext.Size = new System.Drawing.Size(232, 128);
            _tooltext.TabIndex = 3;
            _tooltext.Text = "BinaryToolTip .NET Version 2.0 - Sample Tooltip text.";
            _tooltext.TextChanged += new EventHandler(HandleTooltipBodyTextChanged);
            // 
            // _label1
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_label1, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_label1, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_label1, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_label1, "");
            _label1.Location = new System.Drawing.Point(15, 80);
            _label1.Name = "_label1";
            _label1.Size = new System.Drawing.Size(152, 16);
            _label1.TabIndex = 2;
            _label1.Text = "Tooltip Text:";
            // 
            // _tooltitle
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_tooltitle, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_tooltitle, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_tooltitle, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_tooltitle, "");
            _tooltitle.Location = new System.Drawing.Point(18, 42);
            _tooltitle.Name = "_tooltitle";
            _tooltitle.Size = new System.Drawing.Size(232, 20);
            _tooltitle.TabIndex = 1;
            _tooltitle.Text = "BinaryToolTip .NET Version 2.0";
            _tooltitle.TextChanged += new EventHandler(HandleTooltipTitleChanged);
            // 
            // _lbllabel2
            // 
            _binaryToolTip1.SetBinaryToolTipIcon(_lbllabel2, null);
            _binaryToolTip1.SetBinaryToolTipStyle(_lbllabel2, BinaryToolTipStyle.Standard);
            _binaryToolTip1.SetBinaryToolTipText(_lbllabel2, "");
            _binaryToolTip1.SetBinaryToolTipTitle(_lbllabel2, "");
            _lbllabel2.Location = new System.Drawing.Point(16, 24);
            _lbllabel2.Name = "_lbllabel2";
            _lbllabel2.Size = new System.Drawing.Size(152, 16);
            _lbllabel2.TabIndex = 0;
            _lbllabel2.Text = "Tooltip Title:";
            // 
            // _binaryPointTip1
            // 
            _binaryPointTip1.AutomaticMultiLineSupport = true;
            _binaryPointTip1.BackColor = Color.LightYellow;
            _binaryPointTip1.BalloonEdgeCurveFactor = 15;
            _binaryPointTip1.BorderColor = Color.Brown;
            _binaryPointTip1.CustomWidth = 200;
            _binaryPointTip1.Image = null;
            _binaryPointTip1.PointTipText = "Evaluation license!Test text";
            _binaryPointTip1.ShadowOffset = new System.Drawing.Point(7, 7);
            _binaryPointTip1.ShowDelay = 5F;
            _binaryPointTip1.TextForeColor = SystemColors.WindowText;
            _binaryPointTip1.TitleForeColor = SystemColors.WindowText;
            _binaryPointTip1.TitleWillBeBold = true;
            _binaryPointTip1.TitleWillBeUnderlined = false;
            _binaryPointTip1.ToolTipTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            // 
            // ToolTipDemoForm
            // 
            AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            BackColor = Color.White;
            BackgroundDisabledCloseCommandButton.Color = Color.SlateGray;
            BackgroundDisabledMaximizeRestoreCommandButton.Color = Color.SlateGray;
            BackgroundDisabledMinimizeCommandButton.Color = Color.SlateGray;
            BackgroundHotCloseCommandButton.Color = Color.SlateGray;
            BackgroundHotMaximizeRestoreCommandButton.Color = Color.SlateGray;
            BackgroundHotMinimizeCommandButton.Color = Color.SlateGray;
            BackgroundNormalCloseCommandButton.Color = Color.SlateGray;
            BackgroundNormalMaximizeRestoreCommandButton.Color = Color.SlateGray;
            BackgroundNormalMinimizeCommandButton.Color = Color.SlateGray;
            BackgroundPressedCloseCommandButton.Color = Color.SlateGray;
            BackgroundPressedMaximizeRestoreCommandButton.Color = Color.SlateGray;
            BackgroundPressedMinimizeCommandButton.Color = Color.SlateGray;
            ClientSize = new System.Drawing.Size(739, 606);
            Controls.Add(_grpgroupBox6);
            Controls.Add(_btnbutton9);
            Controls.Add(_grpgroupBox2);
            Controls.Add(_grpgroupBox1);
            DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            Name = "ToolTipDemoForm";
            WindowChromeTitleTextBrush.Color = Color.SlateGray;
            WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = Color.SlateGray;
            Load += new EventHandler(FormLoaded);
            _grpgroupBox1.ResumeLayout(false);
            _grpgroupBox1.PerformLayout();
            _grpgroupBox2.ResumeLayout(false);
            _grpgroupBox2.PerformLayout();
            _groupBox2.ResumeLayout(false);
            ((ISupportInitialize)(_customwidth)).EndInit();
            ((ISupportInitialize)(_nudnumericUpDown4)).EndInit();
            ((ISupportInitialize)(_nudnumericUpDown3)).EndInit();
            ((ISupportInitialize)(_nudnumericUpDown2)).EndInit();
            ((ISupportInitialize)(_nudnumericUpDown1)).EndInit();
            _grpgroupBox5.ResumeLayout(false);
            _grpgroupBox4.ResumeLayout(false);
            _grpgroupBox3.ResumeLayout(false);
            _grpgroupBox6.ResumeLayout(false);
            _grpgroupBox6.PerformLayout();
            _groupBox1.ResumeLayout(false);
            _groupBox1.PerformLayout();
            ResumeLayout(false);

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.Run(new ToolTipDemoForm());
        }

        #endregion Infrastructure bits
    }
}
