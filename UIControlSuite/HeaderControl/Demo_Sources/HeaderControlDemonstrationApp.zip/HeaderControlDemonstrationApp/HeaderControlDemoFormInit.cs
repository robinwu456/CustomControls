﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace HeaderControlDemonstrationApp
{
    public partial class HeaderControlDemoForm
    {
        private Binarymission.WinForms.Controls.NavigationControls.BinaryHeaderControl _binaryHeaderControl1;
        private Binarymission.WinForms.Controls.NavigationControls.BinaryScrollablePanel _binaryScrollablePanel1;
        private Binarymission.WinForms.Controls.NavigationControls.BinaryHeaderControl _binaryHeaderControl2;
        private Binarymission.WinForms.Controls.NavigationControls.BinaryScrollablePanel _binaryScrollablePanel2;
        private Label _label1;
        private Label _label2;
        private Label _label3;
        private Label _label4;
        private ContextMenuStrip _contextMenuStrip1;
        private ToolStripMenuItem _sampleCommand1ToolStripMenuItem;
        private ToolStripMenuItem _sampleCommand2ToolStripMenuItem;
        private Label _label5;
        private Label _label6;
        private Label _label7;
        private Label _label8;
        private System.ComponentModel.IContainer components;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeaderControlDemoForm));
            this._binaryHeaderControl1 = new Binarymission.WinForms.Controls.NavigationControls.BinaryHeaderControl();
            this._binaryScrollablePanel1 = new Binarymission.WinForms.Controls.NavigationControls.BinaryScrollablePanel();
            this._contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this._sampleCommand1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._sampleCommand2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._binaryHeaderControl2 = new Binarymission.WinForms.Controls.NavigationControls.BinaryHeaderControl();
            this._binaryScrollablePanel2 = new Binarymission.WinForms.Controls.NavigationControls.BinaryScrollablePanel();
            this._label1 = new System.Windows.Forms.Label();
            this._label2 = new System.Windows.Forms.Label();
            this._label3 = new System.Windows.Forms.Label();
            this._label4 = new System.Windows.Forms.Label();
            this._label5 = new System.Windows.Forms.Label();
            this._label6 = new System.Windows.Forms.Label();
            this._label7 = new System.Windows.Forms.Label();
            this._label8 = new System.Windows.Forms.Label();
            this._binaryHeaderControl1.SuspendLayout();
            this._contextMenuStrip1.SuspendLayout();
            this._binaryHeaderControl2.SuspendLayout();
            this.SuspendLayout();
            // 
            // _binaryHeaderControl1
            // 
            this._binaryHeaderControl1.BackgroundGradientDrawingDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this._binaryHeaderControl1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            this._binaryHeaderControl1.BorderWidth = 2;
            this._binaryHeaderControl1.ContextMenuArrowColor = System.Drawing.Color.Black;
            this._binaryHeaderControl1.ContextMenuEllipseColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(221)))), ((int)(((byte)(250)))));
            this._binaryHeaderControl1.ContextMenuImageType = Binarymission.WinForms.Controls.NavigationControls.ContextMenuButtonImageType.Default;
            this._binaryHeaderControl1.ContextMenuType = Binarymission.WinForms.Controls.NavigationControls.ContextMenuType.ContextMenuStrip;
            this._binaryHeaderControl1.ControlIsInExpandedState = true;
            this._binaryHeaderControl1.Controls.Add(this._binaryScrollablePanel1);
            this._binaryHeaderControl1.CustomContextMenuButtonImageTransparencyColor = System.Drawing.Color.Transparent;
            this._binaryHeaderControl1.CustomIconForContextMenuButton = null;
            this._binaryHeaderControl1.CustomImageForContextMenuButton = null;
            this._binaryHeaderControl1.DrawBorderAround = Binarymission.WinForms.Controls.NavigationControls.DrawBorderAround.HeaderAndFooter;
            this._binaryHeaderControl1.DrawFooter = true;
            this._binaryHeaderControl1.EnableCollapseExpandButton = false;
            this._binaryHeaderControl1.EnableHeaderContextMenu = true;
            this._binaryHeaderControl1.EndColorForBackgroundRendering = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(221)))), ((int)(((byte)(250)))));
            this._binaryHeaderControl1.EndColorForFooterRendering = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(221)))), ((int)(((byte)(250)))));
            this._binaryHeaderControl1.EndColorForHeaderRendering = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(221)))), ((int)(((byte)(250)))));
            this._binaryHeaderControl1.ExpandCollapseCircleFillColor = System.Drawing.SystemColors.Window;
            this._binaryHeaderControl1.ExpandCollapseUpDownArrowsFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(221)))), ((int)(((byte)(250)))));
            this._binaryHeaderControl1.FooterBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(221)))), ((int)(((byte)(250)))));
            this._binaryHeaderControl1.FooterBorderThickness = 2F;
            this._binaryHeaderControl1.FooterCaptionFont = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._binaryHeaderControl1.FooterCaptionHeight = 26;
            this._binaryHeaderControl1.FooterGradientDrawingDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this._binaryHeaderControl1.FooterText = "Sample footer note";
            this._binaryHeaderControl1.FooterTextForeColor = System.Drawing.Color.Black;
            this._binaryHeaderControl1.HeaderBitmapTransparencyColor = System.Drawing.Color.Transparent;
            this._binaryHeaderControl1.HeaderBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(221)))), ((int)(((byte)(250)))));
            this._binaryHeaderControl1.HeaderBorderThickness = 2F;
            this._binaryHeaderControl1.HeaderCaptionFont = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._binaryHeaderControl1.HeaderCaptionHeight = 40;
            this._binaryHeaderControl1.HeaderContextMenu = null;
            this._binaryHeaderControl1.HeaderContextMenuStrip = this._contextMenuStrip1;
            this._binaryHeaderControl1.HeaderFooterDrawingStyle = Binarymission.WinForms.Controls.NavigationControls.HeaderFooterDrawingStyle.OfficeStyle;
            this._binaryHeaderControl1.HeaderGradientDrawingDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this._binaryHeaderControl1.HeaderIcon = null;
            this._binaryHeaderControl1.HeaderImage = null;
            this._binaryHeaderControl1.HeaderImageType = Binarymission.WinForms.Controls.NavigationControls.HeaderImageType.Bitmap;
            this._binaryHeaderControl1.HeaderLocation = Binarymission.WinForms.Controls.NavigationControls.HeaderLocation.Top;
            this._binaryHeaderControl1.HeaderText = "Tools / Utilities";
            this._binaryHeaderControl1.HeaderTextForeColor = System.Drawing.Color.White;
            this._binaryHeaderControl1.Location = new System.Drawing.Point(21, 108);
            this._binaryHeaderControl1.Name = "_binaryHeaderControl1";
            this._binaryHeaderControl1.Size = new System.Drawing.Size(257, 214);
            this._binaryHeaderControl1.StartColorForBackgroundRendering = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            this._binaryHeaderControl1.StartColorForFooterRendering = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            this._binaryHeaderControl1.StartColorForHeaderRendering = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            this._binaryHeaderControl1.TabIndex = 0;
            this._binaryHeaderControl1.UseAntiAliasingAsHeaderCaptionTextRenderingHint = false;
            this._binaryHeaderControl1.UseCustomImageForContextMenuButton = false;
            // 
            // _binaryScrollablePanel1
            // 
            this._binaryScrollablePanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._binaryScrollablePanel1.AutoScroll = true;
            this._binaryScrollablePanel1.BackColor = System.Drawing.Color.White;
            this._binaryScrollablePanel1.EndColorForGradientRendering = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(219)))), ((int)(((byte)(249)))));
            this._binaryScrollablePanel1.GradientDrawingDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this._binaryScrollablePanel1.Location = new System.Drawing.Point(1, 1);
            this._binaryScrollablePanel1.Name = "_binaryScrollablePanel1";
            this._binaryScrollablePanel1.Size = new System.Drawing.Size(251, 142);
            this._binaryScrollablePanel1.StartColorForGradientRendering = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(167)))), ((int)(((byte)(225)))));
            this._binaryScrollablePanel1.TabIndex = 1;
            // 
            // _contextMenuStrip1
            // 
            this._contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._sampleCommand1ToolStripMenuItem,
            this._sampleCommand2ToolStripMenuItem});
            this._contextMenuStrip1.Name = "_contextMenuStrip1";
            this._contextMenuStrip1.Size = new System.Drawing.Size(183, 48);
            // 
            // _sampleCommand1ToolStripMenuItem
            // 
            this._sampleCommand1ToolStripMenuItem.Name = "_sampleCommand1ToolStripMenuItem";
            this._sampleCommand1ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this._sampleCommand1ToolStripMenuItem.Text = "Sample Command 1";
            // 
            // _sampleCommand2ToolStripMenuItem
            // 
            this._sampleCommand2ToolStripMenuItem.Name = "_sampleCommand2ToolStripMenuItem";
            this._sampleCommand2ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this._sampleCommand2ToolStripMenuItem.Text = "Sample Command 2";
            // 
            // _binaryHeaderControl2
            // 
            this._binaryHeaderControl2.BackgroundGradientDrawingDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this._binaryHeaderControl2.BorderColor = System.Drawing.SystemColors.ControlDark;
            this._binaryHeaderControl2.BorderWidth = 2;
            this._binaryHeaderControl2.ColorScheme = Binarymission.WinForms.Controls.NavigationControls.ColorScheme.Control;
            this._binaryHeaderControl2.ContextMenuArrowColor = System.Drawing.Color.White;
            this._binaryHeaderControl2.ContextMenuEllipseColor = System.Drawing.Color.Silver;
            this._binaryHeaderControl2.ContextMenuImageType = Binarymission.WinForms.Controls.NavigationControls.ContextMenuButtonImageType.Default;
            this._binaryHeaderControl2.ContextMenuType = Binarymission.WinForms.Controls.NavigationControls.ContextMenuType.ContextMenuStrip;
            this._binaryHeaderControl2.ControlIsInExpandedState = true;
            this._binaryHeaderControl2.Controls.Add(this._binaryScrollablePanel2);
            this._binaryHeaderControl2.CustomContextMenuButtonImageTransparencyColor = System.Drawing.Color.Transparent;
            this._binaryHeaderControl2.CustomIconForContextMenuButton = null;
            this._binaryHeaderControl2.CustomImageForContextMenuButton = null;
            this._binaryHeaderControl2.DrawBorderAround = Binarymission.WinForms.Controls.NavigationControls.DrawBorderAround.None;
            this._binaryHeaderControl2.DrawFooter = false;
            this._binaryHeaderControl2.EnableCollapseExpandButton = true;
            this._binaryHeaderControl2.EnableHeaderContextMenu = false;
            this._binaryHeaderControl2.EndColorForBackgroundRendering = System.Drawing.Color.White;
            this._binaryHeaderControl2.EndColorForFooterRendering = System.Drawing.Color.White;
            this._binaryHeaderControl2.EndColorForHeaderRendering = System.Drawing.Color.White;
            this._binaryHeaderControl2.ExpandCollapseCircleFillColor = System.Drawing.SystemColors.Window;
            this._binaryHeaderControl2.ExpandCollapseUpDownArrowsFillColor = System.Drawing.Color.Black;
            this._binaryHeaderControl2.FooterBorderColor = System.Drawing.SystemColors.Control;
            this._binaryHeaderControl2.FooterBorderThickness = 2F;
            this._binaryHeaderControl2.FooterCaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._binaryHeaderControl2.FooterCaptionHeight = 26;
            this._binaryHeaderControl2.FooterGradientDrawingDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this._binaryHeaderControl2.FooterText = "Footer text!";
            this._binaryHeaderControl2.FooterTextForeColor = System.Drawing.Color.Black;
            this._binaryHeaderControl2.HeaderBitmapTransparencyColor = System.Drawing.Color.Transparent;
            this._binaryHeaderControl2.HeaderBorderColor = System.Drawing.SystemColors.Control;
            this._binaryHeaderControl2.HeaderBorderThickness = 2F;
            this._binaryHeaderControl2.HeaderCaptionFont = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._binaryHeaderControl2.HeaderCaptionHeight = 40;
            this._binaryHeaderControl2.HeaderContextMenu = null;
            this._binaryHeaderControl2.HeaderContextMenuStrip = null;
            this._binaryHeaderControl2.HeaderFooterDrawingStyle = Binarymission.WinForms.Controls.NavigationControls.HeaderFooterDrawingStyle.OfficeStyle;
            this._binaryHeaderControl2.HeaderGradientDrawingDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this._binaryHeaderControl2.HeaderIcon = null;
            this._binaryHeaderControl2.HeaderImage = global::HeaderControlDemonstrationApp.Properties.Resources.company;
            this._binaryHeaderControl2.HeaderImageType = Binarymission.WinForms.Controls.NavigationControls.HeaderImageType.Bitmap;
            this._binaryHeaderControl2.HeaderLocation = Binarymission.WinForms.Controls.NavigationControls.HeaderLocation.Top;
            this._binaryHeaderControl2.HeaderText = "Company Profile";
            this._binaryHeaderControl2.HeaderTextForeColor = System.Drawing.Color.Black;
            this._binaryHeaderControl2.Location = new System.Drawing.Point(21, 429);
            this._binaryHeaderControl2.Name = "_binaryHeaderControl2";
            this._binaryHeaderControl2.Size = new System.Drawing.Size(257, 214);
            this._binaryHeaderControl2.StartColorForBackgroundRendering = System.Drawing.SystemColors.Control;
            this._binaryHeaderControl2.StartColorForFooterRendering = System.Drawing.SystemColors.Control;
            this._binaryHeaderControl2.StartColorForHeaderRendering = System.Drawing.SystemColors.ControlDark;
            this._binaryHeaderControl2.TabIndex = 2;
            this._binaryHeaderControl2.UseAntiAliasingAsHeaderCaptionTextRenderingHint = false;
            this._binaryHeaderControl2.UseCustomImageForContextMenuButton = false;
            // 
            // _binaryScrollablePanel2
            // 
            this._binaryScrollablePanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._binaryScrollablePanel2.AutoScroll = true;
            this._binaryScrollablePanel2.BackColor = System.Drawing.Color.White;
            this._binaryScrollablePanel2.ColorScheme = Binarymission.WinForms.Controls.NavigationControls.ColorScheme.Control;
            this._binaryScrollablePanel2.EndColorForGradientRendering = System.Drawing.Color.White;
            this._binaryScrollablePanel2.GradientDrawingDirection = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this._binaryScrollablePanel2.Location = new System.Drawing.Point(1, 1);
            this._binaryScrollablePanel2.Name = "_binaryScrollablePanel2";
            this._binaryScrollablePanel2.Size = new System.Drawing.Size(251, 168);
            this._binaryScrollablePanel2.StartColorForGradientRendering = System.Drawing.SystemColors.Control;
            this._binaryScrollablePanel2.TabIndex = 3;
            // 
            // _label1
            // 
            this._label1.AutoSize = true;
            this._label1.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._label1.Location = new System.Drawing.Point(20, 16);
            this._label1.Name = "_label1";
            this._label1.Size = new System.Drawing.Size(153, 18);
            this._label1.TabIndex = 4;
            this._label1.Text = "Control Instance 1:";
            // 
            // _label2
            // 
            this._label2.AutoSize = true;
            this._label2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._label2.Location = new System.Drawing.Point(21, 357);
            this._label2.Name = "_label2";
            this._label2.Size = new System.Drawing.Size(153, 18);
            this._label2.TabIndex = 5;
            this._label2.Text = "Control Instance 2:";
            // 
            // _label3
            // 
            this._label3.AutoSize = true;
            this._label3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._label3.Location = new System.Drawing.Point(22, 378);
            this._label3.Name = "_label3";
            this._label3.Size = new System.Drawing.Size(176, 16);
            this._label3.TabIndex = 6;
            this._label3.Text = "Footer rendering = FALSE";
            // 
            // _label4
            // 
            this._label4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._label4.Location = new System.Drawing.Point(23, 664);
            this._label4.Name = "_label4";
            this._label4.Size = new System.Drawing.Size(238, 38);
            this._label4.TabIndex = 7;
            this._label4.Text = "The control exposes many more properties to deeply customize it.";
            // 
            // _label5
            // 
            this._label5.AutoSize = true;
            this._label5.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._label5.Location = new System.Drawing.Point(22, 396);
            this._label5.Name = "_label5";
            this._label5.Size = new System.Drawing.Size(168, 16);
            this._label5.TabIndex = 9;
            this._label5.Text = "Collapse/Expand = TRUE";
            // 
            // _label6
            // 
            this._label6.AutoSize = true;
            this._label6.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._label6.Location = new System.Drawing.Point(20, 55);
            this._label6.Name = "_label6";
            this._label6.Size = new System.Drawing.Size(174, 16);
            this._label6.TabIndex = 11;
            this._label6.Text = "Collapse/Expand = FALSE";
            // 
            // _label7
            // 
            this._label7.AutoSize = true;
            this._label7.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._label7.Location = new System.Drawing.Point(21, 38);
            this._label7.Name = "_label7";
            this._label7.Size = new System.Drawing.Size(170, 16);
            this._label7.TabIndex = 10;
            this._label7.Text = "Footer rendering = TRUE";
            // 
            // _label8
            // 
            this._label8.AutoSize = true;
            this._label8.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._label8.Location = new System.Drawing.Point(21, 73);
            this._label8.Name = "_label8";
            this._label8.Size = new System.Drawing.Size(224, 16);
            this._label8.TabIndex = 12;
            this._label8.Text = "Header Command button = TRUE";
            // 
            // HeaderControlDemoForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(308, 753);
            this.Controls.Add(this._label8);
            this.Controls.Add(this._label6);
            this.Controls.Add(this._label7);
            this.Controls.Add(this._label5);
            this.Controls.Add(this._label4);
            this.Controls.Add(this._label3);
            this.Controls.Add(this._label2);
            this.Controls.Add(this._label1);
            this.Controls.Add(this._binaryHeaderControl2);
            this.Controls.Add(this._binaryHeaderControl1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "HeaderControlDemoForm";
            this.TitlebarText = "Header Control Demo";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this._binaryHeaderControl1.ResumeLayout(false);
            this._contextMenuStrip1.ResumeLayout(false);
            this._binaryHeaderControl2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.DoEvents();
            Application.Run(new HeaderControlDemoForm());
        }

    }
}
