using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;

namespace HeaderControlDemonstrationApp
{
    /// <summary>
    /// Summary description for Form1.
    /// </summary>
    public partial class HeaderControlDemoForm : ModernChromeWindow
    {
        public HeaderControlDemoForm()
        {
            InitializeComponent();
            Icon = Properties.Resources.App;
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
        }
    }
}
