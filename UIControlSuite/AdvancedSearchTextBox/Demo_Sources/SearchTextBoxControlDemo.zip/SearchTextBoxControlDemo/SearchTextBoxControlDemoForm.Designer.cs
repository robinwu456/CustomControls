﻿
using System;
using Binarymission.Winforms.Controls;
using Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite;

namespace SearchTextBoxControlDemo
{
    partial class SearchTextBoxControlDemoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Drawing.StringFormat stringFormat2 = new System.Drawing.StringFormat();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchTextBoxControlDemoForm));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chkIsCueTextRenderedWhenInFocus = new Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox();
            this.txtCueText = new System.Windows.Forms.TextBox();
            this.extendedLabel1 = new Binarymission.WinForms.Controls.ExtendedLabel();
            this._chkIsSearchCommandsEnabled = new Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox();
            this._chkIsOnlyWatermarkProvider = new Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox();
            this.advancedGroupBox1 = new Binarymission.Winforms.Controls.AdvancedGroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dottedBorderGapSpinner = new System.Windows.Forms.NumericUpDown();
            this.dottedBorderDepthSpinner = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.clrPickerBlinkColor = new Binarymission.WinForms.Controls.ColorPickers.BinaryOfficeColorPickerComboBox();
            this.chkPerformBlinking = new Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox();
            this.chkDottedBorder = new Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox();
            this.searchTextBox1 = new Binarymission.Winforms.Controls.SearchTextBox();
            this.ExitApplicationCommandVisual = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this.groupBox1.SuspendLayout();
            this.advancedGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dottedBorderGapSpinner)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dottedBorderDepthSpinner)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "SearchTextBox instance:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundBrushColor1 = System.Drawing.SystemColors.Control;
            this.groupBox1.BackgroundBrushColor2 = System.Drawing.SystemColors.Control;
            this.groupBox1.BorderColor = System.Drawing.Color.DarkGray;
            this.groupBox1.BorderThickness = 2F;
            this.groupBox1.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal;
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.chkIsCueTextRenderedWhenInFocus);
            this.groupBox1.Controls.Add(this.txtCueText);
            this.groupBox1.Controls.Add(this.extendedLabel1);
            this.groupBox1.Controls.Add(this._chkIsSearchCommandsEnabled);
            this.groupBox1.Controls.Add(this._chkIsOnlyWatermarkProvider);
            this.groupBox1.DottedBorderDepth = 4;
            this.groupBox1.DottedBorderGap = 6;
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopLeft;
            this.groupBox1.HeaderBackgroundColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox1.HeaderBackgroundColor2 = System.Drawing.Color.DarkGray;
            this.groupBox1.HeaderBackgroundLeftMargin = 4;
            this.groupBox1.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.groupBox1.HeaderBackgroundRightMargin = 4;
            this.groupBox1.HeaderBorderColor = System.Drawing.Color.Empty;
            this.groupBox1.HeaderBorderThickness = 0;
            this.groupBox1.HeaderExtraHeightFactor = 8;
            this.groupBox1.HeaderFont = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.groupBox1.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.groupBox1.IsHeaderBackgroundDrawingEnabled = true;
            this.groupBox1.IsHeaderBackgroundGradient = true;
            this.groupBox1.IsHeaderBorderDrawingEnabled = false;
            this.groupBox1.LinearGradientBrushGradientAngle = 90F;
            this.groupBox1.Location = new System.Drawing.Point(12, 69);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.groupBox1.RoundedCornersAngle = 60F;
            this.groupBox1.RoundedCornerTargets = ((Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets)((((Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.TopLeft | Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.TopRight) 
            | Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.BottomLeft) 
            | Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.BottomRight)));
            this.groupBox1.ShouldDrawRoundedCorners = false;
            this.groupBox1.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.groupBox1.Size = new System.Drawing.Size(475, 358);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Customization options";
            this.groupBox1.TextLeftMargin = 3;
            this.groupBox1.TextRightMargin = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(23, 53);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Custom Cue/Banner text:: ";
            // 
            // chkIsCueTextRenderedWhenInFocus
            // 
            this.chkIsCueTextRenderedWhenInFocus.BackColor = System.Drawing.SystemColors.Control;
            this.chkIsCueTextRenderedWhenInFocus.ControlBackColor = System.Drawing.SystemColors.Window;
            this.chkIsCueTextRenderedWhenInFocus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkIsCueTextRenderedWhenInFocus.Location = new System.Drawing.Point(23, 138);
            this.chkIsCueTextRenderedWhenInFocus.Margin = new System.Windows.Forms.Padding(4);
            this.chkIsCueTextRenderedWhenInFocus.Name = "chkIsCueTextRenderedWhenInFocus";
            this.chkIsCueTextRenderedWhenInFocus.NormalControlColor = System.Drawing.Color.Green;
            this.chkIsCueTextRenderedWhenInFocus.OnFocusControlColor = System.Drawing.Color.Red;
            this.chkIsCueTextRenderedWhenInFocus.Size = new System.Drawing.Size(431, 50);
            this.chkIsCueTextRenderedWhenInFocus.TabIndex = 5;
            this.chkIsCueTextRenderedWhenInFocus.Text = "Is the cue/banner text rendered even when the text area of the control is in inpu" +
    "t focus?";
            this.chkIsCueTextRenderedWhenInFocus.UseVisualStyleBackColor = false;
            this.chkIsCueTextRenderedWhenInFocus.CheckedChanged += new System.EventHandler(this.CheckIsCueTextRenderedWhenInFocusCheckedChanged);
            // 
            // txtCueText
            // 
            this.txtCueText.Location = new System.Drawing.Point(192, 49);
            this.txtCueText.Margin = new System.Windows.Forms.Padding(4);
            this.txtCueText.Name = "txtCueText";
            this.txtCueText.Size = new System.Drawing.Size(132, 22);
            this.txtCueText.TabIndex = 6;
            this.txtCueText.TextChanged += new System.EventHandler(this.CueTextTextChanged);
            // 
            // extendedLabel1
            // 
            this.extendedLabel1.BackgroundGradientFloatAngle = 90F;
            this.extendedLabel1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.extendedLabel1.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.extendedLabel1.BorderDrawingStyle = Binarymission.WinForms.Controls.ExtendedLabel.BorderStyle.None;
            this.extendedLabel1.DropShadowGradientFloatAngle = 45F;
            this.extendedLabel1.DropShadowMargin = 8;
            this.extendedLabel1.EndLinearGradientBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.extendedLabel1.EndLinearGradientDropShadowBackgroundColor = System.Drawing.Color.LightGray;
            this.extendedLabel1.IsBackgroundTransparent = false;
            this.extendedLabel1.Location = new System.Drawing.Point(15, 202);
            this.extendedLabel1.Name = "extendedLabel1";
            this.extendedLabel1.Orientation = Binarymission.WinForms.Controls.ExtendedLabel.DrawingOrientation.Horizontal;
            this.extendedLabel1.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.extendedLabel1.ShouldDrawBorder = true;
            this.extendedLabel1.ShouldDrawDropShadow = true;
            this.extendedLabel1.ShouldRefreshUponParentMoveResize = false;
            this.extendedLabel1.Size = new System.Drawing.Size(445, 140);
            this.extendedLabel1.StartLinearGradientBackgroundColor = System.Drawing.Color.White;
            this.extendedLabel1.StartLinearGradientDropShadowBackgroundColor = System.Drawing.Color.Gray;
            stringFormat2.Alignment = System.Drawing.StringAlignment.Center;
            stringFormat2.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat2.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat2.Trimming = System.Drawing.StringTrimming.Character;
            this.extendedLabel1.StringFormat = stringFormat2;
            this.extendedLabel1.TabIndex = 7;
            this.extendedLabel1.TabStop = false;
            this.extendedLabel1.Text = resources.GetString("extendedLabel1.Text");
            this.extendedLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.extendedLabel1.VerticalTextDirection = Binarymission.WinForms.Controls.ExtendedLabel.TextDirection.TopBottom;
            // 
            // _chkIsSearchCommandsEnabled
            // 
            this._chkIsSearchCommandsEnabled.AutoSize = true;
            this._chkIsSearchCommandsEnabled.BackColor = System.Drawing.SystemColors.Control;
            this._chkIsSearchCommandsEnabled.ControlBackColor = System.Drawing.SystemColors.Window;
            this._chkIsSearchCommandsEnabled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._chkIsSearchCommandsEnabled.Location = new System.Drawing.Point(24, 85);
            this._chkIsSearchCommandsEnabled.Margin = new System.Windows.Forms.Padding(4);
            this._chkIsSearchCommandsEnabled.Name = "_chkIsSearchCommandsEnabled";
            this._chkIsSearchCommandsEnabled.NormalControlColor = System.Drawing.Color.Green;
            this._chkIsSearchCommandsEnabled.OnFocusControlColor = System.Drawing.Color.Red;
            this._chkIsSearchCommandsEnabled.Size = new System.Drawing.Size(284, 20);
            this._chkIsSearchCommandsEnabled.TabIndex = 3;
            this._chkIsSearchCommandsEnabled.Text = "Are search command capabilities enabled?";
            this._chkIsSearchCommandsEnabled.UseVisualStyleBackColor = false;
            this._chkIsSearchCommandsEnabled.CheckedChanged += new System.EventHandler(this.CheckIsSearchCommandsEnabledCheckedChanged);
            // 
            // _chkIsOnlyWatermarkProvider
            // 
            this._chkIsOnlyWatermarkProvider.AutoSize = true;
            this._chkIsOnlyWatermarkProvider.BackColor = System.Drawing.SystemColors.Control;
            this._chkIsOnlyWatermarkProvider.ControlBackColor = System.Drawing.SystemColors.Window;
            this._chkIsOnlyWatermarkProvider.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._chkIsOnlyWatermarkProvider.Location = new System.Drawing.Point(23, 116);
            this._chkIsOnlyWatermarkProvider.Margin = new System.Windows.Forms.Padding(4);
            this._chkIsOnlyWatermarkProvider.Name = "_chkIsOnlyWatermarkProvider";
            this._chkIsOnlyWatermarkProvider.NormalControlColor = System.Drawing.Color.Green;
            this._chkIsOnlyWatermarkProvider.OnFocusControlColor = System.Drawing.Color.Red;
            this._chkIsOnlyWatermarkProvider.Size = new System.Drawing.Size(266, 20);
            this._chkIsOnlyWatermarkProvider.TabIndex = 4;
            this._chkIsOnlyWatermarkProvider.Text = "Is the control only a Watermark provider?";
            this._chkIsOnlyWatermarkProvider.UseVisualStyleBackColor = false;
            this._chkIsOnlyWatermarkProvider.CheckedChanged += new System.EventHandler(this.CheckIsOnlyWatermarkProviderCheckedChanged);
            // 
            // advancedGroupBox1
            // 
            this.advancedGroupBox1.BackgroundBrushColor1 = System.Drawing.SystemColors.Control;
            this.advancedGroupBox1.BackgroundBrushColor2 = System.Drawing.SystemColors.Control;
            this.advancedGroupBox1.BorderColor = System.Drawing.Color.DarkGray;
            this.advancedGroupBox1.BorderThickness = 2F;
            this.advancedGroupBox1.ControlBorderStyle = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.ControlBorderStyle.Normal;
            this.advancedGroupBox1.Controls.Add(this.label5);
            this.advancedGroupBox1.Controls.Add(this.label4);
            this.advancedGroupBox1.Controls.Add(this.dottedBorderGapSpinner);
            this.advancedGroupBox1.Controls.Add(this.dottedBorderDepthSpinner);
            this.advancedGroupBox1.Controls.Add(this.label3);
            this.advancedGroupBox1.Controls.Add(this.clrPickerBlinkColor);
            this.advancedGroupBox1.Controls.Add(this.chkPerformBlinking);
            this.advancedGroupBox1.Controls.Add(this.chkDottedBorder);
            this.advancedGroupBox1.DottedBorderDepth = 4;
            this.advancedGroupBox1.DottedBorderGap = 6;
            this.advancedGroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.advancedGroupBox1.HeaderAlignment = Binarymission.Winforms.Controls.AdvancedGroupBoxControl.Enums.HeaderAlignment.TopLeft;
            this.advancedGroupBox1.HeaderBackgroundColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.advancedGroupBox1.HeaderBackgroundColor2 = System.Drawing.Color.DarkGray;
            this.advancedGroupBox1.HeaderBackgroundLeftMargin = 4;
            this.advancedGroupBox1.HeaderBackgroundLinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox1.HeaderBackgroundRightMargin = 4;
            this.advancedGroupBox1.HeaderBorderColor = System.Drawing.Color.Empty;
            this.advancedGroupBox1.HeaderBorderThickness = 0;
            this.advancedGroupBox1.HeaderExtraHeightFactor = 8;
            this.advancedGroupBox1.HeaderFont = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advancedGroupBox1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.advancedGroupBox1.HeaderSolidBrushBackgroundColor = System.Drawing.Color.Empty;
            this.advancedGroupBox1.IsBackgroundDrawingUsingLinerGradientBrush = true;
            this.advancedGroupBox1.IsHeaderBackgroundDrawingEnabled = true;
            this.advancedGroupBox1.IsHeaderBackgroundGradient = true;
            this.advancedGroupBox1.IsHeaderBorderDrawingEnabled = false;
            this.advancedGroupBox1.LinearGradientBrushGradientAngle = 90F;
            this.advancedGroupBox1.Location = new System.Drawing.Point(499, 69);
            this.advancedGroupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.advancedGroupBox1.Name = "advancedGroupBox1";
            this.advancedGroupBox1.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.advancedGroupBox1.RoundedCornersAngle = 60F;
            this.advancedGroupBox1.RoundedCornerTargets = ((Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets)((((Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.TopLeft | Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.TopRight) 
            | Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.BottomLeft) 
            | Binarymission.Winforms.Controls.AdvancedGroupBox.CornerTargets.BottomRight)));
            this.advancedGroupBox1.ShouldDrawRoundedCorners = false;
            this.advancedGroupBox1.ShouldUpdateChildrenUponParentFormMoveSize = false;
            this.advancedGroupBox1.Size = new System.Drawing.Size(475, 144);
            this.advancedGroupBox1.TabIndex = 7;
            this.advancedGroupBox1.TabStop = false;
            this.advancedGroupBox1.Text = "More options...";
            this.advancedGroupBox1.TextLeftMargin = 3;
            this.advancedGroupBox1.TextRightMargin = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(242, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "Dotted border gap:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 16);
            this.label4.TabIndex = 10;
            this.label4.Text = "Dotted border depth:";
            // 
            // dottedBorderGapSpinner
            // 
            this.dottedBorderGapSpinner.Location = new System.Drawing.Point(372, 102);
            this.dottedBorderGapSpinner.Name = "dottedBorderGapSpinner";
            this.dottedBorderGapSpinner.Size = new System.Drawing.Size(46, 22);
            this.dottedBorderGapSpinner.TabIndex = 9;
            this.dottedBorderGapSpinner.ValueChanged += new System.EventHandler(this.DottedBorderGapSpinnerValueChanged);
            // 
            // dottedBorderDepthSpinner
            // 
            this.dottedBorderDepthSpinner.Location = new System.Drawing.Point(180, 102);
            this.dottedBorderDepthSpinner.Name = "dottedBorderDepthSpinner";
            this.dottedBorderDepthSpinner.Size = new System.Drawing.Size(44, 22);
            this.dottedBorderDepthSpinner.TabIndex = 8;
            this.dottedBorderDepthSpinner.ValueChanged += new System.EventHandler(this.DottedBorderDepthSpinnerValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(214, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Blink color:";
            // 
            // clrPickerBlinkColor
            // 
            this.clrPickerBlinkColor.AlphaBlendFactorForControlPainting = 100;
            this.clrPickerBlinkColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.clrPickerBlinkColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.clrPickerBlinkColor.AlphaValue = 255;
            this.clrPickerBlinkColor.BackColor = System.Drawing.SystemColors.Window;
            this.clrPickerBlinkColor.BlendTargetColor = System.Drawing.Color.Empty;
            this.clrPickerBlinkColor.BorderColor = System.Drawing.SystemColors.WindowText;
            this.clrPickerBlinkColor.CustomColorForRectangleBorder = System.Drawing.Color.Yellow;
            this.clrPickerBlinkColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.clrPickerBlinkColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.clrPickerBlinkColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.clrPickerBlinkColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.clrPickerBlinkColor.EnableSettingAlphaValue = false;
            this.clrPickerBlinkColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clrPickerBlinkColor.HeadingBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(219)))), ((int)(((byte)(230)))));
            this.clrPickerBlinkColor.HeadingForeColor = System.Drawing.SystemColors.WindowText;
            this.clrPickerBlinkColor.Items.AddRange(new object[] {
            "Empty"});
            this.clrPickerBlinkColor.Location = new System.Drawing.Point(303, 40);
            this.clrPickerBlinkColor.Name = "clrPickerBlinkColor";
            this.clrPickerBlinkColor.SelectedColor = System.Drawing.Color.Empty;
            this.clrPickerBlinkColor.SelectedColorRectangleBorder = System.Drawing.SystemColors.WindowText;
            this.clrPickerBlinkColor.ShowBorderAlways = false;
            this.clrPickerBlinkColor.ShowColorNameIfKnownColor = false;
            this.clrPickerBlinkColor.ShowHSBInToolTip = false;
            this.clrPickerBlinkColor.ShowToolTip = true;
            this.clrPickerBlinkColor.Size = new System.Drawing.Size(150, 23);
            this.clrPickerBlinkColor.TabIndex = 6;
            this.clrPickerBlinkColor.SelectedColorChanged += new System.EventHandler<Binarymission.WinForms.Controls.ColorPickers.BinaryColorPickerExtendedEventArgs>(this.ColorPickerBlinkColorSelectedColorChanged);
            // 
            // chkPerformBlinking
            // 
            this.chkPerformBlinking.AutoSize = true;
            this.chkPerformBlinking.BackColor = System.Drawing.SystemColors.Control;
            this.chkPerformBlinking.ControlBackColor = System.Drawing.SystemColors.Window;
            this.chkPerformBlinking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkPerformBlinking.Location = new System.Drawing.Point(22, 43);
            this.chkPerformBlinking.Margin = new System.Windows.Forms.Padding(4);
            this.chkPerformBlinking.Name = "chkPerformBlinking";
            this.chkPerformBlinking.NormalControlColor = System.Drawing.Color.Green;
            this.chkPerformBlinking.OnFocusControlColor = System.Drawing.Color.Red;
            this.chkPerformBlinking.Size = new System.Drawing.Size(121, 20);
            this.chkPerformBlinking.TabIndex = 3;
            this.chkPerformBlinking.Text = "Perform Blinking";
            this.chkPerformBlinking.UseVisualStyleBackColor = false;
            this.chkPerformBlinking.CheckedChanged += new System.EventHandler(this.EnablePerformBlickingCheckedChanged);
            // 
            // chkDottedBorder
            // 
            this.chkDottedBorder.AutoSize = true;
            this.chkDottedBorder.BackColor = System.Drawing.SystemColors.Control;
            this.chkDottedBorder.ControlBackColor = System.Drawing.SystemColors.Window;
            this.chkDottedBorder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkDottedBorder.Location = new System.Drawing.Point(22, 72);
            this.chkDottedBorder.Margin = new System.Windows.Forms.Padding(4);
            this.chkDottedBorder.Name = "chkDottedBorder";
            this.chkDottedBorder.NormalControlColor = System.Drawing.Color.Green;
            this.chkDottedBorder.OnFocusControlColor = System.Drawing.Color.Red;
            this.chkDottedBorder.Size = new System.Drawing.Size(265, 20);
            this.chkDottedBorder.TabIndex = 4;
            this.chkDottedBorder.Text = "Is SearchTextBox control border Dotted?";
            this.chkDottedBorder.UseVisualStyleBackColor = false;
            this.chkDottedBorder.CheckedChanged += new System.EventHandler(this.DottedBorderCheckedChanged);
            // 
            // searchTextBox1
            // 
            this.searchTextBox1.BorderColor = System.Drawing.SystemColors.Highlight;
            this.searchTextBox1.BorderColorWhenControlIsNotInFocus = System.Drawing.Color.White;
            this.searchTextBox1.ClearSearchTextCommandInvokerImage = null;
            this.searchTextBox1.CueText = "Search...";
            this.searchTextBox1.DefaultDropListChevronBorderColor = System.Drawing.Color.Teal;
            this.searchTextBox1.DefaultDropListChevronBorderOnHoverColor = System.Drawing.Color.Empty;
            this.searchTextBox1.DefaultDropListChevronBorderWidth = 0F;
            this.searchTextBox1.DefaultDropListChevronRotateFlipType = System.Drawing.RotateFlipType.RotateNoneFlipNone;
            this.searchTextBox1.DotBorderDepth = 4;
            this.searchTextBox1.DotBorderGap = 5;
            this.searchTextBox1.DrawBorder = Binarymission.WinForms.Controls.TextControls.BorderState.Normal;
            this.searchTextBox1.ExtendedState = true;
            this.searchTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchTextBox1.HoverColorForSearchDropListChevron = System.Drawing.Color.Red;
            this.searchTextBox1.IsCueTextRenderedWhenInFocus = true;
            this.searchTextBox1.IsOnlyWatermarkProvider = false;
            this.searchTextBox1.IsSearchCommandSetEnabled = true;
            this.searchTextBox1.IsSearchDropListOpenRequestCompleted = true;
            this.searchTextBox1.Location = new System.Drawing.Point(195, 17);
            this.searchTextBox1.Margin = new System.Windows.Forms.Padding(4);
            this.searchTextBox1.MarginBetweenTextAndCommandInvokers = 9;
            this.searchTextBox1.Name = "searchTextBox1";
            this.searchTextBox1.NormalColorForSearchDropListChevron = System.Drawing.Color.Maroon;
            this.searchTextBox1.SearchCommandInvokerImage = ((System.Drawing.Image)(resources.GetObject("searchTextBox1.SearchCommandInvokerImage")));
            this.searchTextBox1.SearchDropListCommandChevronFillColor = System.Drawing.Color.Empty;
            this.searchTextBox1.SearchDropListCommandInvokerImage = null;
            this.searchTextBox1.ShowBorderAlways = true;
            this.searchTextBox1.Size = new System.Drawing.Size(292, 22);
            this.searchTextBox1.TabIndex = 0;
            this.searchTextBox1.UseEnhancedPasswordChar = false;
            this.searchTextBox1.TextSearchRequested += new System.EventHandler<Binarymission.Winforms.Controls.SearchTextBoxControl.EventsData.SearchRequestEventArgs>(this.SearchTextBoxTextSearchRequested);
            this.searchTextBox1.ClearSearchTextRequested += new System.EventHandler(this.SearchTextBoxClearSearchTextRequested);
            this.searchTextBox1.SearchDropListOpenRequested += new System.EventHandler<Binarymission.Winforms.Controls.SearchTextBoxControl.EventsData.SearchDropListInvokedEventArgs>(this.SearchTextBoxSearchDropListOpenRequested);
            // 
            // ExitApplicationCommandVisual
            // 
            this.ExitApplicationCommandVisual.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ExitApplicationCommandVisual.BorderColor = System.Drawing.Color.Black;
            this.ExitApplicationCommandVisual.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this.ExitApplicationCommandVisual.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this.ExitApplicationCommandVisual.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this.ExitApplicationCommandVisual.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this.ExitApplicationCommandVisual.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this.ExitApplicationCommandVisual.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this.ExitApplicationCommandVisual.ContextMenuProperties.UseGradientPainting = true;
            this.ExitApplicationCommandVisual.DefaultTheme = true;
            this.ExitApplicationCommandVisual.DialogResult = System.Windows.Forms.DialogResult.None;
            this.ExitApplicationCommandVisual.DrawMenuButtonSeparator = true;
            this.ExitApplicationCommandVisual.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this.ExitApplicationCommandVisual.DropDownMenuItems = null;
            this.ExitApplicationCommandVisual.EndColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ExitApplicationCommandVisual.IsRenderingTheme = false;
            this.ExitApplicationCommandVisual.LinearGradientRenderingAngle = 90F;
            this.ExitApplicationCommandVisual.Location = new System.Drawing.Point(868, 399);
            this.ExitApplicationCommandVisual.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this.ExitApplicationCommandVisual.MenuButtonSeparatorLineHeight = -1;
            this.ExitApplicationCommandVisual.Name = "ExitApplicationCommandVisual";
            this.ExitApplicationCommandVisual.PushedEndColor = System.Drawing.Color.White;
            this.ExitApplicationCommandVisual.PushedStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ExitApplicationCommandVisual.Size = new System.Drawing.Size(106, 29);
            this.ExitApplicationCommandVisual.StartColor = System.Drawing.Color.White;
            this.ExitApplicationCommandVisual.TabIndex = 8;
            this.ExitApplicationCommandVisual.Text = "OK";
            this.ExitApplicationCommandVisual.TextStringFormat = null;
            this.ExitApplicationCommandVisual.TransparentColor = System.Drawing.Color.Empty;
            this.ExitApplicationCommandVisual.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this.ExitApplicationCommandVisual.UseCustomTextStringFormat = false;
            this.ExitApplicationCommandVisual.UseUserDefinedColorForArrowMark = true;
            this.ExitApplicationCommandVisual.UseUserDefinedColorForMenuButtonSeparator = true;
            this.ExitApplicationCommandVisual.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this.ExitApplicationCommandVisual.Click += new System.EventHandler(this.ExitApplicationCommandVisualClick);
            // 
            // SearchTextBoxControlDemoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(997, 477);
            this.Controls.Add(this.ExitApplicationCommandVisual);
            this.Controls.Add(this.advancedGroupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.searchTextBox1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SearchTextBoxControlDemoForm";
            this.TitlebarText = "Binarymission AdvancedSearchBox .NET Control for WinForms";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.advancedGroupBox1.ResumeLayout(false);
            this.advancedGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dottedBorderGapSpinner)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dottedBorderDepthSpinner)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Binarymission.Winforms.Controls.SearchTextBox searchTextBox1;
        private Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox _chkIsSearchCommandsEnabled;
        private Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox _chkIsOnlyWatermarkProvider;
        private AdvancedGroupBox groupBox1;
        private Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox chkIsCueTextRenderedWhenInFocus;
        private System.Windows.Forms.TextBox txtCueText;
        private Binarymission.WinForms.Controls.ExtendedLabel extendedLabel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private AdvancedGroupBox advancedGroupBox1;
        private Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox chkDottedBorder;
        private Binarymission.WinForms.Controls.BinaryButtonSuite.ExtendedCheckBox chkPerformBlinking;
        private System.Windows.Forms.Label label3;
        private Binarymission.WinForms.Controls.ColorPickers.BinaryOfficeColorPickerComboBox clrPickerBlinkColor;
        private SmartButton ExitApplicationCommandVisual;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown dottedBorderGapSpinner;
        private System.Windows.Forms.NumericUpDown dottedBorderDepthSpinner;

    }
}

