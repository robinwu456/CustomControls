﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.TextControls;

namespace SearchTextBoxControlDemo
{
    public partial class SearchTextBoxControlDemoForm : ModernChromeWindow
    {
        private ContextMenuStrip _searchBoxDropListCommandHost;
        private Color _blinkColor;

        public SearchTextBoxControlDemoForm()
        {
            InitializeComponent();

            InitialiseForm();
        }

        private void InitialiseForm()
        {
            _searchBoxDropListCommandHost = new ContextMenuStrip();
            _searchBoxDropListCommandHost.Opened += SearchBoxDropListCommandHost_Opened;
            _searchBoxDropListCommandHost.Closing += SearchBoxDropListCommandHost_Closing;
            clrPickerBlinkColor.SelectedColor = Color.Red;

            dottedBorderDepthSpinner.Value = searchTextBox1.DotBorderDepth;
            dottedBorderGapSpinner.Value = searchTextBox1.DotBorderGap;
            dottedBorderDepthSpinner.Enabled = dottedBorderGapSpinner.Enabled = searchTextBox1.DrawBorder == BorderState.Dotted;

            searchTextBox1.DefaultDropListChevronRotateFlipType = RotateFlipType.RotateNoneFlipNone;

            _chkIsSearchCommandsEnabled.Checked = searchTextBox1.IsSearchCommandSetEnabled;
            _chkIsOnlyWatermarkProvider.Checked = searchTextBox1.IsOnlyWatermarkProvider;
            txtCueText.Text = searchTextBox1.CueText;

            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
        }

        private void SearchBoxDropListCommandHost_Opened(object sender, System.EventArgs e)
        {
            searchTextBox1.IsSearchDropListOpenRequestCompleted = false;
            searchTextBox1.DefaultDropListChevronRotateFlipType = RotateFlipType.Rotate90FlipX;
            searchTextBox1.Invalidate();
        }

        private void SearchBoxDropListCommandHost_Closing(object sender, ToolStripDropDownClosingEventArgs e)
        {
            searchTextBox1.IsSearchDropListOpenRequestCompleted = true;
            searchTextBox1.DefaultDropListChevronRotateFlipType = RotateFlipType.RotateNoneFlipNone;
            searchTextBox1.Invalidate();
        }

        private void SearchTextBoxSearchDropListOpenRequested(object sender, Binarymission.Winforms.Controls.SearchTextBoxControl.EventsData.SearchDropListInvokedEventArgs e)
        {
            searchTextBox1.IsSearchDropListOpenRequestCompleted = false;
            searchTextBox1.Invalidate();
            _searchBoxDropListCommandHost.Items.Clear();

            _searchBoxDropListCommandHost.Items.Add(new ToolStripMenuItem("Search list history", Properties.Resources.SearchListHistory, (s, ev) =>
            {
                searchTextBox1.IsSearchDropListOpenRequestCompleted = true;
            }));

            _searchBoxDropListCommandHost.Items.Add(new ToolStripSeparator());

            _searchBoxDropListCommandHost.Items.Add(new ToolStripMenuItem("Custom Action 1", Properties.Resources.SetAlarm, (s, ev) =>
            {
                searchTextBox1.IsSearchDropListOpenRequestCompleted = true;
            }));

            _searchBoxDropListCommandHost.Items.Add(new ToolStripMenuItem("Custom Action 2", Properties.Resources.ShowProperties, (s, ev) =>
            {
                searchTextBox1.IsSearchDropListOpenRequestCompleted = true;
            }));

            _searchBoxDropListCommandHost.Items.Add(new ToolStripMenuItem("Custom Action 3", Properties.Resources.Attach, (s, ev) =>
            {
                searchTextBox1.IsSearchDropListOpenRequestCompleted = true;
            }));

            _searchBoxDropListCommandHost.Items.Add(new ToolStripSeparator());

            _searchBoxDropListCommandHost.Items.Add(new ToolStripMenuItem("Custom  more actions...", Properties.Resources.Properties, (s, ev) =>
            {
                searchTextBox1.IsSearchDropListOpenRequestCompleted = true;
            }));

            var adjustedPoint = e.DropListInvokerTopLeftPoint;
            adjustedPoint = new Point(adjustedPoint.X + 22, adjustedPoint.Y - 1);
            _searchBoxDropListCommandHost.Show(searchTextBox1, adjustedPoint);
        }

        private void SearchTextBoxClearSearchTextRequested(object sender, System.EventArgs e)
        {
            searchTextBox1.Text = string.Empty;
        }

        private void SearchTextBoxTextSearchRequested(object sender, Binarymission.Winforms.Controls.SearchTextBoxControl.EventsData.SearchRequestEventArgs e)
        {
            // In your application, of course, you will pick this data and perform an appropriate action, say, a data search somewhere in your application data.

            MessageBox.Show(this, $"Text search command request data: {Environment.NewLine}{e.SearchText}",
                @"Text Search Command",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void CheckIsSearchCommandsEnabledCheckedChanged(object sender, System.EventArgs e)
        {
            searchTextBox1.IsSearchCommandSetEnabled = _chkIsSearchCommandsEnabled.Checked;
        }

        private void CheckIsOnlyWatermarkProviderCheckedChanged(object sender, System.EventArgs e)
        {
            searchTextBox1.IsOnlyWatermarkProvider = _chkIsOnlyWatermarkProvider.Checked;
            _chkIsSearchCommandsEnabled.Enabled = !_chkIsOnlyWatermarkProvider.Checked;
        }

        private void CueTextTextChanged(object sender, System.EventArgs e)
        {
            searchTextBox1.CueText = txtCueText.Text;
        }

        private void CheckIsCueTextRenderedWhenInFocusCheckedChanged(object sender, System.EventArgs e)
        {
            searchTextBox1.IsCueTextRenderedWhenInFocus = chkIsCueTextRenderedWhenInFocus.Checked;
        }

        private void EnablePerformBlickingCheckedChanged(object sender, System.EventArgs e)
        {
            RefreshControlBlink();
        }

        private void RefreshControlBlink()
        {
            searchTextBox1.RefreshControlBlink(chkPerformBlinking.Checked, _blinkColor);
        }

        private void DottedBorderCheckedChanged(object sender, System.EventArgs e)
        {
            searchTextBox1.DrawBorder = chkDottedBorder.Checked ? BorderState.Dotted : BorderState.Normal;
            dottedBorderDepthSpinner.Enabled = dottedBorderGapSpinner.Enabled = searchTextBox1.DrawBorder == BorderState.Dotted;
        }

        private void ColorPickerBlinkColorSelectedColorChanged(object sender, Binarymission.WinForms.Controls.ColorPickers.BinaryColorPickerExtendedEventArgs e)
        {
            _blinkColor = clrPickerBlinkColor.SelectedColor;
            RefreshControlBlink();
        }

        private void ExitApplicationCommandVisualClick(object sender, System.EventArgs e)
        {
            Close();
        }

        private void DottedBorderDepthSpinnerValueChanged(object sender, System.EventArgs e)
        {
            searchTextBox1.DotBorderDepth = (int)dottedBorderDepthSpinner.Value;
        }

        private void DottedBorderGapSpinnerValueChanged(object sender, System.EventArgs e)
        {
            searchTextBox1.DotBorderGap = (int)dottedBorderGapSpinner.Value;
        }
    }
}
