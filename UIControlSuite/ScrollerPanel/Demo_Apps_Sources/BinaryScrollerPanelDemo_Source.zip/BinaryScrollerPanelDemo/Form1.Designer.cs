﻿using System.Windows.Forms;
using Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite;
using Binarymission.WinForms.Controls.MenuControls.MenuClasses;

namespace BinaryScrollerPanelDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button5 = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button4 = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button3 = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this.button2 = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this.button1 = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.scrollerPanel1 = new Binarymission.WinForms.Controls.CustomScrollerControls.ScrollerPanel();
            this.btnExit = new Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.SmartButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.scrollerPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "BinaryScrollablePanel .NET:";
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.dateTimePicker2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(902, 457);
            this.panel1.TabIndex = 5;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(467, 157);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(390, 20);
            this.textBox4.TabIndex = 32;
            this.textBox4.Text = "[Country]";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(467, 131);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(390, 20);
            this.textBox5.TabIndex = 31;
            this.textBox5.Text = "[Your address 2nd line]";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(466, 105);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(390, 20);
            this.textBox6.TabIndex = 30;
            this.textBox6.Text = "[Your address 1st line]";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Image = global::BinaryScrollerPanelDemo.Properties.Resources.Desert;
            this.pictureBox2.Location = new System.Drawing.Point(470, 198);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(215, 125);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 29;
            this.pictureBox2.TabStop = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.button5.BorderColor = System.Drawing.Color.Black;
            this.button5.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this.button5.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this.button5.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this.button5.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this.button5.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this.button5.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this.button5.ContextMenuProperties.UseGradientPainting = true;
            this.button5.DefaultTheme = true;
            this.button5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.button5.DrawMenuButtonSeparator = true;
            this.button5.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this.button5.DropDownMenuItems = null;
            this.button5.EndColor = System.Drawing.Color.White;
            this.button5.IsRenderingTheme = true;
            this.button5.LinearGradientRenderingAngle = 90F;
            this.button5.Location = new System.Drawing.Point(697, 244);
            this.button5.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this.button5.MenuButtonSeparatorLineHeight = -1;
            this.button5.Name = "button5";
            this.button5.PushedEndColor = System.Drawing.Color.Silver;
            this.button5.PushedStartColor = System.Drawing.Color.White;
            this.button5.Size = new System.Drawing.Size(162, 38);
            this.button5.StartColor = System.Drawing.Color.Silver;
            this.button5.TabIndex = 28;
            this.button5.Text = "Choose Profile Picture...";
            this.button5.TextStringFormat = null;
            this.button5.TransparentColor = System.Drawing.Color.Empty;
            this.button5.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this.button5.UseCustomTextStringFormat = false;
            this.button5.UseUserDefinedColorForArrowMark = true;
            this.button5.UseUserDefinedColorForMenuButtonSeparator = true;
            this.button5.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(464, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "Address:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::BinaryScrollerPanelDemo.Properties.Resources.Penguins;
            this.pictureBox1.Location = new System.Drawing.Point(24, 118);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(215, 125);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.button4.BorderColor = System.Drawing.Color.Black;
            this.button4.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this.button4.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this.button4.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this.button4.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this.button4.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this.button4.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this.button4.ContextMenuProperties.UseGradientPainting = true;
            this.button4.DefaultTheme = true;
            this.button4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.button4.DrawMenuButtonSeparator = true;
            this.button4.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this.button4.DropDownMenuItems = null;
            this.button4.EndColor = System.Drawing.Color.White;
            this.button4.IsRenderingTheme = true;
            this.button4.LinearGradientRenderingAngle = 90F;
            this.button4.Location = new System.Drawing.Point(251, 119);
            this.button4.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this.button4.MenuButtonSeparatorLineHeight = -1;
            this.button4.Name = "button4";
            this.button4.PushedEndColor = System.Drawing.Color.Silver;
            this.button4.PushedStartColor = System.Drawing.Color.White;
            this.button4.Size = new System.Drawing.Size(162, 38);
            this.button4.StartColor = System.Drawing.Color.Silver;
            this.button4.TabIndex = 22;
            this.button4.Text = "Choose Profile Picture...";
            this.button4.TextStringFormat = null;
            this.button4.TransparentColor = System.Drawing.Color.Empty;
            this.button4.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this.button4.UseCustomTextStringFormat = false;
            this.button4.UseUserDefinedColorForArrowMark = true;
            this.button4.UseUserDefinedColorForMenuButtonSeparator = true;
            this.button4.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(21, 80);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(390, 20);
            this.textBox3.TabIndex = 20;
            this.textBox3.Text = "[Country]";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(21, 57);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(390, 20);
            this.textBox2.TabIndex = 19;
            this.textBox2.Text = "[Your address 2nd line]";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(20, 34);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(390, 20);
            this.textBox1.TabIndex = 18;
            this.textBox1.Text = "[Your address 1st line]";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Address:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(467, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Profile 2:";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.button3.BorderColor = System.Drawing.Color.Black;
            this.button3.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this.button3.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this.button3.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this.button3.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this.button3.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this.button3.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this.button3.ContextMenuProperties.UseGradientPainting = true;
            this.button3.DefaultTheme = true;
            this.button3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.button3.DrawMenuButtonSeparator = true;
            this.button3.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this.button3.DropDownMenuItems = null;
            this.button3.EndColor = System.Drawing.Color.White;
            this.button3.IsRenderingTheme = true;
            this.button3.LinearGradientRenderingAngle = 90F;
            this.button3.Location = new System.Drawing.Point(590, 350);
            this.button3.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this.button3.MenuButtonSeparatorLineHeight = -1;
            this.button3.Name = "button3";
            this.button3.PushedEndColor = System.Drawing.Color.Silver;
            this.button3.PushedStartColor = System.Drawing.Color.White;
            this.button3.Size = new System.Drawing.Size(117, 36);
            this.button3.StartColor = System.Drawing.Color.Silver;
            this.button3.TabIndex = 14;
            this.button3.Text = "Cancel";
            this.button3.TextStringFormat = null;
            this.button3.TransparentColor = System.Drawing.Color.Empty;
            this.button3.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this.button3.UseCustomTextStringFormat = false;
            this.button3.UseUserDefinedColorForArrowMark = true;
            this.button3.UseUserDefinedColorForMenuButtonSeparator = true;
            this.button3.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.button2.BorderColor = System.Drawing.Color.Black;
            this.button2.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this.button2.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this.button2.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this.button2.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this.button2.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this.button2.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this.button2.ContextMenuProperties.UseGradientPainting = true;
            this.button2.DefaultTheme = true;
            this.button2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.button2.DrawMenuButtonSeparator = true;
            this.button2.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this.button2.DropDownMenuItems = null;
            this.button2.EndColor = System.Drawing.Color.White;
            this.button2.IsRenderingTheme = true;
            this.button2.LinearGradientRenderingAngle = 90F;
            this.button2.Location = new System.Drawing.Point(744, 349);
            this.button2.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this.button2.MenuButtonSeparatorLineHeight = -1;
            this.button2.Name = "button2";
            this.button2.PushedEndColor = System.Drawing.Color.Silver;
            this.button2.PushedStartColor = System.Drawing.Color.White;
            this.button2.Size = new System.Drawing.Size(112, 36);
            this.button2.StartColor = System.Drawing.Color.Silver;
            this.button2.TabIndex = 13;
            this.button2.Text = "Apply";
            this.button2.TextStringFormat = null;
            this.button2.TransparentColor = System.Drawing.Color.Empty;
            this.button2.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this.button2.UseCustomTextStringFormat = false;
            this.button2.UseUserDefinedColorForArrowMark = true;
            this.button2.UseUserDefinedColorForMenuButtonSeparator = true;
            this.button2.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.button1.BorderColor = System.Drawing.Color.Black;
            this.button1.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this.button1.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this.button1.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this.button1.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this.button1.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this.button1.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this.button1.ContextMenuProperties.UseGradientPainting = true;
            this.button1.DefaultTheme = true;
            this.button1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.button1.DrawMenuButtonSeparator = true;
            this.button1.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this.button1.DropDownMenuItems = null;
            this.button1.EndColor = System.Drawing.Color.White;
            this.button1.IsRenderingTheme = true;
            this.button1.LinearGradientRenderingAngle = 90F;
            this.button1.Location = new System.Drawing.Point(467, 350);
            this.button1.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this.button1.MenuButtonSeparatorLineHeight = -1;
            this.button1.Name = "button1";
            this.button1.PushedEndColor = System.Drawing.Color.Silver;
            this.button1.PushedStartColor = System.Drawing.Color.White;
            this.button1.Size = new System.Drawing.Size(117, 36);
            this.button1.StartColor = System.Drawing.Color.Silver;
            this.button1.TabIndex = 12;
            this.button1.Text = "OK";
            this.button1.TextStringFormat = null;
            this.button1.TransparentColor = System.Drawing.Color.Empty;
            this.button1.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this.button1.UseCustomTextStringFormat = false;
            this.button1.UseUserDefinedColorForArrowMark = true;
            this.button1.UseUserDefinedColorForMenuButtonSeparator = true;
            this.button1.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.checkBox5);
            this.groupBox1.Controls.Add(this.checkBox6);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Location = new System.Drawing.Point(23, 272);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(353, 95);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Options:";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(245, 62);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(102, 17);
            this.checkBox4.TabIndex = 10;
            this.checkBox4.Text = "Send paper mail";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(129, 62);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(79, 17);
            this.checkBox5.TabIndex = 9;
            this.checkBox5.Text = "Send Email";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(20, 62);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(77, 17);
            this.checkBox6.TabIndex = 8;
            this.checkBox6.Text = "Send SMS";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(245, 28);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(91, 17);
            this.checkBox3.TabIndex = 7;
            this.checkBox3.Text = "Check places";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(129, 28);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(101, 17);
            this.checkBox2.TabIndex = 6;
            this.checkBox2.Text = "Cache changes";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(20, 28);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(93, 17);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "Update Profile";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(468, 39);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(402, 20);
            this.dateTimePicker2.TabIndex = 2;
            // 
            // scrollerPanel1
            // 
            this.scrollerPanel1.BackColor = System.Drawing.Color.White;
            this.scrollerPanel1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.scrollerPanel1.BorderSize = 0;
            this.scrollerPanel1.BorderStyle = System.Windows.Forms.ButtonBorderStyle.Solid;
            this.scrollerPanel1.ContentHostingPanel = this.panel1;
            this.scrollerPanel1.Controls.Add(this.panel1);
            // 
            // 
            // 
            this.scrollerPanel1.HorizontalScrollBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.scrollerPanel1.HorizontalScrollBar.HorizontalScrollBarHeight = 24;
            this.scrollerPanel1.HorizontalScrollBar.IsDefaultScrollContextMenuEnabled = true;
            this.scrollerPanel1.HorizontalScrollBar.LargeChange = 433;
            this.scrollerPanel1.HorizontalScrollBar.Location = new System.Drawing.Point(0, 199);
            this.scrollerPanel1.HorizontalScrollBar.MaximumScrollRange = 902;
            this.scrollerPanel1.HorizontalScrollBar.Name = "";
            this.scrollerPanel1.HorizontalScrollBar.PaddingGap = 0;
            this.scrollerPanel1.HorizontalScrollBar.Position = 0D;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarNavigationButtonRenderer = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.BorderColor = System.Drawing.Color.White;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.BuiltInNavigationButtonImageDimension = new System.Drawing.Size(0, 0);
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ColorTheme = Binarymission.WinForms.Controls.ScrollBars.Enums.ColorTheme.GradientBrown;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlOnHoverBorderHighlightColor = System.Drawing.Color.Black;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStatePressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndNavigationButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndThumbFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientEndTrackFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartNavigationButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartThumbFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GradientStartTrackFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GripperColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.GripperColor2 = System.Drawing.Color.White;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalGripperImage = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftHot = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftNormal = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftPressed = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightHot = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightNormal = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightPressed = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageHot = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageNormal = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImagePressed = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.IsDrawingNavigationButtonArrowsEnabled = true;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonArrowColor = System.Drawing.Color.Maroon;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonsColor = System.Drawing.Color.Empty;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ShouldDrawGripperArtefact = true;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbFillColor = System.Drawing.Color.Empty;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMajorColor = System.Drawing.Color.Black;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMinorColor = System.Drawing.Color.White;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.TrackFillColor = System.Drawing.Color.Empty;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalGripperImage = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownHot = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownNormal = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownPressed = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpHot = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpNormal = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpPressed = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageHot = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageNormal = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImagePressed = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarThumbGripperRenderer = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarThumbRenderer = null;
            this.scrollerPanel1.HorizontalScrollBar.ScrollBarTrackRenderer = null;
            this.scrollerPanel1.HorizontalScrollBar.ShouldAutomaticallyPositionScroller = true;
            this.scrollerPanel1.HorizontalScrollBar.ShouldUseExtendedMenuControlForContextMenu = false;
            this.scrollerPanel1.HorizontalScrollBar.Size = new System.Drawing.Size(433, 24);
            this.scrollerPanel1.HorizontalScrollBar.SmallChange = 8;
            this.scrollerPanel1.HorizontalScrollBar.TabIndex = 2;
            this.scrollerPanel1.HorizontalScrollBar.VerticalScrollBarWidth = 24;
            this.scrollerPanel1.Location = new System.Drawing.Point(17, 47);
            this.scrollerPanel1.Name = "scrollerPanel1";
            this.scrollerPanel1.ScrollBarsOpaqueCornerColor = System.Drawing.SystemColors.Control;
            this.scrollerPanel1.ScrollSize = new System.Drawing.Size(8, 8);
            this.scrollerPanel1.Size = new System.Drawing.Size(457, 223);
            this.scrollerPanel1.TabIndex = 6;
            this.scrollerPanel1.Text = "scrollerPanel1";
            // 
            // 
            // 
            this.scrollerPanel1.VerticalScrollBar.Dock = System.Windows.Forms.DockStyle.Right;
            this.scrollerPanel1.VerticalScrollBar.HorizontalScrollBarHeight = 24;
            this.scrollerPanel1.VerticalScrollBar.IsDefaultScrollContextMenuEnabled = true;
            this.scrollerPanel1.VerticalScrollBar.LargeChange = 199;
            this.scrollerPanel1.VerticalScrollBar.Location = new System.Drawing.Point(433, 0);
            this.scrollerPanel1.VerticalScrollBar.MaximumScrollRange = 457;
            this.scrollerPanel1.VerticalScrollBar.Name = "";
            this.scrollerPanel1.VerticalScrollBar.PaddingGap = 0;
            this.scrollerPanel1.VerticalScrollBar.Position = 0D;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarNavigationButtonRenderer = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.BorderColor = System.Drawing.Color.White;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.BuiltInNavigationButtonImageDimension = new System.Drawing.Size(0, 0);
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.ColorTheme = Binarymission.WinForms.Controls.ScrollBars.Enums.ColorTheme.GradientBrown;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlOnHoverBorderHighlightColor = System.Drawing.Color.Black;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStateHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.ControlVisualStatePressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndNavigationButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndThumbFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientEndTrackFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartNavigationButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartThumbFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.GradientStartTrackFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.GripperColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.GripperColor2 = System.Drawing.Color.White;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalGripperImage = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftHot = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftNormal = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageLeftPressed = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightHot = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightNormal = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalScrollButtonImageRightPressed = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageHot = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImageNormal = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.HorizontalThumbBoxImagePressed = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.IsDrawingNavigationButtonArrowsEnabled = true;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonArrowColor = System.Drawing.Color.Maroon;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.NavigationButtonsColor = System.Drawing.Color.Empty;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.ShouldDrawGripperArtefact = true;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbFillColor = System.Drawing.Color.Empty;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMajorColor = System.Drawing.Color.Black;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.ThumbGripperMinorColor = System.Drawing.Color.White;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.TrackFillColor = System.Drawing.Color.Empty;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalGripperImage = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownHot = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownNormal = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageDownPressed = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpHot = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpNormal = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalScrollButtonImageUpPressed = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageHot = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImageNormal = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarRenderingConfigurator.VerticalThumbBoxImagePressed = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarThumbGripperRenderer = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarThumbRenderer = null;
            this.scrollerPanel1.VerticalScrollBar.ScrollBarTrackRenderer = null;
            this.scrollerPanel1.VerticalScrollBar.ShouldAutomaticallyPositionScroller = true;
            this.scrollerPanel1.VerticalScrollBar.ShouldUseExtendedMenuControlForContextMenu = false;
            this.scrollerPanel1.VerticalScrollBar.Size = new System.Drawing.Size(24, 199);
            this.scrollerPanel1.VerticalScrollBar.SmallChange = 8;
            this.scrollerPanel1.VerticalScrollBar.TabIndex = 0;
            this.scrollerPanel1.VerticalScrollBar.VerticalScrollBarWidth = 24;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnExit.BorderColor = System.Drawing.Color.Black;
            this.btnExit.ContextMenuProperties.MenuItemBackgroundColor = System.Drawing.SystemColors.Menu;
            this.btnExit.ContextMenuProperties.MenuItemBorderColor = System.Drawing.SystemColors.ControlText;
            this.btnExit.ContextMenuProperties.MenuItemRenderingStyle = Binarymission.WinForms.Controls.MenuControls.MenuClasses.MenuItemSelectionColorRenderingStyle.Default;
            this.btnExit.ContextMenuProperties.MenuItemSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(187)))), ((int)(((byte)(9)))));
            this.btnExit.ContextMenuProperties.MenuSideBarRenderingColor = System.Drawing.SystemColors.Control;
            this.btnExit.ContextMenuProperties.SmoothenSelectionColorRendering = true;
            this.btnExit.ContextMenuProperties.UseGradientPainting = true;
            this.btnExit.DefaultTheme = true;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnExit.DrawMenuButtonSeparator = true;
            this.btnExit.DropDownArrowMarkColor = System.Drawing.Color.RoyalBlue;
            this.btnExit.DropDownMenuItems = null;
            this.btnExit.EndColor = System.Drawing.Color.Silver;
            this.btnExit.IsRenderingTheme = false;
            this.btnExit.LinearGradientRenderingAngle = 90F;
            this.btnExit.Location = new System.Drawing.Point(369, 298);
            this.btnExit.MenuButtonSeparatorColor = System.Drawing.Color.Blue;
            this.btnExit.MenuButtonSeparatorLineHeight = -1;
            this.btnExit.Name = "btnExit";
            this.btnExit.PushedEndColor = System.Drawing.Color.White;
            this.btnExit.PushedStartColor = System.Drawing.Color.Silver;
            this.btnExit.Size = new System.Drawing.Size(106, 35);
            this.btnExit.StartColor = System.Drawing.Color.White;
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "E&xit";
            this.btnExit.TextStringFormat = null;
            this.btnExit.TransparentColor = System.Drawing.Color.Empty;
            this.btnExit.UseCustomDefinedPropertiesForRenderingContextMenu = false;
            this.btnExit.UseCustomTextStringFormat = false;
            this.btnExit.UseUserDefinedColorForArrowMark = true;
            this.btnExit.UseUserDefinedColorForMenuButtonSeparator = true;
            this.btnExit.XPTheme = Binarymission.WinForms.Controls.ButtonControls.SmartButtonSuite.XPThemes.Blue;
            this.btnExit.Click += new System.EventHandler(this.button6_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(503, 385);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.scrollerPanel1);
            this.Controls.Add(this.label1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.TitlebarText = "Binarymission ScrollablePanel .NET Control  Demo";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.scrollerPanel1.ResumeLayout(false);
            this.scrollerPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private SmartButton button3;
        private SmartButton button2;
        private SmartButton button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label3;
        private SmartButton button4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private SmartButton button5;
        private System.Windows.Forms.Label label5;
        private Binarymission.WinForms.Controls.CustomScrollerControls.ScrollerPanel scrollerPanel1;
        private SmartButton btnExit;

    }
}

